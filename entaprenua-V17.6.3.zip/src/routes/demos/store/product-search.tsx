import { Show } from "solid-js"
import { 
  ProductSearchProvider,
  ProductSearch,
  Search,
  useProductSearch,
  ProductImage,
  ProductName,
  ProductPrice,
} from "~/components/ui/product"
import { Flex } from "~/components/ui/flex"
import { Text } from "~/components/ui/text"
import { Paper } from "~/components/ui/paper"

const TEST_STORE_ID = "019c0000-0000-0000-0000-000000000010"

function SearchDemo() {
  const search = useProductSearch()
  
  return (
    <Paper class="p-6 border rounded-xl">
      <Text variant="h3" class="font-semibold mb-4">Product Search</Text>
      <Text variant="body2" class="text-muted-foreground mb-4">
        Type to search for products. Uses Kobalte Search primitives.
      </Text>
      
      <ProductSearch class="w-full max-w-md">
        <Search.Control>
          <Search.Input 
            placeholder="Search products..." 
            class="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
          />
        </Search.Control>
        <Search.Portal>
          <Search.Content class="z-50 w-full max-w-md mt-2 origin-top-left rounded-md border bg-popover p-4 text-popover-foreground shadow-lg">
            <Search.Listbox class="max-h-80 overflow-y-auto space-y-1">
              <Flex class="items-center gap-3">
                <ProductImage class="size-8 rounded object-cover" />
                <Text class="font-medium text-sm"><ProductName /></Text>
                <Text class="text-xs text-muted-foreground"><ProductPrice /></Text>
              </Flex>
            </Search.Listbox>
            <Search.NoResult class="px-4 py-2 text-sm text-muted-foreground">
              No products found
            </Search.NoResult>
          </Search.Content>
        </Search.Portal>
      </ProductSearch>
      
      <Show when={search.selectedProduct()}>
        <div class="mt-6 p-4 bg-muted rounded-lg">
          <Text variant="body2" class="text-muted-foreground mb-2">Selected Product:</Text>
          <Flex class="items-center gap-4">
            <Show when={search.selectedProduct()!.image}>
              <img 
                src={search.selectedProduct()!.image!} 
                alt={search.selectedProduct()!.name}
                class="size-16 rounded object-cover"
              />
            </Show>
            <div>
              <Text class="font-medium">{search.selectedProduct()!.name}</Text>
              <Text variant="body2" class="text-muted-foreground">
                ${search.selectedProduct()!.price ?? 'N/A'}
              </Text>
            </div>
          </Flex>
        </div>
      </Show>
    </Paper>
  )
}

export default function ProductSearchDemo() {
  return (
    <div class="min-h-screen bg-background p-8">
      <div class="max-w-2xl mx-auto">
        <Text variant="h1" class="font-bold text-3xl mb-8">Product Search Demo</Text>
        
        <ProductSearchProvider storeId={TEST_STORE_ID}>
          <SearchDemo />
        </ProductSearchProvider>
      </div>
    </div>
  )
}
