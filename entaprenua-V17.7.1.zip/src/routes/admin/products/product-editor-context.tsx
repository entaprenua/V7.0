import { createContext, useContext, ParentComponent, createSignal, createEffect, Accessor, createMemo } from "solid-js"
import { createStore, produce } from "solid-js/store"
import { mediaApi } from "~/lib/api/media"
import { productsApi } from "~/lib/api/products"
import type { Product, ProductDto, Media } from "~/lib/types"

export type ProductFormData = {
  name: string
  slug: string
  description: string
  price: string
  compareToPrice: string
  sku: string
  stockQuantity: number
  trackInventory: boolean
  allowBackorder: boolean
  lowStockThreshold: number
  outOfStockThreshold: number
  visibility: "public" | "private" | "draft"
}

/** Validation errors for product form fields */
export type ProductFormErrors = {
  name?: string
  price?: string
}

export type ProductMediaEntry = {
  id: string
  url: string
  type: string
  isNew?: boolean
  isDeleted?: boolean
  file?: File
}

type ProductEditorMode = "create" | "edit" | "quick-edit"

type ProductEditorContextValue = {
  mode: Accessor<ProductEditorMode>
  storeId: Accessor<string | undefined>
  isQuickEdit: Accessor<boolean>
  initialProduct: ProductDto | null | undefined
  
  // Form data
  formData: ProductFormData
  setFormData: (data: Partial<ProductFormData>) => void
  updateField: <K extends keyof ProductFormData>(field: K, value: ProductFormData[K]) => void
  
  // Media
  productImage: Accessor<{ url: string; type: string; file?: File; isNew?: boolean } | null>
  setProductImage: (image: { url: string; type: string; file?: File; isNew?: boolean } | null) => void
  
  productMedia: Record<string, ProductMediaEntry>
  setProductMedia: (media: Record<string, ProductMediaEntry> | ((prev: Record<string, ProductMediaEntry>) => Record<string, ProductMediaEntry>)) => void
  updateProductMedia: (id: string, updates: Partial<ProductMediaEntry>) => void
  
  // Metadata
  productMetadata: Record<string, { key: string; value: string }>
  setProductMetadata: (metadata: Record<string, { key: string; value: string }> | ((prev: Record<string, { key: string; value: string }>) => Record<string, { key: string; value: string }>)) => void
  updateProductMetadata: (id: string, updates: { key?: string; value?: string }) => void
  removeProductMetadata: (id: string) => void
  
  // Name existence check
  nameExistsWarning: Accessor<string | null>
  existingProductId: Accessor<string | null>
  checkNameExists: (name: string) => Promise<void>
  
  // Validation
  errors: ProductFormErrors
  validate: () => boolean
  
  // Loading states
  isSaving: Accessor<boolean>
  isUploading: Accessor<boolean>
  isDeleting: Accessor<boolean>
  
  // Actions
  save: () => Promise<Product | null>
  delete: () => Promise<boolean>
  
  // Reset
  reset: () => void
}

const ProductEditorContext = createContext<ProductEditorContextValue>()

const defaultFormData: ProductFormData = {
  name: "",
  slug: "",
  description: "",
  price: "",
  compareToPrice: "",
  sku: "",
  stockQuantity: 0,
  trackInventory: true,
  allowBackorder: false,
  lowStockThreshold: 10,
  outOfStockThreshold: 0,
  visibility: "draft",
}

type ProductEditorProviderProps = {
  storeId: string
  mode?: ProductEditorMode
  initialProduct?: ProductDto | null
  initialMedia?: Media[]
  initialMetadata?: Record<string, string>
  initialImage?: string | null
  onSaved?: (product: Product) => void
  onDeleted?: () => void
  isQuickEdit?: boolean
}

export const ProductEditorProvider: ParentComponent<ProductEditorProviderProps> = (props) => {
  const resolvedMode = () => props.mode ?? "edit"
  const isQuickEdit = () => props.isQuickEdit ?? false
  
  const [formData, setFormDataStore] = createStore<ProductFormData>({ ...defaultFormData })
  const [productImage, setProductImageState] = createSignal<{ url: string; type: string; file?: File; isNew?: boolean } | null>(null)
  const [productMedia, setProductMediaState] = createStore<Record<string, ProductMediaEntry>>({})
  const [productMetadata, setProductMetadataState] = createStore<Record<string, { key: string; value: string }>>({})
  
  const [nameExistsWarning, setNameExistsWarning] = createSignal<string | null>(null)
  const [existingProductId, setExistingProductId] = createSignal<string | null>(null)
  
  const [isSaving, setIsSaving] = createSignal(false)
  const [isUploading, setIsUploading] = createSignal(false)
  const [isDeleting, setIsDeleting] = createSignal(false)

  /** Form validation errors store */
  const [errors, setErrors] = createStore<ProductFormErrors>({})

  /**
   * Validates the product form before saving.
   * Checks required fields (name) and valid formats (price).
   * @returns true if form is valid, false otherwise
   */
  const validate = (): boolean => {
    const newErrors: ProductFormErrors = {}
    
    if (!formData.name.trim()) {
      newErrors.name = "Product name is required"
    }
    
    if (formData.price && isNaN(parseFloat(formData.price))) {
      newErrors.price = "Price must be a valid number"
    }
    
    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  // Initialize from props
  createEffect(() => {
    if (props.initialProduct) {
      setFormDataStore({
        name: props.initialProduct.name || "",
        slug: props.initialProduct.slug || "",
        description: props.initialProduct.description || "",
        price: props.initialProduct.price?.toString() || "",
        compareToPrice: props.initialProduct.compareToPrice?.toString() || "",
        sku: props.initialProduct.sku || "",
        stockQuantity: props.initialProduct.stockQuantity || 0,
        trackInventory: props.initialProduct.trackInventory ?? true,
        allowBackorder: props.initialProduct.allowBackorder ?? false,
        lowStockThreshold: props.initialProduct.lowStockThreshold ?? 10,
        outOfStockThreshold: props.initialProduct.outOfStockThreshold ?? 0,
        visibility: (props.initialProduct.visibility as "public" | "private" | "draft") || "draft",
      })
      
      // Convert flat metadata to structured format (id -> {key, value})
      const metadataSource = props.initialMetadata || props.initialProduct?.metadata || {}
      const metadataEntries: Record<string, { key: string; value: string }> = {}
      Object.entries(metadataSource).forEach(([key, value], index) => {
        metadataEntries[`meta_${index}`] = { key, value }
      })
      setProductMetadataState(metadataEntries)
      
      if (props.initialImage) {
        setProductImageState({ url: props.initialImage, type: "image", isNew: false })
      }
    }
    
    // Initialize media - guard against non-array (e.g., when API returns null)
    const initialMedia = props.initialMedia || props.initialProduct?.media || []
    const mediaEntries: Record<string, ProductMediaEntry> = {}
    if (Array.isArray(initialMedia)) {
      initialMedia.forEach((item) => {
        mediaEntries[item.id] = { id: item.id, url: item.url, type: item.type, isNew: false, isDeleted: false }
      })
    }
    setProductMediaState(mediaEntries)
  })

  const updateField = <K extends keyof ProductFormData>(field: K, value: ProductFormData[K]) => {
    setFormDataStore(field, value)
    
    // Clear error when user starts typing
    if (field === "name" && errors.name) {
      setErrors("name", undefined)
    }
    if (field === "price" && errors.price) {
      setErrors("price", undefined)
    }
    
    // Check if name already exists (only in create mode)
    if (field === "name" && resolvedMode() === "create" && props.storeId && value) {
      checkNameExists(value as string)
    }
  }

  const setFormData = (data: Partial<ProductFormData>) => {
    setFormDataStore(data)
  }

  const checkNameExists = async (name: string) => {
    if (!props.storeId || !name.trim()) return
    
    const result = await productsApi.existsByName(props.storeId, name.trim())
    if (result.exists && result.id) {
      // In edit mode, ignore if it's the same product
      if (resolvedMode() === "edit" && result.id === props.initialProduct?.id) {
        setNameExistsWarning(null)
        setExistingProductId(null)
        return
      }
      setNameExistsWarning(`A product named "${name}" already exists. Saving will update it.`)
      setExistingProductId(result.id)
    } else {
      setNameExistsWarning(null)
      setExistingProductId(null)
    }
  }

  // Get files that need to be uploaded
  const getNewMediaFiles = (): { id: string; file: File }[] => {
    return Object.values(productMedia)
      .filter(m => m.isNew && m.file && !m.isDeleted)
      .map(m => ({ id: m.id, file: m.file! }))
  }

  // Upload new media files
  const uploadNewMedia = async (): Promise<Record<string, string>> => {
    const files = getNewMediaFiles()
    if (!files || files.length === 0) return {}

    setIsUploading(true)
    try {
      const response = await mediaApi.upload(
        files.map(f => f.file),
        props.storeId
      )
      
      if (response.urls && response.urls.length > 0) {
        const idToUrlMap: Record<string, string> = {}
        files.forEach((f, index) => {
          idToUrlMap[f.id] = response.urls[index]
        })
        
        // Update media entries with uploaded URLs
        Object.entries(idToUrlMap).forEach(([id, url]) => {
          if (productMedia[id]) {
            setProductMediaState(id, "url", url)
            setProductMediaState(id, "file", undefined)
          }
        })
        
        return idToUrlMap
      }
    } catch (error) {
      console.error("Failed to upload media:", error)
    } finally {
      setIsUploading(false)
    }
    return {}
  }

  // Upload product image
  const uploadProductImage = async (): Promise<string | null> => {
    const img = productImage()
    if (!img) return null
    
    if (!img.isNew) return img.url
    if (!img.file) return img.url

    setIsUploading(true)
    try {
      const response = await mediaApi.upload([img.file], props.storeId)
      if (response.urls && response.urls.length > 0) {
        const serverUrl = response.urls[0]
        setProductImageState({ url: serverUrl, type: img.type, isNew: false })
        return serverUrl
      }
    } catch (error) {
      console.error("Failed to upload product image:", error)
    } finally {
      setIsUploading(false)
    }
    return img.url
  }

  // Build media map for save
  const buildMediaMap = (): Record<string, string> => {
    const mediaMap: Record<string, string> = {}
    Object.values(productMedia).forEach((entry) => {
      if (!entry.isDeleted) {
        const key = entry.isNew ? `new-${entry.id}` : entry.id
        mediaMap[key] = entry.url
      }
    })
    return mediaMap
  }

  // Build metadata map for save (convert structured format back to flat)
  const buildMetadataMap = (): Record<string, string> => {
    const metadataMap: Record<string, string> = {}
    Object.values(productMetadata).forEach(({ key, value }) => {
      if (key && value) {
        metadataMap[key] = value
      }
    })
    return metadataMap
  }

  /**
   * Main save function for product create/edit.
   * Uses upsert pattern - always calls productsApi.create() with optional id.
   * - If id is provided, it updates existing product
   * - If no id, creates new product
   * Handles both quick edit (basic fields only) and full edit (with media/metadata).
   */
  const save = async (): Promise<Product | null> => {
    // Validate form before saving
    if (!validate()) {
      return null
    }

    // Confirm if product name already exists (only in create mode)
    if (resolvedMode() === "create" && nameExistsWarning()) {
      if (!confirm(`A product with this name already exists. Do you want to override it?`)) {
        return null
      }
    }

    setIsSaving(true)
    try {
      // Build product data based on mode
      let productData: Partial<Product>
      
      // Quick edit mode - only basic fields
      // Note: include trackInventory to prevent status resetting to "not tracked"
      if (isQuickEdit()) {
        productData = {
          storeId: props.storeId,
          ...(props.initialProduct?.id ? { id: props.initialProduct.id } : {}),
          name: formData.name,
          slug: formData.slug || null,
          sku: formData.sku || null,
          price: formData.price || null,
          compareToPrice: formData.compareToPrice || null,
          visibility: formData.visibility,
          stockQuantity: formData.stockQuantity,
          trackInventory: formData.trackInventory,
        }
      } else {
        // Full edit mode - upload media first
        await uploadNewMedia()
        const uploadedImage = await uploadProductImage()

        productData = {
          storeId: props.storeId,
          ...(props.initialProduct?.id ? { id: props.initialProduct.id } : {}),
          ...(resolvedMode() === "create" && existingProductId() ? { id: existingProductId()! } : {}),
          name: formData.name,
          slug: formData.slug || null,
          sku: formData.sku || null,
          description: formData.description || null,
          price: formData.price || null,
          compareToPrice: formData.compareToPrice || null,
          stockQuantity: formData.stockQuantity,
          trackInventory: formData.trackInventory,
          allowBackorder: formData.allowBackorder,
          lowStockThreshold: formData.lowStockThreshold,
          outOfStockThreshold: formData.outOfStockThreshold,
          visibility: formData.visibility,
          metadata: buildMetadataMap(),
          media: buildMediaMap(),
          image: uploadedImage,
        }
      }

      // Use create API for both create and edit (upsert)
      // API may return product directly or wrapped in ApiResponse - handle both
      const response = await productsApi.create(props.storeId, productData) as Product | { data: Product }
      const result = (response as Product).id ? response as Product : (response as { data: Product }).data

      if (result) {
        props.onSaved?.(result)
      }
      return result
    } catch (error) {
      console.error("Failed to save product:", error)
      return null
    } finally {
      setIsSaving(false)
    }
  }

  // Delete function
  const deleteProduct = async (): Promise<boolean> => {
    if (!props.initialProduct?.id) return false
    if (!confirm("Are you sure you want to delete this product? This action cannot be undone.")) {
      return false
    }

    setIsDeleting(true)
    try {
      await productsApi.delete(props.storeId, props.initialProduct.id)
      props.onDeleted?.()
      return true
    } catch (error) {
      console.error("Failed to delete product:", error)
      return false
    } finally {
      setIsDeleting(false)
    }
  }

  // Reset form
  const reset = () => {
    setFormDataStore({ ...defaultFormData })
    setProductImageState(null)
    setProductMediaState({})
    setProductMetadataState({})
    setNameExistsWarning(null)
    setExistingProductId(null)
    setErrors({})
  }

  // Update individual media entry
  const updateProductMedia = (id: string, updates: Partial<ProductMediaEntry>) => {
    setProductMediaState(id, updates as ProductMediaEntry)
  }

  // Update individual metadata entry (also creates new entry if id doesn't exist)
  const updateProductMetadata = (id: string, updates: { key?: string; value?: string }) => {
    const current = productMetadata[id]
    if (current) {
      setProductMetadataState(id, { ...current, ...updates })
    } else {
      // Add new entry if it doesn't exist
      setProductMetadataState(id, { key: "", value: "", ...updates })
    }
  }

  // Remove metadata entry
  const removeProductMetadata = (id: string) => {
    setProductMetadataState((prev) => {
      const { [id]: _, ...rest } = prev
      return rest
    })
  }

  const value: ProductEditorContextValue = {
    mode: resolvedMode,
    storeId: () => props.storeId,
    isQuickEdit,
    initialProduct: props.initialProduct,
    formData,
    setFormData,
    updateField,
    productImage,
    setProductImage: setProductImageState,
    productMedia,
    setProductMedia: setProductMediaState,
    updateProductMedia,
    productMetadata,
    setProductMetadata: setProductMetadataState,
    updateProductMetadata,
    removeProductMetadata,
    nameExistsWarning,
    existingProductId,
    checkNameExists,
    errors,
    validate,
    isSaving,
    isUploading,
    isDeleting,
    save,
    delete: deleteProduct,
    reset,
  }

  return (
    <ProductEditorContext.Provider value={value}>
      {props.children}
    </ProductEditorContext.Provider>
  )
}

export const useProductEditor = () => {
  const context = useContext(ProductEditorContext)
  if (!context) {
    throw new Error("useProductEditor must be used within a ProductEditorProvider")
  }
  return context
}
