# Product Metadata/Media Atomic Operations Refactoring Plan

## Goal
Refactor Product save operations to use atomic add/remove patterns, matching Category's implementation.

## Problem
Current Product implementation uses magic "deleted" marker in maps:
```kotlin
// Current - Fragile pattern
if (value == "deleted") {
    toBeDeletedMetadata.add(name)
}
```

## Solution
Adopt Category's atomic pattern:
```kotlin
// Target - Explicit operations
val metadataToAdd = input.addMetadata?.mapNotNull { ... } ?: emptyList()
val metadataToRemove = input.removeMetadata?.mapNotNull { ... } ?: emptyList()
```

---

## Backend Changes

### 1. Update ProductInput DTO (`ProductDto.kt`)

Add atomic operation fields:

```kotlin
@Serializable
data class ProductInput(
    // ... existing fields ...
    
    // Metadata atomic operations
    val addMetadata: List<MetadataInput>? = null,
    val removeMetadata: List<String>? = null,
    
    // Media atomic operations  
    val addMedia: List<MediaInput>? = null,
    val removeMedia: List<String>? = null,
)

@Serializable
data class MetadataInput(
    val key: String,
    val value: String
)

@Serializable
data class MediaInput(
    val id: String? = null,  // Optional client-generated ID
    val url: String
)
```

### 2. Update ProductSaveServiceImpl

Change parsing logic:

**Current:**
```kotlin
val metadataMap: Map<String, String> = incoming.metadata ?: mapOf()
// ... iterate with "deleted" check
```

**Target:**
```kotlin
// Parse atomic metadata operations
val addMetadata = incoming.addMetadata?.map { MetadataInput(it.key, it.value) } ?: emptyList()
val removeMetadata = incoming.removeMetadata ?: emptyList()

// Parse atomic media operations
val addMedia = incoming.addMedia?.map { 
    MediaInput(it.id, it.url) 
} ?: emptyList()
val removeMedia = incoming.removeMedia ?: emptyList()

// Execute atomically
for (meta in addMetadata) {
    repository.addMetadata(productId, meta)
}
for (key in removeMetadata) {
    repository.removeMetadata(productId, key)
}
// Same for media
```

### 3. Update ProductRepository

Add new methods:
- `addMetadata(productId, key, value)`
- `removeMetadata(productId, key)`
- `addMedia(productId, id, url)`
- `removeMedia(productId, mediaId)`

---

## Frontend Changes

### 1. Update ProductEditorContext (`product-editor-context.tsx`)

Change `buildMetadataMap()` and `buildMediaMap()` to send atomic operations:

```typescript
// New types for atomic operations
type MetadataOperation = { add?: { key: string; value: string }[]; remove?: string[] }
type MediaOperation = { add?: { id: string; url: string }[]; remove?: string[] }

// Instead of building maps, build operations
const buildMetadataOperations = (): MetadataOperation => {
  const toAdd: { key: string; value: string }[] = []
  const toRemove: string[] = []
  
  Object.values(productMetadata).forEach(({ key, value }) => {
    if (key && value) {
      toAdd.push({ key, value })
    }
  })
  
  return { add: toAdd, remove: toRemove }
}
```

### 2. Update Save Payload

Send atomic operations instead of maps:

```typescript
const savePayload = {
  // ... other fields ...
  addMetadata: operations.add,
  removeMetadata: operations.remove,
  addMedia: mediaOperations.add,
  removeMedia: mediaOperations.remove,
}
```

---

## Files to Modify

### Backend (Kotlin)
| File | Changes |
|------|---------|
| `runtime/src/main/kotlin/com/entaprenua/store/dtos/ProductDto.kt` | Add ProductInput, MetadataInput, MediaInput |
| `runtime/src/main/kotlin/com/entaprenua/store/impl/ProductSaveServiceImpl.kt` | Parse atomic operations |
| `runtime/src/main/kotlin/com/entaprenua/store/repositories/ProductRepository.kt` | Add CRUD methods for metadata/media |

### Frontend (TypeScript)
| File | Changes |
|------|---------|
| `src/routes/admin/products/product-editor-context.tsx` | Change to atomic operations |

---

## Backward Compatibility

Option A: Support both patterns (old maps + new operations)
- Complex, increases technical debt

Option B: Remove old metadata/media fields from ProductInput
- Breaking change
- Requires frontend update (already being done)
- Cleaner solution

**Recommendation:** Option B - Remove old fields, use atomic operations only.

---

## Migration Steps

1. Update ProductInput DTO with new fields
2. Update ProductSaveServiceImpl to parse new fields
3. Update ProductRepository with new methods
4. Update frontend to send atomic operations
5. Test create/update/delete scenarios

---

## Test Scenarios

1. **Create product with metadata/media** - Should add correctly
2. **Update product - add new metadata** - Should add without removing existing
3. **Update product - remove metadata** - Should remove without affecting others
4. **Update product - update existing metadata** - Should replace value
5. **Update product - add new media** - Should add without removing existing
6. **Update product - remove media** - Should remove by ID
7. **Mixed operations** - Add and remove in same save

---

## Implementation Order

1. Backend: Update DTO (ProductInput)
2. Backend: Update ProductSaveServiceImpl parsing
3. Backend: Add repository methods
4. Frontend: Update context to send operations
5. Test all scenarios
