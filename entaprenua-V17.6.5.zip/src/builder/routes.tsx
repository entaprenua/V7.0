import { lazy, Show, For, createEffect, ErrorBoundary, on} from "solid-js";
import { Route } from "@solidjs/router";
import { lazyComponent } from "~/lib/utils";
import { useBuilder } from "./builder-provider";
import { storesApi } from "~/lib/api";

const Canvas = lazyComponent(import("./canvas/index"));

function BuilderRoutes(props: { children?: any }) {
  const builder = useBuilder() 
  const routesList = () => builder?.routes ?? [];
  const getPageSlug = (slug: string) => {
    const baseSlug = slug === '/' || slug === '' ? '/' : slug;
    return `${baseSlug}`;
  };
  
  /* TODO: add nesting */
  return (
    <ErrorBoundary
      fallback={(error, reset) => {
        console.error("routes error:", error);
        return (
          <div class="flex items-center justify-center p-8">
            <p class="text-destructive">Failed to load routes</p>
          </div>
        );
      }}
    >
     <Route path={["/builder/template/:templateId", "/builder/:storeId"]}>
      <Show when={builder.storeDetails}>
       <For each={routesList()}>
          {(route: any) => {
            return (
              <Route
               path={getPageSlug(route?.slug || '/')}
               component={() => <Canvas name={route?.pageName} {...props}/>}
            />
          )}}
        </For>
      </Show>
      <Route path="*" component={() => {
          return (
            <div class="h-screen min-h-30">
               Page not found
            </div>
        ) 
     }}/>
    </Route> 
   </ErrorBoundary>
  );
}

export default BuilderRoutes;
