import { createSignal, For, Show } from "solid-js";
import { Button } from "~/components/ui/button";
import { IconButton } from "~/components/ui/icon-button";
import { Input } from "~/components/ui/input";
import { Label } from "~/components/ui/label";
import { SidebarTrigger } from "~/components/ui/sidebar";
import { useBuilder } from "~";
import { storesApi } from "~/lib/api/stores";
import { showToast } from "~/components/ui/toast";
import PlusIcon from "lucide-solid/icons/plus";
import Trash2Icon from "lucide-solid/icons/trash-2";
import HomeIcon from "lucide-solid/icons/home";
import FileIcon from "lucide-solid/icons/file-text";
import CheckIcon from "lucide-solid/icons/check";
import MenuIcon from "lucide-solid/icons/menu";
import { ReactiveElement } from "~"
import { elementToObject} from "~/view-models"
import { A, useNavigate, useParams } from "@solidjs/router"
/**
 * Pages Sidebar Trigger Button
 * Use this in the toolbar to open the sidebar (with menu icon)
 */
export function PagesSidebarTrigger() {
  return (
    <SidebarTrigger asChild>
      <IconButton variant="ghost" size="sm">
        <MenuIcon />
      </IconButton>
    </SidebarTrigger>
  );
}

/**
 * Pages Sidebar Content
 * The actual content shown inside the sidebar
 */
export function PagesSidebarContent() {
  const builder = useBuilder();
  const navigate = useNavigate()
  const [showAddDialog, setShowAddDialog] = createSignal(false);
  const [newPageName, setNewPageName] = createSignal("");
  const [newPageSlug, setNewPageSlug] = createSignal("");
  const [isCreating, setIsCreating] = createSignal(false);
   
  const routes = () => builder?.routes ?? [];
  const link = (slug) => `builder/${builder?.storeDetails?.id}/${slug}`
  const generateSlug = (name: string) => {
    return name
      .toLowerCase()
      .trim()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-+|-+$/g, "");
  };

  const handleNameChange = (value: string) => {
    setNewPageName(value);
    setNewPageSlug(generateSlug(value));
  };

  const handleAddPage = async () => {
    const name = newPageName().trim();
    const slug = newPageSlug().trim() || generateSlug(name);
    const storeId = builder?.storeDetails?.id;

    if (!name || !storeId) {
      showToast({ title: "Error", description: "Page name is required", variant: "error" });
      return;
    }

    // Default box element for new page
    const defaultElement = new ReactiveElement("box")
    defaultElement.tailwind = "min-h-screen p-4"
    setIsCreating(true);
    try {
      // API returns unwrapped data (client automatically unwraps ApiResponse)
      const result = await storesApi.createPage(storeId, { name, slug, element: elementToObject(defaultElement)});
      
      if (result) {
        builder.setRoutes([...routes(), { pageName: name, slug: `/${slug}` }]);
        builder.setCurrentEditingPage(slug);
        
        setNewPageName("");
        setNewPageSlug("");
        setShowAddDialog(false);
        
        showToast({ title: "Success", description: `Page "${name}" created`, variant: "success" });
      }
    } catch (error) {
      console.log("Errror: ", error) 
      showToast({ title: "Error", description: "Failed to create page", variant: "error" });
    } finally {
      setIsCreating(false);
    }
  };

  const handleDeletePage = async (pageName: string, e: Event) => {
    e.stopPropagation();
    const storeId = builder?.storeDetails?.id;
    
    if (!storeId || pageName.toLowerCase() === "home") return;

    if (!confirm(`Delete page "${pageName}"?`)) return;

    try {
      await storesApi.deletePage(storeId, pageName);
      
      const newRoutes = routes().filter(r => r.pageName !== pageName);
      builder.setRoutes(newRoutes);
      
      if (builder.currentEditingPage === pageName) {
        builder.setCurrentEditingPage("home");
      }
      
      showToast({ title: "Success", description: `Page "${pageName}" deleted`, variant: "success" });
    } catch (error) {
      showToast({ title: "Error", description: "Failed to delete page", variant: "error" });
    }
  };

  const handleSelectPage = (slug: string) => {
    builder.setCurrentEditingPage(slug);
  };

  return (
    <div class="flex flex-col h-full">
      <div class="flex items-center justify-between p-4 border-b">
        <h2 class="text-lg font-semibold">Pages</h2>
        <Button
          variant="ghost"
          size="sm"
          class="gap-1"
          onClick={() => setShowAddDialog(true)}
        >
          <PlusIcon class="w-4 h-4" />
          Add
        </Button>
      </div>

      <Show when={showAddDialog()}>
        <div class="p-4 border-b space-y-3">
          <div class="space-y-2">
            <Label>Page Name</Label>
            <Input
              placeholder="e.g., About Us"
              value={newPageName()}
              onInput={(e) => handleNameChange(e.currentTarget.value)}
            />
          </div>
          <div class="space-y-2">
            <Label>URL Slug</Label>
            <Input
              placeholder="e.g., about-us"
              value={newPageSlug()}
              onInput={(e) => setNewPageSlug(e.currentTarget.value)}
            />
          </div>
          <div class="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              class="flex-1"
              onClick={() => setShowAddDialog(false)}
            >
              Cancel
            </Button>
            <Button
              size="sm"
              class="flex-1"
              onClick={handleAddPage}
              disabled={!newPageName().trim() || isCreating()}
            >
              {isCreating() ? "Creating..." : "Create"}
            </Button>
          </div>
        </div>
      </Show>

      <div class="flex-1 overflow-y-auto p-2">
        <For each={routes()}>
          {(route) => {
            const isHome = route.pageName.toLowerCase() === "home" || route.slug === "/" || route.slug === "/home";
            const isActive = builder.currentEditingPage === route.pageName || 
              builder.currentEditingPage === route.slug?.replace("/", "") ||
              builder.currentEditingPage === route.slug;

            return (
              <div
                class={`flex items-center gap-2 px-3 py-2 cursor-pointer hover:bg-accent rounded-md mb-1 ${
                  isActive ? "bg-accent" : ""
                }`}
                onClick={() => navigate(link(route.slug))} 
                //onClick={() => handleSelectPage(route.slug?.replace("/", "") || route.pageName)}
                 
              >
                <Show when={isHome} fallback={<FileIcon class="w-4 h-4 text-muted-foreground" />}>
                  <HomeIcon class="w-4 h-4 text-muted-foreground" />
                </Show>
                <span class="flex-1">{route.pageName}</span>
                <Show when={isActive}>
                  <CheckIcon class="w-4 h-4 text-green-500" />
                </Show>
                <Show when={!isHome}>
                  <Button
                    variant="ghost"
                    size="icon"
                    class="h-6 w-6 opacity-50 hover:opacity-100"
                    onClick={(e) => handleDeletePage(route.pageName, e)}
                  >
                    <Trash2Icon class="w-3 h-3" />
                  </Button>
                </Show>
              </div>
            );
          }}
        </For>
      </div>
    </div>
  );
}
