# Mock URL Bar Implementation Plan

## Overview

Implement a mock URL bar at the top of the builder toolbar that shows the "preview" URL of the current page being edited. This is internal routing - no actual URL changes when switching pages.

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│  🌍 storeName/home                        [Preview] [Publish] │  ← Mock URL Bar
├─────────────────────────────────────────────────────────────┤
│  [Logo] [Pages ▼] [Theme] [Settings]           [Device] [User]│  ← Main Toolbar
├─────────────────────────────────────────────────────────────┤
│  [Pages Panel / Layers / Components]                        │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│                    BUILDER CANVAS                           │
│                    (page-container renders current page)     │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

## URL Formula

```
Mock URL = domain + "/" + currentEditingPage

Where:
- domain = store.domainName (if present) OR sanitize(store.name)
- currentEditingPage = page slug (e.g., "home", "about", "contact")

Examples:
- With domain: "mystore.com" + "home" = "mystore.com/home"
- Without domain: "my-store" + "about" = "my-store/about"
```

## Implementation Steps

### Step 1: Add Internal Page State to BuilderProvider
**File: `src/builder/builder-provider.tsx`**

- Add `currentEditingPage: Signal<string>` - tracks current page slug being edited
- Add `setCurrentEditingPage(pageSlug: string)` method
- Initialize with default page ("home" or first page in routes)

### Step 2: Create Mock URL Bar Component
**File: `src/builder/toolbar/mock-url-bar.tsx` (NEW)**

- Accepts no props (reads from builder context)
- Computes mock URL from:
  - `builder.storeDetails.domainName` OR sanitized `builder.storeDetails.name`
  - `builder.currentEditingPage`
- Renders:
  - Globe icon + mock URL text
  - Preview button (toggle preview mode)
  - Publish button (publish store)

### Step 3: Add Mock URL Bar to Toolbar
**File: `src/builder/toolbar/toolbar.tsx` or `src/builder/toolbar/index.tsx`**

- Import and add `<MockUrlBar />` at the top of toolbar layout
- Ensure it spans full width

### Step 4: Update Pages Panel to Set Current Page
**File: `src/builder/panels/pages-panel.tsx`** (or relevant file)

- When user clicks a page in the list:
  - Call `builder.setCurrentEditingPage(pageSlug)`
  - This triggers the page-container to load the corresponding page

### Step 5: Update RootPage to Use Internal State
**File: `src/builder/canvas/pages/root-page.tsx`**

- Instead of relying on `props.children` (router):
  - Read `builder.currentEditingPage`
  - Fetch the page data for that page
  - Load into page-container
- Remove dependency on router children

### Step 6: Simplify Routes
**File: `src/builder/routes.tsx`**

- Remove all page-specific routes (`/builder/home`, `/builder/about`, etc.)
- Keep only the entry route: `/builder?storeId=xxx`
- Or remove entirely since FileRoutes handles `/builder`

### Step 7: Clean Up
- Remove debug console logs added during testing
- Verify all pieces work together

## Helper Functions

### Sanitize Store Name to Slug
```typescript
function sanitizeSlug(name: string): string {
  return name
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');
}
```

## Files to Modify

| File | Action |
|------|--------|
| `src/builder/builder-provider.tsx` | Add currentEditingPage signal |
| `src/builder/toolbar/mock-url-bar.tsx` | **CREATE** - New component |
| `src/builder/toolbar/toolbar.tsx` | Add MockUrlBar to layout |
| `src/builder/panels/pages-panel.tsx` | Update to set currentEditingPage |
| `src/builder/canvas/pages/root-page.tsx` | Use internal page state |
| `src/builder/routes.tsx` | Simplify routes |

## Testing Checklist

- [ ] Mock URL bar displays correctly in toolbar
- [ ] Mock URL shows domainName if present, otherwise sanitized name
- [ ] Mock URL updates when switching pages
- [ ] Preview button toggles preview mode
- [ ] Pages panel click updates currentEditingPage
- [ ] Page container loads correct page based on currentEditingPage
- [ ] No console errors on page switch
- [ ] Refresh works (stays on same internal page)
