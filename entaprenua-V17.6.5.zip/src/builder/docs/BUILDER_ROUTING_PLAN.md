# Builder Routing Plan (Final)

## Overview
Unified routing for the visual website builder using query parameters.

## URL Structure

```
/builder                  -> Error: requires storeId or templateId
/builder?storeId=xxx     -> Edit existing store
/builder?templateId=xxx  -> Preview/edit template
```

## Why Query Params?

For a **visual builder**, query parameters are superior to path-based routing:

1. **Single Entry Point** - One component handles all builder functionality
2. **Shared State Management** - Data loading, error handling, cleanup all in one place
3. **Flexible URL State** - Can easily add parameters like `?storeId=xxx&page=home&selected=header`
4. **Maintainability** - Avoids duplicating loading/error/cleanup logic across multiple routes
5. **Industry Pattern** - Similar to Shopify, WordPress, Wix builders

## Files

### Routes
- `src/lib/utils/routes.ts` - Route definitions

### Builder Route
- `src/routes/builder/index.tsx` - Unified builder page component
- `src/builder/home.tsx` - Builder UI component
- `src/builder/builder-provider.tsx` - Builder state

### Templates
- `src/routes/templates/index.tsx` - Preview navigates to builder
- `src/routes/templates/[id].tsx` - Live Preview navigates to builder

### Stores  
- `src/routes/stores/index.tsx` - Build navigates to builder
- `src/routes/stores/[id]/index.tsx` - Build navigates to builder
- `src/routes/stores/[id]/build.tsx` - Open Builder navigates to builder

## Flow

1. User clicks "Edit" or "Preview"
2. Navigate to `/builder?storeId=xxx` or `/builder?templateId=xxx`
3. `BuilderPageContent` mounts and:
   - Reads `storeId` or `templateId` from query params
   - Fetches data from API
   - Sets builder state (`storeDetails`, `isTemplatePreview`, `preview`)
   - Loads router configuration
4. `BuilderHome` renders the builder UI
