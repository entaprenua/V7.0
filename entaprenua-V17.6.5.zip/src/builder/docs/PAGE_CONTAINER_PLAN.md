# Builder Layout with Page Container - Implementation Plan

## Overview

Refactor the builder to use a layout pattern where:
- `RootPage` is the main layout with base UI elements
- A `child-pages-container` element serves as the outlet
- Pages are loaded as ReactiveElements inside the container
- Pages are fully editable - just like any other ReactiveElement

## Architecture

```
URL: /builder/[storeId]     → RootPage + child-pages-container shows "home" element
URL: /builder/[storeId]/contacts → RootPage + child-pages-container shows "contacts" element
```

### How It Works

1. **RootPage** (always rendered as layout)
   - Renders base UI from `builder.content`
   - Contains `child-pages-container` element
   - Container displays the current page element

2. **Current Page Element**
   - Loaded into container when route changes
   - It's a **ReactiveElement** - selectable, editable, draggable
   - Just like any other element in the tree

3. **Routes** - Flat, lazy-loaded

## Implementation Steps

### Step 1: Add `child-pages-container` to Component Registry
**File: `src/builder/utils/component-registry.ts`**

- Add special component that renders `{props.children}` (the outlet)
- Register in `componentMap`

### Step 2: Auto-create Container in Builder
**File: `src/builder/builder-provider.tsx`**

- Add `currentPageElement` signal
- Add `child-pages-container` element to `builder.content` by default

### Step 3: Update Renderer to Handle Container
**File: `src/builder/canvas/renderer/index.tsx`**

- When element is `child-pages-container`:
  - Render `{props.children}` (current routed page)
  - Also render any user-added child elements (for builder preview)

### Step 4: Add Helper to Find Container Element
**File: `src/builder/builder-provider.tsx`**

- Add `getContainerElement()` method
- Finds the `child-pages-container` element in the tree

### Step 5: Refactor RootPage as Layout
**File: `src/builder/canvas/pages/root-page.tsx`**

- Fetch root page data
- Render base UI via BuilderComponentChildren
- Container automatically renders {props.children}

### Step 6: Page Component Updates Builder
**File: `src/builder/canvas/pages/page.tsx`**

- Lazy-loaded when route accessed
- Fetches page data → creates ReactiveElement
- Sets `builder.currentPageElement = pageElement`
- Doesn't render - RootPage handles display

### Step 7: Update Routes
**File: `src/builder/routes.tsx`**

- Keep flat structure, lazy-load Page component
- Page updates builder context

## Data Flow

```
User clicks "/contacts" in builder
         ↓
Route loads Page component (/contacts)
         ↓
Page fetches contacts page data → creates ReactiveElement
         ↓
builder.currentPageElement = contactsPageElement
         ↓
RootPage's container detects change → appends element to container
         ↓
contactsPageElement renders as ReactiveElement (editable!)
```

## Files to Modify

1. `src/builder/utils/component-registry.ts` - Add child-pages-container
2. `src/builder/builder-provider.tsx` - Add currentPageElement, auto-create container
3. `src/builder/canvas/renderer/index.tsx` - Handle container rendering
4. `src/builder/canvas/pages/root-page.tsx` - Refactor as layout
5. `src/builder/canvas/pages/page.tsx` - Update to set currentPageElement

## Key Concepts

- **Layout Pattern**: RootPage always shown, pages render inside container
- **Page as Element**: Pages are ReactiveElements, fully editable
- **Lazy Loading**: Each page loads on-demand when route accessed
- **Builder Preview**: Container shows both user-added elements + current page
