# Builder Refactoring Implementation Plan

## Overview

This document outlines the refactoring of the builder module to consolidate component registries and clarify naming conventions.

## Current Problems

1. **Two registries with same name** - Confusing duplication
   - `builder/components/registry.ts` (simple: `{ box: Box }`)
   - `builder/utils/component-registry.ts` (rich: `{ box: { component, attributes, contextuals } }`)

2. **Misleading folder names** - `builder/components/` contains renderer logic, not just components

3. **Split concerns** - Rendering logic scattered across multiple folders

## Target Architecture

```
builder/
├── utils/
│   ├── component-registry.ts   # SINGLE SOURCE OF TRUTH
│   │   ├── componentRegistry   # Rich: { box: { component, attributes, contextuals } }
│   │   ├── componentMap       # Simple: { box: Box, button: Button }
│   │   ├── componentMeta     # { box: { label, description, category } }
│   │   └── COMPONENT_CATEGORIES
│   └── ...
│
├── canvas/
│   ├── renderer/               # ELEMENT RENDERER
│   │   ├── index.tsx         # BuilderComponent (recursive)
│   │   ├── types.ts          # ComponentElement, ComponentProps
│   │   └── computeProps.ts   # Props computation for builder mode
│   │
│   ├── pages/
│   │   ├── page.tsx
│   │   └── loadPage.ts
│   │
│   └── utils/
│       └── handleClick.ts
│
├── core/                       # Foundation
├── editor/                     # Editor UI
├── inspector/                  # Property panel
├── menubar/                   # Menu bar
└── toolbar/                   # Toolbar
```

## What Was Implemented

### Phase 1: ✅ Single Registry Source

- Added `componentMap` to `builder/utils/component-registry.ts`
- Updated `builder/utils/index.ts` to export `componentMap`

### Phase 2: ✅ Canvas Renderer

- Created `builder/canvas/renderer/` directory
- Moved `builder/components/index.tsx` → `builder/canvas/renderer/index.tsx`
- Moved `builder/components/types.ts` → `builder/canvas/renderer/types.ts`
- Moved `builder/canvas/utils/computeProps.ts` → `builder/canvas/renderer/computeProps.ts`
- Updated imports to use `componentMap` instead of `componentRegistry`

### Phase 3: ✅ Clean Up

- Deleted `builder/components/` folder (all redundant re-export files)
- Kept `builder/utils/component-registry.ts` as single source of truth

### Phase 4: ✅ Import Updates

- Updated `builder/index.tsx` to export from `./canvas/renderer`
- Updated `canvas/pages/page.tsx` to import from `~/builder/canvas/renderer`
- Updated `canvas/pages/root-page.tsx` to import from `~/builder/canvas/renderer`
- All other files import via `~/builder/utils` which re-exports everything

## Verification

After implementation, verify:

1. Builder loads correctly
2. Components render in canvas
3. Inspector shows component attributes
4. Drag and drop works
5. Insert components from menubar works

## Benefits

1. **Single source of truth** - One registry file for all component definitions
2. **Clear naming** - `canvas/renderer` clearly indicates purpose
3. **No duplication** - Removed redundant registry files
4. **Maintainable** - Changes to components only in one place
5. **Organized** - Each piece in its logical location
