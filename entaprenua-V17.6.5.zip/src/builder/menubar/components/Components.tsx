import { 
  Flex, Text, Paper, Box, Grid, Button, Badge,
} from "~/components/ui";
import { 
  createSignal, Show, For, createMemo,
} from 'solid-js';
import { 
  componentRegistry,
  componentMeta,
  COMPONENT_CATEGORIES,
  type ComponentCategory,
  ComponentInsertTrigger, 
  InsertPositionSelector,
  type InsertPosition,
  DEFAULT_INSERT_POSITION,
} from "./../utils";
import { useBuilder } from "~";
import { cn } from "~/lib/utils"
import StarIcon from "lucide-solid/icons/star"
import ClockIcon from "lucide-solid/icons/clock"
import SearchIcon from "lucide-solid/icons/search"
import LayoutGridIcon from "lucide-solid/icons/layout-grid"
import BoxIcon from "lucide-solid/icons/box"
import FormInputIcon from "lucide-solid/icons/form-input"
import CompassIcon from "lucide-solid/icons/compass"
import TypeIcon from "lucide-solid/icons/type"
import AlertCircleIcon from "lucide-solid/icons/alert-circle"
import LayersIcon from "lucide-solid/icons/layers"
import TableIcon from "lucide-solid/icons/table"
import ImageIcon from "lucide-solid/icons/image"
import ShoppingCartIcon from "lucide-solid/icons/shopping-cart"

const CATEGORY_ICONS: Record<ComponentCategory, typeof BoxIcon> = {
  layout: LayoutGridIcon,
  input: FormInputIcon,
  navigation: CompassIcon,
  display: TypeIcon,
  feedback: AlertCircleIcon,
  surface: LayersIcon,
  data: TableIcon,
  media: ImageIcon,
  commerce: ShoppingCartIcon,
};

interface ComponentItem {
  name: string;
  label: string;
  description: string;
  category: ComponentCategory;
  keywords: string[];
  isNew?: boolean;
  isPopular?: boolean;
}

interface FavoritesStore {
  favorites: string[];
  recent: string[];
}

const FAVORITES_KEY = "builder-component-favorites";
const RECENT_KEY = "builder-component-recent";
const MAX_RECENT = 8;
const MAX_FAVORITES = 12;

function getFavorites(): string[] {
  try {
    return JSON.parse(localStorage.getItem(FAVORITES_KEY) || "[]");
  } catch {
    return [];
  }
}

function setFavorites(favorites: string[]) {
  localStorage.setItem(FAVORITES_KEY, JSON.stringify(favorites));
}

function getRecent(): string[] {
  try {
    return JSON.parse(localStorage.getItem(RECENT_KEY) || "[]");
  } catch {
    return [];
  }
}

function setRecent(recent: string[]) {
  localStorage.setItem(RECENT_KEY, JSON.stringify(recent.slice(0, MAX_RECENT)));
}

export default function Components(props){
  const builder = useBuilder()
  
  const [searchQuery, setSearchQuery] = createSignal("")
  const [selectedCategory, setSelectedCategory] = createSignal<ComponentCategory | "all" | "favorites" | "recent">("all")
  const [favorites, setFavoritesState] = createSignal<string[]>(getFavorites())
  const [recent, setRecentState] = createSignal<string[]>(getRecent())
  const [insertPosition, setInsertPosition] = createSignal<InsertPosition>(DEFAULT_INSERT_POSITION)
  
  const allComponents = createMemo((): ComponentItem[] => {
    return Object.keys(componentRegistry).map(name => {
      const meta = componentMeta[name];
      return {
        name,
        label: meta?.label || name,
        description: meta?.description || "",
        category: meta?.category || "surface",
        keywords: meta?.keywords || [],
        isNew: meta?.isNew,
        isPopular: meta?.isPopular,
      };
    });
  });

  const filteredComponents = createMemo((): ComponentItem[] => {
    const query = searchQuery().toLowerCase().trim();
    const category = selectedCategory();
    const favs = favorites();
    const recents = recent();
    let items = allComponents();

    // Filter by category
    if (category === "favorites") {
      items = items.filter(c => favs.includes(c.name));
    } else if (category === "recent") {
      items = items.filter(c => recents.includes(c.name));
    } else if (category !== "all") {
      items = items.filter(c => c.category === category);
    }

    // Filter by search
    if (query) {
      items = items.filter(c => 
        c.name.toLowerCase().includes(query) ||
        c.label.toLowerCase().includes(query) ||
        c.description.toLowerCase().includes(query) ||
        c.keywords.some(k => k.toLowerCase().includes(query))
      );
    }

    return items;
  });

  const handleInsert = (componentName: string) => {
    // Add to recent
    const recents = getRecent().filter(n => n !== componentName);
    setRecent([componentName, ...recents].slice(0, MAX_RECENT));
    setRecentState(getRecent());
  };

  const toggleFavorite = (componentName: string, e: Event) => {
    e.stopPropagation();
    const favs = favorites();
    const newFavorites = favs.includes(componentName)
      ? favs.filter(n => n !== componentName)
      : [...favs, componentName].slice(0, MAX_FAVORITES);
    setFavorites(newFavorites);
    setFavoritesState(newFavorites);
  };

  const categories = createMemo(() => {
    const cats: { id: ComponentCategory | "all" | "favorites" | "recent"; label: string; icon: typeof LayoutGridIcon; count: number }[] = [
      { id: "all", label: "All", icon: LayoutGridIcon, count: allComponents().length },
      { id: "favorites", label: "Favorites", icon: StarIcon, count: favorites().length },
      { id: "recent", label: "Recent", icon: ClockIcon, count: recent().length },
    ];
    
    Object.entries(COMPONENT_CATEGORIES).forEach(([key, val]) => {
      const cat = key as ComponentCategory;
      const count = allComponents().filter(c => c.category === cat).length;
      if (count > 0) {
        cats.push({ id: cat, label: val.label, icon: CATEGORY_ICONS[cat], count });
      }
    });
    
    return cats;
  });

  const activeTab = createMemo(() => selectedCategory());

  return (
    <Flex flexDirection="col" class="w-[400px] max-h-[70vh]">
      {/* Header with Search */}
      <Flex class="gap-2 p-3 border-b items-center">
        <Box class="relative flex-1">
          <SearchIcon class="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
          <input
            type="text"
            placeholder="Search components..."
            value={searchQuery()}
            onInput={(e) => setSearchQuery(e.currentTarget.value)}
            class="w-full h-9 pl-9 pr-3 rounded-md border bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring"
          />
          <Show when={searchQuery()}>
            <Button
              variant="ghost"
              size="sm"
              class="absolute right-1 top-1/2 -translate-y-1/2 h-6 px-1"
              onClick={() => setSearchQuery("")}
            >
              ×
            </Button>
          </Show>
        </Box>
      </Flex>

      {/* Insert Position Selector */}
      <Box class="p-2 border-b">
        <Text class="text-xs text-muted-foreground mb-1 block">Insert Position:</Text>
        <InsertPositionSelector 
          value={insertPosition()} 
          onChange={setInsertPosition}
          showLabels={false}
        />
      </Box>

      {/* Category Tabs */}
      <div class="border-b p-2">
        <div class="flex gap-1 overflow-x-auto w-full">
          <For each={categories()}>
            {(cat) => (
              <Button
                variant={selectedCategory() === cat.id ? "secondary" : "ghost"}
                size="sm"
                class={cn(
                  "gap-1.5 whitespace-nowrap text-xs flex-shrink-0",
                  selectedCategory() === cat.id && "bg-secondary"
                )}
                onClick={() => setSelectedCategory(cat.id)}
              >
                <cat.icon class="size-3.5" />
                {cat.label}
                <Badge variant="secondary" class="text-[10px] px-1.5">
                  {cat.count}
                </Badge>
              </Button>
            )}
          </For>
        </div>
      </div>

      {/* Component Grid */}
      <Box class="flex-1 overflow-y-auto p-3">
        <Show when={filteredComponents().length === 0}>
          <Flex class="flex-col items-center justify-center py-8 text-muted-foreground">
            <SearchIcon class="size-8 mb-2 opacity-50" />
            <Text class="text-sm">No components found</Text>
            <Text class="text-xs">Try a different search or category</Text>
          </Flex>
        </Show>

        <Show when={filteredComponents().length > 0}>
          <Grid 
            cols={2}
            class="gap-2"
          >
            <For each={filteredComponents()}>
              {(component) => (
                <ComponentCard 
                  component={component}
                  isFavorite={favorites().includes(component.name)}
                  onToggleFavorite={toggleFavorite}
                  onInsert={handleInsert}
                  insertPosition={insertPosition()}
                />
              )}
            </For>
          </Grid>
        </Show>
      </Box>

      {/* Footer */}
      <Flex class="justify-between items-center p-2 border-t text-xs text-muted-foreground">
        <Text>{filteredComponents().length} components</Text>
        <Text>Press Tab to navigate</Text>
      </Flex>
    </Flex>
  );
}

interface ComponentCardProps {
  component: ComponentItem;
  isFavorite: boolean;
  onToggleFavorite: (name: string, e: Event) => void;
  onInsert: (name: string) => void;
  insertPosition: InsertPosition;
}

function ComponentCard(props: ComponentCardProps) {
  const [isHovered, setIsHovered] = createSignal(false);
  const CategoryIcon = CATEGORY_ICONS[props.component.category] || SurfaceIcon;

  const handleInsert = () => {
    props.onInsert(props.component.name);
  };

  return (
    <ComponentInsertTrigger
      name={props.component.name}
      role={props.insertPosition}
      onInsert={handleInsert}
      class="w-full h-full"
    >
      <Paper
        class={cn(
          "relative p-3 cursor-pointer transition-all duration-200",
          "hover:shadow-md hover:border-primary/50",
          "focus:outline-none focus:ring-2 focus:ring-ring",
          "group"
        )}
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
      >
        {/* Favorite Button */}
        <Button
          variant="ghost"
          size="sm"
          class={cn(
            "absolute top-1 right-1 h-6 w-6 p-0 opacity-0 group-hover:opacity-100 transition-opacity",
            props.isFavorite && "opacity-100 text-yellow-500"
          )}
          onClick={(e) => props.onToggleFavorite(props.component.name, e)}
        >
          <StarIcon class={cn("size-3.5", props.isFavorite && "fill-current")} />
        </Button>

        {/* Component Icon */}
        <Flex class="mb-2 size-8 rounded-md bg-primary/10 items-center justify-center">
          <CategoryIcon class="size-4 text-primary" />
        </Flex>

        {/* Component Label */}
        <Text class="font-medium text-sm truncate block">
          {props.component.label}
        </Text>

        {/* Description */}
        <Text class="text-xs text-muted-foreground line-clamp-1 mt-1">
          {props.component.description}
        </Text>

        {/* Badges */}
        <Flex class="gap-1 mt-2">
          <Show when={props.component.isPopular}>
            <Badge variant="outline" class="text-[10px] py-0 px-1">Popular</Badge>
          </Show>
          <Show when={props.component.isNew}>
            <Badge variant="secondary" class="text-[10px] py-0 px-1">New</Badge>
          </Show>
        </Flex>
      </Paper>
    </ComponentInsertTrigger>
  );
}
