import { Box, Flex, Text, IconButton } from "~/components/ui";
import { createSignal, Show, onCleanup } from "solid-js";
import { cn } from "~/lib/utils"
import SearchIcon from "lucide-solid/icons/search"
import XIcon from "lucide-solid/icons/x"

export interface SearchFilterOption {
  value: string;
  label?: string;
  group?: string;
}

interface SearchProps {
  value?: string;
  placeholder?: string;
  options?: SearchFilterOption[];
  onChange?: (value: string) => void;
  onClear?: () => void;
  class?: string;
}

export function SearchInput(props: SearchProps) {
  const [query, setQuery] = createSignal(props.value || "");
  let inputRef: HTMLInputElement | undefined;

  const handleInput = (e: Event) => {
    const value = (e.target as HTMLInputElement).value;
    setQuery(value);
    props.onChange?.(value);
  };

  const handleClear = () => {
    setQuery("");
    props.onChange?.("");
    props.onClear?.();
    inputRef?.focus();
  };

  const handleKeyDown = (e: KeyboardEvent) => {
    if (e.key === "Escape" && query()) {
      handleClear();
    }
    if (e.key === "/" && document.activeElement !== inputRef) {
      e.preventDefault();
      inputRef?.focus();
    }
  };

  onCleanup(() => {
    document.removeEventListener("keydown", handleKeyDown);
  });

  return (
    <Box class={cn("relative", props.class)}>
      <Flex class="absolute left-3 top-1/2 -translate-y-1/2 items-center gap-2 pointer-events-none">
        <SearchIcon class="size-4 text-muted-foreground" />
      </Flex>
      <input
        ref={inputRef}
        type="text"
        value={query()}
        onInput={handleInput}
        placeholder={props.placeholder || "Search..."}
        class={cn(
          "w-full h-10 pl-9 pr-9 rounded-md border bg-background",
          "text-sm focus:outline-none focus:ring-2 focus:ring-ring",
          "placeholder:text-muted-foreground"
        )}
        aria-label={props.placeholder}
      />
      <Show when={query()}>
        <IconButton
          variant="ghost"
          size="sm"
          class="absolute right-1 top-1/2 -translate-y-1/2 h-8 w-8"
          onClick={handleClear}
          aria-label="Clear search"
        >
          <XIcon class="size-4" />
        </IconButton>
      </Show>
      <Show when={!query()}>
        <Text class="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-muted-foreground pointer-events-none">
          /
        </Text>
      </Show>
    </Box>
  );
}

export function filterOptions<T extends { name?: string; label?: string; description?: string }>(
  options: T[],
  query: string
): T[] {
  if (!query.trim()) return options;
  
  const q = query.toLowerCase().trim();
  return options.filter(opt => {
    const name = opt.name?.toLowerCase() || "";
    const label = opt.label?.toLowerCase() || "";
    const desc = opt.description?.toLowerCase() || "";
    return name.includes(q) || label.includes(q) || desc.includes(q);
  });
}
