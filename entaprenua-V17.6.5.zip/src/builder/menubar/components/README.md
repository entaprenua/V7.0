# Builder Menubar Components

## Overview

The `builder/menubar/components/*` directory contains the **component picker/selector UI** for the visual website builder. This is the interface users interact with to add new components to their pages.

## Architecture

### Files

| File | Purpose |
|------|---------|
| `Components.tsx` | Main component selector with categories, search, favorites |
| `Search.tsx` | Search input component with keyboard shortcuts |
| `ContextualComponents.tsx` | Context-aware component picker |
| `README.md` | This documentation |

### Key Dependencies

- **`componentRegistry`** (`builder/utils/component-registry.ts`) - Registry of all available components
- **`componentMeta`** - Metadata (labels, descriptions, categories) for each component
- **`COMPONENT_CATEGORIES`** - Category definitions with icons

## Features

### 1. Categorized Components
Components are organized into categories:
- **Layout** - Box, Flex, Grid, Spacer
- **Input** - Button, Search, Checkbox, Radio, Switch, Select
- **Navigation** - Link, Pagination, Navbar, Menu, Drawer, Sidebar
- **Display** - Text, Heading, Badge, Avatar, Separator
- **Surface** - Card, Paper, Accordion, App Bar
- **Feedback** - Alert, Dialog, Toast, Tooltip, Skeleton, Spinner
- **Media** - Image, Video, Carousel, Aspect Ratio
- **Commerce** - Product, Cart, Add to Cart

### 2. Search with Filtering
- Real-time search by name, label, or description
- Keyboard shortcut: Press `/` to focus search
- Press `Escape` to clear search

### 3. Favorites System
- Star components to add them to favorites
- Favorites persist in localStorage
- Quick access via "Favorites" tab

### 4. Recent Components
- Recently used components are tracked
- Quick access via "Recent" tab
- Shows last 8 recently used components

### 5. Component Badges
- **Popular** - Most commonly used components
- **New** - Recently added components

### 6. Keyboard Navigation
- `Tab` - Navigate between components
- `Enter` / `Space` - Insert selected component
- `/` - Focus search
- `Escape` - Clear search

## Component Flow

```
User clicks "Components" → Popover opens → Components.tsx loads
    │
    ├── Load favorites & recent from localStorage
    │
    ├── Show category tabs (All, Favorites, Recent, Layout, Input, etc.)
    │
    ├── Show search input (optional)
    │
    ├── Filter by category (if selected)
    │
    ├── Filter by search query
    │
    └── Display grid of ComponentCards
         │
         ├── Click card → Insert component
         │
         ├── Click star → Toggle favorite
         │
         └── Add to recent on insert
```

## Enhancement Ideas (Future)

1. **Drag and Drop** - Drag component directly to canvas
2. **Component Preview** - Show mini preview of component
3. **Documentation Links** - Link to component documentation
4. **Keyboard Navigation** - Arrow keys to navigate grid
5. **Usage Analytics** - Track most used components
6. **Custom Components** - User-defined components
7. **Component Templates** - Pre-built component groups

## Data Storage

- **Favorites**: `localStorage` key `builder-component-favorites`
- **Recent**: `localStorage` key `builder-component-recent`
- Max favorites: 12
- Max recent: 8
