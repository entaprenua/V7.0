import { 
  Flex, Text, Paper, Grid, Box,
} from "~/components/ui";
import { 
  Show, For, createMemo,
} from 'solid-js';
import { 
  componentRegistry,
  componentMeta,
  type ComponentCategory,
  ComponentInsertTrigger, 
} from "./../utils";
import { useBuilder } from "~";
import { cn } from "~/lib/utils"
import SurfaceIcon from "lucide-solid/icons/layers"

interface ComponentItem {
  name: string;
  label: string;
  description: string;
  category: ComponentCategory;
}

export default function ContextualComponents() {
  const builder = useBuilder()
  const selected = () => builder.selected

  const contextualComponents = createMemo((): ComponentItem[] => {
    const sel = selected();
    if (!sel) return [];

    const parentName = sel.name;
    const parentConfig = componentRegistry[parentName];
    
    if (!parentConfig?.contextuals) return [];

    const contextuals = parentConfig.contextuals;
    return Object.keys(contextuals).map(name => {
      const meta = componentMeta[name];
      return {
        name,
        label: meta?.label || name,
        description: meta?.description || "",
        category: meta?.category || "surface",
      };
    });
  });

  return (
    <Flex flexDirection="col" class="w-[350px] max-h-[50vh]">
      {/* Header */}
      <Flex class="p-3 border-b items-center gap-2">
        <SurfaceIcon class="size-4 text-muted-foreground" />
        <Text class="font-medium text-sm">
          Add to "{selected()?.name || 'selected element'}"
        </Text>
      </Flex>

      {/* Components */}
      <Box class="flex-1 overflow-y-auto p-3">
        <Show when={contextualComponents().length === 0}>
          <Flex class="flex-col items-center justify-center py-6 text-muted-foreground">
            <Text class="text-sm">No valid components</Text>
            <Text class="text-xs">This element cannot have children</Text>
          </Flex>
        </Show>

        <Show when={contextualComponents().length > 0}>
          <Grid cols={2} class="gap-2">
            <For each={contextualComponents()}>
              {(component) => (
                <ComponentInsertTrigger
                  name={component.name}
                  role="last-child"
                  class="w-full h-full"
                >
                  <Paper
                    class={cn(
                      "p-3 cursor-pointer transition-all duration-200",
                      "hover:shadow-md hover:border-primary/50"
                    )}
                  >
                    <Text class="font-medium text-sm truncate block">
                      {component.label}
                    </Text>
                    <Text class="text-xs text-muted-foreground line-clamp-1 mt-1">
                      {component.description}
                    </Text>
                  </Paper>
                </ComponentInsertTrigger>
              )}
            </For>
          </Grid>
        </Show>
      </Box>

      {/* Footer */}
      <Flex class="justify-between items-center p-2 border-t text-xs text-muted-foreground">
        <Text>{contextualComponents().length} available</Text>
        <Text>Click to add</Text>
      </Flex>
    </Flex>
  );
}
