import { Button } from "~/components/ui/button"
import { Flex } from "~/components/ui/flex"
import { cn } from "~/lib/utils"
import { 
  createSignal, Show
} from "solid-js"
import { 
  Query, QueryTrigger, useQueryState,
} from "~/components/ui/fetch"
import { useBuilder, ReactiveElement, CodeEditor as Editor, CreatorFetchFeedback  } from "~";
import { uploadCustomCode, objectToElement } from "~/view-models"
import { ComponentRole, useComponent } from "./utils"

export default function CodeEditor(props){
   const builder = useBuilder();
   const selected = () => builder?.selected;
   const fetch = useFetch()
   const componentContext = useComponent() 
   const [rawCode, setRawCode] = createSignal("")
   
   return (
    <> {/* 
     <Query
       queryFn={() => uploadCustomCode(rawCode())}
     > 
      {() => {
         const fetch = useFetch()
         const handleApply = () => {
            fetch?.onSuccess((data) => { 
             try { 
	       data = data.data
               if(data) { 
	         const el = objectToElement(data)?.clone() 
                 if(el instanceof ReactiveElement){
	  	   builder?.record.add({
                     ref: selected(), element: el, role: componentContext.role            
                  })   
                  el.setAttribute("raw-code", rawCode()) 
	        }
              } 
	    }catch(e) {
	       console.error("Error occured in inserting custom code: ", e)
	   }
	  })
       }
       return ( 
         <div class="overflow-clip"> 
	  <CreatorFetchFeedback />
          <Flex class="justify-around"> 
            <QueryTrigger disabled={rawCode().length == 0}
              onClick={handleApply}
	    >
             Apply
            </QueryTrigger>
	    <Flex class="justify-end">Select Role: <ComponentRole/> </Flex>
          </Flex>
         <Editor 
           class="max-h-150" 
	   onChange={value => setRawCode(value)}
         />
       </div> 
     )
    }}
   </Query>  
  */}</> 
   )
}




        










