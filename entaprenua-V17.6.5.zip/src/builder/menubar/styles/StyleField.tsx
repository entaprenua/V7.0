import {
  Tooltip, TooltipTrigger, TooltipContent,
} from "~/components/ui/tooltip";
import { Box } from "~/components/ui/box"
import { Button } from "~/components/ui/button"

import ClipboardIcon from "~/icons/Clipboard"
import Trash2Icon from "~/icons/Trash2"
import CopyIcon from "~/icons/Copy"
import FileIcon  from "lucide-solid/icons/file"
import {
   Editor, useEditor, TransactionSpecProps, EditorFileReader, 
   EditorCopyTrigger, EditorDeleteTrigger, EditorPasteTrigger,
   EditorTextBox,
} from "~";
import { createSignal, createEffect, on, onMount, onCleanup } from "solid-js";
import { capitalize } from "~/lib/utils"
import { useBuilder } from "~";
import { Select} from "../../utils/ui"

export default function StyleField(props){
   const builder = useBuilder();
   const selected = () =>  builder?.selected; 

   const [defaultValue, setDefaultValue] = createSignal( 
     selected()?.tailwind ?? ""
   )

   return (
     <Editor
       defaultValue={defaultValue()}        
       class="min-h-[20vh] max-h-[50vh] max-w-[80vw] overflow-auto" 
       extensions={["tailwind"]} 
     > 
      <> {() => {
          const editor = useEditor();
          const [disableSaveButton, setDisableSaveButton] = createSignal(false);
          
	  let timer: any  
          onCleanup(() => { clearTimeout(timer) })
          const handleApply = () => {
             const selectedEl = builder?.selected; 
	     const value = editor?.value ?? "" 
             try{  
               if(builder.multiselection) {
                  builder.selection.forEach((el: any, id: any) => {
                    el.tailwind = value;
                  })
               }else {
                 selectedEl.tailwind = value;
               }
             }catch(error) {
               console.error("Error occured", error) 
            }
            setDisableSaveButton(true); 
            timer = window.setTimeout(() => {
               setDisableSaveButton(false); 
            }, 1000)
          }

          const handleReset  = async() => {
            await editor.clear(); 
	    editor.insert(selected()?.tailwind ?? "");
          } 
       
          createEffect(on(selected, async(selectedEl) => {
	       handleReset(); 
          }, { defer: true }))


          return (
 	    <Box class="mb-3">  
	       <Box 
	         class="flex justify-center gap-3"
	       > <p class="opacity-[0.6]"> Style for: </p> 
	           <strong> { capitalize(selected()?.name) }</strong>
	       </Box>
	       <div class="flex justify-around gap-5 items-center">
                 <Tooltip>
		  <TooltipTrigger>
		   <EditorFileReader>
		     <Button size="icon" class="size-5 border-none">
		       <FileIcon /> 
		    </Button> 
                   </EditorFileReader>
                 </TooltipTrigger>
		  <TooltipContent> Upload file </TooltipContent>
		 </Tooltip> 
		 <Button
        variant="ghost"  
        onClick={handleApply} 
	      enabled={!disableSaveButton()} 
		    class="hover:cursor-pointer" 
		 > Apply     
     </Button>     
	   <Tooltip>
		  <TooltipTrigger>
		   <EditorCopyTrigger 
		     size={"icon"}
		   >
		     <CopyIcon />
		   </EditorCopyTrigger>
		  </TooltipTrigger>
		  <TooltipContent class="z-3000000000"> Copy </TooltipContent>
		 </Tooltip>
		 <Tooltip>
		  <TooltipTrigger>
		    <EditorPasteTrigger
		      size="icon"
		     > 
		       <ClipboardIcon />
		     </EditorPasteTrigger>
                   </TooltipTrigger> 
		   <TooltipContent class="z-3000000000"> Paste </TooltipContent>
		  </Tooltip>
		  
		  <Tooltip>
                   <TooltipTrigger>
                    <EditorDeleteTrigger
		      size={"icon"}
                     > 
                      <Trash2Icon />
                    </EditorDeleteTrigger> 
		  </TooltipTrigger>
                  <TooltipContent class="z-3000000000"> delete </TooltipContent>
                 </Tooltip> 
              </div>
	      <EditorTextBox /> 
	    </Box>
          )
      }}</>
     </Editor> 

  )
}
