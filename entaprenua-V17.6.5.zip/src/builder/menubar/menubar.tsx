import { Button } from "~/components/ui/button"
import { IconButton } from "~/components/ui/icon-button"
import { Link } from "~/components/ui/link"
import { Spacer } from "~/components/ui/spacer"
import { Flex } from "~/components/ui/flex"
import {  
    Popover as Ppover, PopoverArrow,
     PopoverContent as PpoverContent, 
     PopoverCloseButton, PopoverTrigger, PopoverTitle,
} from "~/components/ui/popover";
import  ArrowLeftIcon  from "~/icons/ArrowLeft"
import  MoreVertIcon  from "~/icons/MoreVert"
import GlobeIcon from "lucide-solid/icons/globe"
import MenuIcon from "lucide-solid/icons/menu"
import CrossIcon from "~/icons/Cross"
import { routes, Z_INDEX, cn } from "~/lib/utils"
import { splitProps } from "solid-js"
import  { Components }  from "./components/";
import  StyleField  from "./styles/StyleField" 
import CodeEditor from "./code-editor"
import { useBuilder } from "~"
import { PagesSidebarTrigger } from "../panels/pages-panel";

export default function Menubar(){
    const builder = useBuilder();
    
    const Popover = (props: any) => {
       const [local, others] = splitProps(props, ["onOpenChange"]) 
       return (
         <Ppover 
            onOpenChange={() => { 
             if(builder.expandAttributesPanel) 
 	        builder.expandAttributesPanel = false
            }}
            {...others}
         />
       )
   }

    const PopoverContent = (props: any) => {
 	return ( 
 	 <PpoverContent class={cn(Z_INDEX, "w-auto", props.class)}> 
            <PopoverArrow /> 
 	    <PopoverCloseButton class="absolute top-2 right-2"> <CrossIcon /> </PopoverCloseButton> 
 	    <Spacer height="5px" /> 
 	    {props.children} 
        </PpoverContent>   
     )
   } 
    
    return (
      <Flex class="items-center gap-1 w-full"> 
        <IconButton 
          variant="ghost" 
          class="p-0" 
          href={routes.mySites}
          as={Link}
        > 
          <GlobeIcon /> 
        </IconButton> 
       
        {/* Menu icon opens the sidebar */}
        <PagesSidebarTrigger />
       
        <Popover
            closeOnFocusOutside={false}
            closeOnInteractOutside={false}
        >
            <PopoverTrigger 
 	      as={Button<"button">} 
              variant="ghost" 
            > Components
 	  </PopoverTrigger> 
            <PopoverContent> <Components /> </PopoverContent> 
         </Popover>
        
        <Popover modal 
            closeOnEscapeKeyDown={false} 
 	    closeOnFocusOutside={false}
            closeOnInteractOutside={false}
        >
            <PopoverTrigger> Code </PopoverTrigger> 
            <PopoverContent  
 	      class="max-h-[80vh] inset-x-0 w-[80vw] overflow-clip"
 	    >  
              <CodeEditor /> 
            </PopoverContent> 
        </Popover> 
        
        <Popover 
          modal
          closeOnEscapeKeyDown={false} 
 	  closeOnInteractOutside={false}
 	  closeOnFocusOutside={false}
        >
          <PopoverTrigger> Style </PopoverTrigger> 
          <PopoverContent>  <StyleField /> </PopoverContent> 
        </Popover>
      </Flex>
  )
}
