import { showToast, Toaster } from "~/components/ui/toast"
import { 
  Box,
} from "~/components/ui/box"
import { Flex } from "~/components/ui/flex"
import {IconButton} from "~/components/ui/icon-button"
import { 
 Tooltip, TooltipTrigger, TooltipContent as TtContent,
} from '~/components/ui/tooltip';
import {
  Popover, PopoverTrigger, PopoverCloseButton, PopoverContent,
  PopoverTitle, PopoverArrow, PopoverDescription
} from "~/components/ui/popover"
import { 
   Button
} from "~/components/ui/button"
import { Spacer } from "~/components/ui/spacer"
import  Trash2Icon  from "~/icons/Trash2"
import  LinkIcon  from "~/icons/Link"
import  SaveIcon  from "~/icons/Save"
import  UndoIcon  from "~/icons/Undo"
import  RedoIcon  from "~/icons/Redo"
import  ClipboardIcon  from "~/icons/Clipboard"
import  CopyIcon  from "~/icons/Copy"
import  CutIcon  from "~/icons/Cut"
import  CrossIcon  from "~/icons/Cross"
import  DownloadIcon  from "lucide-solid/icons/download"
import { createSignal, splitProps, createEffect, on,  Show, onCleanup} from "solid-js";
import { createStore } from "solid-js/store";
import { createAsync } from "@solidjs/router"
import { useBuilder } from "~";
import { capitalize, cn, Z_INDEX } from "~/lib/utils";
import { ComponentRole, useComponent,  componentRegistry, isInsertable } from "./../utils"
import { storesApi } from "~/lib/api/stores";
import { elementToObject} from "~/view-models"

const StandardToolbar= (props) => {
   
    const builder = useBuilder();
    const targetEl = () => builder.selected
    const [isSaving, setIsSaving] = createSignal(false)
    
    const handleSave = async () => {
      const storeId = builder?.storeDetails?.id;
      if (!storeId) {
        showToast({ title: "Error", description: "No store selected", variant: "error" });
        return;
      }

      setIsSaving(true);
      try {
        const routes = builder?.routes || [];
        if (builder?.pages.size === 0) {
           showToast({ title: "Error", description: "No content to save", variant: "error" });
           return;
        }
        const pageList = [...builder.pages.values()].map(page => { 
          const el  = elementToObject(page.element)
             page.element = el 
             return page 
        }) 
         
        const content = {
           ...builder.storeDetails,
           pages: pageList,
        } 
        await storesApi.saveStoreWithPages(content)
        showToast({ title: "Success", description: "Saved successfully!", variant: "success" });
      } catch (error) {
        console.error("Save failed:", error);
        showToast({ title: "Error", description: "Failed to save", variant: "error" });
      } finally {
        setIsSaving(false);
      }
    }

    const TooltipContent = (props) => {
      const [local, others] = splitProps(props, ["class"]) 
      return (
        <TtContent
          /* z-index above App bar */ 
          class={cn(Z_INDEX, local.class)} 
	  {...others}    
        />
      )
    }
    

    return (
      <Flex
        class="justify-around" 
	style={{
	   overflow: "auto",
	   "scrollbar-width": "none",
	   width: '100%',
	}}>
        
	<Toaster class="z-2000 top-40 w-auto ml-20 h-3"/>
        <Tooltip>
	  <TooltipTrigger> 
	    <IconButton disabled={isSaving()} onClick={handleSave}>
	     <SaveIcon />
	    </IconButton>
          </TooltipTrigger>
	  <TooltipContent> {isSaving() ? 'Saving...' : 'Save Work'} </TooltipContent>
	</Tooltip>
  <Tooltip>
	 <TooltipTrigger>
	  <IconButton
	   disabled={!targetEl() || targetEl().isRoot()|| 
	   builder.multiselection}
	   onClick={() => builder.record.cut()} 
	  > <CutIcon/> 
	  </IconButton>
         </TooltipTrigger>
	 <TooltipContent> Cut </TooltipContent>
	</Tooltip> 
	
	<Tooltip>
	 <TooltipTrigger>
	   <IconButton
	    disabled={!targetEl() || targetEl().isRoot() || builder.multiselection}
	    onClick={() => builder.clipboard.copy()} 
	   > <CopyIcon />
  	  </IconButton>
         </TooltipTrigger>
	 <TooltipContent> Copy </TooltipContent>
        </Tooltip> 
         
	<Popover>	
	  <>{() => {
             const component = useComponent() 
             const pastableEl = () =>  builder.clipboard.peek 
	     const isPastable = isInsertable(builder.clipboard.peek);
	     return ( 
	      <> 
	       <PopoverTrigger 
		     as={IconButton<"button">} 
	             disabled={!targetEl() ||
		       builder.clipboard.isEmpty() || 
		       targetEl().isRoot() || builder.multiselection
		    }
		 > <ClipboardIcon />
              </PopoverTrigger>
              <PopoverContent class="z-2000">
		<PopoverCloseButton> <CrossIcon /> </PopoverCloseButton> 
	        <Spacer class="h-8" />	
		<ComponentRole 
                 label={`Select role of the pastable: ${pastableEl()?.name}`}
		/>
	        <Button 
	          onClick={() => builder.clipboard.paste(component?.role)}
	          disabled={!isPastable()} 
		  class="w-full rounded-xl" 
		 > Paste 
	         </Button> 
	         <p class="text-red-500 text-sm flex justify-center">
		   {!isPastable()? `Forbidded Paste `: ""} 
		 </p>
	       </PopoverContent>
            </>) 
	   }}</> 
	</Popover>	
	<Tooltip>
         <TooltipTrigger> 
	  <IconButton 
	    disabled={builder?.record.isEmpty()}
	    onClick={() => builder?.record.remove()}
	  >
	   <UndoIcon />
	  </IconButton>
         </TooltipTrigger>
	 <TooltipContent> Undo </TooltipContent>
	</Tooltip>

        <Tooltip>
	  <TooltipTrigger> 
	   <IconButton
	     disabled={builder?.trash.isEmpty()} 
	     onClick={() => builder?.record.add({})}
	   >
	     <RedoIcon />
	   </IconButton>
         </TooltipTrigger>
	 <TooltipContent> Redo </TooltipContent>
	</Tooltip>
          
	<Tooltip>
         <TooltipTrigger> 
	  <IconButton 
	    /* enabled if selection is not empty, or selected is non-null */ 
	    disabled={
	      !targetEl() || 
	      targetEl()?.isPage() ||
	      builder?.multiselection  
	    }
            onClick={async(event) => {  
	         await builder.record.remove(targetEl()) 
	    }}
	  >
           <Trash2Icon />
          </IconButton>
         </TooltipTrigger>
	 <TooltipContent> Delete </TooltipContent>
	</Tooltip>
       </Flex>
    );

}; 

export default StandardToolbar;




























