export const handleDelete = (builder) => {

     const target = builder.selected!;
     const parent = target.parent;
     
    
   if(parent.firstChild!.id == target.id) {
	if(target.nextSibling == null) {
	  builder.selected = parent;
	}
	else {
	   builder.selected =  target.nextSibling;
	}
     }
     /* target is between siblings */
     else if(target.nextSibling) {
	builder.selected = target.nextSibling;
     }
     /* Else target is last child */ 
     else if(parent.lastChild!.id == target.id) {
         builder.selected = target.previousSibling;
     }
     else { 
	console.log("Error deleting element")
     }
     parent.removeChild(target);
}
	

