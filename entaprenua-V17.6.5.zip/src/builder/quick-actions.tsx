import { Button } from "~/components/ui/button";
import { useBuilder } from "~/";
import { Show } from "solid-js";
import { cn } from "~/lib/utils";
import EyeIcon from "~/icons/Eye";
import EyeOffIcon from "~/icons/EyeOff";
import SettingsIcon from "~/icons/Settings";

/**
 * QuickActions component - contains quick action buttons for the builder toolbar.
 * Provides preview toggle and attributes panel access.
 */
export const QuickActions = () => {
  const builder = useBuilder();
  const isPreview = () => builder?.preview ?? false;
  const isPanelOpen = () => builder?.expandAttributesPanel ?? false;
  
  const togglePreview = () => {
    if (builder) {
      builder.preview = !builder.preview;
    }
  };
  
  const openPanel = () => {
    if (builder) {
      builder.expandAttributesPanel = true;
    }
  };

  return (
    <div class="flex items-center gap-2 px-3 py-1">
      {/* Preview toggle button */}
      <Button
        variant={isPreview() ? "default" : "outline"}
        size="sm"
        onClick={togglePreview}
        class={cn(
          "h-8 gap-2 transition-all",
          isPreview() && "bg-primary text-primary-foreground"
        )}
      >
        {isPreview() ? (
          <>
            <EyeOffIcon class="size-4" />
            <span class="text-xs">Exit Preview</span>
          </>
        ) : (
          <>
            <EyeIcon class="size-4" />
            <span class="text-xs">Preview</span>
          </>
        )}
      </Button>
      
      {/* Panel toggle button - only visible when panel is closed and not in preview */}
      <Show when={!isPanelOpen() && !isPreview()}>
        <Button
          variant="ghost"
          size="sm"
          onClick={openPanel}
          class="h-8 gap-2"
        >
          <SettingsIcon class="size-4" />
          <span class="text-xs">Attributes</span>
        </Button>
      </Show>
      
      {/* Keyboard shortcut hint */}
      <Show when={!isPreview()}>
        <span class="text-xs text-muted-foreground ml-2 hidden sm:inline">
          Press <kbd class="px-1 py-0.5 text-[10px] border rounded bg-muted">P</kbd> to preview
        </span>
      </Show>
    </div>
  );
};
