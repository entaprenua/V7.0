import {
  For, createEffect, Switch, Match, createMemo,
  onMount, createResource, on, createSignal,
} from "solid-js";
import { createStore } from "solid-js/store";
import { htmlEvents, cn } from "~/lib/utils"
import {
   handleClick, 
} from "./../utils";
import { createAsync, createAsyncStore } from "@solidjs/router"
import { useParams as useRouterParams } from "@solidjs/router"
import {useBuilder, convertFromTailwindToCss} from "~"
import { styled, css } from "solid-styled-components"

export const computeProps = (el) => {
   const builder = useBuilder();
   
   // Get element attributes to pass as props to component
   const getElementAttributes = () => {
     const attrs: Record<string, any> = {};
     const element = el();
     if (!element?.attributes) return attrs;
     
     element.attributes.forEach((value: any, key: string) => {
       attrs[key] = value;
     });
     return attrs;
   };
   
   const getEditorModeClasses = () => {
       const base = [];
       
       if (!builder?.preview) {
           base.push("border-dotted", "border-current", "border-2");
       }
       
       if (builder?.selected?.id === el()?.id && !builder?.preview) {
           base.push("outline-dotted", "outline-3", "outline-yellow-300");
       }
       
       if (el()?.isPage() && !el()?.isRoot()) {
           base.push("w-full", "h-100");
       }
       
       return base.join(" ");
   }

   const getComponentClasses = () => {
       const classes: string[] = [];
       
       if (!builder?.preview) {
           classes.push("hover:cursor-pointer");
           classes.push(el()?.name === "text" ? "p-0" : "p-1");
       }
       
       return classes.join(" ");
   }

   const tailwindClasses = createMemo(() => {
        try{                  
           const _css = convertFromTailwindToCss(el()?.tailwind?.replace(/"/g, "")?? "")
	         console.log("Converted: ", _css) 
           return css(_css ?? "")
     	}catch(error) {
          console.error(`Error applying tailwind style`,  error);
          return "" 
	     }
   })

   const _value_ = createMemo(() => {
        const dnd: any = el()?.dragAndDrop ?? {};
        dnd.builder = builder
        
        const isEditor = !builder?.preview;
        const canDrag = isEditor && !el()?.isPage() && !!el()?.parent;
        
        // Get element attributes (from Inspector)
        const elementAttrs = getElementAttributes();
        
        return { 
            // Spread element attributes as props to component
            ...elementAttrs,
            
            get element() { return el() },
            builder: builder,
            get id() { return el()?.id }, 
            draggable: canDrag,
           
           ondragstart: dnd.onDragStart,
           ondrag: dnd.onDrag,
           ondragover: dnd.onDragOver,
           ondragenter: dnd.onDragEnter,
           ondrop: dnd.onDrop,
           ondragleave: dnd.onDragLeave,
           ondragend: dnd.onDragEnd,
           
           get class() { 
               return cn(
                   getComponentClasses(),
                   getEditorModeClasses(),
                   tailwindClasses()
               );
           },
           defaultStyle: cn(getComponentClasses(), getEditorModeClasses()),
           onClick: (event: Event) => {               
              if(!builder?.preview) event.stopPropagation();
              builder.selected = el(); 
           },
       }
   })
   
   return _value_()
}
