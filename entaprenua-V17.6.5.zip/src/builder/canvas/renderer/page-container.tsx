import { ParentComponent } from "solid-js";

export const PageContainer: ParentComponent = (props) => {
  return <div {...props} />;
};
