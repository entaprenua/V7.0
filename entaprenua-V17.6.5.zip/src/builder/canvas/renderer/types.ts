import { JSX, ParentComponent, Accessor } from "solid-js";

export interface BuilderComponent {
  name: string;
  group?: string;
}

export interface ComponentElement {
  id: string;
  name: string;
  group?: string;
  children?: ComponentElement[];
  tailwind?: string;
  [key: string]: unknown;
}

export interface ComponentProps {
  element: ComponentElement;
  class?: string;
  children?: JSX.Element;
  id?: string;
  draggable?: boolean;
  defaultStyle?: string;
  onClick?: (event: Event) => void;
  onDragStart?: (event: DragEvent) => void;
  onDrag?: (event: DragEvent) => void;
  onDragOver?: (event: DragEvent) => void;
  onDragEnter?: (event: DragEvent) => void;
  onDrop?: (event: DragEvent) => void;
  onDragLeave?: (event: DragEvent) => void;
  onDragEnd?: (event: DragEvent) => void;
  [key: string]: unknown;
}

export interface BuilderProps {
  builder: unknown;
}

export interface ComponentRegistry {
  [key: string]: ParentComponent<ComponentProps>;
}

export type ComponentVariant = 
  | 'default'
  | 'primary'
  | 'secondary'
  | 'outline'
  | 'ghost'
  | 'destructive'
  | 'link'
  | 'success'
  | 'warning'
  | 'info';

export type ComponentSize = 
  | 'xs'
  | 'sm'
  | 'md'
  | 'lg'
  | 'xl';

export type Alignment = 'start' | 'center' | 'end' | 'stretch';
export type Direction = 'row' | 'column';
export type Wrap = 'nowrap' | 'wrap' | 'wrap-reverse';
export type Justify = 'start' | 'end' | 'center' | 'between' | 'around' | 'evenly';

export interface LayoutProps {
  direction?: Direction;
  justify?: Justify;
  align?: Alignment;
  wrap?: Wrap;
  gap?: number | string;
}

export interface SpacingProps {
  padding?: number | string;
  paddingTop?: number | string;
  paddingBottom?: number | string;
  paddingLeft?: number | string;
  paddingRight?: number | string;
  margin?: number | string;
  marginTop?: number | string;
  marginBottom?: number | string;
  marginLeft?: number | string;
  marginRight?: number | string;
}

export interface SizeProps {
  width?: number | string;
  height?: number | string;
  minWidth?: number | string;
  minHeight?: number | string;
  maxWidth?: number | string;
  maxHeight?: number | string;
}

export interface ResponsiveProps<T> {
  base?: T;
  sm?: T;
  md?: T;
  lg?: T;
  xl?: T;
  '2xl'?: T;
}

export type ResponsiveValue<T> = T | ResponsiveProps<T>;
