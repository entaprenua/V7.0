import { ErrorBoundary, createMemo, Show, For, splitProps } from "solid-js";
import { componentMap } from "../../utils/component-registry";
import type { ComponentProps, ComponentElement } from "./types";
import { computeProps } from "./computeProps";
import { PageContainer } from "./page-container";

const componentMapWithPageContainer = {
  ...componentMap,
  //"page-container": PageContainer,
};

// HTML text tags that should use Text component with variant prop
const TEXT_VARIANTS = ['h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'p', 'span', 'a', 'strong', 'em', 'code', 'small', 'pre', 'blockquote'];



const BuilderComponentChildren = (props) =>  {
  const childrenElements = createMemo(() => {
     const elements =  {} 
     /* Sometimes actions such as cloning/swapping may be called
      * quicky many times by user, but props.element yet 
      * visible, so we call firstChild once it is visible,
      * to prevent NPE ,
      */
     let child = props.element?.firstChild;
     
     while(child) { 
        /* Dont insert pages here */
	if(!child.isPage()) {
	  elements[child.id] = child 
        }	
	const nextSibling = child.nextSibling
        child = nextSibling 
     }
     return Object.values(elements);
  })


  return (
    <>  
     <Show when={props.element?.name !== "page-container"}
        fallback={<PageContainer {...props} /> }
     >
     <For each={childrenElements()}>
         {(child, index)  => {
           return (
             <BuilderComponent {...props} element={child} /> 
          )
        }}
    </For>
  </Show> 
 </> 
 )
}



export function BuilderComponent(props) {
  const element = () => props.element;
  const computedProps = computeProps(element);
  const [local, others] = splitProps(computedProps, ["class", "onClick"]) 
  
  const componentName = () => props.element?.name;
  const component = createMemo(() => componentMapWithPageContainer[componentName()]);
  
  // Determine variant for HTML text tags
  const variant = createMemo(() => {
    const name = componentName();
    if (TEXT_VARIANTS.includes(name)) {
      return name;
    }
    return undefined;
  });
  
  return (
    <ErrorBoundary
      fallback={(error, reset) => {
        console.error("Rendering failed:", error);
        return <div class="p-4 border border-red-500 bg-red-50 text-red-700">Error: {componentName()}</div>;
      }}
    >
     <Show when={props.element.name !== "page-container"}
         fallback={<PageContainer {...props} />}
      >
       <Show when={component()} fallback={
        <div class="p-2 text-gray-400">Unknown: {componentName()}</div>
       }>
        {() => {
          const Comp = component();
          return (
            <Comp {...computedProps} variant={variant()}>
            { props.element.name }   
            <BuilderComponentChildren element={props.element} {...props} /> 
            </Comp>
          );
        }}
      </Show>
     </Show> 
    </ErrorBoundary>
  );
}

export { BuilderComponentChildren, computeProps };
export type { ComponentProps, ComponentElement };
