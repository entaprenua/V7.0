import { Box } from "~/components/ui/box";
import { Flex } from "~/components/ui/flex";
import { Spinner } from "~/components/ui/spinner";
import { useBuilder, TOP_APPBAR_HEIGHT } from "~";
import { BuilderComponentChildren } from "~/builder/canvas/renderer";
import { createEffect, splitProps, createResource, on, Suspense } from "solid-js";
import { objectToElement} from "~/view-models"
import { storesApi } from "~/lib/api/stores";
import { cn } from "~/lib/utils";
import { computeProps } from "./renderer/";
import { createAsync, useParams } from "@solidjs/router";
import { loadPage } from "./loadPage"
/**
 * RootPage Component
 * 
 * The main entry point for the builder canvas.
 * Fetches the root page data and renders the page content.
 * Also handles creating a default route if none exists.
 */
const ROOT_PAGE_NAME = "root" 

export default function Canvas(props: {name?: string, children?: any }) {
  const builder = useBuilder();
  const pageName = () => props.name ?? ROOT_PAGE_NAME
  const fallbackRootPage = {
     id: crypto.randomUUID(),  
     name: ROOT_PAGE_NAME,
     slug: null, 
     element: builder.createElement("box") 
  }
  const rootPageEl = () => builder?.pages.get(ROOT_PAGE_NAME)?.element
  const pageEl = () => builder?.pages.get(pageName())?.element
  
  const [data] = createResource(() => {
      return storesApi.getPage(builder?.storeDetails?.id, pageName());
  });
    
  createEffect(() => { 
    let page = null 
    try {
      const page =  data() 
      if(page) {  
        page.element = page.element
           ?objectToElement(page.element)
           :builder.createElement("box") 
      }  
    }catch (error) {
       console.error("Failed to load page:", error);
       /* TODO: Check if the error is not_found if true, keep the code below,
        *else throw an error here
       */ 
       if(pageName() === ROOT_PAGE_NAME) {
         page = fallbackRootPage 
        } 
    }finally{
       builder.pages.set(pageName(), page)
    }
  });
  /* Add page-container if rootpage children count is zero */ 
  createEffect(on(() => rootPageEl()?.childrenCount, count => {
    console.log("Eleement", rootPageEl()?.firstChild) 
    if(count === 0) {  
      const pageContainer = builder.createElement("page-container")
      pageContainer.name = "page-container"
      rootPageEl().appendChild(pageContainer)
    } 
  })) 
  /* Initilize builder.selected if undefined */ 
  createEffect(on(rootPageEl, rootElement => { 
    if(builder.selected == undefined)
        builder.selected = rootElement;
  }))
 
  /*
  createEffect(on(() => builder?.routes.length, (count) => {
    if (count === 0) {
      const slug = "/"
      const pageName = "home"
      builder.createRoute(slug, pageName) 
      const page = builder.createPage(pageName);
    }
  }));
  */
  const computedProps = computeProps(pageEl);
  const [local, others] = splitProps(computedProps || {}, ["class"]);

  // Calculate header offset class
  const headerOffsetClass = () => builder?.preview  && pageEl().isRoot()? "" : `mt-${TOP_APPBAR_HEIGHT}`;
  
  // Pass children (current Page component) to the page-container
  const pageContainerProps = () => ({
    ...props,
    children: props.children
  });
  
  return (
    <Box class="overflow-auto w-full h-full">
      <Suspense
        fallback={
          <Flex class="w-full h-full items-center justify-center">
            <Spinner />
          </Flex>
        }
      >
        <Box
          class={cn(
            "overflow-auto m-0.5 h-full",
            headerOffsetClass(),
            local.class
          )}
           {...others} 
         >
         <BuilderComponentChildren 
             element={pageEl() ?? builder.createElement("box")} 
             {...pageContainerProps}
          />
        </Box>
      </Suspense>
    </Box>
  );
}
