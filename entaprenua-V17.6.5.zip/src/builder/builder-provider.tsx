import {
  createContext,  createSignal, 
  useContext, on, createEffect,
} from "solid-js";
import { createStore } from "solid-js/store"
import { ReactiveSet } from "@solid-primitives/set"
import type { Builder } from "./types/Builder";
import ReactiveElement from "./core/ReactiveElement"
import { ReactiveMap } from "./core/primitives/ReactiveMap"
import Record from "./core/Record"
import Clipboard from "./core/Clipboard"
import Selection from "./core/Selection"
import { makePersisted} from "~/lib/utils/makePersisted"
import { storesApi } from "~/lib/api"

const BuilderContext = createContext();


type RouteInfo = {
  pageName: string
  slug: string
}

export const BuilderProvider = (props: { children?: any }) => {
  
  type pageName = string 
  const pages = new ReactiveMap<pageName, ReactiveElement>()
  const [routes, setRoutes] = createStore<RouteInfo[]>([]); 
  const [ selected, setSelected] = 
     createSignal<ReactiveElement | null | undefined>(undefined);
  const [ expandAttributesPanel, setExpandAttributesPanel ] = 
     createSignal<boolean>(true);
  const [ panelPosition, setPanelPosition ] = 
     createSignal<"top" | "bottom" | "left" | "right">("right");
  const [preview, setPreview ] = createSignal<boolean>(false)
  const [isTemplatePreview, setIsTemplatePreview ] = createSignal<boolean>(false)
  const [storeDetails, setStoreDetails] = createSignal<any>(undefined)
  const [userId, setUserId] = createSignal<string | null>(null); 

  const record = new Record()
  const clipboard = new Clipboard();
  const selection = new Selection();
  
  const builder: Builder = {
       get newStoreDetails() { return newStoreDetails() },
       set newStoreDetails(value) { 
           setNewStoreDetails(value) 
        },
        get storeDetails() { return storeDetails()},
        set storeDetails(value) { 
           setStoreDetails(value) 
        },
        pages, 
        get routes() { return routes },
        setRoutes, 
        createRoute(slug: string, pageName: string) { 
              this.setRoutes(prev => [...prev, {slug, pageName}])  
        }, 
        isTemplatePreview,
         setIsTemplatePreview,
       get record(){
	        record.builder = this;
         return record 
       },
       get trash(){
	 return this.record.deletedItems;
       },
       
       get clipboard() {
           clipboard.builder = this;
	   return clipboard;
       },
       
        get preview(){ return preview() }, 
        set preview(value: boolean){ setPreview(value) }, 
        get expandAttributesPanel(){ return expandAttributesPanel() },
        set expandAttributesPanel(value){ setExpandAttributesPanel(value) },
        get panelPosition(){ return panelPosition() },
        set panelPosition(value: "top" | "bottom" | "left" | "right"){ setPanelPosition(value) },
        get selected() { return selected() },
       set selected(element: any){
           setSelected((previous: any) => {
             if(element != null) { 
               const id = element?.id;

               if(previous?.id != id) {
                     return element;
               }
               return previous
             }
             else return null
          })

       },
      createElement: (name) =>  new ReactiveElement(name),
      async loadStore(storeId: string) {
          try {
            const response = await storesApi.getById(storeId)
            if (response && response.data) {
              this.storeDetails = response.data
              return response.data
            }
            return null
          } catch (error) {
            console.error("Failed to load store:", error)
            return null
          }
        },
   }


    return (
       <BuilderContext.Provider value={builder}>
         {props.children}
       </BuilderContext.Provider>
   );
}

export function useBuilder(): Builder { 
    const value: any  =  useContext(BuilderContext);
    return value;
}
