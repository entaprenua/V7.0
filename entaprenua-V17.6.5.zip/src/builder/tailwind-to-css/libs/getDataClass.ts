const getDataClass = (input: string) => {
    return input
        .replaceAll("\n", " ")
        .split(" ")
        .filter((i) => i.startsWith("data-["))
        .map((i) => {
            const match = i.match(/^data-\[([^:]+)\]:(.+)$/);
            if (!match) return null;
            const attrName = match[1].replace(/=.+$/, "");
            const value = match[2];
            return { attribute: `data-${attrName}`, value };
        })
        .filter(Boolean);
};


