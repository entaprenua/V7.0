- in convertFromTailwindToCss,  I changed the outhers ":hover" to "&:hover"
   [ 
     ${hoverClasses.length !== 0 ? `:hover {\n ${convertToCss(hoverClasses)} }` : ""}
         ---to ---
   ${hoverClasses.length !== 0 ? `&:hover {\n ${convertToCss(hoverClasses)} }` : ""}
  ]

- Added data-classes conversion

