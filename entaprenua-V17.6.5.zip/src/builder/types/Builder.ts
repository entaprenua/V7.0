import ReactiveElement from "../core/ReactiveElement";

export interface StoreDetails {
  id?: string;
  ownerId?: string;
  templateId?: string;
  name?: string;
  isTemplate?: boolean;
  [key: string]: any;
}

export interface UserDetails {
  id?: string;
  email?: string;
  name?: string;
  [key: string]: any;
}

export interface PersistedStoreDetails {
  userId?: string;
  id?: string;
  name?: string;
  [key: string]: any;
}

export interface Builder {
  [key: string]: any;
}
