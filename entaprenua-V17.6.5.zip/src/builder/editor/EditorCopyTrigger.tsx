import { Button } from "~/components/ui/button"
import { splitProps } from "solid-js"
import { useEditor } from "./Editor"

export default function EditorCopyTrigger(props){
  
  const editor = useEditor();

  const [local, others] = splitProps(props, [
    "onClick"
  ]);


   const handleCopy = (event) => {
        try{ 
          navigator?.clipboard?.writeText?.(editor?.value ?? "")
        }catch(error) {
           console.error("Error Copying: ", error)
       }
       local.onClick?.(event); 
   }

   return (
     <Button 
       variant="ghost"
       onClick={handleCopy}
       {...others}
     />
   )
}


