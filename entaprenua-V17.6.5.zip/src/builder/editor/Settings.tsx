import {
  Popover, Box, MenuItem, MenuList, Flex, Switch, IconButton, 
} from "~/components/ui"
import { SettingsIcon }from "~/icons"

import { createSignal } from "solid-js"

import { EditorView, lineNumbers } from "@codemirror/view";
import { extensions } from "./extensions";

/* TODO: createExtension is not reactive. fix it */

export const Settings = (props) => {
  
   const {createExtension} = props.editor;

   const [anchorEl, setAnchorEl] = createSignal<HTMLElement | null>(null)
   const [showLineNumbers, setShowLineNumbers] = createSignal(false);
   
   
   const toggleSettings = (event) => {
      setAnchorEl(anchorEl()? null: event.currentTarget)
   }
   createExtension(showLineNumbers()? lineNumbers(): [])
   
   const toggleLineNumbers = (event, value) => {
     setShowLineNumbers(!showLineNumbers());
   }
   



  return (
   <Box /*modifier={{ml: "auto", ...props.modifier}}*/>    
    {/*<IconButton
       onClick={toggleSettings} 
       color="default"
      > <SettingsIcon variant="outlined"  />
      </IconButton> 

    <Popover
      anchorEl={anchorEl()}
      expanded={anchorEl()? true: false}
      onClose={toggleSettings} 
      PaperProps={{
        sx: {
	  pb: "20px",
	}
      }}
   >
       <MenuList>
        <MenuItem>
         <Flex> 
 	 Show line number
          <Switch onChange={toggleLineNumbers} />
         </Flex>
        </MenuItem>
        <MenuItem>
         <Flex>
 	 Dark Mode 
 	 <Switch />
 	</Flex>
        </MenuItem>
       </MenuList>
     </Popover> 
    */} 
    </Box> 
  )
}
