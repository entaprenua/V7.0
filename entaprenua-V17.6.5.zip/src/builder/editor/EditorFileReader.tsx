import { 
   FileReader, FileReaderHiddenInput, FileReaderTrigger
} from "~/components/ui/file-reader"
import { useEditor } from "./Editor"
import { splitProps } from "solid-js"

export default function(props){
 
  const editor = useEditor();
  const [_, others ] = splitProps(props, [
    "children"
  ])
  
  const handleChange = (value) => { 
         let $ = value.toString()
         /* TODO:  Fix the [Object Event] thing in the end of
           * value and learn why passing insert: value is
            * leading to infinite loop
         */
          editor?.insert($)
  }

  return(
    <FileReader
       onChange={(value) => {
            props.onChange?.(value)  
	      ??
            handleChange(value); 
       }} 
     >

          <FileReaderTrigger {...others}> 
	    {props.children} 
	  </FileReaderTrigger>
	<FileReaderHiddenInput />
      </FileReader>
  )
}
