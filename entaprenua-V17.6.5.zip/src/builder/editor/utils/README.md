- This library is created by:[
   https://github.com/riccardoperra/solid-codemirror/archive/refs/heads/main.zip]

- Also can be stored into node-modules via: https://www.npmjs.com/package/solid-codemirror (basic docs here too)
- The lib is also used by <CodeImage application>








