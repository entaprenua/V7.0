import { Box } from "~/components/ui/box"
import { Button } from "~/components/ui/button"
import { HorizontalDivider } from "~/components/ui/horizontal-divider"
import { Flex } from "~/components/ui/flex"
import { IconButton } from "~/components/ui/icon-button"
import { TextButton } from "~/components/ui/text-button"
import { Spacer } from "~/compoents/ui/spacer"
import { 
 mergeProps, splitProps, createMemo,
 createEffect, on, createSignal, onMount,
 Component, ComponentProps, JSX, useContext, createContext,
} from "solid-js";
import { createStore } from "solid-js/store"
import { Settings } from "./Settings"

import { createCodeMirror } from "./utils";
import { css } from '@codemirror/lang-css';
import { xml } from "@codemirror/lang-xml"
import { javascript } from "@codemirror/lang-javascript"
import { extensions as defaultExtensions  } from "./extensions";
import { EditorView, lineNumbers } from "@codemirror/view";
import { EditorState, Transaction, Compartment, Text } from '@codemirror/state'
import { useBuilder } from "~";
import { cn } from "~/lib/utils"

type TransactionSpecProps = {
    changes: { from: number, to?: number, insert?: string, delete?: string}
}

type EditorProps = {
      defaultValue?: string, 
      onChange?: (value: string) => void
      onUpdate?: (tr, view) => void 
      children?: JSX.Element
      transaction?: TransactionSpecProps 
      extensions?: string[]
} & ComponentProps<"div">

type Value = {
  defaultValue: any
  setDefaultValue: any, 
  value: any
  setValue: any
  transaction: any
  setTransaction: any
  clear: any
  insert: any
}

const EditorContext: any = createContext();
const useEditor = (): Value  => useContext(EditorContext);

const Editor: Component<EditorProps> = (rawProps) => {
   
   const builder = useBuilder(); 
   const props = mergeProps({
   }, rawProps);
   
   const [local, others] = splitProps(props, [
     "defaultValue",
     "onChange",
     "class", 
     "onUpdate",
     "transaction",
     "extensions",
   ])
   
   const [defaultValue, setDefaultValue] = createSignal(local.defaultValue ?? "");
   const [value, setValue] = createSignal(defaultValue()) 
   const [transaction, setTransaction] = createSignal<any>(undefined)
   

   const { editorView, ref: container, createExtension } = createCodeMirror({
      value: defaultValue(), 
      onValueChange: (value) => { 
         local.onChange?.(value) 
         setValue(value); 
      },
      onModelViewUpdate: (modelView) => { 
      },
      onTransactionDispatched: (tr: Transaction, view: EditorView) => {
         local.onUpdate?.(tr, view);
      }
    })
   
   defaultExtensions.forEach(extension => {
      createExtension(extension)
   })
   
   props.extensions?.forEach(name => {
     if(name === "javascript")createExtension(javascript())
     else if(name === "css") createExtension(css())
     else if(name === "xml") createExtension(xml())
     else if(name === "jsx") { 
       createExtension(javascript({typescript: true, jsx: true}))
       /* Later do more */
     }
  }) 
  createEffect(on(transaction, (data) => {
      try{ 
       if(data) editorView()?.dispatch(data);   
      }catch(error) {
        console.error("Transaction dispatch failed with error: ", error);
      }
   }))  

 
   const view = {                   
     get container(){ return container }, 
     get value() { return value() },
     setValue: setValue, 
     get defaultValue() { return defaultValue() },
     setDefaultValue: setDefaultValue,
     get transaction() { return transaction() },
     setTransaction: setTransaction,
     clear(){
        try{ 
          setTransaction({
            changes: {                                                 
              from: 0, to: value()?.length ?? 0, delete: value() ?? ""
            }
          }) 
        }catch(error) {
         console.error("Clearing editor failed with error: ", error)
        }
      
    },
    insert(token: string = "") {
      try {
        setTransaction({
          changes: {from: value()?.length ?? 0, insert: token}
        })
      }catch(error) {
        console.error("Insertion into editor failed with error: ", error)
      }
    }
   
  }


  return (
   <EditorContext.Provider value={view}>  
    <Box 
      class={cn(local.class)} 
      {...others} 
    />
   </EditorContext.Provider> 
  )
}

const EditorTextBox = (props) => {
  const editor = useEditor()
  const [local, others] = splitProps(props, ["ref", "class"]) 
  return (
    <Box 
      ref={editor.container}
      class={cn("overflow-auto", local.class)} 
      {...others}
    />
  )
}




export type { TransactionSpecProps }
export { Editor,  useEditor, EditorTextBox }












