import { Button } from "~/components/ui/button"
import { splitProps } from "solid-js"
import { useEditor } from "./Editor"

export default function EditorDeleteTrigger(props){
  
  const editor = useEditor();

  const [local, others] = splitProps(props, [
    "onClick",
    "onDelete"
  ]);

  
  const handleDelete = (event) => {
	 try { 
           local.onDelete?.() ?? editor?.clear()
	 }catch(error) {
             console.log("Deleting editor view failed with error: ", error);
         }
         local.onClick?.(event); 
  }


   return (
     <Button 
       variant="ghost"
       onKeyDown={(e) => {
	if(e.key == "Enter")  handleDelete(e) 
       }} 
       onClick={handleDelete}
       {...others}
     />
   )
}


