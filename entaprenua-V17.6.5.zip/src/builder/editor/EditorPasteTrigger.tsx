import { Button } from "~/components/ui/button"
import { splitProps } from "solid-js"
import { useEditor } from "./Editor"

export default function EditorPasteTrigger(props){
  
  const editor = useEditor();

  const [local, others] = splitProps(props, [
    "onClick",
    "onPaste"
  ]);

  
  const handlePaste = (event) => {
         try { 
            navigator?.clipboard?.readText?.()?.then(text => {
               local.onPaste?.(text) ?? editor?.insert(text)
            })
         }catch(error) {
             console.log("Error Pasting: ", error);
         }
         local.onClick?.(event); 
  }


   return (
     <Button 
       variant="ghost"
       onClick={handlePaste}
       {...others}
     />
   )
}


