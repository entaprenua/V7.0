import { SidebarProvider, Sidebar, SidebarContent, useSidebar } from "~/components/ui/sidebar";
import { PagesSidebarContent } from "./panels/pages-panel";
import { useBuilder } from "./builder-provider";
import Toolbar from "./toolbar";
import Canvas   from "./canvas";
import { Menubar } from "./menubar";
import { Standardtoolbar } from "./standardtoolbar";
import { ComponentContext } from "./utils/ui/ComponentContext";
import { AttributesPanel } from "./inspector"
import { QuickActions } from "./quick-actions";
import { useColorMode, cn } from "~/lib/utils"
import PencilIcon from "~/icons/Pencil"
import { onMount, on, Show, createEffect, createSignal } from "solid-js";
import { useParams, useNavigate } from "@solidjs/router";
import { routes } from "~/lib/utils/routes";
import { storesApi } from "~/lib/api";
import { Flex, Text, Heading, Button, Separator } from "~/components/ui";
import LoaderIcon from "lucide-solid/icons/loader";
import AlertCircleIcon from "lucide-solid/icons/alert-circle";
import ArrowLeftIcon from "lucide-solid/icons/arrow-left";

/**
 * Unified Builder Page
 * 
 * Supports two modes:
 * - Edit mode: ?storeId=xxx - Edit an existing store
 * - Preview mode: ?templateId=xxx - Preview a template
 * 
 */

function SidebarContentWrapper(props: { children: any }) {
  const { open } = useSidebar();
  
  return (
    <div class={`flex-1 transition-all duration-200 ${open() ? 'ml-64' : 'ml-0'}`}>
      {props.children}
    </div>
  );
}

export default function BuilderHome(props) {
  const builder = useBuilder();
  const navigate = useNavigate();
  const { colorMode } = useColorMode();
  const params = useParams<{
    storeId?: string;
    templateId?: string;
  }>();

  const [isLoading, setIsLoading] = createSignal(true);
  const [error, setError] = createSignal<string | null>(null);

  const storeId = () => params.storeId;
  const templateId = () => params.templateId;

  createEffect(on(() => builder?.storeDetails, async (storeDetails) => {
    if (storeDetails?.id) {
      // API returns array directly (unwrapped)
      const routes = await storesApi.getRoutes(storeDetails.id);
      
      if (routes && builder) {
        builder.setRoutes(routes);
        }
    }
  }, { defer: true }));

  onMount(async () => {
    setIsLoading(true);
    setError(null);

    try {
      // Mode 1: Edit existing store
      if (storeId()) {
        builder.setIsTemplatePreview(false);
        builder.preview = false;
        
        const response = await storesApi.getById(storeId()!);
        console.log("Store API response:", response);
        
        // Handle both response formats: { success, data } or direct object
        const storeData = response.data || response;
        if (storeData && storeData.id) {
          builder.storeDetails = storeData;
          // Load the store's router
          await builder.loadStore(storeId()!);
        } else {
          setError("Store not found");
        }
      }
      // Mode 2: Preview template (public API - anyone can preview)
      else if (templateId()) {
        builder.setIsTemplatePreview(true);
        builder.preview = false;
        
        const response = await storesApi.getTemplateById(templateId()!);
        console.log("Template API response:", response);
        
        // Handle both response formats: { success, data } or direct object
        const storeData = response.data || response;
        if (storeData && storeData.id) {
          builder.storeDetails = storeData;
          // Load the template's router
          await builder.loadStore(templateId()!);
        } else {
          setError("Template not found");
        }
      }
      // No valid params
      else {
        setError("Missing storeId or templateId parameter");
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load");
    } finally {
      setIsLoading(false);
    }
  });

  // Cleanup on unmount
  createEffect(() => {
    return () => {
      // Reset builder state when leaving
      builder.preview = false;
    };
  });

  return (
    <Show
      when={!isLoading()}
      fallback={
        <Flex class="min-h-screen items-center justify-center">
          <Flex class="flex-col items-center gap-4">
            <LoaderIcon class="size-8 animate-spin" />
            <Text class="text-muted-foreground">Loading builder...</Text>
          </Flex>
        </Flex>
      }
    >
      <Show
        when={!error()}
        fallback={
          <Flex class="min-h-screen items-center justify-center">
            <Flex class="flex-col items-center gap-4 text-center">
              <AlertCircleIcon class="size-12 text-destructive" />
              <Heading level={3}>{error()}</Heading>
              <Button onClick={() => navigate(routes.stores)}>
                <ArrowLeftIcon class="size-4 mr-2" />
                Back to Stores
              </Button>
            </Flex>
          </Flex>
        }
      >
      <SidebarProvider defaultOpen={false}>
      <Show
        when={builder?.storeDetails}
        fallback={
          <div class="flex items-center justify-center h-screen">
            <div class="flex flex-col items-center gap-4">
              <div class="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
              <span class="text-sm text-muted-foreground">Loading builder...</span>
            </div>
          </div>
        }
      >
        <div class="h-screen flex flex-col overflow-hidden">
          {/* Toolbar - sticky at top, higher z-index */}
          <div class="sticky w-full top-0 z-50">
           <ComponentContext>
            <Show
               when={!builder.preview}
               fallback={
                  <Button
                    class="absolute rounded-full z-50 p-2 bg-secondary"
                    onClick={() => builder.preview = false}
                  >
                    <PencilIcon /> Edit
                  </Button>
               }
             >
             <Flex
               class={cn(
                 colorMode() === "light" ? "bg-white border-b" : "bg-black border-b",
                  "items-center gap-2 px-2 py-1 w-full"
               )}
               >
                <Menubar />
                <Separator orientation="vertical" class="h-6" />
                <Standardtoolbar />
                 <Separator orientation="vertical" class="h-6" />
                 <AttributesPanel />
                <QuickActions />
             </Flex>
            </Show>
            </ComponentContext>
          </div>

          {/* Main content area */}
          <div class="flex flex-1 overflow-hidden">
            {/* Sidebar - fixed left, below toolbar */}
            <Sidebar side="left" class="top-30" collapsible="offcanvas">
              <SidebarContent>
                <PagesSidebarContent />
              </SidebarContent>
            </Sidebar>

            {/* Canvas - takes remaining space */}
            <div class="flex-1 overflow-hidden mx-2 w-[100vw]">
              <Canvas {...props} />
            </div>
          </div>
        </div>
        </Show>
       </SidebarProvider>
     </Show>
   </Show>
 );
}

