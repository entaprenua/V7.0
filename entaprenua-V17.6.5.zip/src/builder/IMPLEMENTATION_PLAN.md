# Builder Component Registry - Implementation Plan

## Overview

Refactor `builder/body/content/*` to use a standard component registry pattern that's type-safe, maintainable, and follows industry standards.

## Current State

```
builder/body/content/
├── Component.tsx          # Big Switch/Match for routing
├── Children.tsx          # Recursive children renderer
├── layout/
│   ├── box.tsx
│   ├── flex.tsx
│   ├── grid.tsx
│   └── index.tsx
├── input/
│   ├── button.tsx
│   ├── input.tsx
│   └── index.tsx
├── data-display/
│   ├── image.tsx
│   ├── text.tsx
│   └── index.tsx
├── feedback/
│   ├── alert.tsx
│   └── index.tsx
├── navigation/
│   └── ...
└── surface/
    └── ...
```

**Problems:**
- Switch/Match in Component.tsx needs updating for each new component
- No type safety
- Group + name mapping is unnecessary complexity
- Inconsistent prop handling

## Target State

```
builder/
├── components/
│   ├── registry.ts        # Component registry (single source of truth)
│   ├── index.ts           # Main renderer (simple lookup)
│   ├── types.ts          # TypeScript interfaces
│   │
│   ├── layout/           # Layout components
│   │   ├── Box.tsx
│   │   ├── Flex.tsx
│   │   └── Grid.tsx
│   │
│   ├── input/            # Form components
│   │   ├── Button.tsx
│   │   ├── Input.tsx
│   │   └── ...
│   │
│   └── ...
│
└── body/
    └── content/          # Keep for backward compat, re-export from components/
```

## Implementation Plan

### Phase 1: Create Types
- [ ] Create `builder/components/types.ts` with:
  - `ComponentSchema` interface (matches server JSON)
  - `ComponentProps` interface
  - Type-safe variant enums

### Phase 2: Create Component Registry
- [ ] Create `builder/components/registry.ts`
- [ ] Register all existing components
- [ ] Export as type-safe record

### Phase 3: Create Main Renderer
- [ ] Create `builder/components/index.tsx`
- [ ] Simple lookup: `components[element.name]`
- [ ] Remove Switch/Match complexity

### Phase 4: Refactor Individual Components
- [ ] Standardize prop handling with splitProps
- [ ] Add TypeScript types to each component
- [ ] Fix error handling

### Phase 5: Cleanup
- [ ] Rename folder structure
- [ ] Update imports
- [ ] Add documentation

## Benefits

| Aspect | Before | After |
|--------|--------|-------|
| Add component | Edit 2+ files | Add to registry |
| Type safety | None | Full |
| Code changes | O(n) | O(1) |
| Testing | Hard | Easy |

## Migration Path

1. Create new `components/` folder
2. Build registry alongside existing code
3. Switch imports to new location
4. Remove old `content/` structure

## Notes

- Server stores `name` only (e.g., "box", "button")
- Match exactly: `components["box"]` → Box component
- No need for group categorization in registry
