import ReactiveElement from "../core/ReactiveElement";

export const handleDelete = (builder: any, target?: ReactiveElement) => {
   const selectedTarget = target ?? builder.selected;
   const parent = selectedTarget.parent;
  
  try {
   if(selectedTarget.isPage()) { 
 	console.error("Deleting page element is not allowed");
   }else {
      if(parent?.firstChild?.id == selectedTarget.id) {
 	if(selectedTarget.nextSibling == null) {
 	  builder.selected = parent;
 	}else {
 	   builder.selected =  selectedTarget.nextSibling;
 	}
       }
       else if(selectedTarget.nextSibling) {
  	 builder.selected = selectedTarget.nextSibling;
       }
       else if(parent?.lastChild?.id == selectedTarget.id) {
           builder.selected = selectedTarget.previousSibling;
       }
       else if(selectedTarget.isAttribute()) {
        const attributeOf = selectedTarget.attributeOf;
 	attributeOf?.deleteAttribute(selectedTarget.attributeName)
        builder.selected = attributeOf; 
      }else {
 	console.log("Error deleting element: ", selectedTarget);
       }
       parent?.removeChild(selectedTarget);
    } 
   }catch(error) {
 	  console.error("Error deleting: ", error)
  }
}
	

