export * from "./ui"; 
export { 
  componentRegistry, 
  componentMap,
  componentMeta,
  COMPONENT_CATEGORIES,
  type ComponentConfig,
  type ComponentCategory,
  type ComponentMeta,
} from "./component-registry";
export { useSelectedElement, getAllowedChildren, isValidChild, getComponentAttributes } from "./component"
export { component } from "./component"
export { handleInsert } from "./handleInsert";
export { handleDelete } from "./handleDelete";
export * from "./isInsertable"
