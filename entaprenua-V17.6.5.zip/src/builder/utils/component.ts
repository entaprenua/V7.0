import { createSignal, createEffect, createMemo, Accessor, on } from "solid-js";
import { componentRegistry, type ComponentConfig } from "./component-registry";
import { useBuilder } from "~";

export type ElementConfig = {
  prevName: string | null;
  prevConfig: ComponentConfig[string] | null;
  name: string | null;
  config: ComponentConfig[string] | null;
  attributes: Record<string, unknown> | null;
  contextuals: Record<string, unknown> | null;
  role: string;
  parentName: string | null;
};

const LAYOUT_COMPONENTS = ["box", "flex", "grid"];

function getComponentConfig(elementName: string | null | undefined): ComponentConfig[string] | null {
  if (!elementName) return null;
  return componentRegistry[elementName] ?? null;
}

function getParentConfig(element: { parent: { name: string } | null }): ComponentConfig[string] | null {
  if (!element?.parent?.name) return null;
  return componentRegistry[element.parent.name] ?? null;
}

function isAllowedChild(childName: string, parentConfig: { contextuals?: Record<string, unknown> } | null): boolean {
  if (!parentConfig?.contextuals) return false;
  return childName in parentConfig.contextuals;
}

export function useSelectedElement() {
  const builder = useBuilder();
  const selectedElement = () => builder.selected;

  const [prevName, setPrevName] = createSignal<string | null>(null);
  const [prevConfig, setPrevConfig] = createSignal<ComponentConfig[string] | null>(null);
  const [currentName, setCurrentName] = createSignal<string | null>(null);
  const [currentConfig, setCurrentConfig] = createSignal<ComponentConfig[string] | null>(null);
  const [parentName, setParentName] = createSignal<string | null>(null);
  const [insertRole, setInsertRole] = createSignal<"first-child" | "last-child" | "replace">("first-child");

  createEffect(on(selectedElement, (element) => {
    if (!element) {
      setCurrentName(null);
      setCurrentConfig(null);
      setParentName(null);
      return;
    }

    const newName = element.name;
    const isLayout = LAYOUT_COMPONENTS.includes(newName);
    const isSameComponent = newName === prevName();

    setPrevName(currentName());
    setPrevConfig(currentConfig());

    setCurrentName(newName);

    let config: ComponentConfig[string] | null = null;
    let pName: string | null = null;

    if (isLayout) {
      config = getComponentConfig(newName);
      pName = element.parent?.name ?? null;
      setParentName(pName);
    } else if (isSameComponent && prevConfig()) {
      config = prevConfig();
    } else if (element.parent?.name) {
      const parentConfig = getComponentConfig(element.parent.name);
      const childConfig = parentConfig?.contextuals?.[newName] as { attributes?: Record<string, unknown>; contextuals?: Record<string, unknown> } | undefined;
      if (childConfig) {
        config = { 
          attributes: childConfig.attributes ?? {},
          contextuals: childConfig.contextuals ?? {}
        };
        pName = element.parent.name;
      } else {
        config = getComponentConfig(newName);
        pName = element.parent?.name ?? null;
      }
    } else {
      config = getComponentConfig(newName);
    }

    setCurrentConfig(config);
    setParentName(pName);
  }, { defer: true }));

  const elementConfig: Accessor<ElementConfig> = createMemo(() => ({
    get prevName() { return prevName(); },
    get prevConfig() { return prevConfig(); },
    get name() { return currentName(); },
    get config() { return currentConfig(); },
    get attributes() { return currentConfig()?.attributes ?? null; },
    get contextuals() { 
      const ctx = currentConfig()?.contextuals;
      return ctx && Object.keys(ctx).length > 0 ? ctx : null;
    },
    get role() { return insertRole(); },
    set role(value: string) { setInsertRole(value as "first-child" | "last-child" | "replace"); },
    get parentName() { return parentName(); },
  }));

  return elementConfig;
}

export function getAllowedChildren(elementName: string): string[] {
  const config = componentRegistry[elementName];
  if (!config?.contextuals) return [];
  return Object.keys(config.contextuals);
}

export function isValidChild(parentName: string, childName: string): boolean {
  const parentConfig = componentRegistry[parentName];
  if (!parentConfig?.contextuals) return false;
  return childName in parentConfig.contextuals;
}

export function getComponentAttributes(componentName: string): Record<string, unknown> | null {
  const config = componentRegistry[componentName];
  return config?.attributes ?? null;
}

export { componentRegistry, type ComponentConfig } from "./component-registry";

export const component = useSelectedElement;
