import { 
  FileField,  FileFieldTrigger, 
  FileFieldLabel, FileFieldHiddenInput, FileFieldItem,  FileFieldItemList, 
  FileFieldItemName, FileFieldItemSize, FileFieldItemDeleteTrigger, 
} from "~/components/ui/file-field"
import { useBuilder } from "~"
import  { mergeProps } from "solid-js"

export const Media = (props) => {
   
   const builder = useBuilder();

   props = mergeProps({
      multiple: true,
      maxFiles: 100, 
   }, props)
   
    const handleFileChange = (details) => {
      const files = details.acceptedFiles
      files.forEach((file, index) => {
        const url = URL.createObjectURL(file);
        const el = builder.createElement("media");
        el.setAttribute("src", url)
          .setAttribute("fileName", file.name) 
	  .setStyle("height", "200px")
          .setStyle("width", "200px")
        builder.record.add({element: el, role: "lastChild"}) 
     })
   }

   return (
     <FileField
        onFileChange={handleFileChange}	
	{...props}
      >
       <FileFieldTrigger> {props.triggerLabel} </FileFieldTrigger>
       <FileFieldHiddenInput /> 
   </FileField>
  )
}
