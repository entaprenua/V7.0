import { createSignal, createEffect, For, Show, createMemo } from "solid-js";
import { Button } from "~/components/ui/button";
import { cn } from "~/lib/utils";

export type InsertPosition = 
  | "first-child" 
  | "last-child" 
  | "previous-sibling" 
  | "next-sibling"
  | "wrapper"
  | "replacer";

interface InsertPositionOption {
  value: InsertPosition;
  label: string;
  icon: string;
  description: string;
  disabled?: boolean;
}

interface InsertPositionSelectorProps {
  value?: InsertPosition;
  onChange?: (position: InsertPosition) => void;
  disabled?: boolean;
  showLabels?: boolean;
  class?: string;
}

const POSITIONS: InsertPositionOption[] = [
  { 
    value: "wrapper", 
    label: "Wrap", 
    icon: "⊞",
    description: "Wrap element with new component"
  },
  { 
    value: "replacer", 
    label: "Replace", 
    icon: "↻",
    description: "Replace selected element"
  },
  { 
    value: "first-child", 
    label: "Inside First", 
    icon: "◤",
    description: "Insert as first child"
  },
  { 
    value: "last-child", 
    label: "Inside Last", 
    icon: "◥",
    description: "Insert as last child"
  },
  { 
    value: "previous-sibling", 
    label: "Before", 
    icon: "↑",
    description: "Insert before selected element"
  },
  { 
    value: "next-sibling", 
    label: "After", 
    icon: "↓",
    description: "Insert after selected element"
  },
];

export function InsertPositionSelector(props: InsertPositionSelectorProps) {
  const [position, setPosition] = createSignal<InsertPosition>(props.value || "last-child");
  
  createEffect(() => {
    if (props.value !== undefined && props.value !== position()) {
      setPosition(props.value);
    }
  });

  const handleSelect = (pos: InsertPosition) => {
    setPosition(pos);
    props.onChange?.(pos);
  };

  return (
    <div class={cn("flex flex-wrap gap-1", props.class)}>
      <For each={POSITIONS}>
        {(option) => (
          <Button
            variant={position() === option.value ? "secondary" : "ghost"}
            size="sm"
            class={cn(
              "h-8 px-2 text-xs flex-col gap-0.5",
              props.disabled && "opacity-50 cursor-not-allowed"
            )}
            disabled={props.disabled || option.disabled}
            onClick={() => handleSelect(option.value)}
            title={option.description}
          >
            <span class="text-sm">{option.icon}</span>
            <Show when={props.showLabels !== false}>
              <span class="text-[10px]">{option.label}</span>
            </Show>
          </Button>
        )}
      </For>
    </div>
  );
}

// Hook to get available positions based on selected element
export function useInsertPositions(selectedElement: any, parentElement: any) {
  return createMemo(() => {
    const positions: InsertPositionOption[] = [];
    
    // Always available: first-child, last-child
    if (selectedElement) {
      positions.push(POSITIONS.find(p => p.value === "first-child")!);
      positions.push(POSITIONS.find(p => p.value === "last-child")!);
    }
    
    // Previous/Next sibling - only if parent exists
    if (parentElement) {
      positions.push(POSITIONS.find(p => p.value === "previous-sibling")!);
      positions.push(POSITIONS.find(p => p.value === "next-sibling")!);
    }
    
    // Wrapper - only if element can be wrapped
    if (selectedElement && selectedElement.name !== "root") {
      positions.push(POSITIONS.find(p => p.value === "wrapper")!);
    }
    
    // Replacer - only if not root
    if (selectedElement && selectedElement.name !== "root") {
      positions.push(POSITIONS.find(p => p.value === "replacer")!);
    }
    
    return positions;
  });
}

// Export default position
export const DEFAULT_INSERT_POSITION: InsertPosition = "last-child";
