import {
  useContext, createContext, createSignal, 
  createEffect, on, mergeProps, Context,
} from "solid-js";
import { createStore } from "solid-js/store";
import { component } from "./../component"
import type { Component as ComponentContextProps} from "./../component"

const ComponentContxt: Context<ComponentContextProps | undefined> = createContext();

export const useComponent = (): ComponentContextProps =>{
    const value = useContext(ComponentContxt);
    return value!;
}

export  function ComponentContext(props){ 
    const value = component()
    return (
     <ComponentContxt.Provider value={value}>
         { props.children } 
    </ComponentContxt.Provider>
  )
};
























