import {
 Select as Slect, SelectTrigger,
 SelectValue, SelectContent, 
 SelectItem, SelectLabel,
} from "~/components/ui";
import { 
  createSignal,
} from "solid-js"
import { useAttribute } from "./AttributeContext";
import { cn, Z_INDEX} from "~/lib/utils"
import { useComponent } from "./ComponentContext"

export const ComponentRole = (props) => {
   const component = useComponent();
   const roles = [ "previous-sibling", "first-child", "last-child", 
     "next-sibling", "replacer", "wrapper"
    ]

   return (
      <Slect
        defaultValue={component?.role} 
	onChange={(value) => component.role = value} 
	itemComponent={(props) => 
	   <SelectItem item={props.item}>{(props.item as any).rawValue}</SelectItem>
	}
	closeOnSelection={false}	
        options={roles}	
        class={cn("flex flex-col items-center", props.class)} 
       >
        <SelectLabel class="opacity-[0.6]"> {props.label} </SelectLabel>	
	<SelectTrigger 
          class="hover:cursor-pointer w-auto border-none"
	  aria-label={props["aria-label"] ?? props.of}
	 > 
	 <SelectValue<string>> 
	    {(state) => {
	       return (
	         <>
	          {state?.selectedOption()}
	         </>
	        )
	    }}
	  </SelectValue>
         </SelectTrigger>
         <SelectContent class={cn(Z_INDEX, props.class)}/>
     </Slect> 
  )
} //EndFunction






















