import { 
  Flex,
} from "~/components/ui";

import { 
   Show
} from 'solid-js';
import { ComponentRole } from "./ComponentRole"
import { useComponent } from "./ComponentContext"
import { useBuilder } from "~";
import { cn } from "~/lib/utils"

export default function ForbiddenInsertAlert(props){
   
    const builder = useBuilder()
    const selectedEl = () => builder.selected;
    const componentContext = useComponent(); 
    
     /* Only replacement here can be an issue if wrongly done, so check */ 
     /*if role of incoming is to replace targetel, then target el should have
     * not contextuals and if has, it should have no children
    */
    const isIrreplaceable = () => 
       componentContext?.role === "replacer" &&   
       (selectedEl().isPage() || 
	(componentContext?.contextuals && selectedEl()?.childrenCount > 0)
      )
    const isInsertForbidden = () =>  
	  componentContext?.role?.includes("sibling") && selectedEl().isRoot() 
    /* This also disabled scrolll of inner children due to z-index, if
     * pointer events is none
     */
    return (
     <Flex flexDirection="col" 
          class={cn(
             {"pointer-events-none z-3000 bg-gray-100 text-gray-400 overflow-auto":  isIrreplaceable() || isInsertForbidden() || props.rules }, props.class
	 )}
     > 
       <Show when={isIrreplaceable()}>
         <pre class="text-red-600 text-sm"> Forbidden replace attempt </pre>
       </Show>
       <Show when={isInsertForbidden()}>
        <pre class="text-red-600 text-sm"> Forbidden insert attempt </pre> 
       </Show>
       <Show when={props.rules}>
         <pre class={"text-red-600 text-sm"}>
 	    {props.rationale/*if specific  specific props.rules are broken */}
         </pre> 
       </Show> 
      {props.children}
    </Flex>
  )
}























