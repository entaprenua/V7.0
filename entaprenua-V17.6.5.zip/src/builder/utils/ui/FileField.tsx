import { 
  FileField as FileFld, FileFieldTrigger, FileFieldDropzone,
  FileFieldLabel, FileFieldHiddenInput, FileFieldItem,  FileFieldItemList, 
  FileFieldItemName, FileFieldItemSize, FileFieldItemDeleteTrigger, 
  FileFieldItemPreviewImage, Button, Popover, 
  PopoverTrigger, PopoverContent, PopoverArrow, 
} from "~/components/ui"
import  Trash2Icon  from "~/icons/Trash2"
import  { mergeProps } from "solid-js"

export const FileField = (props) => {
  
   props = mergeProps({
      multiple: true,
      maxFiles: 10, 
   }, props)
   
   return (
     <FileFld
	{...props}
      >
       <FileFieldLabel> {props.label} </FileFieldLabel>
       <FileFieldTrigger> {props.triggerLabel} </FileFieldTrigger>
       <FileFieldHiddenInput /> 
       <Popover>
        <PopoverTrigger> {props.previewTriggerLabel} </PopoverTrigger>
	<PopoverContent class="z-2000 max-h-100 overflow-auto"> 
          <PopoverArrow /> 
	  <FileFieldItemList> 
            {(file) => {
	      const src = URL.createObjectURL(file);
         
	     return ( 
	       <FileFieldItem>
		 {/*<FileFieldItemPreviewImage  class="h-100 w-100"/> */} 
		 <FileFieldItemName />
		 <FileFieldItemSize />
		 <FileFieldItemDeleteTrigger> 
		   <Trash2Icon />
		 </FileFieldItemDeleteTrigger>
	       </FileFieldItem>
             )
	   }}
       </FileFieldItemList>
     </PopoverContent>
    </Popover>
   </FileFld>
  )
}
