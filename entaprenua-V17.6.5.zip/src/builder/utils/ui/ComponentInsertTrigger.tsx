import { Button } from "~/components/ui/button";
import { splitProps, mergeProps, createSignal } from "solid-js";
import { cn } from "~/lib/utils";
import { useBuilder } from "~";

interface ComponentInsertTriggerProps {
  name?: string;
  value?: any;
  role?: "first-child" | "last-child" | "previous-sibling" | "next-sibling" | "wrapper" | "replacer";
  onInsert?: (elementId: string) => void;
  onClick?: (e: MouseEvent) => void;
  class?: string;
  children?: any;
  as?: any;
  variant?: string;
  href?: string;
}

export const ComponentInsertTrigger = (props: ComponentInsertTriggerProps) => {
  const merged = mergeProps({
    role: "last-child",
    variant: "ghost",
  }, props);
  
  const [local, others] = splitProps(merged, [
    "name",
    "value",
    "role",
    "onInsert",
    "onClick",
    "class",
    "children",
    "as",
    "variant",
    "href",
  ]);
  
  const builder = useBuilder();
  const [id, setId] = createSignal("");

  const handleClick = (e: MouseEvent) => {
    try {
      local.onClick?.(e);
      
      const name = local.name;
      const role = local.role;
      const value = local.value;
      
      let target = value;
      if (!value && name) {
        target = builder.createElement(name);
      }
      
      if (target) {
        setId(target.id);
        builder.record.add({ element: target, role });
        local.onInsert?.(target.id);
      }
    } catch (error) {
      console.log("Insert failed with error:", error);
    }
  };

  const Component = local.as || Button;
  
  return (
    <Component
      variant={local.variant}
      href={local.href ? `#${id()}` : undefined}
      class={cn("flex justify-center text-lg border border-2", local.class)}
      onClick={handleClick}
      {...others}
    >
      {local.children}
    </Component>
  );
};
