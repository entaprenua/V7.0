import {
 TextButton, Text, Box, Flex, Button,
 FileField, FileFieldTrigger, FileFieldHiddenInput, TextField, TextFieldInput, 
 Popover, PopoverTrigger, PopoverContent,
} from "~/components/ui";

import  ImageIcon from "~/icons/Image";
import { Match, Show, For, Index, Switch, mergeProps, createSignal } from "solid-js";
import { useBuilder } from "~/";

export  function Url(props){

  const onHoverStyle = { "&:hover": {bgcolor: "white"}};
  const builder = useBuilder();
  const selected = () =>  builder.selected

  const [url, setUrl] = createSignal(props.defaultValue);
  const [file, setFile] = createSignal(props.defaultValue);
  
  /* Set media element type name attribute */
  const setMediaNameAttribute = (file) => {
    if(selected().name ==="media")
       selected().setAttribute("name", file.name)
  }
  const handleUrlChange = (event) => {
     setUrl(event.target.value)
  }

  const handleFileChange = (details) => {
     const newFile = details.acceptedFiles[0]
     setMediaNameAttribute(newFile); 
     const url = URL.createObjectURL(newFile);
     setFile(url) 
  }
 

    return (
     <Popover
        closeOnEscapeKeyDown={false}  
        closeOnInteractOutside={false}
        closeOnFocusOutside={false} 
        modal={false} 
        //hideWhenDetached={false} 
     >
       <PopoverTrigger
	 //as={Button<"button">} 
	 class="border-input border-1 px-10 w-full rounded-xl"
       > {props.of} </PopoverTrigger>
       <PopoverContent 
         as={Flex}
 	 class="z-2000 max-w-[70vw] min-w-[40vw] w-full overflow-auto bottom-[50vh] right-[20vw] gap-2"
       > 
 	 <Flex class="gap-3 w-full justify-center">
          {/*<TextField>
	    <TextFieldInput
	      onChange={handleUrlChange}
	      class="focus: outline-none" 
	    />
	    </TextField>
           */} 
	   <FileField
             onFileChange={handleFileChange} 
             multiple={false} 
	     {...props}
           >
             <FileFieldTrigger 
                  as={Button<"button">} 
 		 class="border-input py-1 border-1 inset-x-5 "
 	    >
 	      <ImageIcon />  
 	      Gallery    
 	     </FileFieldTrigger>
             <FileFieldHiddenInput /> 
            </FileField>
           </Flex>
     </PopoverContent>
    </Popover> 

  )
 
} //EndFunction






















