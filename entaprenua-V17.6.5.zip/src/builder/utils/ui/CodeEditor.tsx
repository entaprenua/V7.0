import {
  Tooltip, TooltipTrigger, TooltipContent,
} from "~/components/ui/tooltip";
import { 
  Popover, PopoverContent, PopoverTrigger
} from "~/components/ui/popover"
import { 
  TextField, TextFieldDescription, TextFieldInput 
} from "~/components/ui/text-field"
import {
  Select, SelectTrigger, SelectContent, 
  SelectItem, 
} from "~/components/ui";
import { IconButton } from "~/components/ui/icon-button"
import { Button } from "~/components/ui/button"
import { Separator } from "~/components/ui/separator"
import { Box } from "~/components/ui/box"
import { Flex } from "~/components/ui/flex"
import { Text } from "~/components/ui/text"
import { cn } from "~/lib/utils"
import ClipboardIcon from "~/icons/Clipboard"
import Trash2Icon from "~/icons/Trash2"
import CopyIcon from "~/icons/Copy"
import MoreVertIcon from "~/icons/MoreVert"
import FileIcon  from "lucide-solid/icons/file"
import {
   useEditor, EditorFileReader, EditorCopyTrigger, EditorDeleteTrigger,
   EditorPasteTrigger, EditorTextBox,
} from "~/builder/editor"
import { 
  createSignal, mergeProps, Switch, Match, splitProps, onCleanup, createEffect, on, createMemo, Show
} from "solid-js";
import { useBuilder } from "~/";
import  PopoverCloseTrigger  from "./PopoverCloseTrigger"
import { useAttribute } from "./AttributeContext"
import { SearchAttribute } from "./SearchAttribute"
import { capitalize } from "~/lib/utils"


const [modal, setModal] = createSignal(false)

export  function CodeEditor(props){
     
   const builder = useBuilder();
   const selected = () => builder?.selected;
   props = mergeProps({
     extensions: ["javascript"]
   }, props)

   const [_, others] = splitProps(props, [
     "class", 
   ])
   const attribute = () => props.attribute
   const attributeValue = createMemo(() =>
       selected()?.getAttribute(attribute())
   )
   const [defaultValue, setDefaultValue] = createSignal(attributeValue() ?? "")
   const [disableSaveButton, setDisableSaveButton] = createSignal(false)

   return (
        <Box class={cn("min-h-[20vh] max-h-[50vh] max-w-[80vw] overflow-clip", props.class)}>
          <EditorTextBox {...others} />
          <>{() => {
            const editor = useEditor();
            const resetView = async () => {
               await editor?.clear();
               await editor?.insert(attributeValue())
            }
            createEffect(on(attribute, (attribute) => { 
               resetView() 
            }, {defer: true}))
            
            createEffect(on(selected, selected => {
                resetView();
            }, { defer: true}))
            
            createEffect(on(() => editor?.value, value => {
                 setModal(true);
            }, {defer: true}))
            
            let timer: any  
            onCleanup(() => { clearTimeout(timer) })
            const handleApply = () => {
               try{  
                  const selected = builder.selected; 
                  setDisableSaveButton(true); 
                  timer = window.setTimeout(() => {
                    setDisableSaveButton(false); 
                  })
                  const value = editor?.value?.length > 0? editor?.value: undefined 
                  builder?.selected?.setAttribute(attribute(), value) 
                  setModal(false);  
               }catch(error) {
                  console.error(error);
               }
            } 
             
            return (
             <Box class="overflow-clip mb-3">  
               <Flex justifyContent="space-around" class="gap-5">
                 <Show when={!props.readOnly}> 
                   <Button
                     onClick={handleApply} 
                     disabled={disableSaveButton()} 
                     class="hover:cursor-pointer" 
                   > Apply     
                   </Button>     
                 </Show> 
                 <Tooltip>        
                   <TooltipTrigger>
                     <EditorFileReader>
                       <IconButton class="size-5 border-none" />
                     </EditorFileReader>
                   </TooltipTrigger>
                   <TooltipContent class="z-30000000000"> Upload file </TooltipContent>
                 </Tooltip>

                 <Tooltip>
                   <TooltipTrigger>
                     <EditorCopyTrigger size={"icon"}>
                       <CopyIcon />
                     </EditorCopyTrigger>
                   </TooltipTrigger>
                   <TooltipContent class="z-3000000000"> Copy </TooltipContent>
                 </Tooltip>
                 
                 <Tooltip>
                   <TooltipTrigger>
                     <EditorPasteTrigger size="icon">
                       <ClipboardIcon />
                     </EditorPasteTrigger>
                   </TooltipTrigger> 
                   <TooltipContent class="z-300000000"> Paste </TooltipContent>
                 </Tooltip>
                  
                 <Tooltip>
                   <TooltipTrigger>
                     <EditorDeleteTrigger size={"icon"}>
                       <Trash2Icon />
                     </EditorDeleteTrigger> 
                   </TooltipTrigger>
                   <TooltipContent class="z-300000000"> delete </TooltipContent>
                 </Tooltip> 
               </Flex>
               <Separator /> 
             </Box>
           )
         }}
         </>
        </Box>
   )
}
