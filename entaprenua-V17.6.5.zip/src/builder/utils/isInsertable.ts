import { componentRegistry, useSelectedElement } from "./component"
import { useBuilder } from "~"
import { createMemo } from "solid-js"

const ROOT_COMPONENTS = Object.keys(componentRegistry);

const isValidContextMatch = (parentName: string, targetName: string): boolean => {
  const contextMatches: Record<string, string[]> = {
    "alert-dialog": ["alert-dialog"],
    "alert": ["alert"],
  };

  const allowed = contextMatches[parentName];
  if (!allowed) return false;
  
  return allowed.some(prefix => targetName.startsWith(prefix));
};

export const isInsertableAtRoot = (targetName: string, parentName: string | null): boolean => {
  if (!parentName) return ROOT_COMPONENTS.includes(targetName);
  
  const parentConfig = componentRegistry[parentName];
  if (!parentConfig?.contextuals) return false;
  
  return targetName in parentConfig.contextuals;
};

export const isInsertableAsChild = (targetName: string, contextuals: Record<string, unknown> | null): boolean => {
  if (!contextuals) return false;
  return targetName in contextuals;
};

export const canReplaceSelected = (
  selectedName: string | null,
  targetName: string,
  hasChildren: boolean
): boolean => {
  if (!selectedName) return false;
  
  return (
    selectedName === targetName ||
    !hasChildren
  );
};

export const useIsInsertable = () => {
  const builder = useBuilder();
  const selectedElementConfig = useSelectedElement();
  
  const isInsertable = createMemo(() => {
    const target = builder.selected;
    if (!target) return false;
    
    const targetName = target.name;
    const role = selectedElementConfig()?.role;
    const contextuals = selectedElementConfig()?.contextuals;
    const parentName = selectedElementConfig()?.parentName;
    
    if (target.isIcon()) return true;
    
    if (role?.includes("sibling") || role?.includes("child")) {
      let parent = target.parent;
      while (parent) {
        if (isValidContextMatch(parent.name, targetName)) {
          return true;
        }
        parent = parent.parent;
      }
    }
    
    if (role?.includes("sibling") && target.isRoot()) {
      if (isInsertableAtRoot(targetName, parentName)) {
        return true;
      }
    }
    
    if (role?.includes("child")) {
      if (ROOT_COMPONENTS.includes(targetName) || isInsertableAsChild(targetName, contextuals)) {
        return true;
      }
    }
    
    if (role === "replacer") {
      if (canReplaceSelected(target.name, targetName, target.childrenCount > 0)) {
        return true;
      }
    }
    
    return false;
  });
  
  return isInsertable;
};

export const isInsertable = (target: { name: string } | null): ReturnType<typeof useIsInsertable> => {
  return useIsInsertable();
};
