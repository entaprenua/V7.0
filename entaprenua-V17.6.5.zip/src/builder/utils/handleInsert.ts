import ReactiveElement from "../core/ReactiveElement";

interface InsertOptions {
  builder: any;
  ref?: ReactiveElement;
  value: ReactiveElement;
  role: "first-child" | "last-child" | "previous-sibling" | "next-sibling" | "wrapper" | "replacer";
}

const VALID_ROLES = [
  "first-child", "last-child", "previous-sibling",
  "next-sibling", "wrapper", "replacer"
] as const;

export const handleInsert = ({ builder, ref, value, role }: InsertOptions) => {
  const newEl = value;
  const selectedEl = builder.selected;
  const targetEl = ref ?? selectedEl;

  if (!VALID_ROLES.includes(role)) {
    console.error("Invalid role:", role);
    return;
  }

  switch (role) {
    case "wrapper":
      targetEl.wrapWith(newEl);
      break;
    case "replacer":
      targetEl.replaceWith(newEl);
      builder.selected = newEl;
      break;
    case "previous-sibling":
      targetEl.insertSiblingBeforebegin(newEl);
      break;
    case "next-sibling":
      targetEl.insertSiblingAfterend(newEl);
      break;
    case "first-child":
      targetEl.prependChild(newEl);
      break;
    case "last-child":
      targetEl.appendChild(newEl);
      break;
  }
};
