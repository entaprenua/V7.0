import { Flex } from "~/components/ui/flex"
import { Grid } from "~/components/ui/grid"
import { Box } from "~/components/ui/box"
import { Button} from "~/components/ui/button"
import {Text } from "~/components/ui/text"
import { Badge } from "~/components/ui/badge"
import {Separator } from "~/components/ui/separator"
import {Image, ImageImg, ImageFallback} from "~/components/ui/image"
import {Avatar,AvatarImage, AvatarFallback} from "~/components/ui/avatar"
import { AspectRatio } from "~/components/ui/aspect-ratio"
import {Video} from "~/components/ui/video"
import {Audio} from "~/components/ui/audio"
import {
  Search,
  SearchContent,
  SearchInput,
} from "~/components/ui/search"
import {
  Card,
  CardHeader,
  CardTitle,
  CardDescription,
  CardContent,
  CardFooter,
} from "~/components/ui/card" 
 import { 
  Accordion,
  AccordionItem,
  AccordionTrigger,
  AccordionContent,
 } from "~/components/ui/accordion" 
 import {  
  Collapsible,
  CollapsibleTrigger,
  CollapsibleContent,
} from "~/components/ui/collapsible"
import {
  Alert,
  AlertTitle,
  AlertDescription,
} from "~/components/ui/alert" 
import { 
  AlertDialog,
  AlertDialogTrigger,
  AlertDialogCloseButton,
  AlertDialogContent,
  AlertDialogTitle,
  AlertDialogDescription,
} from "~/components/ui/alert-dialog" 
import { 
  Dialog,
  DialogTrigger,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
  DialogCloseButton,
} from "~/components/ui/dialog" 
import {  Callout, CalloutTitle,  CalloutContent} from "~/components/ui/callout"
import { 
  Tooltip,
  TooltipTrigger,
  TooltipContent,
  TooltipArrow,
} from "~/components/ui/tooltip" 
import {Skeleton} from "~/components/ui/skeleton"
import {
  Popover,
  PopoverTrigger,
  PopoverContent,
  PopoverTitle,
  PopoverDescription,
  PopoverCloseButton,
  PopoverArrow,
} from "~/components/ui/popover"
import {
  Breadcrumb,
  BreadcrumbList,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbSeparator,
  BreadcrumbEllipsis,
} from "~/components/ui/breadcrumb" 
import {  
  HoverCard, HoverCardTrigger,  HoverCardContent
} from "~/components/ui/hover-card"
import { 
  Sidebar,
  SidebarProvider,
  SidebarTrigger,
  SidebarContent,
  SidebarHeader,
  SidebarFooter,
  SidebarSeparator,
  SidebarInput,
  SidebarInset,
  SidebarRail,
  SidebarGroup,
  SidebarGroupAction,
  SidebarGroupLabel,
  SidebarGroupContent,
  SidebarMenu,
  SidebarMenuAction,
  SidebarMenuBadge,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarMenuSkeleton,
  SidebarMenuSub,
  SidebarMenuSubButton,
  SidebarMenuSubItem,
} from "~/components/ui/sidebar"
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSub,
  DropdownMenuSubContent,
  DropdownMenuSubTrigger,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
  DropdownMenuIcon,
} from "~/components/ui/dropdown-menu" 
import { 
  Drawer, 
  DrawerPortal,
  DrawerOverlay,
  DrawerTrigger,
  DrawerCloseButton,
  DrawerContent,
  DrawerHeader,
  DrawerFooter,
  DrawerTitle,
  DrawerDescription,
} from "~/components/ui/drawer"
import { 
  NavigationMenuViewport,
  NavigationMenuItem,
  NavigationMenuContent,
  NavigationMenuIcon,
  NavigationMenuLink,
  NavigationMenuDescription,
  NavigationMenuLabel,
  NavigationMenuTrigger,
} from "~/components/ui/navigation-menu"

import { Link } from "~/components/ui/link"
import { 
  Navbar, 
  NavbarBrand, 
  NavbarContent, 
  NavbarEnd, 
  NavbarToggle,
  NavbarLink 
} from "~/components/ui/navbar"
import { Spinner } from "~/components/ui/spinner"

const layoutProps = {
  direction: ["col", "row", "row-reverse", "col-reverse"],
  wrap: "boolean",
  align: ["start", "center", "end", "stretch", "baseline"],
  justify: ["start", "center", "end", "space-between", "space-around", "space-evenly"],
};
const overlayBehavior = {
  closeOnEscapeKeyDown: "boolean",
  closeOnInteractOutside: "boolean",
  closeOnPointerDownOutside: "boolean",
  defaultOpen: "boolean",
  open: "boolean",
  forceMount: "boolean",
};
const collectionLayoutProps = (children: Record<string, unknown>) => ({
  attributes: {
    layout: ["column", "row", "grid"],
    columns: "number",
    columnsSmall: "number",
    columnsMedium: "number",
    columnsLarge: "number",
    gap: "number",
  },
  contextuals: children,
});

const popoverProps = {
  placement: ["left", "right", "bottom", "top", "top-start", "top-end", "bottom-start", "bottom-end"],
  gutter: "number",
  shift: "number",
  flip: "boolean",
  slide: "boolean",
  overlap: "boolean",
  sameWidth: "boolean",
  fillViewport: "boolean",
};

export type ComponentCategory = 
  | "layout" 
  | "input" 
  | "navigation" 
  | "display" 
  | "feedback" 
  | "surface"
  | "data"
  | "media"
  | "commerce";

export interface ComponentMeta {
  label: string;
  description?: string;
  category: ComponentCategory;
  icon?: string;
  keywords?: string[];
  isNew?: boolean;
  isPopular?: boolean;
}

export const COMPONENT_CATEGORIES: Record<ComponentCategory, { label: string; icon: string }> = {
  layout: { label: "Layout", icon: "LayoutGrid" },
  input: { label: "Input", icon: "Input" },
  navigation: { label: "Navigation", icon: "Navigation" },
  display: { label: "Display", icon: "Display" },
  feedback: { label: "Feedback", icon: "Feedback" },
  surface: { label: "Surface", icon: "Surface" },
  data: { label: "Data", icon: "Data" },
  media: { label: "Media", icon: "Media" },
  commerce: { label: "Commerce", icon: "ShoppingCart" },
};

export const componentMeta: Record<string, ComponentMeta> = {
  box: { label: "Box", description: "Generic container", category: "layout" },
  flex: { label: "Flex", description: "Flexible layout container", category: "layout" },
  grid: { label: "Grid", description: "Grid layout container", category: "layout" },
  button: { label: "Button", description: "Clickable button", category: "input", keywords: ["click", "action"], isPopular: true },
  search: { label: "Search", description: "Search input", category: "input" },
  searchInput: { label: "Search Input", description: "Search field", category: "input" },
  input: { label: "Input", description: "Text input field", category: "input" },
  selectTrigger: { label: "Select", description: "Dropdown select", category: "input" },
  link: { label: "Link", description: "Hyperlink", category: "navigation", isPopular: true },
  navLink: { label: "Nav Link", description: "Navigation link", category: "navigation" },
  navbar: { label: "Navbar", description: "Navigation bar", category: "navigation", isPopular: true },
  menu: { label: "Menu", description: "Dropdown menu", category: "navigation" },
  sidebar: { label: "Sidebar", description: "Side navigation", category: "navigation" },
  text: { label: "Text", description: "Text content", category: "display", isPopular: true },
  image: { label: "Image", description: "Image element", category: "media", isPopular: true },
  video: { label: "Video", description: "Video player", category: "media" },
  avatar: { label: "Avatar", description: "User avatar", category: "display" },
  badge: { label: "Badge", description: "Status badge", category: "display" },
  card: { label: "Card", description: "Content card", category: "surface", isPopular: true },
  accordion: { label: "Accordion", description: "Collapsible accordion", category: "surface" },
  collapsible: { label: "Collapsible", description: "Collapsible content", category: "surface" },
  alert: { label: "Alert", description: "Alert message", category: "feedback" },
  dialog: { label: "Dialog", description: "Modal dialog", category: "feedback", isPopular: true },
  tooltip: { label: "Tooltip", description: "Hover tooltip", category: "feedback" },
  skeleton: { label: "Skeleton", description: "Loading skeleton", category: "feedback" },
  spinner: { label: "Spinner", description: "Loading spinner", category: "feedback" },
  product: { label: "Product", description: "Product display", category: "commerce", isPopular: true },
  cart: { label: "Cart", description: "Shopping cart", category: "commerce", isPopular: true },
  separator: { label: "Separator", description: "Divider line", category: "display" },
  aspectRatio: { label: "Aspect Ratio", description: "Aspect ratio container", category: "media" },
  switch: { label: "Switch", description: "Toggle switch", category: "input" },
};

export const componentRegistry: Record<string, {
  component?: any;
  attributes?: Record<string, unknown>;
  contextuals?: Record<string, unknown>;
  variant?: string;
}> = {
  // Layout
  box: {
    component: Box,
    contextuals: {},
  },
  flex: {
    component: Flex,
    attributes: layoutProps,
    contextuals: {},
  },
  grid: {
    component: Grid,
    attributes: {
      ...layoutProps,
      columns: "number",
      columnsSmall: "number",
      columnsMedium: "number",
      columnsLarge: "number",
    },
    contextuals: {},
  },

  // Input
  button: {
    component: Button,
    attributes: {
      variant: ["default", "ghost", "outline", "secondary", "destructive", "link"],
      size: ["default", "sm", "lg", "icon"],
      href: "string",
      type: ["button", "submit", "reset"],
    },
    contextuals: {},
  },
  search: {
    component: Search,
    attributes: {
      placeholder: "string",
    },
    contextuals: {
      searchInput: {
       component: SearchInput,
         attributes: {
           placeholder: "string",
        },
        contextuals: {},
      }
    }
  },
  // Navigation
  link: {
    component: Link,
    attributes: {
      href: "string",
      target: ["_self", "_blank", "_parent", "_top"],
    },
    contextuals: {},
  },
  navbar: {
    component: Navbar,
    attributes: {
      position: ["sticky", "absolute", "relative", "fixed"],
      variant: ["default", "outline", "ghost"],
    },
    contextuals: {
      navbarBrand: { component: NavbarBrand },
      navbarContent: { component: NavbarContent },
      navbarEnd: { component: NavbarEnd },
      navbarToggle: { component: NavbarToggle },
      navbarLink: { component: NavbarLink },
    },
  },
  dropdownMenu: {
    component: DropdownMenu,
    attributes: {
      ...overlayBehavior,
      ...popoverProps,
    },
    contextuals: {
      dropdownMenuTrigger: {
        component: DropdownMenuTrigger,
        contextuals: {
          dropdownMenuIcon: { component: DropdownMenuIcon },
        },
      },
      dropdownMenuContent: {
        component: DropdownMenuContent,
        contextuals: {
          dropdownMenuItem: { component: DropdownMenuItem },
          dropdownMenuSub: {
            component: DropdownMenuSub,
            contextuals: {
              dropdownMenuSubTrigger: { component: DropdownMenuSubTrigger },
              dropdownMenuSubContent: {
                component: DropdownMenuSubContent,
                contextuals: {
                  dropdownMenuItem: { component: DropdownMenuItem },
                  dropdownMenuSeparator: { component: DropdownMenuSeparator },
                },
              },
            },
          },
          dropdownMenuSeparator: { component: DropdownMenuSeparator },
        },
      },
    },
  },
  hoverCard: {
    component: HoverCard,
    attributes: {
      ...overlayBehavior,
      ...popoverProps,
      openDelay: "number",
      closeDelay: "number",
    },
    contextuals: {
      hoverCardTrigger: { component: HoverCardTrigger },
      hoverCardContent: { component: HoverCardContent },
    },
  },
  sidebar: {
    component: Sidebar,
    attributes: {
      defaultOpen: "boolean",
      open: "boolean",
      side: ["left", "right"],
      variant: ["sidebar", "floating", "inset"],
      collapsible: ["none", "icon", "offcanvas"],
    },
    contextuals: {
      sidebarTrigger: { component: SidebarTrigger },
      sidebarProvider: { component: SidebarProvider },
      sidebarContent: { component: SidebarContent },
      sidebarHeader: { component: SidebarHeader },
      sidebarFooter: { component: SidebarFooter },
      sidebarSeparator: { component: SidebarSeparator },
      sidebarRail: { component: SidebarRail },
      sidebarInset: { component: SidebarInset },
    },
  },
  drawer: {
    component: Drawer,
    attributes: {
      ...overlayBehavior,
      ...popoverProps,
    },
    contextuals: {
      drawerTrigger: { component: DrawerTrigger },
      drawerContent: { component: DrawerContent },
      drawerOverlay: { component: DrawerOverlay },
      drawerCloseButton: { component: DrawerCloseButton },
      drawerHeader: { component: DrawerHeader },
      drawerFooter: { component: DrawerFooter },
      drawerTitle: { component: DrawerTitle },
      drawerDescription: { component: DrawerDescription },
    },
  },
  navigationMenu: {
    component: NavigationMenuViewport,
    attributes: {
      ...overlayBehavior,
      loop: "boolean",
      delayDuration: "number",
    },
    contextuals: {
      navigationMenuItem: { component: NavigationMenuItem },
      navigationMenuTrigger: {
        component: NavigationMenuTrigger,
        contextuals: {
          navigationMenuIcon: { component: NavigationMenuIcon },
        },
      },
      navigationMenuContent: {
        component: NavigationMenuContent,
        contextuals: {
          navigationMenuLink: {
            component: NavigationMenuLink,
            attributes: {
              href: "string",
            },
            contextuals: {
              navigationMenuLabel: { component: NavigationMenuLabel },
              navigationMenuDescription: { component: NavigationMenuDescription },
            },
          },
        },
      },
    },
  },
  breadcrumb: {
    component: Breadcrumb,
    contextuals: {
      breadcrumbList: {
        component: BreadcrumbList,
        contextuals: {
          breadcrumbItem: {
            component: BreadcrumbItem,
            contextuals: {
              breadcrumbLink: { component: BreadcrumbLink },
              breadcrumbSeparator: { component: BreadcrumbSeparator },
              breadcrumbEllipsis: { component: BreadcrumbEllipsis },
            },
          },
        },
      },
    },
  },

  // Data Display
  text: {
    component: Text,
    attributes: {
      variant: ["h1", "h2", "h3", "h4", "h5", "h6", "subtitle1", "subtitle2", "body1", "body2", "caption", "overline"],
    },
    contextuals: {},
  },
  image: {
    component: Image,
    attributes: {
      src: "string",
      alt: "string",
      fallbackDelay: "number",
    },
    contextuals: {
      imageImg: { component: ImageImg },
      imageFallback: { component: ImageFallback },
    },
  },
  video: {
    component: Video,
    attributes: {
      src: "string",
      autoplay: "boolean",
      loop: "boolean",
      muted: "boolean",
      controls: "boolean",
    },
    contextuals: {},
  },
  audio: {
    component: Audio,
    attributes: {
      src: "string",
      autoplay: "boolean",
      muted: "boolean",
      controls: "boolean",
    },
    contextuals: {},
  },
  avatar: {
    component: Avatar,
    attributes: {
      fallbackDelay: "number",
    },
    contextuals: {
      avatarImage: {
        component: AvatarImage,
        attributes: {
          src: "string",
        },
      },
      avatarFallback: { component: AvatarFallback },
    },
  },
  badge: {
    component: Badge,
    attributes: {
      variant: ["default", "secondary", "outline", "success", "warning", "error"],
    },
    contextuals: {},
  },
  separator: {
    component: Separator,
    attributes: {
      orientation: ["horizontal", "vertical"],
    },
    contextuals: {},
  },
  aspectRatio: {
    component: AspectRatio,
    attributes: {
      ratio: "number",
    },
    contextuals: {},
  },

  // Surface
  card: {
    component: Card,
    contextuals: {
      cardHeader: {
        component: CardHeader,
        contextuals: {
          cardTitle: { component: CardTitle },
          cardDescription: { component: CardDescription },
        },
      },
      cardContent: { component: CardContent },
      cardFooter: { component: CardFooter },
    },
  },
  accordion: {
    component: Accordion,
    attributes: {
      collapsible: "boolean",
      multiple: "boolean",
    },
    contextuals: {
      accordionItem: {
        component: AccordionItem,
        contextuals: {
          accordionContent: { component: AccordionContent },
          accordionTrigger: { component: AccordionTrigger },
        },
      },
    },
  },
  collapsible: {
    component: Collapsible,
    attributes: {
      open: "boolean",
      defaultOpen: "boolean",
    },
    contextuals: {
      collapsibleContent: { component: CollapsibleContent },
      collapsibleTrigger: { component: CollapsibleTrigger },
    },
  },

  // Feedback
  dialog: {
    component: Dialog,
    attributes: {
      ...overlayBehavior,
    },
    contextuals: {
      dialogTrigger: { component: DialogTrigger },
      dialogContent: {
        component: DialogContent,
        contextuals: {
          dialogHeader: {
            component: DialogHeader,
            contextuals: {
              dialogTitle: { component: DialogTitle },
              dialogDescription: { component: DialogDescription },
            },
          },
          dialogFooter: { component: DialogFooter },
          dialogCloseButton: { component: DialogCloseButton },
        },
      },
    },
  },
  alertDialog: {
    component: AlertDialog,
    attributes: {
      ...overlayBehavior,
    },
    contextuals: {
      alertDialogTrigger: { component: AlertDialogTrigger },
      alertDialogContent: {
        component: AlertDialogContent,
        contextuals: {
          alertDialogTitle: { component: AlertDialogTitle },
          alertDialogDescription: { component: AlertDialogDescription },
          alertDialogCloseButton: { component: AlertDialogCloseButton },
        },
      },
    },
  },
  alert: {
    component: Alert,
    attributes: {
      variant: ["default", "destructive"],
    },
    contextuals: {
      alertTitle: { component: AlertTitle },
      alertDescription: { component: AlertDescription },
    },
  },
  tooltip: {
    component: Tooltip,
    attributes: {
      ...overlayBehavior,
      ...popoverProps,
      openDelay: "number",
      closeDelay: "number",
    },
    contextuals: {
      tooltipTrigger: { component: TooltipTrigger },
      tooltipContent: {
        component: TooltipContent,
        contextuals: {
          tooltipArrow: { component: TooltipArrow },
        },
      },
    },
  },
  skeleton: {
    component: Skeleton,
    attributes: {
      visible: "boolean",
      animate: "boolean",
      radius: "number",
      circle: "boolean",
    },
    contextuals: {},
  },
  spinner: {
    component: Spinner,
    attributes: {
      size: ["xs", "sm", "md", "lg", "xl"],
      arcLength: "number",
    },
    contextuals: {},
  },
  callout: {
    component: Callout,
    attributes: {
      variant: ["default", "success", "warning", "error"],
    },
    contextuals: {
      calloutTitle: { component: CalloutTitle },
      calloutContent: { component: CalloutContent },
    },
  },

  // Overlay
  popover: {
    component: Popover,
    attributes: {
      ...overlayBehavior,
      ...popoverProps,
    },
    contextuals: {
      popoverTrigger: { component: PopoverTrigger },
      popoverContent: {
        component: PopoverContent,
        contextuals: {
          popoverArrow: { component: PopoverArrow },
          popoverTitle: { component: PopoverTitle },
          popoverDescription: { component: PopoverDescription },
          popoverCloseButton: { component: PopoverCloseButton },
        },
      },
    },
  },
  /* Commerce
  cart: {
    contextuals: {
      cartItems: collectionLayoutProps({
        cartItem: {
          contextuals: {
            cartItemCheckbox: { component: CartItemCheckbox },
            cartItemName: { component: ProductName },
            cartItemPrice: { component: ProductPrice },
            cartItemQuantity: { component: ProductQuantityInput },
          },
        },
      }),
      cartSubtotal: { component: CartSubtotal },
      cartItemsCount: {},
      cartEmpty: { component: CartEmpty },
      cartCheckoutTrigger: { component: CartCheckoutTrigger },
    },
  },
  product: {
    component: Product,
    contextuals: {
      productAddToCartTrigger: { component: ProductAddToCartTrigger },
      productRemoveFromCartTrigger: { component: ProductRemoveFromCartTrigger },
      productAddToWishlistTrigger: { component: ProductAddToWishlistTrigger },
      productRemoveFromWishlistTrigger: { component: ProductRemoveFromWishlistTrigger },
      productMakeOrderTrigger: { component: ProductOrderTrigger },
      productQuantityDecrementTrigger: { component: ProductQuantityDecrementTrigger },
      productQuantityIncrementTrigger: { component: ProductQuantityIncrementTrigger },
      productQuantityInput: { component: ProductQuantityInput },
      productName: { component: ProductName },
      productPrice: { component: ProductPrice },
    },
  }*/
};

// ============================================================================
// Add HTML Tags to registry
// ============================================================================

const HTML_BLOCK_TAGS = ['div', 'section', 'article', 'main', 'header', 'footer', 'nav'];
const HTML_TEXT_TAGS = ['h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'p', 'span', 'a', 'strong', 'em', 'code', 'small', 'pre', 'blockquote'];

for (const tag of HTML_BLOCK_TAGS) {
  componentRegistry[tag] = { component: Box };
}

for (const tag of HTML_TEXT_TAGS) {
  componentRegistry[tag] = { component: Text, variant: tag };
}

// ============================================================================
// Derived exports (computed once at module load)
// ============================================================================

type RegistryType = typeof componentRegistry;

function flattenToSet(reg: RegistryType): Set<string> {
  const names = new Set<string>();
  function traverse(obj: Record<string, any> | undefined) {
    if (!obj) return;
    for (const [key, value] of Object.entries(obj)) {
      names.add(key);
      if (value?.contextuals) {
        traverse(value.contextuals);
      }
    }
  }
  traverse(reg);
  return names;
}

// Case-insensitive lookup map (built once at module load)
function buildCaseInsensitiveMap(reg: RegistryType): Map<string, string> {
  const map = new Map<string, string>();
  function traverse(obj: Record<string, any> | undefined) {
    if (!obj) return;
    for (const [key, value] of Object.entries(obj)) {
      map.set(key.toLowerCase(), key);
      if (value?.contextuals) {
        traverse(value.contextuals);
      }
    }
  }
  traverse(reg);
  return map;
}

export const COMPONENT_NAME_MAP = buildCaseInsensitiveMap(componentRegistry);

function flattenToMap(reg: RegistryType): Record<string, any> {
  const map: Record<string, any> = {};
  function traverse(obj: Record<string, any> | undefined) {
    if (!obj) return;
    for (const [key, value] of Object.entries(obj)) {
      if (value?.component) {
        map[key] = value.component;
      }
      if (value?.contextuals) {
        traverse(value.contextuals);
      }
    }
  }
  traverse(reg);
  return map;
}

export const ALLOWED_COMPONENTS = flattenToSet(componentRegistry);
export const componentMap = flattenToMap(componentRegistry);

export type ComponentConfig = RegistryType;
export type ComponentName = keyof RegistryType;
