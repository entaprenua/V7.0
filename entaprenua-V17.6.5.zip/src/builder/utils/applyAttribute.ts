import { Builder } from "~/types";

export const applyAttribute = (builder: Builder, attribute) => {
   let target = builder.selected!
   const applyToSingleEl = () => {  
     if(target.isMutable()) {
       if(!attribute.isStyle) {
	   target.attributes.set(attribute.name, attribute.value)   
       }
       else {
           /* User can always override in stylefield as we call ~
	    * in cssobject, 
	    * User will have view of values in various input fields input,
	    * so no need
	    * to copy it to StyleField
	    */
	   target.setStyle(attribute.name, attribute.value);

	}

    }
  }
  
  if(!builder.multiselection) {
       applyToSingleEl();
  }  
  /*If multiple items are selected */ 
  else {
    builder.selection.items.forEach((element, id) => {
        target = element;	
	applyToSingleEl();
   })
  }
}
