import ReactiveElement from "./ReactiveElement";
import type { Builder } from "../types/Builder";
import Container from "./Container";
import { handleInsert } from "../utils/handleInsert";
import { TriggerCache } from "@solid-primitives/trigger";

export default class Clipboard extends Container {
  #triggers = new TriggerCache<any>();
  #copied: boolean = false;

  constructor(builder?: Builder) {
    super();
    if (builder) {
      this.builder = builder;
    }
  }

  get selectedEl(): ReactiveElement | undefined {
    return this.builder?.selected;
  }

  set copied(value: boolean) {
    this.#copied = Boolean(value);
    this.#triggers.dirty("copied");
  }

  get copied(): boolean {
    this.#triggers.track("copied");
    return this.#copied;
  }

  copy(): void {
    const el = this.selectedEl;
    if (el != null) {
      this.updateItems(() => this.items.push(el.clone()));
      this.#copied = true;
    } else {
      console.error("Copy Failed");
      this.#copied = false;
    }
  }

  paste(role?: string): void {
    if (!this.isEmpty()) {
      const child = this.peek;
      if (child) {
        const clonedChild = child.clone();
        this.builder?.record.add({
          element: clonedChild,
          role: role ?? "first-child",
        });
      }
    } else {
      console.error("Paste failed because clipboard is empty");
    }
  }
}
