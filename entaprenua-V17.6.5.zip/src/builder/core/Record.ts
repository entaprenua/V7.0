import ReactiveElement from "./ReactiveElement";
import type { Builder } from "../types/Builder";
import Container from "./Container";
import { handleInsert } from "../utils/handleInsert";
import { handleDelete } from "../utils/handleDelete";

export default class Record extends Container {
  #deletedItems: Container;

  constructor(builder?: Builder) {
    super();
    if (builder) {
      this.builder = builder;
    }
    this.#deletedItems = new Container();
  }

  get deletedItems(): Container {
    return this.#deletedItems;
  }

  get trash(): Container {
    return this.#deletedItems;
  }

  #redo(element: ReactiveElement): void {
    if (element.isAttribute()) {
      const attributeOf = element.attributeOf;
      if (attributeOf) {
        const attr = element.attributeName;
        attributeOf.setAttribute(attr, element);
      }
    } else {
      const previousSibling = element?.previousSibling;
      if (previousSibling) {
        previousSibling.insertSiblingAfterend(element);
      } else {
        element.parent?.prependChild(element);
      }
    }
  }

  add(options: { ref?: any; element: ReactiveElement; role?: string }): void {
    const { ref, element, role } = options;

    try {
      const update = () => this.updateItems(() => this.items.push(element));

      if (element) {
        if (role === undefined && ref === undefined) {
          // No action needed for standalone elements
        } else {
          handleInsert({
            builder: this.builder,
            ref,
            role: role as any,
            value: element,
          });
        }
        update();
      } else if (!this.deletedItems.isEmpty()) {
        const restoredItem = this.deletedItems.peek;
        if (restoredItem) {
          if (Array.isArray(restoredItem)) {
            this.handleAll(restoredItem, (target) => {
              if (target) {
                this.#redo(target as ReactiveElement);
              }
            });
          } else if (restoredItem instanceof ReactiveElement) {
            this.#redo(restoredItem);
          }
          update();
          this.deletedItems.remove();
        }
      } else {
        console.error("Failed: Nothing to add to the record");
      }
    } catch (error) {
      console.error("Error adding to the record:", error);
    }
  }

  remove(target?: ReactiveElement): void {
    try {
      let itemToRemove = target;
      if (!itemToRemove) {
        const peakItem = this.peek;
        if (peakItem) {
          this.updateItems(() => this.items.pop());
          itemToRemove = peakItem;
        }
      }
      if (itemToRemove) {
        handleDelete(this.builder, itemToRemove);
        this.deletedItems.add(itemToRemove);
      }
    } catch (error) {
      console.error("Error occurred in undo operation:", error);
    }
  }

  cut(): void {
    try {
      const selectedEl = this.builder?.selected;
      if (selectedEl != null) {
        this.builder?.clipboard.copy();
        selectedEl.removeFromList(this.items);
        this.remove(selectedEl);
      }
    } catch (error) {
      console.error("Error occurred in cut operation:", error);
    }
  }
}
