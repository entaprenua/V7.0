import ReactiveElement from "./ReactiveElement";
import type { Builder } from "../types/Builder";
import Container from "./Container";
import { ReactiveMap } from "./primitives/ReactiveMap";

export default class Selection extends Container {
  #onlyOne: boolean = false;

  constructor(builder?: Builder) {
    super();
    this.items = new ReactiveMap();
  }

  includes(value: ReactiveElement | string): boolean {
    if (value instanceof ReactiveElement) {
      return (this.items as any).has(value.id);
    } else if (typeof value === "string") {
      return (this.items as any).has(value);
    } else {
      console.error("Item is of unsupported type");
      return false;
    }
  }

  get count(): number {
    return (this.items as any).size;
  }

  get peek(): any {
    return null;
  }

  add(value: ReactiveElement | string): void {
    this.updateItems(() => {
      if (value instanceof ReactiveElement) {
        if (this.onlyOne && !this.isEmpty()) {
          this.removeAll();
        }
        (this.items as any).set(value.id, value);
        const el = document.getElementById(value.id);
        if (el) {
          el.style.outline = "dotted purple 3px";
        }
      } else {
        (this.items as any).add(value);
        const el = document.getElementById(value);
        if (el) {
          el.style.outline = "dotted purple 3px";
        }
      }
    });
  }

  remove(value: ReactiveElement | string): void {
    this.updateItems(() => {
      if (value instanceof ReactiveElement) {
        (this.items as any).delete(value.id);
        const el = document.getElementById(value.id);
        if (el) {
          el.style.outline = "";
        }
      } else {
        (this.items as any).delete(value);
        const el = document.getElementById(value);
        if (el) {
          el.style.outline = "";
        }
      }
    });
  }

  clear(): void {
    this.removeAll();
  }

  addAll(items?: any): void {
    if (items) {
      this.handleAll(items, (item: any) => {
        if (item) {
          this.add(item);
        }
      });
    }
  }

  removeAll(items?: any): void {
    if (!items) {
      items = this.items;
    }
    this.handleAll(items, (item: any) => {
      if (item) {
        this.remove(item);
      }
    });
  }

  get size(): number {
    return (this.items as any).size;
  }

  get onlyOne(): boolean {
    return this.#onlyOne;
  }

  set onlyOne(value: boolean) {
    this.#onlyOne = value;
  }
}
