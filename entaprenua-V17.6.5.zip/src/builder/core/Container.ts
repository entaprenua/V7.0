import ReactiveElement from "./ReactiveElement";
import type { Builder } from "../types/Builder";
import { TriggerCache } from "@solid-primitives/trigger";
import { ReactiveSet } from "./primitives/ReactiveSet";
import { ReactiveMap } from "./primitives/ReactiveMap";

export default class Container {
  triggers = new TriggerCache<any>();
  #items: any = [];
  #builder: Builder | null = null;

  set builder(value: Builder | null) {
    this.#builder = value;
  }

  get builder(): Builder | null {
    return this.#builder;
  }

  set items(value: any) {
    this.#items = value;
    this.triggers.dirty("items");
  }

  get items(): any {
    this.triggers.track("items");
    return this.#items;
  }

  updateItems(action: () => any = () => undefined): void {
    action?.();
    this.triggers.dirty("items");
  }

  isEmpty(): boolean {
    if (this.#items instanceof Array) {
      return this.#items.length === 0;
    } else if (this.#items instanceof Map) {
      return this.#items.size === 0;
    }
    return true;
  }

  get peek(): any {
    if (this.isEmpty()) return null;
    if (Array.isArray(this.#items)) {
      return this.#items[this.#items.length - 1];
    }
    return null;
  }

  add(value?: any): void {
    if (Array.isArray(this.#items)) {
      this.updateItems(() => this.#items.push(value));
    } else if (this.#items instanceof Map && value instanceof ReactiveElement) {
      this.updateItems(() => this.#items.set(value.id, value));
    } else if (this.#items instanceof Set || this.#items instanceof ReactiveSet) {
      this.updateItems(() => this.#items.add(value));
    } else {
      console.error("Adding to container failed");
    }
  }

  remove(value?: any): void {
    if (Array.isArray(this.#items)) {
      this.updateItems(() => this.#items.pop());
    } else if (this.#items instanceof ReactiveMap && value instanceof ReactiveElement) {
      this.updateItems(() => value.removeFromMap(this.#items));
    } else if (this.#items instanceof Set || this.#items instanceof ReactiveSet) {
      this.updateItems(() => this.#items.delete(value));
    } else {
      console.error("Removal from container failed");
    }
  }

  removeAtIndex(index: number): any[] {
    this.updateItems(() => this.#items.splice(index, 1));
    return this.#items;
  }

  handleAll(
    items: Map<string, ReactiveElement> | ReactiveElement[],
    action: (item?: ReactiveElement) => any
  ): void {
    if (Array.isArray(items) || items instanceof Set || items instanceof ReactiveSet) {
      items.forEach((item) => {
        if (item) {
          action(item);
        } else {
          action();
        }
      });
    } else if (items instanceof ReactiveMap) {
      const values = [...items.values()];
      values.forEach((item) => {
        if (item) {
          action(item);
        } else {
          action();
        }
      });
    }
  }

  forEach(action: (item: any, id?: any) => void): void {
    this.#items.forEach(action);
  }
}
