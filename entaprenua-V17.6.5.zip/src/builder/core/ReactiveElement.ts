import { createUniqueId } from "~/lib/utils"
import { cloneElement } from "./cloneElement"
import DragAndDrop from "./DragAndDrop"
import { TriggerCache } from "@solid-primitives/trigger";
import { Builder } from "../types";
import { ReactiveMap } from "./primitives/ReactiveMap"
import { ReactiveSet } from "./primitives/ReactiveSet"
import { componentRegistry } from "../utils/component-registry"

export default class ReactiveElement{
   
    #triggers: TriggerCache<any> = new TriggerCache<any>();
    #name: string 
    #id = createUniqueId() 
    #attributes: ReactiveMap<string, any> = new ReactiveMap()
    #children: ReactiveMap<string, ReactiveElement> = new ReactiveMap() 
    /* Remember, during initalization, content is empty so: */
    #firstChild: ReactiveElement | null  = null;
    #lastChild: ReactiveElement | null = null;
    /* During initialization, we havent set a reference of prev and next, 
     * so null, untill we set it
    */
    #previousSibling: ReactiveElement | null = null 
    #nextSibling: ReactiveElement | null = null 
    #parent: ReactiveElement | null = null;
    #tailwind: string = ""
    /* custom code */ 
    #rawCode: string = ""  
    #isPage: bolean = false 
    constructor(name: string) { 
	      this.#name = name;
   }
   
   get isPage(){
     this.#triggers.track("isPage")
     /* So that will be called as function isPage()*/ 
     return () => this.#isPage;
   }
   set isPage(value) {
     this.#isPage = value; 
     this.#triggers.dirty("isPage");
   }
   get rawCode(){
     this.#triggers.track("rawCode")
     return this.#rawCode;
   }
   set rawCode(value) {
     this.#rawCode = value; 
     this.#triggers.dirty("rawCode");
    }

   get id(){
     this.#triggers.track("id")
     return this.#id;
   }
    set id(value) {
     this.#id = value; 
     this.#triggers.dirty("id");
    }
   
    get name() {
      this.#triggers.track("name") 
      return this.#name
    }
    set name(value: string) { 
        this.#name = value
        this.#triggers.dirty("name")
    }
    /* return this to activate piping */
    setAttribute(key, value): ReactiveElement {
        const attributes = this.#attributes	
	attributes.set(key, value)
        //this.#triggers.dirty("attributes") 
	return this; 
    }
    getAttribute(key): any {
       const attr = this.attributes.get(key);
       return attr
    } 
    get attributes(){
      //this.#triggers.track("attributes") 
      return this.#attributes
    }
    deleteAttribute(attr) { 
	this.#attributes.delete(attr.id)
    }
    set children(value) {
	this.#children = value
        this.#triggers.dirty("children")	
    } /* whole reset */ 
    
    get children(){ 
        this.#triggers.track("children")	
	return this.#children 
    } 

    set tailwind(value) {
        this.#tailwind = value                  
        this.#triggers.dirty("tailwind")
    } /* whole reset */ 
    
    get tailwind(){ 
        this.#triggers.track("tailwind")        
        return this.#tailwind
    }
  
    /* set a reference of the parent */
    set parent(value: ReactiveElement | null){
	this.#parent = value
        this.#triggers.dirty("parent") 
    }
    get parent() { 
       this.#triggers.track("parent") 
       return this.#parent 
    }
    
    /* set a reference of previousSibling */
    set previousSibling(value: ReactiveElement | null) {
	this.#previousSibling = value
	this.#triggers.dirty("previousSibling")
    }
    get previousSibling() {
        this.#triggers.track("previousSibling")	
	return this.#previousSibling 
    }
    
    /* create a referece of next Sibling */
    set nextSibling(value: ReactiveElement | null) {
	this.#nextSibling = value
        this.#triggers.dirty("nextSibling") 
    } 
    get nextSibling() { 
      this.#triggers.track("nextSibling") 
      return this.#nextSibling 
    } 
   

    set #firstChildS(value){ this.#firstChild = value}
    get firstChild() {
        let _child: ReactiveElement | null = null; 
	for(let [key, child] of this.children) {
          if(child.previousSibling == null) {
	     this.#firstChildS = child;
	  }
        }       
	return this.#firstChild; //if children is empty
    }
    
    set #lastChildS(value){ this.#lastChild = value}
    get lastChild() { 
	for(let [key, child ] of this.children) {
            if(child.nextSibling == null) 
               this.#lastChildS = child	
	}
        return  this.#lastChild 
     }
     get childrenCount(){
	 return this.#children.size
     }
     /* TODO: ~ is only for cms build, so remove is during final user's
      * website build as is unnecessary 
      */
     get dragAndDrop() {
        const dnd = new DragAndDrop(null, this);
        return dnd 
     }

     /**************** Methods********** */
     
     /* for general insertion */
     insertAdjacentElement(
       position: "afterbegin" | "afterend" | "beforebegin" | "beforeend",
       element: ReactiveElement
     ){
        /* prepend child */	
	if(position == "afterbegin") 
	   this.prependChild(element);
        /* append child */ 
        else if (position == "beforeend")
	   this.appendChild(element);
        else if (position == "beforebegin") 
	   this.insertSiblingBeforebegin(element);
        else if (position == "afterend")
	   this.insertSiblingAfterend(element);
     
     }


     #handleInsert(parent, child): void {
	 parent.children.set(child.id, child)
	 child.parent = parent;
	 //this.#triggers.dirty("children")
     }


     /* Add child at the end */    
     appendChild(child: ReactiveElement): void { 
        if(this.lastChild) this.lastChild!.nextSibling = child;
        child.previousSibling = this.lastChild;
        child.nextSibling = null;
        this.#handleInsert(this, child); 
     }  

     /* Insert silbing After ~ element */
     insertSiblingAfterend(sibling: ReactiveElement) : void { 
        sibling.previousSibling = this;
        sibling.nextSibling = this.nextSibling
        if(this.nextSibling) this.nextSibling!.previousSibling = sibling        
        this.nextSibling = sibling
        this.#handleInsert(this.parent, sibling) 
     }

     /* Insert before ~ element */
     insertSiblingBeforebegin(sibling: ReactiveElement): void {
	if(this.previousSibling) this.previousSibling!.nextSibling = sibling    
        sibling.previousSibling = this.previousSibling
        sibling.nextSibling = this; 
        this.previousSibling = sibling;
        this.#handleInsert(this.parent, sibling)
     }
     prependChild(child: ReactiveElement): void { 
	if(this.firstChild) this.firstChild!.previousSibling = child;
         child.previousSibling = null;
         child.nextSibling = this.firstChild
         this.#handleInsert(this, child); 
     }
     removeChild(child: ReactiveElement) :void { 
        if(this.children.has(child.id)){ 
          if(child.previousSibling) 
            child.previousSibling.nextSibling = child.nextSibling;
          if(child.nextSibling) 
             child.nextSibling.previousSibling = child.previousSibling;
           
          this.children.delete(child.id);
          /* Remove below references, else, 
            * their deletion wont take place
          **/ 
          if(this.children.size == 0 ){
              this.#firstChild = null;
              this.#lastChild = null;
           }
          this.#triggers.dirty("children")      
        }
     }
  
      clone(maintainRefs: boolean = false): ReactiveElement {
	 return cloneElement(this, maintainRefs) 
      }
      isIcon(){
	return this.name.endsWith("icon")
      }
      isMutable(): boolean{
       return true; 
      }
     
      isRoot() { return this.#id.includes("root") } 
      isChildOf(el: ReactiveElement){
	 if(el.id === this.parent?.id) return true
	  return false
      }
      isDescendantOf(el: ReactiveElement){ 
           let parent  = this.parent
	  let state = false 
	  while(parent && el) {
  	     parent = parent.parent;
	     /* This could turn true if both defined, hence reason
	      * for checking nullability of both above
	      */
	     if(parent?.id === el?.id) {
	         state = true;   
		 break;	
             }
          } 
	  return state 
       }

    /* **********Other methods ***********/
    /* remove the element from a list container */ 
    removeFromList(list: ReactiveElement[]) {
      const index: number = list.findIndex((el, index) => {
          return el.id === this.id
      })
      /* Start removal at ~ index, and only the el */ 
      list.splice(index, 1);
      
      return list;
    }
    /* Delete from a map container */ 
    removeFromMap(map: Map<string, ReactiveElement>){
	map.delete(this.id);
        return map
    }

}

























