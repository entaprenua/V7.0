import  ReactiveElement from "./ReactiveElement";
import { createUniqueId } from "~/lib/utils"

export const cloneElement = (
    original: ReactiveElement,
    maintainRefs: boolean = false 
): ReactiveElement => {
    
   const clone = new ReactiveElement (original.name)
   clone.id = createUniqueId(); 
   clone.tailwind = original.tailwind
  /* This wont clone nested siblings though eg next of next or prev of prev */
  if(maintainRefs) {
	clone.nextSibling = original.nextSibling;
	clone.previousSibling = original.previousSibling
	clone.parent = original.parent
   }


   original.attributes.forEach((attribute, key) => {
       if(attribute instanceof ReactiveElement){
           clone
             .attributes
             .set(key, cloneElement(attribute as ReactiveElement));
      }else clone.attributes.set(key, attribute);
   })
    
    const children = original.children
    let origChild = original.firstChild;
    while (origChild != null) {
       const child = cloneElement(origChild)
       const origNextSibling = origChild.nextSibling;
       const origPrevSibling = origChild.previousSibling 
       const prevSibling = origPrevSibling?
	   cloneElement(origPrevSibling) : null
       
       clone.appendChild(child);   
       if(prevSibling){ 
	   prevSibling.nextSibling = child;
       } 
       child.previousSibling = prevSibling;
       /* child.nextSibling will be set by origNextSibling as 
	* by ~ child will be its prevSibling
	*/
       origChild = origNextSibling;
    }

    return clone
}
