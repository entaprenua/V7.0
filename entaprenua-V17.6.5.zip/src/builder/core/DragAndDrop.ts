import { ReactiveElement} from "./ReactiveElement";
import { Builder } from "../types";
import { TriggerCache } from "@solid-primitives/trigger";
import { componentRegistry } from "../utils/component-registry"

export default class DragAndDrop {
   
   #builder: Builder | null 
   #element: ReactiveElement 
   #draggable: ReactiveElement | null = null;
   #droppable: ReactiveElement | null = null;
   
   constructor(builder: Builder | null, element: ReactiveElement ){
       this.#builder = builder;
       this.#element = element;
   }
   
   #stopEffects(event: Event): void { 
       event.preventDefault();
       event.stopPropagation();
   }
     
   set builder(value: Builder | null) {
       this.#builder = value;
   }
   get builder(): Builder | null {
       return this.#builder
   }

   set draggable(value: ReactiveElement | null) {
       this.#draggable = value;
   }
   get draggable(): ReactiveElement | null {
       return this.#draggable;
   }
   
   set droppable(value: ReactiveElement | null) {
       this.#droppable = value;
   }
   get droppable(): ReactiveElement | null {
       return this.#droppable;
   }

   onDragStart = (event: DragEvent): void => {
       event.stopPropagation();
       this.#draggable = this.#element;	
   }
   
   onDrag = (event: DragEvent): void => {
       this.#stopEffects(event); 
   }
   
   onDragOver = (event: DragEvent): void => {
       this.#stopEffects(event); 
   }

   onDrop = (event: DragEvent): void => {
       this.#stopEffects(event); 
       this.#droppable = this.#element;
       
       try { 
           if (
                Object.keys(componentRegistry).includes(this.#draggable?.name) &&
               this.#draggable?.parent && 
               !this.#draggable.isPage() &&
               this.#draggable?.name !== this.#droppable?.name
           ) { 
               const child = this.#draggable!.clone();
               this.builder!.record.remove(this.#draggable); 
               this.builder!.record.add({
                   ref: this.#droppable, 
                   element: child, 
                   role: "first-child", 
               });
           } else {
               console.error("Forbidden drag drop action"); 
           }
       } catch (error) {
           console.error("Drag and drop failed with error: ", error);
       }
   }
}
