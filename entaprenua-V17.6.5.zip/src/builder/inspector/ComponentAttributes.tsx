import { Show, For, createMemo } from "solid-js";
import { useBuilder } from "~/";
import { Text } from "~/components/ui/text";
import { componentRegistry } from "../utils/component-registry";
import { capitalize } from "~/lib/utils";

// Helper: kebab-case to camelCase
const kebabToCamel = (str: string) => str.replace(/-([a-z])/g, (_, c) => c.toUpperCase());

export function ComponentAttributes() {
  const builder = useBuilder();
  const selected = () => builder.selected;

  const config = createMemo(() => {
    const el = selected();
    if (!el) return null;
    return componentRegistry[el.name] ?? null;
  });

  const attributes = createMemo(() => {
    const c = config();
    return c?.attributes ?? null;
  });

  const getAttributeValue = (attrName: string): string | undefined => {
    // Convert kebab to camel to read stored value
    const camelKey = kebabToCamel(attrName)
    return selected()?.getAttribute(camelKey);
  };

  const setAttributeValue = (attrName: string, value: string) => {
    // Convert kebab to camel for component props
    const camelKey = kebabToCamel(attrName)
    selected()?.setAttribute(camelKey, value);
  };

  const renderInput = (attrName: string, attrType: unknown) => {
    const currentValue = getAttributeValue(attrName) ?? "";
    
    if (Array.isArray(attrType)) {
      // Select dropdown for enum values
      return (
        <select
          class="w-full border rounded px-2 py-1 text-sm"
          value={currentValue}
          onChange={(e) => setAttributeValue(attrName, e.currentTarget.value)}
        >
          <option value="">Select...</option>
          <For each={attrType}>
            {(opt) => <option value={opt}>{opt}</option>}
          </For>
        </select>
      );
    }
    
    if (attrType === "boolean") {
      return (
        <input
          type="checkbox"
          checked={currentValue === "true"}
          onChange={(e) => setAttributeValue(attrName, String(e.currentTarget.checked))}
        />
      );
    }
    
    if (attrType === "number") {
      return (
        <input
          type="number"
          class="w-full border rounded px-2 py-1 text-sm"
          value={currentValue}
          onInput={(e) => setAttributeValue(attrName, e.currentTarget.value)}
        />
      );
    }
    
    // Default: text input
    return (
      <input
        type="text"
        class="w-full border rounded px-2 py-1 text-sm"
        value={currentValue}
        onInput={(e) => setAttributeValue(attrName, e.currentTarget.value)}
      />
    );
  };

  return (
    <Show when={selected() && attributes() && Object.keys(attributes()!).length > 0}>
      <div class="p-2 overflow-auto">
        <Text class="text-sm font-medium mb-2">
          {capitalize(selected()?.name ?? "")} Properties
        </Text>
        
        <div class="flex flex-col gap-2">
          <For each={Object.entries(attributes()!)}>
            {([attrName, attrType]) => (
              <div class="flex flex-col gap-1">
                <Text class="text-xs text-gray-500">{capitalize(attrName)}</Text>
                {renderInput(attrName, attrType)}
              </div>
            )}
          </For>
        </div>
      </div>
    </Show>
  );
}
