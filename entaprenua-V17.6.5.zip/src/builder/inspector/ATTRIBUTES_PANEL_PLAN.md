AttributesPanel
 - Should open when user explicitly open and when builder.preview is true, close otherwise.
Sections: 
1. This is the docking section, with icon buttons for user to select side
  of the panel(bottom, top, right, left)
2. Has name of currently selected element, next and previous arrows to 
   make builder.selected = builder.selected.previousSibling/builder.selected.nextSibling, and disabled if null.
3. Contains a trigger button to open contextuals of currently selected element(menubar/components/*), and a button to change builder.selected = builder.selected.parent
4. Common elements attributes(Height, width number field with option
  to change units of input value(px, %...), Robust colorPicker to change the currently selected element tailwind's height, width and bg-
5. Each specific element/component attributes (see componentRegistry)
The Styles were in menubar/styles but are now obsolete.

