import { Show, createSignal } from "solid-js";
import { useBuilder } from "~/";
import { Button } from "~/components/ui/button";
import { Popover, PopoverContent, PopoverTrigger } from "~/components/ui/popover";
import { Text } from "~/components/ui/text";
import { componentRegistry } from "../utils/component-registry";
import { capitalize } from "~/lib/utils";

export function ContextualsTrigger() {
  const builder = useBuilder();
  const selected = () => builder.selected;
  const [open, setOpen] = createSignal(false);

  const contextuals = () => {
    const el = selected();
    if (!el) return null;
    const config = componentRegistry[el.name];
    return config?.contextuals ?? null;
  };

  const hasContextuals = () => {
    const ctx = contextuals();
    return ctx && Object.keys(ctx).length > 0;
  };

  const goToParent = () => {
    const el = selected();
    if (el?.parent) {
      builder.selected = el.parent;
    }
  };

  const hasParent = () => !!selected()?.parent;

  return (
    <Show when={selected() && !builder.preview}>
      <div class="flex gap-2 p-2 border-b">
        <Popover open={open()} onOpenChange={setOpen}>
          <PopoverTrigger as={Button} variant="outline" class="flex-1">
            <Text class="text-sm">Add Contextual</Text>
          </PopoverTrigger>
          <PopoverContent class="max-h-60 overflow-auto p-2">
            <Show when={hasContextuals()} fallback={<Text class="text-sm text-gray-500">No contextual components</Text>}>
              <div class="flex flex-col gap-1">
                {Object.keys(contextuals() ?? {}).map((name) => (
                  <Button
                    variant="ghost"
                    class="justify-start text-sm"
                    onClick={() => {
                      const el = selected();
                      if (el) {
                        // Create new contextual element as child
                        // This would need implementation based on how elements are created
                        setOpen(false);
                      }
                    }}
                  >
                    {capitalize(name)}
                  </Button>
                ))}
              </div>
            </Show>
          </PopoverContent>
        </Popover>

        <Button
          variant="outline"
          onClick={goToParent}
          disabled={!hasParent()}
          title="Go to parent element"
        >
          <Text class="text-sm">Parent</Text>
        </Button>
      </div>
    </Show>
  );
}
