import { Show, For, createSignal } from "solid-js";
import { useBuilder } from "~/";
import { Text } from "~/components/ui/text";
import { Separator } from "~/components/ui/separator";

/**
 * List of common Tailwind CSS properties with their prefix and display label.
 * Used to generate individual input fields for each property.
 * Also used for the global slider to quickly adjust values.
 */
const TAILWIND_ATTRIBUTES = [
  { name: "p", prefix: "p-", label: "Padding" },
  { name: "px", prefix: "px-", label: "Padding X" },
  { name: "py", prefix: "py-", label: "Padding Y" },
  { name: "pt", prefix: "pt-", label: "Padding Top" },
  { name: "pr", prefix: "pr-", label: "Padding Right" },
  { name: "pb", prefix: "pb-", label: "Padding Bottom" },
  { name: "pl", prefix: "pl-", label: "Padding Left" },
  { name: "m", prefix: "m-", label: "Margin" },
  { name: "mx", prefix: "mx-", label: "Margin X" },
  { name: "my", prefix: "my-", label: "Margin Y" },
  { name: "mt", prefix: "mt-", label: "Margin Top" },
  { name: "mr", prefix: "mr-", label: "Margin Right" },
  { name: "mb", prefix: "mb-", label: "Margin Bottom" },
  { name: "ml", prefix: "ml-", label: "Margin Left" },
  { name: "gap", prefix: "gap-", label: "Gap" },
  { name: "w", prefix: "w-", label: "Width" },
  { name: "h", prefix: "h-", label: "Height" },
  { name: "min-w", prefix: "min-w-", label: "Min Width" },
  { name: "min-h", prefix: "min-h-", label: "Min Height" },
  { name: "max-w", prefix: "max-w-", label: "Max Width" },
  { name: "max-h", prefix: "max-h-", label: "Max Height" },
  { name: "text", prefix: "text-", label: "Text Size" },
  { name: "font", prefix: "font-", label: "Font Weight" },
  { name: "bg", prefix: "bg-", label: "Background" },
];

const SLIDER_ATTRIBUTES = [
  // Properties that can be adjusted via slider with their max values
  { name: "p", prefix: "p-", label: "Padding", max: 96 },
  { name: "px", prefix: "px-", label: "Padding X", max: 96 },
  { name: "py", prefix: "py-", label: "Padding Y", max: 96 },
  { name: "m", prefix: "m-", label: "Margin", max: 96 },
  { name: "mx", prefix: "mx-", label: "Margin X", max: 96 },
  { name: "my", prefix: "my-", label: "Margin Y", max: 96 },
  { name: "gap", prefix: "gap-", label: "Gap", max: 96 },
  { name: "w", prefix: "w-", label: "Width", max: 96 },
  { name: "h", prefix: "h-", label: "Height", max: 96 },
  { name: "text", prefix: "text-", label: "Text Size", max: 20 },
  { name: "font", prefix: "font-", label: "Font Weight", max: 9 },
];

/**
 * Splits a Tailwind class string into an array of individual classes.
 * @param tailwindString - Space-separated Tailwind classes
 * @returns Array of individual class names
 */
function getTailwindClasses(tailwindString: string): string[] {
  return tailwindString.split(/\s+/).filter(Boolean);
}

/**
 * Finds a Tailwind class that starts with the given prefix.
 * @param classes - Array of Tailwind classes
 * @param prefix - The prefix to search for (e.g., "p-", "bg-")
 * @returns The matching class or undefined if not found
 */
function findClassByPrefix(classes: string[], prefix: string): string | undefined {
  return classes.find((c) => c.startsWith(prefix));
}

/**
 * Sets or replaces a Tailwind class with a new value.
 * Search for existing class with same prefix, replace if found, otherwise add new.
 * @param tailwindString - Current Tailwind classes string
 * @param prefix - The prefix to search/replace (e.g")
 * @param., "p- value - The value to append after the prefix (e.g., "4" for "p-4")
 * @returns Updated Tailwind classes string
 */
function setTailwindClass(tailwindString: string, prefix: string, value: string): string {
  const classes = getTailwindClasses(tailwindString);
  const newClass = `${prefix}${value}`;
  
  // Find if a class with the same prefix already exists
  const existingIndex = classes.findIndex((c) => c.startsWith(prefix));
  if (existingIndex >= 0) {
    // Replace existing class with new value
    classes[existingIndex] = newClass;
  } else {
    // Add new class
    classes.push(newClass);
  }
  
  return classes.join(" ");
}

/**
 * Extracts the value portion of a Tailwind class (without the prefix).
 * @param tailwindString - Current Tailwind classes string
 * @param prefix - The prefix to extract value from (e.g., "p-")
 * @returns The value after the prefix, or empty string if not found
 */
function getTailwindClassValue(tailwindString: string, prefix: string): string {
  const classes = getTailwindClasses(tailwindString);
  const existing = findClassByPrefix(classes, prefix);
  if (!existing) return "";
  return existing.replace(prefix, "");
}

/**
 * CommonAttributes Panel Component
 * Displays a form for editing Tailwind CSS classes on the selected element.
 * Includes individual inputs for common properties, color pickers, and a raw text area.
 */
export function CommonAttributes() {
  const builder = useBuilder();
  const selected = () => builder.selected;
  
  // Global slider state for quick length adjustments
  const [sliderAttr, setSliderAttr] = createSignal(SLIDER_ATTRIBUTES[0]);
  const [sliderValue, setSliderValue] = createSignal(4);

  /**
   * Gets the value of a Tailwind class for a given prefix.
   * @param prefix - The Tailwind prefix (e.g., "p-", "m-")
   * @returns The value after the prefix
   */
  const getTailwindValue = (prefix: string): string => {
    const tw = selected()?.tailwind ?? "";
    return getTailwindClassValue(tw, prefix);
  };

  /**
   * Sets a Tailwind class value on the selected element.
   * Uses search-and-replace logic: finds existing class with same prefix, replaces if found.
   * @param prefix - The Tailwind prefix (e.g., "p-", "m-")
   * @param value - The value to set
   */
  const setTailwindValue = (prefix: string, value: string) => {
    if (!selected()) return;
    const currentTw = selected()!.tailwind ?? "";
    selected()!.tailwind = setTailwindClass(currentTw, prefix, value);
  };

  /**
   * Handles slider change - updates the selected element's Tailwind class.
   * @param value - The numeric value from the slider
   */
  const handleSliderChange = (value: number) => {
    setSliderValue(value);
    setTailwindValue(sliderAttr().prefix, String(value));
  };

  /**
   * Handles attribute selection from the dropdown.
   * Updates slider max value and resets to default.
   * @param attr - The selected attribute
   */
  const handleAttrChange = (attr: { name: string; prefix: string; label: string; max: number }) => {
    setSliderAttr(attr);
    // Try to get existing value, default to 4
    const existing = getTailwindValue(attr.prefix);
    setSliderValue(existing ? parseInt(existing) || 4 : 4);
  };

  /**
   * Gets the color value for a given prefix (bg-, text-, etc.).
   * Handles both Tailwind color names and arbitrary values like [#123456].
   * @param prefix - The Tailwind prefix (e.g., "bg-", "text-")
   * @returns The color value (Tailwind name or arbitrary value)
   */
  const getColorValue = (prefix: string): string => {
    const tw = selected()?.tailwind ?? "";
    const classes = getTailwindClasses(tw);
    const existing = findClassByPrefix(classes, prefix);
    if (!existing) return "";
    const value = existing.replace(prefix, "");
    // Return arbitrary values as-is (e.g., "[#123456]")
    if (value.startsWith("[")) return value;
    return value;
  };

  /**
   * Sets a color value on the selected element.
   * Converts hex colors (#123456) to Tailwind arbitrary syntax (bg-[#123456]).
   * Converts plain names (red-500) to standard Tailwind (bg-red-500).
   * Removes the class if value is empty.
   * @param prefix - The Tailwind prefix (e.g., "bg-", "text-")
   * @param value - The color value to set
   */
  const setColorValue = (prefix: string, value: string) => {
    if (!selected()) return;
    const currentTw = selected()!.tailwind ?? "";
    const classes = getTailwindClasses(currentTw);
    
    const existingIndex = classes.findIndex((c) => c.startsWith(prefix));
    if (value) {
      let newClass: string;
      // Already in arbitrary syntax: bg-[#123456]
      if (value.startsWith("[") && value.endsWith("]")) {
        newClass = `${prefix}${value}`;
      } 
      // Hex color: #123456 -> bg-[#123456]
      else if (value.startsWith("#")) {
        newClass = `${prefix}[${value}]`;
      } 
      // Plain Tailwind name: red-500 -> bg-red-500
      else {
        newClass = `${prefix}${value}`;
      }
      if (existingIndex >= 0) {
        classes[existingIndex] = newClass;
      } else {
        classes.push(newClass);
      }
    } else if (existingIndex >= 0) {
      // Remove the class if value is empty
      classes.splice(existingIndex, 1);
    }
    
    selected()!.tailwind = classes.join(" ");
  };

  return (
    <Show when={selected() && !builder.preview}>
      <div class="p-2 border-b">
        {/* Global Slider for quick length adjustments */}
        <Text class="text-sm font-medium mb-2">Quick Adjust</Text>
        <div class="flex flex-col gap-2 mb-3">
          {/* Attribute selector dropdown */}
          <select
            class="w-full border rounded px-2 py-1 text-sm bg-background"
            value={sliderAttr().name}
            onChange={(e) => {
              const attr = SLIDER_ATTRIBUTES.find(a => a.name === e.currentTarget.value);
              if (attr) handleAttrChange(attr);
            }}
          >
            <For each={SLIDER_ATTRIBUTES}>
              {(attr) => (
                <option value={attr.name}>{attr.label}</option>
              )}
            </For>
          </select>
          
          {/* Slider input */}
          <div class="flex items-center gap-2">
            <input
              type="range"
              min="0"
              max={sliderAttr().max}
              value={sliderValue()}
              onInput={(e) => handleSliderChange(parseInt(e.currentTarget.value))}
              class="flex-1"
            />
            <input
              type="number"
              min="0"
              max={sliderAttr().max}
              value={sliderValue()}
              onInput={(e) => handleSliderChange(parseInt(e.currentTarget.value) || 0)}
              class="w-12 border rounded px-1 py-1 text-sm text-center"
            />
          </div>
        </div>

        <Separator class="my-3" />

        <Text class="text-sm font-medium mb-2">Tailwind Classes</Text>
        
        {/* Individual input fields for each Tailwind property */}
        <div class="flex flex-col gap-2 max-h-[300px] overflow-y-auto">
          <For each={TAILWIND_ATTRIBUTES}>
            {(attr) => (
              <div class="flex items-center gap-2">
                <Text class="text-xs w-16 shrink-0">{attr.label}</Text>
                <input
                  type="text"
                  class="flex-1 border rounded px-2 py-1 text-sm"
                  value={getTailwindValue(attr.prefix)}
                  onInput={(e) => setTailwindValue(attr.prefix, e.currentTarget.value)}
                  placeholder={`${attr.prefix}4`}
                />
              </div>
            )}
          </For>
        </div>

        <Separator class="my-3" />

        {/* Color pickers for background and text color */}
        <Text class="text-sm font-medium mb-2">Colors</Text>
        <div class="flex flex-col gap-2">
          {/* Background color */}
          <div class="flex items-center gap-2">
            <Text class="text-xs w-16 shrink-0">Background</Text>
            <input
              type="color"
              class="w-8 h-8 border rounded cursor-pointer shrink-0"
              value={getColorValue("bg-") || "#000000"}
              onInput={(e) => setColorValue("bg-", e.currentTarget.value)}
            />
            <input
              type="text"
              class="flex-1 border rounded px-2 py-1 text-sm"
              value={getColorValue("bg-")}
              onInput={(e) => setColorValue("bg-", e.currentTarget.value)}
              placeholder="red-500 or [#123456]"
            />
          </div>
          {/* Text color */}
          <div class="flex items-center gap-2">
            <Text class="text-xs w-16 shrink-0">Text</Text>
            <input
              type="color"
              class="w-8 h-8 border rounded cursor-pointer shrink-0"
              value={getColorValue("text-") || "#000000"}
              onInput={(e) => setColorValue("text-", e.currentTarget.value)}
            />
            <input
              type="text"
              class="flex-1 border rounded px-2 py-1 text-sm"
              value={getColorValue("text-")}
              onInput={(e) => setColorValue("text-", e.currentTarget.value)}
              placeholder="red-500 or [#123456]"
            />
          </div>
        </div>

        <Separator class="my-3" />

        {/* Raw textarea for direct Tailwind class editing */}
        <Text class="text-sm font-medium mb-2">Raw Tailwind</Text>
        <textarea
          class="w-full border rounded px-2 py-1 text-sm font-mono h-20 resize-none"
          value={selected()?.tailwind ?? ""}
          onInput={(e) => {
            if (selected()) selected()!.tailwind = e.currentTarget.value;
          }}
          placeholder="p-4 m-2 bg-red-500..."
        />
      </div>
    </Show>
  );
}
