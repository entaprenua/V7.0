import { Show } from "solid-js";
import { useBuilder } from "~/";
import { Button } from "~/components/ui/button";
import { Text } from "~/components/ui/text";
import ChevronLeftIcon from "~/icons/ChevronLeft";
import ChevronRightIcon from "~/icons/ChevronRight";
import { capitalize } from "~/lib/utils";

export function ElementNav() {
  const builder = useBuilder();
  const selected = () => builder.selected;

  const goToPrevious = () => {
    const el = selected();
    if (el?.previousSibling) {
      builder.selected = el.previousSibling;
    }
  };

  const goToNext = () => {
    const el = selected();
    if (el?.nextSibling) {
      builder.selected = el.nextSibling;
    }
  };

  const hasPrevious = () => !!selected()?.previousSibling;
  const hasNext = () => !!selected()?.nextSibling;

  return (
    <Show when={selected() && !builder.preview}>
      <div class="flex items-center gap-2 p-2 border-b">
        <Button
          variant="ghost"
          onClick={goToPrevious}
          disabled={!hasPrevious()}
          class="p-1"
          title="Previous sibling"
        >
          <ChevronLeftIcon size={20} />
        </Button>

        <Text class="text-sm font-medium truncate flex-1">
          {capitalize(selected()?.name ?? "No element")}
        </Text>

        <Button
          variant="ghost"
          onClick={goToNext}
          disabled={!hasNext()}
          class="p-1"
          title="Next sibling"
        >
          <ChevronRightIcon size={20} />
        </Button>
      </div>
    </Show>
  );
}
