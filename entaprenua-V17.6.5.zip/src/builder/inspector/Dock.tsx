import { Show } from "solid-js";
import { useBuilder } from "~/";
import { Button } from "~/components/ui/button";
import ChevronLeftIcon from "~/icons/ChevronLeft";
import ChevronRightIcon from "~/icons/ChevronRight";
import ChevronUpIcon from "~/icons/ChevronUp";
import ChevronDownIcon from "~/icons/ChevronDown";

type PanelPosition = "top" | "bottom" | "left" | "right";

export function Dock() {
  const builder = useBuilder();
  const position = () => builder.panelPosition ?? "right";

  const setPosition = (pos: PanelPosition) => {
    builder.panelPosition = pos;
  };

  return (
    <Show when={!builder.preview}>
      <div class="flex gap-1 p-2 border-b">
        <Button
          variant={position() === "left" ? "default" : "ghost"}
          onClick={() => setPosition("left")}
          title="Dock to left"
          class="p-2"
        >
          <ChevronLeftIcon size={20} />
        </Button>
        
        <Button
          variant={position() === "top" ? "default" : "ghost"}
          onClick={() => setPosition("top")}
          title="Dock to top"
          class="p-2"
        >
          <ChevronUpIcon size={20} />
        </Button>
        
        <Button
          variant={position() === "bottom" ? "default" : "ghost"}
          onClick={() => setPosition("bottom")}
          title="Dock to bottom"
          class="p-2"
        >
          <ChevronDownIcon size={20} />
        </Button>
        
        <Button
          variant={position() === "right" ? "default" : "ghost"}
          onClick={() => setPosition("right")}
          title="Dock to right"
          class="p-2"
        >
          <ChevronRightIcon size={20} />
        </Button>
      </div>
    </Show>
  );
}

export function useDock() {
  const builder = useBuilder();
  
  return {
    get position() { return builder.panelPosition ?? "right" },
    setPosition: (pos: PanelPosition) => { builder.panelPosition = pos; },
  };
}
