# AttributesPanel Implementation Plan

## Overview
Implementation of the AttributesPanel based on the plan in `ATTRIBUTES_PANEL_PLAN.md`

## Sections to Implement

### 1. Dock Section
- Icon buttons to select panel position: bottom, top, right, left
- Updates `builder.panelPosition` state

### 2. Element Navigation
- Display selected element name
- Previous arrow: `builder.selected = builder.selected.previousSibling` (disabled if null)
- Next arrow: `builder.selected = builder.selected.nextSibling` (disabled if null)

### 3. Contextual Components Trigger
- Trigger button to open contextual components (from menubar/components/*)
- Button to navigate to parent: `builder.selected = builder.selected.parent`

### 4. Common Element Attributes
- Height (number field with unit selector: px, %, rem, em, vh, vw)
- Width (number field with unit selector)
- Color picker for background (`bg-` Tailwind properties)
- All attributes from componentRegistry

### 5. Component-Specific Attributes
- Dynamic rendering based on `componentRegistry[elementName]`
- All attributes defined in the registry

## Component Structure

```
src/builder/panels/
├── index.ts           # Exports
├── AttributesPanel.tsx # Main panel
├── Dock.tsx          # Dock section
├── ElementNav.tsx    # Element navigation (section 2)
├── ContextualsTrigger.tsx # Contextual components trigger (section 3)
├── CommonAttributes.tsx   # Common attributes (section 4)
└── ComponentAttributes.tsx # Component-specific (section 5)
```

## State Management
- Open: `builder.expandAttributesPanel` when explicitly opened OR `builder.preview === true`
- Position: stored in builder state

## Dependencies
- useBuilder from builder-provider
- componentRegistry from utils
- Existing UI components from ~/components/ui
