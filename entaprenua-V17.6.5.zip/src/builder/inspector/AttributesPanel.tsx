import { Show } from "solid-js";
import { useBuilder } from "~/";
import { Sheet, SheetContent } from "~/components/ui/sheet";
import { Dock } from "./Dock";
import { ElementNav } from "./ElementNav";
import { ContextualsTrigger } from "./ContextualsTrigger";
import { CommonAttributes } from "./CommonAttributes";
import { ComponentAttributes } from "./ComponentAttributes";

export function AttributesPanel() {
  const builder = useBuilder();
  const isOpen = () => builder.expandAttributesPanel || builder.preview;

  return (
    <Show when={isOpen()}>
      <Sheet 
         open={true} 
         onOpenChange={(open) => {
           if (!open) {
             builder.expandAttributesPanel = false;
          }
         }}
        modal={false}  
      >
        <SheetContent
          position={builder.panelPosition ?? "right"}
          class={(() => {
            const pos = builder.panelPosition ?? "right";
            return pos === "top" || pos === "bottom" 
              ? "w-full h-80 overflow-auto" 
              : "w-80 overflow-auto";
          })()}
        >
          <Dock />
          <ElementNav />
          <ContextualsTrigger />
          <CommonAttributes />
          <ComponentAttributes />
        </SheetContent>
      </Sheet>
    </Show>
  );
}
