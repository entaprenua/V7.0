import { createSignal, createMemo, For, Show, onMount, createEffect } from "solid-js"
import { A, useNavigate } from "@solidjs/router"
import { Title, Meta } from "@solidjs/meta"
import { Query, QueryBoundary } from "~/components/ui/query"
import { Card, CardContent, CardFooter } from "~/components/ui/card"
import { Button } from "~/components/ui/button"
import { Flex, Grid, Badge, Text, Heading, Skeleton, Box } from "~/components/ui"
import { Pagination } from "~/components/ui/pagination"
import { storesApi } from "~/lib/api"
import { routes } from "~/lib/utils/routes"
import type { Store } from "~/lib/types"
import StarIcon from "lucide-solid/icons/star"
import SearchIcon from "lucide-solid/icons/search"
import EyeIcon from "lucide-solid/icons/eye"
import DownloadIcon from "lucide-solid/icons/download"
import ShoppingCartIcon from "lucide-solid/icons/shopping-cart"
import LayoutTemplateIcon from "lucide-solid/icons/layout-template"
import StoreIcon from "lucide-solid/icons/store"
import CheckIcon from "lucide-solid/icons/check"
import AlertCircleIcon from "lucide-solid/icons/alert-circle"
import RefreshCwIcon from "lucide-solid/icons/refresh-cw"
import { useBuilder } from "~"

type SortOption = "newest" | "price-low" | "price-high" | "name"

interface Category {
  id: string
  label: string
}

interface TemplateFeature {
  icon: typeof LayoutTemplateIcon
  title: string
  description: string
}

interface TemplateStats {
  templates: string
  components: string
  storesCreated: string
  rating: string
}

const CATEGORIES: Category[] = [
  { id: "all", label: "All Templates" },
  { id: "ecommerce", label: "E-Commerce" },
  { id: "portfolio", label: "Portfolio" },
  { id: "blog", label: "Blog" },
  { id: "business", label: "Business" },
  { id: "landing", label: "Landing Page" },
]

const TEMPLATE_PREVIEWS: Record<string, string> = {
  default: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=800&h=600&fit=crop",
}

const FEATURES: TemplateFeature[] = [
  { icon: LayoutTemplateIcon, title: "Drag & Drop Builder", description: "Easily customize your store with our visual editor" },
  { icon: StoreIcon, title: "E-Commerce Ready", description: "Products, carts, checkout, and payments built-in" },
  { icon: DownloadIcon, title: "One-Click Export", description: "Download your store as NextJS or SolidStart" },
  { icon: CheckIcon, title: "Mobile Responsive", description: "Looks great on all devices out of the box" },
]

const STATS: TemplateStats = {
  templates: "50+",
  components: "100+",
  storesCreated: "10K+",
  rating: "4.9",
}

function formatPrice(price: string | number | null | undefined): string {
  if (price === null || price === undefined || price === 0 || price === "0" || price === "0.00") {
    return "Free"
  }
  const num = typeof price === "string" ? parseFloat(price) : price
  return `$${num.toFixed(2)}`
}

function isFreeTemplate(price: string | number | null | undefined): boolean {
  if (price === null || price === undefined) return true
  if (typeof price === "number") return price === 0
  return price === "0" || price === "0.00"
}

function useDebounce<T>(value: () => T, delay: number): () => T {
  const [debounced, setDebounced] = createSignal<T>(value())
  let timer: ReturnType<typeof setTimeout> | undefined
  
  createEffect(() => {
    const v = value()
    clearTimeout(timer)
    timer = setTimeout(() => setDebounced(() => v), delay)
  })
  
  return debounced
}

interface TemplateCardProps {
  template: Store
}

function TemplateCard(props: TemplateCardProps) {
  const template = () => props.template
  const navigate = useNavigate()
  const builder = useBuilder()

  const handleUseTemplate = () => {
    navigate(`${routes.newStore}?templateId=${template().id}`)
  }
  
  const handleBuyTemplate = () => {
    console.log("Buy template:", template().id)
  }
  
  const handlePreview = () => {
    navigate(`/builder/template/${template().id}`);
  };

  return (
    <Card class="group overflow-hidden hover:shadow-lg transition-all duration-300">
      <div class="aspect-[4/3] bg-gradient-to-br from-muted to-muted/50 relative overflow-hidden">
        <img
          src={template().logo || TEMPLATE_PREVIEWS.default}
          alt={`${template().name} preview`}
          class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          loading="lazy"
        />
        <div class="absolute inset-0 bg-black/0 group-hover:bg-black/40 transition-colors duration-300 flex items-center justify-center">
            <Button 
              variant="secondary"
              size="sm" 
              class="gap-2"
              href="" 
              onClick={handlePreview}
            >
              <EyeIcon class="size-4" />
              Preview
            </Button>
        </div>
        <Show when={isFreeTemplate(template().price)}>
          <Badge class="absolute top-3 right-3 bg-green-500">Free</Badge>
        </Show>
        <Show when={!isFreeTemplate(template().price)}>
          <Badge class="absolute top-3 right-3 bg-primary">
            {formatPrice(template().price)}
          </Badge>
        </Show>
      </div>
      <CardContent class="p-4">
        <Flex class="items-start justify-between gap-2 mb-2">
          <div class="size-10 rounded-lg bg-muted flex items-center justify-center shrink-0">
            <Show when={template().logo} fallback={
              <LayoutTemplateIcon class="size-5 text-muted-foreground" />
            }>
              <img 
                src={template().logo!} 
                alt="" 
                class="size-8 rounded-lg object-contain" 
              />
            </Show>
          </div>
          <div class="flex-1 min-w-0">
            <Text variant="subtitle1" class="font-semibold truncate">{template().name}</Text>
            <Text variant="caption" class="text-muted-foreground line-clamp-2">
              {template().description || "A beautiful store template"}
            </Text>
          </div>
        </Flex>
      </CardContent>
      <CardFooter class="p-4 pt-0 flex gap-2">
          <Button 
            variant="outline" 
            size="sm" 
            class="w-full gap-2"
            onClick={handlePreview}  
          >
            <EyeIcon class="size-4" />
            Preview
          </Button>
        <Show when={isFreeTemplate(template().price)}>
          <Button size="sm" class="gap-2" onClick={handleUseTemplate}>
            <DownloadIcon class="size-4" />
            Use Free
          </Button>
        </Show>
        <Show when={!isFreeTemplate(template().price)}>
          <Button size="sm" class="gap-2" onClick={handleBuyTemplate}>
            <ShoppingCartIcon class="size-4" />
            Buy Now
          </Button>
        </Show>
      </CardFooter>
    </Card>
  )
}

interface TemplateFiltersProps {
  selectedCategory: string
  onSelectCategory: (id: string) => void
  searchQuery: string
  onSearchChange: (query: string) => void
  sortBy: SortOption
  onSortChange: (sort: SortOption) => void
  totalResults: number
}

function TemplateFilters(props: TemplateFiltersProps) {
  return (
    <div class="space-y-4">
      <div class="flex flex-col sm:flex-row gap-4">
        <div class="relative flex-1">
          <SearchIcon class="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground pointer-events-none" />
          <input
            type="search"
            placeholder="Search templates..."
            value={props.searchQuery}
            onInput={(e) => props.onSearchChange(e.currentTarget.value)}
            class="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 pl-10"
            aria-label="Search templates"
          />
        </div>
        <select
          class="h-10 px-3 rounded-md border bg-background text-sm"
          value={props.sortBy}
          onChange={(e) => props.onSortChange(e.currentTarget.value as SortOption)}
          aria-label="Sort templates"
        >
          <option value="newest">Newest</option>
          <option value="price-low">Price: Low to High</option>
          <option value="price-high">Price: High to Low</option>
          <option value="name">Name</option>
        </select>
      </div>
      <div class="flex flex-wrap gap-2" role="tablist" aria-label="Template categories">
        <For each={CATEGORIES}>{(category) => (
          <button
            role="tab"
            aria-selected={props.selectedCategory === category.id}
            class={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
              props.selectedCategory === category.id
                ? "bg-primary text-primary-foreground"
                : "bg-muted hover:bg-muted/80"
            }`}
            onClick={() => props.onSelectCategory(category.id)}
          >
            {category.label}
          </button>
        )}</For>
      </div>
      <Text variant="body2" class="text-muted-foreground">
        {props.totalResults} template{props.totalResults !== 1 ? "s" : ""} found
      </Text>
    </div>
  )
}

function Stats() {
  return (
    <Grid cols={2} colsMd={4} class="gap-4">
      <div class="text-center p-4 rounded-lg bg-muted/50">
        <Heading level={3}>{STATS.templates}</Heading>
        <Text variant="caption" class="text-muted-foreground">Templates</Text>
      </div>
      <div class="text-center p-4 rounded-lg bg-muted/50">
        <Heading level={3}>{STATS.components}</Heading>
        <Text variant="caption" class="text-muted-foreground">Components</Text>
      </div>
      <div class="text-center p-4 rounded-lg bg-muted/50">
        <Heading level={3}>{STATS.storesCreated}</Heading>
        <Text variant="caption" class="text-muted-foreground">Stores Created</Text>
      </div>
      <div class="text-center p-4 rounded-lg bg-muted/50">
        <Flex class="items-center justify-center gap-1">
          <StarIcon class="size-4 text-yellow-500 fill-yellow-500" aria-hidden="true" />
          <Heading level={3}>{STATS.rating}</Heading>
        </Flex>
        <Text variant="caption" class="text-muted-foreground">Average Rating</Text>
      </div>
    </Grid>
  )
}

function FeatureGrid() {
  return (
    <Grid cols={1} colsSm={2} colsLg={4} class="gap-6">
      <For each={FEATURES}>{(feature) => (
        <div class="text-center p-6 rounded-xl bg-background border">
          <div class="size-12 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
            <feature.icon class="size-6 text-primary" aria-hidden="true" />
          </div>
          <Text variant="subtitle1" class="font-semibold mb-2">{feature.title}</Text>
          <Text variant="body2" class="text-muted-foreground">{feature.description}</Text>
        </div>
      )}</For>
    </Grid>
  )
}

function TemplateCardSkeleton() {
  return (
    <Card class="overflow-hidden">
      <div class="aspect-[4/3] bg-muted animate-pulse" />
      <CardContent class="p-4">
        <Flex class="items-start gap-2 mb-2">
          <Skeleton class="size-10 rounded-lg" />
          <div class="flex-1">
            <Skeleton class="h-4 w-3/4 mb-2" />
            <Skeleton class="h-3 w-1/2" />
          </div>
        </Flex>
      </CardContent>
      <CardFooter class="p-4 pt-0 flex gap-2">
        <Skeleton class="h-8 flex-1 rounded-md" />
        <Skeleton class="h-8 w-20 rounded-md" />
      </CardFooter>
    </Card>
  )
}

function ErrorState(props: { message: string; onRetry: () => void }) {
  return (
    <Flex class="flex-col items-center justify-center py-16 text-center">
      <AlertCircleIcon class="size-16 text-destructive mb-4" aria-hidden="true" />
      <Heading level={4} class="mb-2">Failed to Load Templates</Heading>
      <Text class="text-muted-foreground mb-4 max-w-md">
        {props.message}
      </Text>
      <Button variant="outline" onClick={props.onRetry} class="gap-2">
        <RefreshCwIcon class="size-4" />
        Try Again
      </Button>
    </Flex>
  )
}

function EmptyState(props: { onClearFilters: () => void }) {
  return (
    <Flex class="flex-col items-center justify-center py-16 text-center">
      <LayoutTemplateIcon class="size-16 text-muted-foreground mb-4" aria-hidden="true" />
      <Heading level={4} class="mb-2">No Templates Found</Heading>
      <Text class="text-muted-foreground mb-4">
        Try adjusting your search or filters
      </Text>
      <Button variant="outline" onClick={props.onClearFilters}>
        Clear Filters
      </Button>
    </Flex>
  )
}

function TemplateGrid(props: { templates: Store[] }) {
  return (
    <Grid cols={1} colsSm={2} colsLg={3} colsXl={4} class="gap-6 mt-8">
      <For each={props.templates}>
        {(template) => <TemplateCard template={template} />}
      </For>
    </Grid>
  )
}

function LoadingState() {
  return (
    <Grid cols={1} colsSm={2} colsLg={3} colsXl={4} class="gap-6 mt-8">
      <For each={[1, 2, 3, 4, 5, 6, 7, 8]}>
        {() => <TemplateCardSkeleton />}
      </For>
    </Grid>
  )
}

function CTASection() {
  return (
    <div class="border-t bg-muted/30">
      <div class="container mx-auto px-4 py-16">
        <Flex flexDirection="col" class="items-center text-center">
          <Heading level={2} class="mb-4">Can't Find What You're Looking For?</Heading>
          <Text class="text-muted-foreground mb-6 max-w-xl">
            We can build a custom template tailored to your specific needs.
            Contact our team for a personalized solution.
          </Text>
          <Button size="lg" class="gap-2">
            <ShoppingCartIcon class="size-4" aria-hidden="true" />
            Contact Sales
          </Button>
        </Flex>
      </div>
    </div>
  )
}

interface TemplatesSectionProps {
  templates: Store[]
  selectedCategory: string
  onSelectCategory: (id: string) => void
  searchQuery: string
  onSearchChange: (query: string) => void
  sortBy: SortOption
  onSortChange: (sort: SortOption) => void
}

function TemplatesSection(props: TemplatesSectionProps) {
  const debouncedSearch = useDebounce(() => props.searchQuery, 300)
  
  const filteredTemplates = createMemo(() => {
    let result = props.templates
    
    const search = debouncedSearch().toLowerCase().trim()
    if (search) {
      result = result.filter(
        (t) =>
          t.name?.toLowerCase().includes(search) ||
          t.description?.toLowerCase().includes(search)
      )
    }
    
    const sorted = [...result]
    switch (props.sortBy) {
      case "price-low":
        sorted.sort((a, b) => (parseFloat(String(a.price)) || 0) - (parseFloat(String(b.price)) || 0))
        break
      case "price-high":
        sorted.sort((a, b) => (parseFloat(String(b.price)) || 0) - (parseFloat(String(a.price)) || 0))
        break
      case "name":
        sorted.sort((a, b) => (a.name || "").localeCompare(b.name || ""))
        break
      case "newest":
      default:
        sorted.sort(
          (a, b) => new Date(b.insertedAt || 0).getTime() - new Date(a.insertedAt || 0).getTime()
        )
    }
    
    return sorted
  })

  const clearFilters = () => {
    props.onSearchChange("")
    props.onSelectCategory("all")
    props.onSortChange("newest")
  }

  return (
    <div class="container mx-auto px-4 py-12">
      <Box class="mb-8">
        <Heading level={2} class="mb-4">Why Use Our Templates?</Heading>
        <FeatureGrid />
      </Box>

      <Flex class="justify-between items-center mb-6">
        <Heading level={2}>Browse Templates</Heading>
      </Flex>

      <TemplateFilters
        selectedCategory={props.selectedCategory}
        onSelectCategory={props.onSelectCategory}
        searchQuery={props.searchQuery}
        onSearchChange={props.onSearchChange}
        sortBy={props.sortBy}
        onSortChange={props.onSortChange}
        totalResults={filteredTemplates().length}
      />

      <Show when={filteredTemplates().length === 0}>
        <EmptyState onClearFilters={clearFilters} />
      </Show>

      <Show when={filteredTemplates().length > 0}>
        <TemplateGrid templates={filteredTemplates()} />
      </Show>
    </div>
  )
}

function TemplatesContent() {
  const [selectedCategory, setSelectedCategory] = createSignal("all")
  const [searchQuery, setSearchQuery] = createSignal("")
  const [sortBy, setSortBy] = createSignal<SortOption>("newest")
  const [page, setPage] = createSignal(0)
  const [totalPages, setTotalPages] = createSignal(1)
  const [mounted, setMounted] = createSignal(false)

  onMount(() => {
    setMounted(true)
  })

  const fetchTemplates = async (): Promise<Store[]> => {
    try {
      const response = await storesApi.getTemplates({ 
        page: page(), 
        size: 12,
        search: searchQuery() || undefined,
      })
      // Handle array response (server returns array instead of PagedResponse)
      let content: Store[] = []
      if (Array.isArray(response)) {
        content = response
      } else if (response && typeof response === 'object' && 'content' in response) {
        content = (response as any).content || []
      }
      setTotalPages(Math.ceil(content.length / 12) || 1)
      return content
    } catch {
      setTotalPages(1)
      return []
    }
  }

  return (
    <>
      <Title>Store Templates - Entaprenua</Title>
      <Meta name="description" content="Choose from our collection of professional e-commerce templates. Launch your online store in minutes with ready-made designs." />
      <Meta name="keywords" content="e-commerce templates, online store templates, shop templates, ecommerce themes, store builder" />
      
      <div class="min-h-screen bg-background">
        <div class="border-b">
          <div class="container mx-auto px-4 py-16">
            <Flex flexDirection="col" class="items-center text-center mb-8">
              <Badge class="mb-4 px-4 py-1.5 text-sm bg-primary/10 text-primary border-primary/20">
                Template Marketplace
              </Badge>
              <Heading level={1} class="text-4xl md:text-5xl font-bold mb-4">
                Choose Your Perfect Store Template
              </Heading>
              <Text class="text-lg text-muted-foreground max-w-2xl">
                Start with a professional template and customize it to match your brand.
                Create your dream online store in minutes.
              </Text>
            </Flex>
            <Stats />
          </div>
        </div>

        <Show when={mounted()} fallback={<LoadingState />}>
          <Query
            queryFn={fetchTemplates}
            queryKey={["templates"]}
          >
            <QueryBoundary
              loadingFallback={<LoadingState />}
              errorFallback={(error, retry) => (
                <ErrorState 
                  message={error?.message || "Failed to load templates. Please try again."} 
                  onRetry={retry} 
                />
              )}
            >
              {(data) => {
                const templates = (data as Store[]) ?? []
                return (
                  <>
                    <TemplatesSectionWrapper
                      templates={templates}
                      selectedCategory={selectedCategory()}
                      onSelectCategory={(val) => setSelectedCategory(val)}
                      searchQuery={searchQuery()}
                      onSearchChange={(val) => setSearchQuery(val)}
                      sortBy={sortBy()}
                      onSortChange={(val) => setSortBy(val)}
                    />
                  </>
                )
              }}
            </QueryBoundary>
          </Query>
        </Show>

        <Pagination
          page={page()}
          totalPages={totalPages()}
          onPageChange={setPage}
          class="justify-center py-8"
        />

        <CTASection />
      </div>
    </>
  )
}

interface TemplatesSectionWrapperProps {
  templates: Store[]
  selectedCategory: string
  onSelectCategory: (id: string) => void
  searchQuery: string
  onSearchChange: (query: string) => void
  sortBy: SortOption
  onSortChange: (sort: SortOption) => void
}

function TemplatesSectionWrapper(props: TemplatesSectionWrapperProps) {
  return (
    <TemplatesSection
      templates={props.templates}
      selectedCategory={props.selectedCategory}
      onSelectCategory={props.onSelectCategory}
      searchQuery={props.searchQuery}
      onSearchChange={props.onSearchChange}
      sortBy={props.sortBy}
      onSortChange={props.onSortChange}
    />
  )
}

export default TemplatesContent
