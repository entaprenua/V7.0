import { createSignal, onMount, Show, For, createResource } from "solid-js"
import { A, useParams, useNavigate, useSearchParams } from "@solidjs/router"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "~/components/ui/card"
import { Button } from "~/components/ui/button"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "~/components/ui/dialog"
import { Flex, Grid, Badge, Text, Heading, TextField, TextFieldLabel, TextFieldInput } from "~/components/ui"
import { storesApi } from "~/lib/api"
import { routes } from "~/lib/utils/routes"
import { formatCurrency } from "~/lib/utils"
import EyeIcon from "lucide-solid/icons/eye"
import ShoppingCartIcon from "lucide-solid/icons/shopping-cart"
import DownloadIcon from "lucide-solid/icons/download"
import ArrowLeftIcon from "lucide-solid/icons/arrow-left"
import StarIcon from "lucide-solid/icons/star"
import CheckIcon from "lucide-solid/icons/check"
import LayoutTemplateIcon from "lucide-solid/icons/layout-template"
import GlobeIcon from "lucide-solid/icons/globe"
import LoaderIcon from "lucide-solid/icons/loader"
import { useAuth } from "~/lib/guards/auth"

export default function TemplateDetailPage() {
  const params = useParams()
  const navigate = useNavigate()
  const [searchParams] = useSearchParams<{ purchased?: string }>()
  const { isAuthenticated } = useAuth()
  
  const [template, setTemplate] = createSignal<any>(null)
  const [isLoading, setIsLoading] = createSignal(true)
  const [error, setError] = createSignal<string | null>(null)
  const [showUseDialog, setShowUseDialog] = createSignal(false)
  const [isPurchasing, setIsPurchasing] = createSignal(false)
  const [purchased, setPurchased] = createSignal(false)
  
  const [hasPurchased] = createResource(
    () => [template()?.id, isAuthenticated()] as [string, boolean],
    async ([templateId, auth]) => {
      if (!auth || !templateId) return false
      try {
        const result = await storesApi.checkTemplatePurchased(templateId)
        return result?.purchased === true
      } catch {
        return false
      }
    },
    { initialValue: false }
  )

  onMount(async () => {
    const templateId = params.id
    if (!templateId) {
      setError("Template not found")
      setIsLoading(false)
      return
    }
    
    if (searchParams.purchased === "true") {
      setPurchased(true)
      setShowUseDialog(true)
    }
    
    try {
      const templateData = await storesApi.getTemplateById(templateId)
      if (templateData) {
        setTemplate(templateData)
      } else {
        setError("Template not found")
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load template")
    } finally {
      setIsLoading(false)
    }
  })

  const isFree = () => !template()?.price || template()?.price === "0" || template()?.price === "0.00"

  const handleUseTemplate = async () => {
    if (!isAuthenticated()) {
      const redirect = routes.templateDetails(params.id || '')
      navigate(`${routes.logIn}?redirect=${encodeURIComponent(redirect)}`)
      return
    }
    
    if (!isFree() && !hasPurchased()) {
      await handlePurchase()
      return
    }
    
    navigate(`${routes.newStore}?templateId=${template()?.id}`)
  }

  const handlePurchase = async () => {
    if (!isAuthenticated()) {
      const redirect = routes.templateDetails(params.id || '')
      navigate(`${routes.logIn}?redirect=${encodeURIComponent(redirect)}`)
      return
    }
    
    setIsPurchasing(true)
    try {
      const result = await storesApi.purchaseTemplate(template()?.id || '')
      if (result?.checkoutUrl) {
        window.location.href = result.checkoutUrl
      } else {
        setError("Failed to initiate purchase")
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to initiate purchase")
    } finally {
      setIsPurchasing(false)
    }
  }

  const features = [
    "Drag & Drop Builder",
    "Mobile Responsive",
    "SEO Optimized",
    "Product Management",
    "Shopping Cart",
    "Order Management",
    "Payment Integration",
    "Analytics Dashboard",
  ]

  return (
    <div class="min-h-screen bg-background">
      <Show when={isLoading()}>
        <div class="container mx-auto px-4 py-8">
          <div class="animate-pulse space-y-4">
            <div class="h-8 bg-muted rounded w-48" />
            <div class="h-64 bg-muted rounded-lg" />
            <div class="h-4 bg-muted rounded w-3/4" />
          </div>
        </div>
      </Show>

      <Show when={error()}>
        <div class="container mx-auto px-4 py-16">
          <Flex flexDirection="col" class="items-center text-center">
            <LayoutTemplateIcon class="size-16 text-muted-foreground mb-4" />
            <Heading level={3} class="mb-2">Template Not Found</Heading>
            <Text class="text-muted-foreground mb-6">{error()}</Text>
            <A href={routes.templates}>
              <Button>Browse Templates</Button>
            </A>
          </Flex>
        </div>
      </Show>

      <Show when={!isLoading() && !error() && template()}>
        <div class="border-b">
          <div class="container mx-auto px-4 py-4">
            <A href={routes.templates} class="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground">
              <ArrowLeftIcon class="size-4" />
              Back to Templates
            </A>
          </div>
        </div>

        <div class="container mx-auto px-4 py-8">
          <Grid cols={1} colsLg={2} class="gap-8">
            <div class="aspect-[4/3] rounded-xl overflow-hidden bg-muted">
              <img
                src="https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=800&h=600&fit=crop"
                alt={template().name}
                class="w-full h-full object-cover"
              />
            </div>

            <div>
              <Flex class="items-start justify-between gap-4 mb-4">
                <div class="size-16 rounded-xl bg-muted flex items-center justify-center">
                  <Show when={template().logo} fallback={
                    <LayoutTemplateIcon class="size-8 text-muted-foreground" />
                  }>
                    <img src={template().logo} alt="" class="size-14 rounded-xl object-contain" />
                  </Show>
                </div>
                <Show when={isFree()}>
                  <Badge class="text-lg px-4 py-2 bg-green-500">Free</Badge>
                </Show>
                <Show when={!isFree()}>
                  <Badge class="text-lg px-4 py-2 bg-primary">
                    ${formatCurrency(template().price || "0")}
                  </Badge>
                </Show>
              </Flex>

              <Heading level={1} class="text-3xl font-bold mb-2">
                {template().name}
              </Heading>

              <Flex class="items-center gap-4 mb-4">
                <Flex class="items-center gap-1">
                  <StarIcon class="size-5 text-yellow-500 fill-yellow-500" />
                  <Text class="font-semibold">4.9</Text>
                  <Text class="text-muted-foreground">(128 reviews)</Text>
                </Flex>
                <Text class="text-muted-foreground">|</Text>
                <Text class="text-muted-foreground">1,234 uses</Text>
              </Flex>

              <Text class="text-muted-foreground mb-6">
                {template().description || "A beautiful, modern store template perfect for any business."}
              </Text>

              <div class="space-y-3 mb-8">
                <Heading level={4} class="mb-3">What's Included</Heading>
                <For each={features}>{(feature) => (
                  <Flex class="items-center gap-2">
                    <CheckIcon class="size-5 text-green-500" />
                    <Text>{feature}</Text>
                  </Flex>
                )}</For>
              </div>

              <Flex class="flex-col sm:flex-row gap-3">
                <Show when={isFree() || hasPurchased()}>
                  <Button size="lg" class="flex-1 gap-2" onClick={() => setShowUseDialog(true)} disabled={hasPurchased() && purchased()}>
                    <Show when={hasPurchased() && purchased()}>
                      <CheckIcon class="size-5" />
                      Purchased - Use Template
                    </Show>
                    <Show when={!hasPurchased() || !purchased()}>
                      <DownloadIcon class="size-5" />
                      {isFree() ? "Use This Template (Free)" : "Use This Template"}
                    </Show>
                  </Button>
                </Show>
                <Show when={!isFree() && !hasPurchased()}>
                  <Button size="lg" class="flex-1 gap-2" onClick={handleUseTemplate} disabled={isPurchasing()}>
                    <Show when={isPurchasing()}>
                      <LoaderIcon class="size-5 animate-spin" />
                      Processing...
                    </Show>
                    <Show when={!isPurchasing()}>
                      <ShoppingCartIcon class="size-5" />
                      Buy Now - {formatCurrency(template()?.price || "0")}
                    </Show>
                  </Button>
                </Show>
                <Button variant="outline" size="lg" class="gap-2" onClick={() => navigate(`/builder/template/${params.id}`)}>
                  <EyeIcon class="size-5" />
                  Live Preview
                </Button>
              </Flex>
            </div>
          </Grid>
        </div>

        <div class="container mx-auto px-4 py-12">
          <Heading level={2} class="mb-6">Template Screenshots</Heading>
          <Grid cols={1} colsSm={2} colsLg={3} class="gap-4">
            <For each={[1, 2, 3]}>{(i) => (
              <div class="aspect-video rounded-lg bg-muted overflow-hidden">
                <img
                  src={`https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=800&h=600&fit=crop&sig=${i}`}
                  alt={`Screenshot ${i}`}
                  class="w-full h-full object-cover"
                />
              </div>
            )}</For>
          </Grid>
        </div>

        <div class="border-t bg-muted/30">
          <div class="container mx-auto px-4 py-12">
            <Grid cols={1} colsSm={2} class="gap-8">
              <div>
                <Heading level={3} class="mb-4">Template Details</Heading>
                <div class="space-y-3">
                  <Flex class="justify-between">
                    <Text class="text-muted-foreground">Category</Text>
                    <Text class="font-medium">E-Commerce</Text>
                  </Flex>
                  <Flex class="justify-between">
                    <Text class="text-muted-foreground">Last Updated</Text>
                    <Text class="font-medium">February 2026</Text>
                  </Flex>
                  <Flex class="justify-between">
                    <Text class="text-muted-foreground">Version</Text>
                    <Text class="font-medium">1.0.0</Text>
                  </Flex>
                </div>
              </div>
              <div>
                <Heading level={3} class="mb-4">Support</Heading>
                <Text class="text-muted-foreground mb-4">
                  Need help? Contact the template developer for support.
                </Text>
                <Flex class="gap-3">
                  <Button variant="outline">
                    Contact Support
                  </Button>
                </Flex>
              </div>
            </Grid>
          </div>
        </div>
      </Show>

      <Dialog open={showUseDialog()} onOpenChange={(open) => !open && setShowUseDialog(false)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {purchased() ? "Template Purchased!" : "Use Template"}
            </DialogTitle>
            <DialogDescription>
              {purchased() 
                ? "Your payment was successful. Create your store now."
                : "Create a new store using this template"
              }
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowUseDialog(false)}>Cancel</Button>
            <Button onClick={() => navigate(`${routes.newStore}?templateId=${template()?.id}`)}>
              Continue to Create Store
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
