import { Show, For, createEffect } from "solid-js"
import { A, useNavigate } from "@solidjs/router"
import { Title, Meta } from "@solidjs/meta"
import { Button } from "~/components/ui/button"
import { Text, Flex } from "~/components/ui"
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarProvider,
  SidebarTrigger,
} from "~/components/ui/sidebar"
import { useAuth } from "~/lib/guards/auth"
import { AdminPanelProvider, useAdminPanel } from "~/lib/stores/admin-panel"
import Logo from "~/logo"
import { routes } from "~/lib/utils/routes"
import {
  ShoppingCartIcon,
  ImageIcon,
  SettingsIcon,
  PlusIcon,
  ChevronRightIcon,
  UserIcon,
  HomeIcon,
  SearchIcon,
} from "~/icons"
import ExternalLinkIcon from "lucide-solid/icons/external-link"
import CodeIcon from "lucide-solid/icons/code"

const menuItems = [
  { icon: HomeIcon, label: "Stores", href: routes.stores },
  { icon: PlusIcon, label: "New Store", href: routes.newStore },
  { icon: ShoppingCartIcon, label: "Products", href: routes.adminProducts },
  { icon: SearchIcon, label: "Categories", href: routes.adminCategories },
  { icon: ShoppingCartIcon, label: "Orders", href: routes.adminOrders },
  { icon: ImageIcon, label: "Media", href: routes.adminMedia },
  { icon: SettingsIcon, label: "Settings", href: routes.adminSettings },
]

export function AppSidebar() {
  const auth = useAuth()
  const navigate = useNavigate()
  const admin = useAdminPanel()
  const state = admin()
  const actions = admin as Record<string, any>

  const handleLogout = async () => {
    await auth.logout()
    navigate(routes.logIn)
  }
  
  return (
    <Sidebar side="left" variant="sidebar" collapsible="offcanvas">
      <SidebarHeader class="p-4 border-b">
        <A href={routes.home} class="flex items-center gap-2">
          <Logo class="size-8" />
          <Text variant="subtitle1" class="font-bold">Entaprenua</Text>
        </A>
      </SidebarHeader>

      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel>Current Store</SidebarGroupLabel>
          <SidebarGroupContent>
            <Show when={state.currentStore} fallback={
              <Button variant="outline" size="sm" class="w-full justify-between">
                <span>No store</span>
                <ChevronRightIcon class="size-4" />
              </Button>
            }>
              <select
                class="w-full h-10 px-3 pr-8 rounded-md border bg-background text-sm appearance-none cursor-pointer"
                value={state.currentStore?.id || ""}
                onChange={(e) => actions.switchStore(e.currentTarget.value)}
              >
                <For each={state.stores}>{(store) => (
                  <option value={store.id}>{store.name}</option>
                )}</For>
              </select>
            </Show>
          </SidebarGroupContent>
        </SidebarGroup>

        <SidebarGroup>
          <SidebarGroupLabel>Menu</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              <For each={menuItems}>{(item) => (
                <SidebarMenuItem>
                  <SidebarMenuButton as={A} href={item.href} class="flex items-center gap-3 px-3 py-2 rounded-md text-sm hover:bg-accent">
                    <item.icon class="size-4" />
                    <span>{item.label}</span>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              )}</For>
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>

      <SidebarFooter class="p-4 border-t">
        <Flex class="items-center gap-3 mb-3">
          <div class="size-8 rounded-full bg-primary/10 flex items-center justify-center">
            <UserIcon class="size-4 text-primary" />
          </div>
          <div class="flex-1 min-w-0">
            <Text variant="body2" class="font-medium truncate">{auth.user()?.email}</Text>
          </div>
        </Flex>
        <Button variant="ghost" size="sm" class="w-full justify-start" onClick={handleLogout}>
          Sign Out
        </Button>
      </SidebarFooter>
    </Sidebar>
  )
}

export default function AdminPageWrapper(props: { children: any }) {
  return (
    <AdminPanelProvider>
      <AdminPageContent>{props.children}</AdminPageContent>
    </AdminPanelProvider>
  )
}

function AdminPageContent(props: { children: any }) {
  const navigate = useNavigate()
  const admin = useAdminPanel()
  const state = admin()
  const actions = admin as Record<string, any>
  
  return (
    <>
      <Title>Admin - Entaprenua</Title>
      <Meta name="description" content="Manage your stores" />
      <SidebarProvider defaultOpen>
        <div class="flex h-screen">
          <AppSidebar />
          <main class="flex-1 overflow-y-auto bg-muted/30">
            <Show when={state.currentStore}>
              <div class="border-b bg-background px-4 py-3">
                <Flex class="items-center justify-between">
                  <Flex class="items-center gap-2 text-sm">
                    <A href={routes.stores} class="text-muted-foreground hover:text-foreground">
                      Stores
                    </A>
                    <ChevronRightIcon class="size-3 text-muted-foreground" />
                    <A href={`/stores/${state.currentStore?.id}`} class="font-medium hover:text-foreground">
                      {state.currentStore?.name}
                    </A>
                    <ChevronRightIcon class="size-3 text-muted-foreground" />
                    <span class="text-muted-foreground">Admin</span>
                  </Flex>
                  <Flex class="items-center gap-2">
                    <Button variant="outline" size="sm" class="gap-1" onClick={() => navigate(`/stores/${state.currentStore?.id}`)}>
                      <ExternalLinkIcon class="size-3" />
                      View Store
                    </Button>
                    <Button variant="outline" size="sm" class="gap-1" onClick={() => navigate(`/builder/${state.currentStore?.id}`)}>
                      <CodeIcon class="size-3" />
                      Build
                    </Button>
                  </Flex>
                </Flex>
              </div>
            </Show>
            <div class="p-4">
              <SidebarTrigger />
            </div>
            {props.children}
          </main>
        </div>
      </SidebarProvider>
    </>
  )
}
