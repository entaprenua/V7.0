import parse from '~/lib/server/parser'

const MAX_CODE_SIZE = 500 * 1024 // 500KB

export async function POST({ request }: { request: Request }) {
  try {
    const body = await request.json()
    
    const code = body?.code
    
    if (!code) {
      return Response.json(
        { success: false, error: 'Code is required' },
        { status: 400 }
      )
    }
    
    if (typeof code !== 'string') {
      return Response.json(
        { success: false, error: 'Code must be a string' },
        { status: 400 }
      )
    }
    
    if (code.length > MAX_CODE_SIZE) {
      return Response.json(
        { success: false, error: 'Code exceeds 500KB limit' },
        { status: 413 }
      )
    }
    
    const result = parse(code)
    
    return Response.json(result)
  } catch (error: any) {
    return Response.json(
      { success: false, error: error.message || 'Parse failed' },
      { status: 400 }
    )
  }
}
