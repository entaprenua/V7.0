import { json } from '@solidjs/router';
import { storeRepository } from '~/lib/db/repositories/store.repository';
import { apiSuccess, apiError } from '~/lib/server/api-response';

export async function GET({ request }: { request: Request }) {
  try {
    // Templates are public - no auth required
    const stores = await storeRepository.findTemplates();
    
    return json(apiSuccess(stores));
  } catch (error: any) {
    return json(apiError(error.message || 'Failed to get templates', 'BAD_REQUEST'), { status: 400 });
  }
}
