import { json } from '@solidjs/router';
import { storeRepository } from '~/lib/db/repositories/store.repository';
import { authMiddleware } from '~/lib/server/auth';

export async function GET({ request }: { request: Request }) {
  try {
    const user = await authMiddleware(request);
    
    const url = new URL(request.url);
    const name = url.searchParams.get('name');
    
    if (!name) {
      return json({ exists: false, message: 'Name is required' }, { status: 400 });
    }
    
    const exists = await storeRepository.existsByOwnerIdAndName(user.id, name);
    
    return json({ exists });
  } catch (error: any) {
    return json({ exists: false, message: error.message || 'Failed to check name' }, { status: 400 });
  }
}
