import { json } from '@solidjs/router';
import { storeRepository } from '~/lib/db/repositories/store.repository';
import { authMiddleware } from '~/lib/server/auth';
import { apiSuccess, apiError } from '~/lib/server/api-response';

// NOTE: GET /api/stores moved to Spring Boot (/api/v1/stores)
// Use Spring Boot for listing stores (read-only)
// Use SolidStart for: create, update, delete, clone, pages

export async function POST({ request }: { request: Request }) {
  try {
    const user = await authMiddleware(request);
    const body = await request.json();
    
    const store = await storeRepository.create({
      userId: user.id,
      name: body.name,
      domainName: body.domainName,
      isTemplate: body.isTemplate,
      visibility: body.visibility,
    });
    
    return json(apiSuccess(store), { status: 201 });
  } catch (error: any) {
    return json(apiError(error.message || 'Failed to create store', 'BAD_REQUEST'), { status: 400 });
  }
}
