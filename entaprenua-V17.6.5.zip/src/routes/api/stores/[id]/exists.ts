import { json } from '@solidjs/router';
import { storeRepository } from '~/lib/db/repositories/store.repository';
import { authMiddleware } from '~/lib/server/auth';

export async function GET({ request, params }: { request: Request; params: { id: string } }) {
  try {
    const user = await authMiddleware(request);
    
    // Check if store name exists (for validation)
    const url = new URL(request.url);
    const name = url.searchParams.get('name');
    
    if (name) {
      const exists = await storeRepository.existsByOwnerIdAndName(
        user.id,
        name,
        params.id // exclude current store if updating
      );
      
      return json({ exists });
    }
    
    return json({ exists: false });
  } catch (error: any) {
    return json({ error: error.message || 'Failed to check existence' }, { status: 400 });
  }
}
