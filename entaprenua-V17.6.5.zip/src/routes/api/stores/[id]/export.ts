import { json } from '@solidjs/router';
import { storeRepository } from '~/lib/db/repositories/store.repository';
import { generateStore } from '~/lib/server/generator';
import { authMiddleware } from '~/lib/server/auth';

export async function GET({ params, request }: { params: { id: string }, request: Request }) {
  try {
    await authMiddleware(request);
    
    const store = await storeRepository.findById(params.id);
    
    if (!store) {
      return json({ error: 'Store not found' }, { status: 404 });
    }

    // Generate store files
    const result = await generateStore(params.id);
    
    if (!result.success) {
      return json({ error: result.error }, { status: 400 });
    }

    // Create ZIP file (simplified - return JSON for now)
    return json({
      store,
      files: result.files,
      fileCount: Object.keys(result.files || {}).length,
    });
  } catch (error: any) {
    return json({ error: error.message || 'Failed to export store' }, { status: 400 });
  }
}
