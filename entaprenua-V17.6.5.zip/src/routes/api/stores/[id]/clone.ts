import { json } from '@solidjs/router';
import { storeRepository } from '~/lib/db/repositories/store.repository';
import { authMiddleware } from '~/lib/server/auth';
import { apiSuccess, apiError } from '~/lib/server/api-response';

export async function POST({ params, request }: { params: { id: string }, request: Request }) {
  try {
    const user = await authMiddleware(request);
    const body = await request.json();
    
    const { name: newName, purchaseId } = body;
    
    if (purchaseId) {
      const purchase = await storeRepository.findPurchaseById(purchaseId);
      
      if (!purchase) {
        return json(apiError('Purchase not found', 'NOT_FOUND'), { status: 404 });
      }
      
      if (purchase.userId !== user.id) {
        return json(apiError('Invalid purchase', 'FORBIDDEN'), { status: 403 });
      }
      
      if (purchase.status !== 'COMPLETED') {
        return json(apiError('Payment not completed', 'FORBIDDEN'), { status: 403 });
      }
      
      if (purchase.storeId !== params.id) {
        return json(apiError('Purchase does not match template', 'FORBIDDEN'), { status: 403 });
      }
    } else {
      const sourceStore = await storeRepository.findById(params.id);
      if (!sourceStore) {
        return json(apiError('Store not found', 'NOT_FOUND'), { status: 404 });
      }
      
      const price = typeof sourceStore.price === 'string' ? parseFloat(sourceStore.price) : sourceStore.price;
      if (sourceStore.isTemplate && price && price > 0) {
        return json(apiError('This is a paid template. Please provide purchaseId.', 'FORBIDDEN'), { status: 403 });
      }
    }
    
    const newStoreId = crypto.randomUUID();
    const finalName = newName || `Copy of Store`;
    
    const store = await storeRepository.clone(
      params.id,
      newStoreId,
      finalName,
      user.id
    );
    
    return json(apiSuccess(store), { status: 201 });
  } catch (error: any) {
    return json(apiError(error.message || 'Failed to clone store', 'BAD_REQUEST'), { status: 400 });
  }
}
