import { json } from '@solidjs/router';
import { storeRepository } from '~/lib/db/repositories/store.repository';
import { authMiddleware } from '~/lib/server/auth';
import { apiSuccess, apiError } from '~/lib/server/api-response';

export async function GET({ params, request }: { 
  params: { id: string; name: string }, 
  request: Request 
}) {
  try {
    await authMiddleware(request);
    
    const page = await storeRepository.findPage(params.id, params.name);
    
    if (!page) {
      return json(apiError('Page not found', 'NOT_FOUND'), { status: 404 });
    }
    
    return json(apiSuccess(page));
  } catch (error: any) {
    return json(apiError(error.message || 'Failed to get page', 'UNAUTHORIZED'), { status: 401 });
  }
}

export async function PUT({ params, request }: { 
  params: { id: string; name: string }, 
  request: Request 
}) {
  try {
    await authMiddleware(request);
    
    const body = await request.json();
    
    const page = await storeRepository.savePage({
      storeId: params.id,
      name: params.name,
      slug: body.slug,
      element: body.element,
    });
    
    return json(apiSuccess(page));
  } catch (error: any) {
    return json(apiError(error.message || 'Failed to update page', 'BAD_REQUEST'), { status: 400 });
  }
}

export async function DELETE({ params, request }: { 
  params: { id: string; name: string }, 
  request: Request 
}) {
  try {
    await authMiddleware(request);
    
    await storeRepository.deletePage(params.id, params.name);
    
    return json(apiSuccess({ success: true }));
  } catch (error: any) {
    return json(apiError(error.message || 'Failed to delete page', 'BAD_REQUEST'), { status: 400 });
  }
}
