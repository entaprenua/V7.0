import { json } from '@solidjs/router';
import { storeRepository } from '~/lib/db/repositories/store.repository';
import { authMiddleware } from '~/lib/server/auth';
import { apiSuccess, apiError } from '~/lib/server/api-response';

export async function GET({ params, request }: { params: { id: string }, request: Request }) {
  try {
    await authMiddleware(request);
    
    const pages = await storeRepository.findAllPages(params.id);
    
    return json(apiSuccess(pages));
  } catch (error: any) {
    return json(apiError(error.message || 'Failed to get pages', 'UNAUTHORIZED'), { status: 401 });
  }
}

export async function POST({ params, request }: { params: { id: string }, request: Request }) {
  try {
    await authMiddleware(request);
    
    const body = await request.json();
    
    const page = await storeRepository.savePage({
      storeId: params.id,
      name: body.name,
      slug: body.slug,
      element: body.element,
    });
    
    return json(apiSuccess(page), { status: 201 });
  } catch (error: any) {
    return json(apiError(error.message || 'Failed to save page', 'BAD_REQUEST'), { status: 400 });
  }
}
