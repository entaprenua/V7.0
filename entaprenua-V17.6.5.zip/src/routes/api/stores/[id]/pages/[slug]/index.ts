import { json } from '@solidjs/router';
import { storeRepository } from '~/lib/db/repositories/store.repository';
import { apiSuccess, apiError } from '~/lib/server/api-response';

/**
 * Get page by slug.
 * NOTE: For root/home page, use slug="home" instead of "/" - URL routing doesn't support "/" as a parameter.
 * Shopify pattern: each resource has a single-segment handle, no nested slashes allowed.
 */

export async function GET({ params }: { params: { id: string; slug: string } }) {
  try {
    const page = await storeRepository.findPageBySlug(params.id, params.slug);
    
    if (!page) {
      return json(apiError('Page not found', 'NOT_FOUND'), { status: 404 });
    }
    
    return json(apiSuccess(page));
  } catch (error: any) {
    return json(apiError(error.message || 'Failed to get page', 'INTERNAL_ERROR'), { status: 500 });
  }
}