import { json } from '@solidjs/router';
import { storeRepository } from '~/lib/db/repositories/store.repository';
import { authMiddleware } from '~/lib/server/auth';
import { apiSuccess, apiError } from '~/lib/server/api-response';

// NOTE: GET /api/stores/{id} also exists in Spring Boot (/api/v1/stores/{id})
// SolidStart version: for builder (cloning purchased templates)
// Spring Boot version: for e-commerce (products, cart, etc.)

export async function GET({ params, request }: { params: { id: string }, request: Request }) {
  try {
    await authMiddleware(request);
    
    const store = await storeRepository.findById(params.id);
    
    if (!store) {
      return json(apiError('Store not found', 'NOT_FOUND'), { status: 404 });
    }
    
    return json(apiSuccess(store));
  } catch (error: any) {
    return json(apiError(error.message || 'Failed to get store', 'UNAUTHORIZED'), { status: 401 });
  }
}

export async function PUT({ params, request }: { params: { id: string }, request: Request }) {
  try {
    await authMiddleware(request);
    
    const body = await request.json();
    
    const store = await storeRepository.update(params.id, body);
    
    return json(apiSuccess(store));
  } catch (error: any) {
    return json(apiError(error.message || 'Failed to update store', 'BAD_REQUEST'), { status: 400 });
  }
}

export async function DELETE({ params, request }: { params: { id: string }, request: Request }) {
  try {
    await authMiddleware(request);
    
    await storeRepository.delete(params.id);
    
    return json(apiSuccess({ success: true }));
  } catch (error: any) {
    return json(apiError(error.message || 'Failed to delete store', 'BAD_REQUEST'), { status: 400 });
  }
}
