import { json } from '@solidjs/router';
import { saveStoreWithPages, type SaveStoreWithPagesData } from '~/lib/db/repositories/store.repository';
import { authMiddleware } from '~/lib/server/auth';
import { apiSuccess, apiError } from '~/lib/server/api-response';

export async function PUT({ params, request }: { params: { id: string }, request: Request }) {
  try {
    await authMiddleware(request);
    
    const body: SaveStoreWithPagesData = await request.json();
    
    if (!body.userId) {
      return json(apiError('userId is required', 'BAD_REQUEST'), { status: 400 });
    }

    if (!body.pages || !Array.isArray(body.pages)) {
      return json(apiError('pages array is required', 'BAD_REQUEST'), { status: 400 });
    }

    const data: SaveStoreWithPagesData = {
      id: params.id,
      userId: body.userId,
      name: body.name,
      description: body.description,
      domainName: body.domainName,
      logo: body.logo,
      favicon: body.favicon,
      visibility: body.visibility,
      isInMaintenanceMode: body.isInMaintenanceMode,
      pages: body.pages,
    };
    
    const result = await saveStoreWithPages(data);
    
    return json(apiSuccess(result));
  } catch (error: any) {
    console.error('Error saving store with pages:', error);
    return json(apiError(error.message || 'Failed to save store with pages', 'BAD_REQUEST'), { status: 400 });
  }
}
