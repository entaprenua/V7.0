import { json } from '@solidjs/router';
import { storeRepository } from '~/lib/db/repositories/store.repository';
import { authMiddleware } from '~/lib/server/auth';
import { apiSuccess, apiError } from '~/lib/server/api-response';

export async function GET({ params, request }: { params: { id: string }, request: Request }) {
  try {
    await authMiddleware(request);
    
    const routes = await storeRepository.findRoutes(params.id);
    
    return json(apiSuccess(routes));
  } catch (error: any) {
    return json(apiError(error.message || 'Failed to get routes', 'UNAUTHORIZED'), { status: 401 });
  }
}
