import { json } from '@solidjs/router';
import { authMiddleware } from '~/lib/server/auth';
import { importCodebaseToStore } from '~/lib/server/upload';

const MAX_FILE_SIZE = 50 * 1024 * 1024; // 50MB

export async function POST({ params, request }: { params: { id: string }, request: Request }) {
  try {
    await authMiddleware(request);
    
    const contentType = request.headers.get('content-type') || '';
    
    if (!contentType.includes('multipart/form-data')) {
      return json({ error: 'Content-Type must be multipart/form-data' }, { status: 400 });
    }

    const formData = await request.formData();
    const file = formData.get('file') as File | null;

    if (!file) {
      return json({ error: 'No file provided' }, { status: 400 });
    }

    if (!file.name.endsWith('.zip')) {
      return json({ error: 'Please upload a ZIP file' }, { status: 400 });
    }

    if (file.size > MAX_FILE_SIZE) {
      return json({ error: 'File exceeds 50MB limit' }, { status: 400 });
    }

    const content = await file.arrayBuffer();

    const result = await importCodebaseToStore(params.id, content);
    
    if (!result.success) {
      return json({ error: result.error }, { status: 400 });
    }

    return json({
      success: true,
      pagesCreated: result.pagesCreated,
      message: `Successfully imported ${result.pagesCreated} pages`,
    });
  } catch (error: any) {
    console.error('[Import] Failed:', error);
    return json({ error: error.message || 'Failed to import store' }, { status: 400 });
  }
}
