import { json } from '@solidjs/router';
import { authMiddleware } from '~/lib/server/auth';
import { importStore, importCodebaseToStore, parseTsxFile } from '~/lib/server/upload';
import { db } from '~/lib/db';
import { stores, storePages } from '~/lib/db/schema';

const MAX_FILE_SIZE = 50 * 1024 * 1024; // 50MB

export async function POST({ request }: { request: Request }) {
  try {
    const user = await authMiddleware(request);
    
    const contentType = request.headers.get('content-type') || '';
    
    if (!contentType.includes('multipart/form-data')) {
      return json({ error: 'Content-Type must be multipart/form-data' }, { status: 400 });
    }

    const formData = await request.formData();
    
    const name = formData.get('name') as string;
    const description = formData.get('description') as string;
    const file = formData.get('file') as File | null;

    if (!name) {
      return json({ error: 'Store name is required' }, { status: 400 });
    }

    // Use user from auth, not from formData
    const userId = user.id;

    if (!file) {
      return json({ error: 'No file provided' }, { status: 400 });
    }

    if (file.size > MAX_FILE_SIZE) {
      return json({ error: 'File exceeds 50MB limit' }, { status: 400 });
    }

    // Create store first
    const storeId = crypto.randomUUID();
    
    await db.insert(stores).values({
      id: storeId,
      userId,
      name,
      parentId: storeId,
      visibility: 'public',
      isTemplate: false,
    });

    // Handle file based on type
    let pagesCreated = 0;
    
    if (file.name.endsWith('.zip')) {
      // ZIP file - extract and import
      const buffer = await file.arrayBuffer();
      const result = await importCodebaseToStore(storeId, buffer);
      
      if (!result.success) {
        // Rollback store creation
        await db.delete(stores).where(/* @trash */ undefined);
        return json({ error: result.error }, { status: 400 });
      }
      
      pagesCreated = result.pagesCreated || 0;
    } else {
      // Single TSX/JSX file - parse it
      const content = await file.text();
      const parseResult = parseTsxFile(content);
      
      const pageId = crypto.randomUUID();
      await db.insert(storePages).values({
        id: pageId,
        storeId,
        name: 'home',
        slug: '',
        element: parseResult.element || { name: 'box', children: [] },
        version: 1,
      });
      pagesCreated = 1;
    }

    return json({
      success: true,
      storeId,
      pagesCreated,
    }, { status: 201 });
  } catch (error: any) {
    console.error('[Import] Failed:', error);
    return json({ error: error.message || 'Failed to import store' }, { status: 400 });
  }
}
