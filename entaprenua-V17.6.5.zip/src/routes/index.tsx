import { For, Show, createSignal } from "solid-js"
import { A } from "@solidjs/router"
import { Title, Meta } from "@solidjs/meta"
import { Card, CardContent, CardHeader, CardTitle } from "~/components/ui/card"
import { Button } from "~/components/ui/button"
import { Flex, Grid, Text, Heading, Badge, Separator } from "~/components/ui"
import Logo from "~/logo"
import { routes } from "~/lib/utils/routes"
import {
  ShoppingCartIcon,
  SettingsIcon,
  PaletteIcon,
  GlobeIcon,
  ImageIcon,
  ShieldUserIcon,
  ArrowRightIcon,
  CheckIcon,
  SunIcon,
  MoonIcon,
  MenuIcon,
  CrossIcon,
} from "~/icons"
import { useColorMode } from "~/components/ui/color-mode"
import { useAuth } from "~/lib/guards/auth"

const features = [
  {
    icon: PaletteIcon,
    title: "Visual Page Builder",
    description: "Drag-and-drop interface to create stunning storefronts without writing code.",
    color: "bg-blue-500",
  },
  {
    icon: GlobeIcon,
    title: "Multi-Store Support",
    description: "Manage multiple e-commerce stores from a single dashboard.",
    color: "bg-green-500",
  },
  {
    icon: ShoppingCartIcon,
    title: "E-Commerce Engine",
    description: "Full cart, checkout, orders, and payment processing with Stripe.",
    color: "bg-orange-500",
  },
  {
    icon: ImageIcon,
    title: "Media Management",
    description: "Upload, organize, and transform images with automatic variants.",
    color: "bg-purple-500",
  },
  {
    icon: ShieldUserIcon,
    title: "Enterprise Security",
    description: "JWT authentication, CSRF protection, rate limiting, and audit logging.",
    color: "bg-red-500",
  },
  {
    icon: SettingsIcon,
    title: "API-First Design",
    description: "RESTful API with 40+ endpoints for full customization.",
    color: "bg-cyan-500",
  },
]

const stats = [
  { value: "40+", label: "API Endpoints" },
  { value: "150+", label: "Components" },
  { value: "99.9%", label: "Uptime" },
]

const stack = {
  "Frontend": ["SolidJS", "SolidStart", "Tailwind", "Kobalte"],
  "Backend": ["Kotlin", "Spring Boot", "WebFlux", "R2DBC"],
  "Database": ["PostgreSQL", "Redis", "Flyway"],
}

function Header() {
  const { colorMode, toggleColorMode } = useColorMode()
  const auth = useAuth()
  const [mobileMenuOpen, setMobileMenuOpen] = createSignal(false)
  const isLoggedIn = () => !!auth.user()

  return (
    <header class="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur-md overflow-x-hidden">
      <div class="container mx-auto px-4">
        <div class="flex h-14 items-center justify-between">
          {/* Logo */}
          <A href={routes.home} class="flex items-center gap-2 shrink-0">
            <Logo class="size-9" />
            <span class="font-bold text-lg hidden sm:inline">Entaprenua</span>
          </A>
          
          {/* Desktop Navigation - centered */}
          <nav class="hidden md:flex items-center gap-1 absolute left-1/2 transform -translate-x-1/2">
            <Show when={isLoggedIn()}>
              <A href={routes.stores} class="px-3 py-2 text-sm font-medium text-muted-foreground hover:text-foreground">Stores</A>
            </Show>
            <Show when={!isLoggedIn()}>
              <A href={routes.stores} class="px-3 py-2 text-sm font-medium text-muted-foreground hover:text-foreground">Stores</A>
              <A href={routes.templates} class="px-3 py-2 text-sm font-medium text-muted-foreground hover:text-foreground">Templates</A>
              <A href={routes.documentation} class="px-3 py-2 text-sm font-medium text-muted-foreground hover:text-foreground">Docs</A>
            </Show>
          </nav>
          
          {/* Right side */}
          <div class="flex items-center gap-2 shrink-0">
            <button
              onClick={toggleColorMode}
              class="p-2 rounded-lg hover:bg-accent"
              aria-label="Toggle theme"
            >
              <Show when={colorMode() === 'dark'} fallback={<MoonIcon class="size-4" />}>
                <SunIcon class="size-4" />
              </Show>
            </button>
            
            <Show when={isLoggedIn()} fallback={
              <>
                <A href={routes.logIn}>
                  <Button variant="ghost" size="sm">Log In</Button>
                </A>
                <A href={routes.signUp}>
                  <Button size="sm">Sign Up</Button>
                </A>
              </>
            }>
              <A href={routes.stores}>
                <Button variant="ghost" size="sm">Dashboard</Button>
              </A>
              <A href={routes.admin}>
                <Button size="sm">Admin</Button>
              </A>
            </Show>

            {/* Mobile Menu Button */}
            <button
              class="md:hidden p-2 rounded-lg hover:bg-accent"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen())}
            >
              <Show when={mobileMenuOpen()} fallback={<MenuIcon class="size-5" />}>
                <CrossIcon class="size-5" />
              </Show>
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        <Show when={mobileMenuOpen()}>
          <nav class="md:hidden py-3 border-t flex flex-col">
            <A href={routes.stores} class="px-3 py-2 text-sm font-medium" onClick={() => setMobileMenuOpen(false)}>Stores</A>
            <A href={routes.templates} class="px-3 py-2 text-sm font-medium" onClick={() => setMobileMenuOpen(false)}>Templates</A>
            <A href={routes.stores} class="px-3 py-2 text-sm font-medium" onClick={() => setMobileMenuOpen(false)}>Sell Store</A>
            <A href={routes.documentation} class="px-3 py-2 text-sm font-medium" onClick={() => setMobileMenuOpen(false)}>Docs</A>
            <A href={routes.support} class="px-3 py-2 text-sm font-medium" onClick={() => setMobileMenuOpen(false)}>Support</A>
            <div class="flex gap-2 mt-3 pt-3 border-t">
              <Show when={isLoggedIn()} fallback={
                <>
                  <A href={routes.logIn} class="flex-1" onClick={() => setMobileMenuOpen(false)}>
                    <Button variant="outline" size="sm" class="w-full">Log In</Button>
                  </A>
                  <A href={routes.signUp} class="flex-1" onClick={() => setMobileMenuOpen(false)}>
                    <Button size="sm" class="w-full">Sign Up</Button>
                  </A>
                </>
              }>
                <A href={routes.stores} class="flex-1" onClick={() => setMobileMenuOpen(false)}>
                  <Button variant="outline" size="sm" class="w-full">Dashboard</Button>
                </A>
                <A href={routes.admin} class="flex-1" onClick={() => setMobileMenuOpen(false)}>
                  <Button size="sm" class="w-full">Admin</Button>
                </A>
              </Show>
            </div>
          </nav>
        </Show>
      </div>
    </header>
  )
}

function Hero() {
  return (
    <section class="relative overflow-hidden py-24 md:py-32 lg:py-40">
      {/* Background decoration */}
      <div class="absolute inset-0 -z-10">
        <div class="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-primary/10 via-transparent to-transparent" />
        <div class="absolute top-20 left-1/4 w-96 h-96 bg-primary/5 rounded-full blur-3xl" />
        <div class="absolute bottom-20 right-1/4 w-96 h-96 bg-secondary/5 rounded-full blur-3xl" />
      </div>
      
      <div class="container mx-auto px-4">
        <Flex flexDirection="col" class="items-center text-center max-w-4xl mx-auto">
          <Logo class="w-20 h-20 mb-6" />
          <Badge class="mb-6 px-4 py-1.5 text-sm bg-primary/10 text-primary border-primary/20">
            🚀 Enterprise-Grade E-Commerce Platform
          </Badge>
          
          <Heading level={1} class="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight mb-6 bg-gradient-to-r from-foreground to-foreground/70 bg-clip-text text-transparent">
            Build Stores <span class="text-primary">Without Code</span>
          </Heading>
          
          <Text class="text-lg md:text-xl text-muted-foreground max-w-2xl mb-10 leading-relaxed">
            Create beautiful, production-ready e-commerce storefronts with our visual page builder. 
            Generate NextJS or SolidStart applications with a single click.
          </Text>
          
          <Flex class="gap-4 flex-wrap justify-center mb-16">
            <A href={routes.signUp}>
              <Button size="lg" class="gap-2 px-8 h-12 text-base">
                Start Building Free
                <ArrowRightIcon class="size-4" />
              </Button>
            </A>
            <A href={routes.templates}>
              <Button variant="secondary" size="lg" class="gap-2 px-8 h-12 text-base">
                Browse Templates
              </Button>
            </A>
            <A href={routes.stores}>
              <Button variant="outline" size="lg" class="px-8 h-12 text-base">
                My Stores
              </Button>
            </A>
          </Flex>
          
          {/* Stats */}
          <Grid cols={2} colsMd={4} class="gap-8 w-full max-w-2xl">
            <For each={stats}>{(stat) => (
              <div class="text-center">
                <Text class="text-3xl md:text-4xl font-bold text-primary">{stat.value}</Text>
                <Text class="text-sm text-muted-foreground mt-1">{stat.label}</Text>
              </div>
            )}</For>
          </Grid>
        </Flex>
      </div>
    </section>
  )
}

function Features() {
  return (
    <section class="py-24 bg-muted/30">
      <div class="container mx-auto px-4">
        <Flex flexDirection="col" class="items-center text-center mb-16">
          <Badge variant="outline" class="mb-4">Features</Badge>
          <Heading level={2} class="text-3xl md:text-4xl font-bold mb-4">
            Everything You Need to Succeed
          </Heading>
          <Text class="text-muted-foreground text-lg max-w-2xl">
            From visual page building to enterprise payments, we've built every feature your store needs.
          </Text>
        </Flex>
        
        <Grid cols={1} colsMd={2} colsLg={3} class="gap-6">
          <For each={features}>{(f) => (
            <Card class="group hover:shadow-lg hover:border-primary/30 transition-all duration-300">
              <CardHeader>
                <div class={`size-12 rounded-xl ${f.color} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300`}>
                  <f.icon class="size-6 text-white" />
                </div>
                <CardTitle class="text-xl">{f.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <Text class="text-muted-foreground">{f.description}</Text>
              </CardContent>
            </Card>
          )}</For>
        </Grid>
      </div>
    </section>
  )
}

function TechStack() {
  return (
    <section class="py-24">
      <div class="container mx-auto px-4">
        <Flex flexDirection="col" class="items-center text-center mb-16">
          <Badge variant="outline" class="mb-4">Technology</Badge>
          <Heading level={2} class="text-3xl md:text-4xl font-bold mb-4">
            Built With Modern Tech
          </Heading>
          <Text class="text-muted-foreground text-lg max-w-2xl">
            Enterprise-grade technologies for reliability, performance, and scalability.
          </Text>
        </Flex>
        
        <Grid cols={1} colsMd={3} class="gap-6 max-w-4xl mx-auto">
          <For each={Object.entries(stack)}>{([category, items]) => (
            <Card class="relative overflow-hidden">
              <div class="absolute top-0 left-0 w-1 h-full bg-gradient-to-b from-primary to-primary/50" />
              <CardHeader>
                <Text class="text-sm font-semibold text-primary uppercase tracking-wider">{category}</Text>
              </CardHeader>
              <CardContent>
                <Flex class="flex-wrap gap-2">
                  <For each={items}>{(item) => (
                    <Badge variant="secondary" class="px-3 py-1">{item}</Badge>
                  )}</For>
                </Flex>
              </CardContent>
            </Card>
          )}</For>
        </Grid>
      </div>
    </section>
  )
}

function CTASection() {
  return (
    <section class="py-24 bg-gradient-to-br from-primary via-primary/90 to-primary/80 relative overflow-hidden dark:from-primary/90 dark:via-primary/80 dark:to-primary/70">
      {/* Background pattern */}
      <div class="absolute inset-0 opacity-10 dark:opacity-5">
        <div class="absolute inset-0" style="background-image: radial-gradient(circle at 2px 2px, white 1px, transparent 0); background-size: 32px 32px;" />
      </div>
      
      <div class="container mx-auto px-4 relative">
        <Flex flexDirection="col" class="items-center text-center text-primary-foreground max-w-3xl mx-auto">
          <Heading level={2} class="text-3xl md:text-4xl font-bold mb-6 dark:text-white">
            Start Building Your Empire Today
          </Heading>
          <Text class="text-xl text-primary-foreground/80 mb-10 max-w-xl">
            Join thousands of entrepreneurs who've already launched their stores with Entaprenua.
          </Text>
          
          <Flex class="gap-4 flex-wrap justify-center">
            <A href={routes.signUp}>
              <Button size="lg" variant="secondary" class="gap-2 px-8 h-12 text-base font-semibold">
                Get Started Free
                <ArrowRightIcon class="size-4" />
              </Button>
            </A>
            <A href={routes.documentation}>
              <Button 
                size="lg" 
                variant="outline" 
                class="border-primary-foreground/30 text-primary-foreground hover:bg-primary-foreground/10 px-8 h-12 text-base dark:text-white dark:border-white/30 dark:hover:bg-white/10"
              >
                Read the Docs
              </Button>
            </A>
          </Flex>
          
          <Flex class="items-center gap-6 mt-12 text-sm text-primary-foreground/70">
            <Flex class="items-center gap-2">
              <CheckIcon class="size-4" />
              <span>No credit card required</span>
            </Flex>
            <Flex class="items-center gap-2">
              <CheckIcon class="size-4" />
              <span>Free tier available</span>
            </Flex>
            <Flex class="items-center gap-2">
              <CheckIcon class="size-4" />
              <span>Cancel anytime</span>
            </Flex>
          </Flex>
        </Flex>
      </div>
    </section>
  )
}

function Footer() {
  return (
    <footer class="border-t bg-background py-16">
      <div class="container mx-auto px-4">
        <Grid cols={1} colsMd={4} class="gap-12 mb-12">
          <div>
            <A href={routes.home} class="flex items-center gap-3 mb-4">
              <Logo class="size-8" />
              <Text class="font-bold text-lg dark:text-foreground">Entaprenua</Text>
            </A>
            <Text class="text-muted-foreground text-sm leading-relaxed">
              The visual e-commerce platform for entrepreneurs who want to build, not code.
            </Text>
          </div>
          
          <div>
            <Text class="font-semibold mb-4">Product</Text>
            <Flex flexDirection="col" class="gap-2">
              <A href={routes.templates} class="text-sm text-muted-foreground hover:text-foreground">Templates</A>
              <A href={routes.documentation} class="text-sm text-muted-foreground hover:text-foreground">Documentation</A>
              <A href={routes.support} class="text-sm text-muted-foreground hover:text-foreground">Support</A>
            </Flex>
          </div>
          
          <div>
            <Text class="font-semibold mb-4">Resources</Text>
            <Flex flexDirection="col" class="gap-2">
              <A href={routes.documentation} class="text-sm text-muted-foreground hover:text-foreground">API Reference</A>
              <A href={routes.documentation} class="text-sm text-muted-foreground hover:text-foreground">Guides</A>
              <A href={routes.support} class="text-sm text-muted-foreground hover:text-foreground">Contact</A>
            </Flex>
          </div>
          
          <div>
            <Text class="font-semibold mb-4">Company</Text>
            <Flex flexDirection="col" class="gap-2">
              <A href="#" class="text-sm text-muted-foreground hover:text-foreground">About</A>
              <A href="#" class="text-sm text-muted-foreground hover:text-foreground">Blog</A>
              <A href="#" class="text-sm text-muted-foreground hover:text-foreground">Careers</A>
            </Flex>
          </div>
        </Grid>
        
        <Separator class="mb-8" />
        
        <Flex class="justify-between items-center flex-wrap gap-4">
          <Text class="text-sm text-muted-foreground">
            © {new Date().getFullYear()} Entaprenua. All rights reserved.
          </Text>
          <Flex class="gap-6">
            <A href="#" class="text-sm text-muted-foreground hover:text-foreground">Privacy</A>
            <A href="#" class="text-sm text-muted-foreground hover:text-foreground">Terms</A>
          </Flex>
        </Flex>
      </div>
    </footer>
  )
}

export default function HomePage() {
  return (
    <>
      <Title>Entaprenua - Visual E-Commerce Platform</Title>
      <Meta name="description" content="Build production-ready e-commerce storefronts without code. Visual page builder, multi-framework support, and enterprise-grade backend." />
      <Meta name="keywords" content="e-commerce, page builder, no-code, SolidJS, NextJS, storefront, online store" />
      
      <div class="min-h-screen flex flex-col bg-background">
        <Header />
        <main class="flex-1">
          <Hero />
          <Features />
          <TechStack />
          <CTASection />
        </main>
        <Footer />
      </div>
    </>
  )
}
