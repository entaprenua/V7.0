import { onMount, on, Show, createEffect, createSignal } from "solid-js";
import { useParams, useNavigate } from "@solidjs/router";
import { useBuilder } from "~/builder/builder-provider";
import BuilderHome from "~/builder/home";
import { routes } from "~/lib/utils/routes";
import { storesApi } from "~/lib/api";
import { Flex, Text, Heading, Button } from "~/components/ui";
import LoaderIcon from "lucide-solid/icons/loader";
import AlertCircleIcon from "lucide-solid/icons/alert-circle";
import ArrowLeftIcon from "lucide-solid/icons/arrow-left";

/**
 * Unified Builder Page
 * 
 * Supports two modes:
 * - Edit mode: ?storeId=xxx - Edit an existing store
 * - Preview mode: ?templateId=xxx - Preview a template
 * 
 * Note: BuilderProvider is already provided in app.tsx
 */
function BuilderPageContent(props) {
  const builder = useBuilder();
  const navigate = useNavigate();
  const params = useParams<{
    storeId?: string;
    templateId?: string;
  }>();

  const [isLoading, setIsLoading] = createSignal(true);
  const [error, setError] = createSignal<string | null>(null);

  const storeId = () => params.storeId;
  const templateId = () => params.templateId;

  createEffect(on(() => builder?.storeDetails, async (storeDetails) => {
    if (storeDetails?.id) {
      // API returns array directly (unwrapped)
      const routes = await storesApi.getRoutes(storeDetails.id);
      
      if (routes && builder) {
        builder.setRoutes(routes);
        }
    }
  }, { defer: true }));




  onMount(async () => {
    setIsLoading(true);
    setError(null);

    try {
      // Mode 1: Edit existing store
      if (storeId()) {
        builder.setIsTemplatePreview(false);
        builder.preview = false;
        
        const response = await storesApi.getById(storeId()!);
        console.log("Store API response:", response);
        
        // Handle both response formats: { success, data } or direct object
        const storeData = response.data || response;
        if (storeData && storeData.id) {
          builder.storeDetails = storeData;
          // Load the store's router
          await builder.loadStore(storeId()!);
        } else {
          setError("Store not found");
        }
      }
      // Mode 2: Preview template (public API - anyone can preview)
      else if (templateId()) {
        builder.setIsTemplatePreview(true);
        builder.preview = false;
        
        const response = await storesApi.getTemplateById(templateId()!);
        console.log("Template API response:", response);
        
        // Handle both response formats: { success, data } or direct object
        const storeData = response.data || response;
        if (storeData && storeData.id) {
          builder.storeDetails = storeData;
          // Load the template's router
          await builder.loadStore(templateId()!);
        } else {
          setError("Template not found");
        }
      }
      // No valid params
      else {
        setError("Missing storeId or templateId parameter");
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load");
    } finally {
      setIsLoading(false);
    }
  });

  // Cleanup on unmount
  createEffect(() => {
    return () => {
      // Reset builder state when leaving
      builder.preview = false;
    };
  });

  return (
    <Show
      when={!isLoading()}
      fallback={
        <Flex class="min-h-screen items-center justify-center">
          <Flex class="flex-col items-center gap-4">
            <LoaderIcon class="size-8 animate-spin" />
            <Text class="text-muted-foreground">Loading builder...</Text>
          </Flex>
        </Flex>
      }
    >
      <Show
        when={!error()}
        fallback={
          <Flex class="min-h-screen items-center justify-center">
            <Flex class="flex-col items-center gap-4 text-center">
              <AlertCircleIcon class="size-12 text-destructive" />
              <Heading level={3}>{error()}</Heading>
              <Button onClick={() => navigate(routes.stores)}>
                <ArrowLeftIcon class="size-4 mr-2" />
                Back to Stores
              </Button>
            </Flex>
          </Flex>
        }
      >
        <BuilderHome {...props}/>
        </Show>
    </Show>
  );
}

export default BuilderPageContent;
