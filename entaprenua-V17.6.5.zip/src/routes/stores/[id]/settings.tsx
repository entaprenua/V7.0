import { createSignal, createEffect, Show, onMount } from "solid-js"
import { A, useParams, useNavigate } from "@solidjs/router"
import { Title, Meta } from "@solidjs/meta"
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "~/components/ui/card"
import { Button } from "~/components/ui/button"
import { Flex, Text, Heading, TextField, TextFieldLabel, TextFieldInput, TextFieldTextArea, TextFieldErrorMessage } from "~/components/ui"
import { storesApi } from "~/lib/api"
import { routes } from "~/lib/utils/routes"
import type { Store } from "~/lib/types"
import ArrowLeftIcon from "lucide-solid/icons/arrow-left"
import SaveIcon from "lucide-solid/icons/save"
import LoaderIcon from "lucide-solid/icons/loader"
import CheckIcon from "lucide-solid/icons/check"

export default function StoreSettingsPage() {
  const params = useParams()
  const navigate = useNavigate()
  const storeId = () => params.id || ""

  const [store, setStore] = createSignal<Store | null>(null)
  const [isLoading, setIsLoading] = createSignal(true)
  const [isSaving, setIsSaving] = createSignal(false)
  const [isSaved, setIsSaved] = createSignal(false)
  const [error, setError] = createSignal<string | null>(null)
  
  const [name, setName] = createSignal("")
  const [description, setDescription] = createSignal("")
  const [domain, setDomain] = createSignal("")
  const [subdomain, setSubdomain] = createSignal("")
  const [visibility, setVisibility] = createSignal("private")

  onMount(async () => {
    await loadStore()
  })

  const loadStore = async () => {
    setIsLoading(true)
    setError(null)
    try {
      const storeData = await storesApi.getById(storeId())
      if (storeData) {
        setStore(storeData)
        setName(storeData.name)
        setDescription(storeData.description || "")
        setDomain(storeData.domain || "")
        setSubdomain(storeData.subdomain || "")
        setVisibility(storeData.visibility || "private")
      } else {
        setError("Store not found")
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load store")
    } finally {
      setIsLoading(false)
    }
  }

  const handleSave = async () => {
    setIsSaving(true)
    setError(null)
    setIsSaved(false)
    
    try {
      await storesApi.update(storeId(), {
        name: name(),
        description: description() || undefined,
        domain: domain() || undefined,
        subdomain: subdomain() || undefined,
        visibility: visibility() as any,
      })
      
      setIsSaved(true)
      setTimeout(() => setIsSaved(false), 3000)
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to save")
    } finally {
      setIsSaving(false)
    }
  }

  return (
    <>
      <Title>Store Settings - Entaprenua</Title>
      <Meta name="description" content="Configure your store settings" />
      
      <div class="min-h-screen bg-background">
        <div class="border-b">
          <div class="container mx-auto px-4 py-6">
            <Flex class="items-center gap-4">
              <A href={routes.storeDetails(storeId())}>
                <Button variant="ghost" size="icon">
                  <ArrowLeftIcon class="size-5" />
                </Button>
              </A>
              <div>
                <Heading level={1} class="text-2xl font-bold">Store Settings</Heading>
                <Text class="text-muted-foreground">
                  {store()?.name || "Loading..."}
                </Text>
              </div>
            </Flex>
          </div>
        </div>

        <div class="container mx-auto px-4 py-8 max-w-2xl">
          <Show when={isLoading()}>
            <Flex class="flex-col items-center justify-center py-16">
              <LoaderIcon class="size-8 animate-spin mb-4" />
              <Text class="text-muted-foreground">Loading...</Text>
            </Flex>
          </Show>

          <Show when={error() && !isLoading()}>
            <Card class="border-destructive">
              <CardContent class="pt-6">
                <Text class="text-destructive">{error()}</Text>
              </CardContent>
            </Card>
          </Show>

          <Show when={!isLoading() && !error()}>
            <Flex class="flex-col gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Basic Information</CardTitle>
                  <CardDescription>General store details</CardDescription>
                </CardHeader>
                <CardContent class="space-y-4">
                  <TextField>
                    <TextFieldLabel>Store Name</TextFieldLabel>
                    <TextFieldInput
                      value={name()}
                      onInput={(e) => setName(e.currentTarget.value)}
                    />
                  </TextField>
                  
                  <TextField>
                    <TextFieldLabel>Description</TextFieldLabel>
                    <TextFieldTextArea
                      value={description()}
                      onInput={(e: any) => setDescription(e.currentTarget.value)}
                      rows={3}
                    />
                  </TextField>

                  <div>
                    <Text variant="caption" class="text-muted-foreground mb-2 block">Visibility</Text>
                    <Flex class="gap-2">
                      <Button
                        variant={visibility() === "private" ? "default" : "outline"}
                        size="sm"
                        onClick={() => setVisibility("private")}
                      >
                        Private
                      </Button>
                      <Button
                        variant={visibility() === "public" ? "default" : "outline"}
                        size="sm"
                        onClick={() => setVisibility("public")}
                      >
                        Public
                      </Button>
                      <Button
                        variant={visibility() === "unlisted" ? "default" : "outline"}
                        size="sm"
                        onClick={() => setVisibility("unlisted")}
                      >
                        Unlisted
                      </Button>
                    </Flex>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Domain Settings</CardTitle>
                  <CardDescription>Configure your store domain</CardDescription>
                </CardHeader>
                <CardContent class="space-y-4">
                  <TextField>
                    <TextFieldLabel>Custom Domain</TextFieldLabel>
                    <TextFieldInput
                      placeholder="www.mystore.com"
                      value={domain()}
                      onInput={(e) => setDomain(e.currentTarget.value)}
                    />
                    <Text variant="caption" class="text-muted-foreground mt-1">
                      Point your domain to Entaprenua DNS
                    </Text>
                  </TextField>
                  
                  <TextField>
                    <TextFieldLabel>Subdomain</TextFieldLabel>
                    <Flex class="gap-2">
                      <TextFieldInput
                        placeholder="mystore"
                        value={subdomain()}
                        onInput={(e) => setSubdomain(e.currentTarget.value)}
                      />
                      <div class="px-3 py-2 bg-muted rounded-md text-sm text-muted-foreground">
                        .entaprenua.com
                      </div>
                    </Flex>
                  </TextField>
                </CardContent>
              </Card>

              <Card>
                <CardFooter class="flex justify-between">
                  <Button variant="outline" onClick={() => navigate(routes.storeDetails(storeId()))}>
                    Cancel
                  </Button>
                  <Button onClick={handleSave} disabled={isSaving()} class="gap-2">
                    <Show when={isSaving()}>
                      <LoaderIcon class="size-4 animate-spin" />
                      Saving...
                    </Show>
                    <Show when={isSaved()}>
                      <CheckIcon class="size-4" />
                      Saved!
                    </Show>
                    <Show when={!isSaving() && !isSaved()}>
                      <SaveIcon class="size-4" />
                      Save Changes
                    </Show>
                  </Button>
                </CardFooter>
              </Card>
            </Flex>
          </Show>
        </div>
      </div>
    </>
  )
}
