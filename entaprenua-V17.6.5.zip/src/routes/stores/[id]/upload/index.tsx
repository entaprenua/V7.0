import { createSignal, Show, For } from "solid-js"
import { A, useParams, useNavigate } from "@solidjs/router"
import { Title, Meta } from "@solidjs/meta"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "~/components/ui/card"
import { Button } from "~/components/ui/button"
import { Flex, Text, Heading, Progress, TextField, TextFieldLabel, TextFieldInput } from "~/components/ui"
import { storesApi } from "~/lib/api"
import { routes } from "~/lib/utils/routes"
import ArrowLeftIcon from "lucide-solid/icons/arrow-left"
import UploadIcon from "lucide-solid/icons/upload"
import CheckIcon from "lucide-solid/icons/check"
import XIcon from "lucide-solid/icons/x"
import LoaderIcon from "lucide-solid/icons/loader"
import FileCodeIcon from "lucide-solid/icons/file-code"
import AlertCircleIcon from "lucide-solid/icons/alert-circle"
import StoreIcon from "lucide-solid/icons/store"
import FileIcon from "lucide-solid/icons/file"

interface FilePreview {
  file: File
  name: string
  slug: string
  status: "pending" | "uploading" | "done" | "error"
  error?: string
}

interface UploadProgress {
  stage: "preparing" | "extracting" | "scanning" | "parsing" | "saving" | "complete" | "error"
  progress: number
  message: string
}

function extractPageInfo(fileName: string, filePath: string): { name: string; slug: string } {
  const path = filePath || fileName
  
  // Remove src/routes/ prefix if present
  const pathWithoutRoutes = path.replace(/^.*\/routes\//, '')
  
  const parts = pathWithoutRoutes.split('/')
  const name = parts[parts.length - 1].replace(/\.(tsx|jsx)$/, '')
  const dirParts = parts.slice(0, -1)
  
  let pageName = ''
  let slug = ''
  
  const isIndex = name === 'index'
  const isPage = name === 'page'
  
  if (dirParts.length === 0 && isIndex) {
    pageName = 'home'
    slug = ''
  } else if (isPage) {
    slug = dirParts.join('/')
    pageName = slug.replace(/\//g, '-') || 'home'
  } else if (isIndex && dirParts.length > 0) {
    slug = dirParts.join('/')
    pageName = slug.replace(/\//g, '-')
  } else {
    slug = pathWithoutRoutes.replace(/\.(tsx|jsx)$/, '')
    pageName = slug.replace(/\//g, '-') || 'home'
  }
  
  return { name: pageName, slug }
}

export default function UploadPage() {
  const params = useParams()
  const navigate = useNavigate()
  
  const storeId = () => params.id
  const isNewStore = () => !storeId()

  const [selectedFiles, setSelectedFiles] = createSignal<FilePreview[]>([])
  const [isUploading, setIsUploading] = createSignal(false)
  const [progress, setProgress] = createSignal<UploadProgress | null>(null)
  const [error, setError] = createSignal<string | null>(null)
  const [isDragOver, setIsDragOver] = createSignal(false)
  
  // For new store flow
  const [storeName, setStoreName] = createSignal("")
  const [storeDescription, setStoreDescription] = createSignal("")
  const [isCreatingStore, setIsCreatingStore] = createSignal(false)
  const [showDetailsForm, setShowDetailsForm] = createSignal(false)

  const handleFileSelect = (e: Event) => {
    const input = e.target as HTMLInputElement
    if (input.files && input.files.length > 0) {
      processFiles(Array.from(input.files))
    }
  }

  const processFiles = (files: File[]) => {
    const validFiles: FilePreview[] = []
    
    for (const file of files) {
      const isZip = file.name.endsWith('.zip')
      const isTsx = file.name.endsWith('.tsx') || file.name.endsWith('.jsx')
      
      if (isZip || isTsx) {
        const pageInfo = extractPageInfo(file.name, '')
        validFiles.push({
          file,
          name: pageInfo.name,
          slug: pageInfo.slug,
          status: 'pending'
        })
      }
    }
    
    if (validFiles.length > 0) {
      setSelectedFiles(validFiles)
      setError(null)
      setProgress(null)
      
      if (isNewStore()) {
        setShowDetailsForm(true)
      }
    } else {
      setError("Please upload .zip, .tsx, or .jsx files")
    }
  }

  const handleDrop = (e: DragEvent) => {
    e.preventDefault()
    setIsDragOver(false)
    
    if (e.dataTransfer?.files && e.dataTransfer.files.length > 0) {
      processFiles(Array.from(e.dataTransfer.files))
    }
  }

  const handleDragOver = (e: DragEvent) => {
    e.preventDefault()
    setIsDragOver(true)
  }

  const handleDragLeave = () => {
    setIsDragOver(false)
  }

  const removeFile = (index: number) => {
    const files = selectedFiles()
    files.splice(index, 1)
    setSelectedFiles([...files])
    
    if (files.length === 0) {
      setShowDetailsForm(false)
    }
  }

  const updatePageName = (index: number, name: string) => {
    const files = selectedFiles()
    files[index].name = name
    setSelectedFiles([...files])
  }

  const updatePageSlug = (index: number, slug: string) => {
    const files = selectedFiles()
    files[index].slug = slug
    setSelectedFiles([...files])
  }

  const handleUploadToExistingStore = async () => {
    const files = selectedFiles()
    if (files.length === 0) return

    const isZip = files[0].file.name.endsWith('.zip')
    
    setIsUploading(true)
    setError(null)
    setProgress({ stage: "preparing", progress: 5, message: "Preparing upload..." })

    try {
      if (isZip) {
        // ZIP upload - single file
        const formData = new FormData()
        formData.append('file', files[0].file)
        
        setProgress({ stage: "extracting", progress: 20, message: "Extracting ZIP..." })
        await storesApi.importCodebase(storeId(), formData)
      } else {
        // Page files upload - handle each file
        for (let i = 0; i < files.length; i++) {
          files[i].status = 'uploading'
          setSelectedFiles([...files])
          
          const content = await files[i].file.text()
          const result = await storesApi.createPage(storeId(), {
            name: files[i].name,
            slug: files[i].slug,
            element: { name: 'box', children: [] }
          })
          
          files[i].status = 'done'
          setSelectedFiles([...files])
          setProgress({ 
            stage: "saving", 
            progress: 20 + Math.round((i + 1) / files.length * 80), 
            message: `Saved page ${i + 1} of ${files.length}...` 
          })
        }
      }

      setProgress({ stage: "complete", progress: 100, message: "Upload complete!" })
      
      setTimeout(() => {
        navigate(routes.storeDetails(storeId()))
      }, 1500)
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : "Upload failed"
      setError(errorMessage)
      setProgress({ stage: "error", progress: 0, message: errorMessage })
    } finally {
      setIsUploading(false)
    }
  }

  const handleCreateAndUpload = async () => {
    const files = selectedFiles()
    if (files.length === 0 || !storeName().trim()) return

    setIsCreatingStore(true)
    setError(null)
    setProgress({ stage: "preparing", progress: 5, message: "Preparing..." })

    try {
      const formData = new FormData()
      formData.append('name', storeName())
      formData.append('description', storeDescription())
      formData.append('file', files[0].file)

      setProgress({ stage: "extracting", progress: 20, message: "Creating store..." })

      const result = await storesApi.importStore(formData)
      
      if (result.success) {
        setProgress({ stage: "complete", progress: 100, message: "Store created successfully!" })
        
        setTimeout(() => {
          navigate(routes.storeDetails(result.storeId))
        }, 1500)
      } else {
        throw new Error(result.error || 'Failed to create store')
      }
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : "Upload failed"
      setError(errorMessage)
      setProgress({ stage: "error", progress: 0, message: errorMessage })
    } finally {
      setIsCreatingStore(false)
    }
  }

  const isValid = () => {
    if (isNewStore()) {
      return selectedFiles().length > 0 && storeName().trim() && !isCreatingStore()
    }
    return selectedFiles().length > 0 && !isUploading()
  }

  const progressColor = () => {
    const p = progress()
    if (!p) return "bg-primary"
    switch (p.stage) {
      case "complete": return "bg-green-500"
      case "error": return "bg-red-500"
      case "extracting":
      case "scanning":
      case "parsing": return "bg-blue-500"
      default: return "bg-primary"
    }
  }

  return (
    <>
      <Title>Upload Code - Entaprenua</Title>
      <Meta name="description" content="Upload your codebase" />

      <div class="min-h-screen bg-background">
        <div class="border-b">
          <div class="container mx-auto px-4 py-4">
            <Flex class="items-center gap-4">
              <A href={isNewStore() ? routes.newStore : routes.storeDetails(storeId())}>
                <Button variant="ghost" size="icon">
                  <ArrowLeftIcon class="size-5" />
                </Button>
              </A>
              <div>
                <Heading level={1} class="text-xl font-bold">
                  {isNewStore() ? "Create Store" : "Upload Code"}
                </Heading>
                <Text variant="caption" class="text-muted-foreground">
                  {isNewStore() 
                    ? "Upload your code to create a new store"
                    : "Add pages to your store"
                  }
                </Text>
              </div>
            </Flex>
          </div>
        </div>

        <div class="container mx-auto px-4 py-8 max-w-2xl">
          <Show when={error()}>
            <div class="mb-6 p-4 rounded-lg bg-red-50 border border-red-200 text-red-700">
              <Flex class="items-center gap-2">
                <AlertCircleIcon class="size-5" />
                <Text>{error()}</Text>
              </Flex>
            </div>
          </Show>

          <Card>
            <CardHeader>
              <CardTitle class="flex items-center gap-2">
                <UploadIcon class="size-5" />
                {isNewStore() ? "Step 1: Upload Files" : "Upload Files"}
              </CardTitle>
              <CardDescription>
                Upload a ZIP file or .tsx/.jsx page files
              </CardDescription>
            </CardHeader>
            <CardContent class="space-y-6">
              <div
                class={`border-2 border-dashed rounded-lg p-8 text-center transition-colors cursor-pointer ${
                  isDragOver() 
                    ? "border-primary bg-primary/5" 
                    : "border-border hover:border-primary/50 hover:bg-muted/50"
                }`}
                onClick={() => document.getElementById('file-input')?.click()}
                onDrop={handleDrop}
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
              >
                <Flex class="flex-col items-center gap-3">
                  <div class="size-12 rounded-full bg-muted flex items-center justify-center">
                    <FileCodeIcon class="size-6 text-muted-foreground" />
                  </div>
                  <div>
                    <Text weight="medium" class="mb-1">
                      Drop files here
                    </Text>
                    <Text variant="caption" class="text-muted-foreground">
                      or click to browse
                    </Text>
                  </div>
                  <Text variant="caption" class="text-muted-foreground">
                    Supported: .zip (codebase), .tsx, .jsx (page files)
                  </Text>
                </Flex>
              </div>

              <input
                id="file-input"
                type="file"
                accept=".zip,.tsx,.jsx"
                multiple
                class="hidden"
                onChange={handleFileSelect}
              />

              <Show when={selectedFiles().length > 0}>
                <div class="space-y-3">
                  <Text variant="caption" class="text-muted-foreground font-medium">
                    Selected Files:
                  </Text>
                  <For each={selectedFiles()}>
                    {(filePreview, index) => (
                      <div class="flex items-start gap-3 p-3 rounded-lg border bg-background">
                        <FileIcon class="size-5 text-muted-foreground mt-1" />
                        <div class="flex-1 space-y-2">
                          <Flex class="items-center justify-between">
                            <Text class="text-sm font-medium">{filePreview.file.name}</Text>
                            <Show when={!isUploading() && !isCreatingStore()}>
                              <button
                                class="p-1 hover:bg-muted rounded"
                                onClick={() => removeFile(index())}
                              >
                                <XIcon class="size-4" />
                              </button>
                            </Show>
                          </Flex>
                          
                          <Show when={!filePreview.file.name.endsWith('.zip')}>
                            <div class="grid grid-cols-2 gap-2">
                              <TextField>
                                <TextFieldLabel class="text-xs">Page Name</TextFieldLabel>
                                <TextFieldInput
                                  value={filePreview.name}
                                  onInput={(e) => updatePageName(index(), e.currentTarget.value)}
                                  disabled={isUploading() || isCreatingStore()}
                                  class="h-8"
                                />
                              </TextField>
                              <TextField>
                                <TextFieldLabel class="text-xs">Slug</TextFieldLabel>
                                <TextFieldInput
                                  value={filePreview.slug}
                                  onInput={(e) => updatePageSlug(index(), e.currentTarget.value)}
                                  disabled={isUploading() || isCreatingStore()}
                                  class="h-8"
                                />
                              </TextField>
                            </div>
                          </Show>
                          
                          <Show when={filePreview.status === 'done'}>
                            <Flex class="items-center gap-1 text-green-600">
                              <CheckIcon class="size-4" />
                              <Text variant="caption">Saved</Text>
                            </Flex>
                          </Show>
                          <Show when={filePreview.status === 'error'}>
                            <Text variant="caption" class="text-red-500">
                              {filePreview.error}
                            </Text>
                          </Show>
                        </div>
                      </div>
                    )}
                  </For>
                </div>
              </Show>

              <Show when={progress()}>
                <div class="space-y-2">
                  <Flex class="justify-between">
                    <Text variant="body2">{progress()?.message}</Text>
                    <Text variant="body2">{progress()?.progress}%</Text>
                  </Flex>
                  <Progress
                    value={progress()?.progress}
                    class={`h-2 ${progressColor()}`}
                  />
                </div>
              </Show>
            </CardContent>
          </Card>

          {/* Store Details for new store */}
          <Show when={isNewStore() && showDetailsForm() && selectedFiles().length > 0}>
            <Card class="mt-6">
              <CardHeader>
                <CardTitle class="flex items-center gap-2">
                  <StoreIcon class="size-5" />
                  Step 2: Store Details
                </CardTitle>
                <CardDescription>
                  Give your store a name
                </CardDescription>
              </CardHeader>
              <CardContent class="space-y-4">
                <TextField>
                  <TextFieldLabel>Store Name *</TextFieldLabel>
                  <TextFieldInput
                    placeholder="My Awesome Store"
                    value={storeName()}
                    onInput={(e) => setStoreName(e.currentTarget.value)}
                  />
                </TextField>
              </CardContent>
            </Card>
          </Show>

          {/* Action Buttons */}
          <div class="p-6 pt-4 flex gap-3">
            <Button
              variant="outline"
              onClick={() => navigate(isNewStore() ? routes.newStore : routes.storeDetails(storeId()))}
              disabled={isUploading() || isCreatingStore()}
            >
              {showDetailsForm() ? "Back" : "Cancel"}
            </Button>
            
            <Show when={isNewStore()}>
              <Button
                onClick={handleCreateAndUpload}
                disabled={!isValid()}
                class="gap-2"
              >
                <Show when={isCreatingStore()} fallback="Create Store">
                  <LoaderIcon class="size-4 animate-spin" />
                  Creating...
                </Show>
              </Button>
            </Show>
            
            <Show when={!isNewStore()}>
              <Button
                onClick={handleUploadToExistingStore}
                disabled={!isValid()}
                class="gap-2"
              >
                <Show when={isUploading()} fallback="Add Pages">
                  <LoaderIcon class="size-4 animate-spin" />
                  Adding...
                </Show>
              </Button>
            </Show>
          </div>
        </div>
      </div>
    </>
  )
}
