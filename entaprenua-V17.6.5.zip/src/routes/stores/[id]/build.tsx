import { createSignal, createMemo, Show, For, onMount } from "solid-js"
import { A, useParams, useNavigate } from "@solidjs/router"
import { Title, Meta } from "@solidjs/meta"
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "~/components/ui/card"
import { Button } from "~/components/ui/button"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "~/components/ui/dialog"
import { Flex, Grid, Badge, Text, Heading, Progress, FileField, FileFieldLabel } from "~/components/ui"
import { storesApi, buildsApi } from "~/lib/api"
import type { Framework } from "~/lib/api/builds"
import { routes } from "~/lib/utils/routes"
import type { Store } from "~/lib/types"
import ArrowLeftIcon from "lucide-solid/icons/arrow-left"
import DownloadIcon from "lucide-solid/icons/download"
import UploadIcon from "lucide-solid/icons/upload"
import CheckIcon from "lucide-solid/icons/check"
import LoaderIcon from "lucide-solid/icons/loader"
import CodeIcon from "lucide-solid/icons/code"
import FileCodeIcon from "lucide-solid/icons/file-code"
import PackageIcon from "lucide-solid/icons/package"
import AlertCircleIcon from "lucide-solid/icons/alert-circle"

interface FrameworkOption {
  id: Framework
  name: string
  description: string
  icon: string
  features: string[]
}

const FRAMEWORKS: FrameworkOption[] = [
  {
    id: "solidstart",
    name: "SolidStart",
    description: "Full-stack SolidJS framework with file-based routing",
    icon: "SolidStart",
    features: [
      "File-based routing",
      "Server-side rendering",
      "API routes included",
      "Smaller bundle size",
      "Reactive performance",
    ],
  },
  {
    id: "nextjs",
    name: "Next.js",
    description: "React framework with App Router",
    icon: "NextJS",
    features: [
      "App Router",
      "Server-side rendering",
      "Static site generation",
      "API routes",
      "Large ecosystem",
    ],
  },
]

interface BuildProgress {
  stage: 'preparing' | 'generating' | 'compressing' | 'complete';
  progress: number;
  message: string;
}

export default function StoreBuildPage() {
  const params = useParams()
  const navigate = useNavigate()
  const storeId = () => params.id || ""
  const getStoreId = () => {
    const id = storeId()
    if (!id) throw new Error("Store ID is required")
    return id
  }

  const [store, setStore] = createSignal<Store | null>(null)
  const [isLoading, setIsLoading] = createSignal(true)
  const [error, setError] = createSignal<string | null>(null)
  const [selectedFramework, setSelectedFramework] = createSignal<Framework>("solidstart")
  const [isBuilding, setIsBuilding] = createSignal(false)
  const [buildProgress, setBuildProgress] = createSignal<BuildProgress | null>(null)
  const [showUploadDialog, setShowUploadDialog] = createSignal(false)
  const [isUploading, setIsUploading] = createSignal(false)
  const [uploadFiles, setUploadFiles] = createSignal<FileList | null>(null)
  const [uploadProgress, setUploadProgress] = createSignal<BuildProgress | null>(null)

  onMount(async () => {
    await loadStore()
  })

  const loadStore = async () => {
    setIsLoading(true)
    setError(null)
    try {
      const storeData = await storesApi.getById(getStoreId())
      if (storeData) {
        setStore(storeData)
      } else {
        setError("Store not found")
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load store")
    } finally {
      setIsLoading(false)
    }
  }

  const handleExport = async () => {
    const currentStore = store()
    if (!currentStore) return

    setIsBuilding(true)
    setBuildProgress({ stage: 'preparing', progress: 0, message: 'Preparing build...' })

    try {
      await buildsApi.downloadStore(
        getStoreId(),
        currentStore.name,
        selectedFramework()
      )
      setBuildProgress({ stage: 'complete', progress: 100, message: 'Download started!' })
    } catch (err) {
      setError(err instanceof Error ? err.message : "Export failed")
      setBuildProgress(null)
    } finally {
      setIsBuilding(false)
    }
  }

  const handleUploadClick = () => {
    setShowUploadDialog(true)
  }

  const handleUploadConfirm = async () => {
    const files = uploadFiles()
    if (!files || files.length === 0) return

    const currentStore = store()
    setIsUploading(true)
    setUploadProgress({ stage: 'preparing', progress: 0, message: 'Preparing upload...' })

    try {
      const fileArray = Array.from(files)
      await buildsApi.importStore(
        fileArray,
        currentStore?.name || "Imported Store",
        setUploadProgress
      )
      setUploadProgress({ stage: 'complete', progress: 100, message: 'Upload complete!' })
      setTimeout(() => {
        setShowUploadDialog(false)
        setUploadFiles(null)
        loadStore()
      }, 1500)
    } catch (err) {
      setError(err instanceof Error ? err.message : "Upload failed")
      setUploadProgress(null)
    } finally {
      setIsUploading(false)
    }
  }

  const progressColor = () => {
    const p = buildProgress() || uploadProgress()
    if (!p) return "bg-primary"
    switch (p.stage) {
      case 'complete': return "bg-green-500"
      case 'compressing': return "bg-yellow-500"
      case 'generating': return "bg-blue-500"
      default: return "bg-primary"
    }
  }

  return (
    <>
      <Title>Build Store - Entaprenua</Title>
      <Meta name="description" content="Export your store as SolidStart or Next.js" />
      
      <div class="min-h-screen bg-background">
        <div class="border-b">
          <div class="container mx-auto px-4 py-6">
            <Flex class="items-center gap-4">
              <A href={routes.storeDetails(getStoreId())}>
                <Button variant="ghost" size="icon">
                  <ArrowLeftIcon class="size-5" />
                </Button>
              </A>
              <div>
                <Heading level={1} class="text-2xl font-bold">Build & Export</Heading>
                <Text class="text-muted-foreground">
                  {store()?.name || "Loading..."}
                </Text>
              </div>
            </Flex>
          </div>
        </div>

        <div class="container mx-auto px-4 py-8 max-w-4xl">
          <Show when={isLoading()}>
            <Flex class="flex-col items-center justify-center py-16">
              <LoaderIcon class="size-8 animate-spin mb-4" />
              <Text class="text-muted-foreground">Loading store...</Text>
            </Flex>
          </Show>

          <Show when={error() && !isLoading()}>
            <Card class="border-destructive">
              <CardContent class="pt-6">
                <Flex class="flex-col items-center text-center py-8">
                  <AlertCircleIcon class="size-12 text-destructive mb-4" />
                  <Heading level={3} class="mb-2">{error()}</Heading>
                  <Button variant="outline" onClick={() => navigate(routes.stores)}>
                    Back to Stores
                  </Button>
                </Flex>
              </CardContent>
            </Card>
          </Show>

          <Show when={!isLoading() && !error() && store()}>
            <Flex class="flex-col gap-8">
              <Card>
                <CardHeader>
                  <CardTitle class="flex items-center gap-2">
                    <DownloadIcon class="size-5" />
                    Export Store
                  </CardTitle>
                  <CardDescription>
                    Download your store as a complete {selectedFramework() === 'solidstart' ? 'SolidStart' : 'Next.js'} project
                  </CardDescription>
                </CardHeader>
                <CardContent class="space-y-6">
                  <div>
                    <Text variant="subtitle2" class="mb-3">Select Framework</Text>
                    <Grid cols={1} colsSm={2} class="gap-4">
                      <For each={FRAMEWORKS}>{(framework) => (
                        <Card 
                          class={`cursor-pointer transition-all ${
                            selectedFramework() === framework.id 
                              ? "ring-2 ring-primary bg-primary/5" 
                              : "hover:bg-muted/50"
                          }`}
                          onClick={() => setSelectedFramework(framework.id)}
                        >
                          <CardContent class="p-4">
                            <Flex class="items-start gap-3">
                              <div class={`size-10 rounded-lg flex items-center justify-center ${
                                selectedFramework() === framework.id ? "bg-primary text-primary-foreground" : "bg-muted"
                              }`}>
                                <CodeIcon class="size-5" />
                              </div>
                              <div class="flex-1">
                                <Text weight="semibold">{framework.name}</Text>
                                <Text variant="caption" class="text-muted-foreground">
                                  {framework.description}
                                </Text>
                              </div>
                              <Show when={selectedFramework() === framework.id}>
                                <Badge class="bg-primary">Selected</Badge>
                              </Show>
                            </Flex>
                          </CardContent>
                        </Card>
                      )}</For>
                    </Grid>
                  </div>

                  <div class="rounded-lg border p-4">
                    <Text variant="subtitle2" class="mb-3">What's Included</Text>
                    <Grid cols={2} class="gap-2">
                      <For each={FRAMEWORKS.find(f => f.id === selectedFramework())?.features || []}>
                        {(feature) => (
                          <Flex class="items-center gap-2">
                            <CheckIcon class="size-4 text-green-500" />
                            <Text variant="caption">{feature}</Text>
                          </Flex>
                        )}
                      </For>
                    </Grid>
                  </div>

                  <Show when={buildProgress()}>
                    <div class="space-y-2">
                      <Flex class="justify-between">
                        <Text variant="caption">{buildProgress()?.message}</Text>
                        <Text variant="caption">{buildProgress()?.progress}%</Text>
                      </Flex>
                      <Progress value={buildProgress()?.progress} class={progressColor()} />
                    </div>
                  </Show>
                </CardContent>
                <CardFooter>
                  <Button 
                    onClick={handleExport}
                    disabled={isBuilding()}
                    class="gap-2"
                  >
                    <Show when={isBuilding()} fallback={
                      <>
                        <DownloadIcon class="size-4" />
                        Export as {selectedFramework() === 'solidstart' ? 'SolidStart' : 'Next.js'}
                      </>
                    }>
                      <LoaderIcon class="size-4 animate-spin" />
                      Building...
                    </Show>
                  </Button>
                </CardFooter>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle class="flex items-center gap-2">
                    <UploadIcon class="size-5" />
                    Import Store
                  </CardTitle>
                  <CardDescription>
                    Upload an existing {selectedFramework() === 'solidstart' ? 'SolidStart' : 'Next.js'} project to import
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Text variant="body2" class="text-muted-foreground mb-4">
                    Upload a ZIP file containing your store source code. We'll automatically detect the framework and import your pages.
                  </Text>
                  <div class="rounded-lg border-2 border-dashed p-6 text-center">
                    <FileCodeIcon class="size-10 text-muted-foreground mx-auto mb-3" />
                    <Text variant="body2" class="text-muted-foreground mb-2">
                      Drag and drop your ZIP file here, or click to browse
                    </Text>
                    <Text variant="caption" class="text-muted-foreground">
                      Supported: SolidStart (src/routes/), Next.js (app/)
                    </Text>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button variant="outline" onClick={handleUploadClick} class="gap-2">
                    <UploadIcon class="size-4" />
                    Upload ZIP
                  </Button>
                </CardFooter>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle class="flex items-center gap-2">
                    <PackageIcon class="size-5" />
                    Quick Actions
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <Grid cols={1} colsSm={3} class="gap-4">
                    <Button variant="outline" class="h-auto py-4 flex-col gap-2" onClick={() => navigate(routes.builderStore(storeId()))}>
                      <CodeIcon class="size-6" />
                      <Text>Open Builder</Text>
                    </Button>
                    <Button variant="outline" class="h-auto py-4 flex-col gap-2" onClick={() => navigate(routes.storeUpload(storeId()))}>
                      <UploadIcon class="size-6" />
                      <Text>Upload Code</Text>
                    </Button>
                    <Button variant="outline" class="h-auto py-4 flex-col gap-2" onClick={() => navigate(routes.storeSettings(storeId()))}>
                      <PackageIcon class="size-6" />
                      <Text>Settings</Text>
                    </Button>
                    <Button variant="outline" class="h-auto py-4 flex-col gap-2" onClick={() => navigate(routes.stores)}>
                      <ArrowLeftIcon class="size-6" />
                      <Text>Back to Stores</Text>
                    </Button>
                  </Grid>
                </CardContent>
              </Card>
            </Flex>
          </Show>
        </div>
      </div>

      <Dialog open={showUploadDialog()} onOpenChange={(open) => !open && setShowUploadDialog(false)}>
        <DialogContent class="max-w-md">
          <DialogHeader>
            <DialogTitle>Import Store</DialogTitle>
            <DialogDescription>
              Upload a ZIP file containing your store source code
            </DialogDescription>
          </DialogHeader>
          
          <div class="py-4">
            <FileField onFileChange={(files) => setUploadFiles(files as unknown as FileList)}>
              <FileFieldLabel>Upload ZIP File</FileFieldLabel>
            </FileField>
            
            <Show when={uploadProgress()}>
              <div class="mt-4 space-y-2">
                <Flex class="justify-between">
                  <Text variant="caption">{uploadProgress()?.message}</Text>
                  <Text variant="caption">{uploadProgress()?.progress}%</Text>
                </Flex>
                <Progress value={uploadProgress()?.progress} />
              </div>
            </Show>

            <Text variant="caption" class="text-muted-foreground mt-4 block">
              Supported folder structures:
              <br />• SolidStart: src/routes/*
              <br />• Next.js: app/*
            </Text>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowUploadDialog(false)}>
              Cancel
            </Button>
            <Button 
              onClick={handleUploadConfirm} 
              disabled={!uploadFiles() || isUploading()}
            >
              <Show when={isUploading()} fallback="Import">
                <LoaderIcon class="size-4 animate-spin mr-2" />
                Importing...
              </Show>
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  )
}
