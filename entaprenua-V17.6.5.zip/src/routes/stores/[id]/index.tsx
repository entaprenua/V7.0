import { createSignal, Show, onMount } from "solid-js"
import { A, useParams, useNavigate } from "@solidjs/router"
import { Title, Meta } from "@solidjs/meta"
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "~/components/ui/card"
import { Button } from "~/components/ui/button"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "~/components/ui/dialog"
import { Badge } from "~/components/ui/badge"
import { Flex, Grid, Text, Heading, Skeleton, Box } from "~/components/ui"
import { storesApi } from "~/lib/api"
import { routes } from "~/lib/utils/routes"
import type { Store } from "~/lib/types"
import ArrowLeftIcon from "lucide-solid/icons/arrow-left"
import SettingsIcon from "lucide-solid/icons/settings"
import GlobeIcon from "lucide-solid/icons/globe"
import CodeIcon from "lucide-solid/icons/code"
import Trash2Icon from "lucide-solid/icons/trash-2"
import ExternalLinkIcon from "lucide-solid/icons/external-link"
import LoaderIcon from "lucide-solid/icons/loader"
import AlertCircleIcon from "lucide-solid/icons/alert-circle"
import ShoppingCartIcon from "lucide-solid/icons/shopping-cart"
import SearchIcon from "lucide-solid/icons/search"
import ChevronRightIcon from "lucide-solid/icons/chevron-right"
import PackageIcon from "lucide-solid/icons/package"

export default function StoreDetailPage() {
  const params = useParams()
  const navigate = useNavigate()
  const storeId = () => params.id || ""

  const [store, setStore] = createSignal<Store | null>(null)
  const [isLoading, setIsLoading] = createSignal(true)
  const [error, setError] = createSignal<string | null>(null)
  const [isDeleting, setIsDeleting] = createSignal(false)
  const [showDeleteDialog, setShowDeleteDialog] = createSignal(false)

  onMount(async () => {
    await loadStore()
  })

  const loadStore = async () => {
    setIsLoading(true)
    setError(null)
    try {
      const storeData = await storesApi.getById(storeId())
      if (storeData) {
        setStore(storeData)
      } else {
        setError("Store not found")
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load store")
    } finally {
      setIsLoading(false)
    }
  }

  const handleDelete = async () => {
    setIsDeleting(true)
    try {
      await storesApi.delete(storeId())
      navigate(routes.stores)
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to delete store")
      setShowDeleteDialog(false)
    } finally {
      setIsDeleting(false)
    }
  }

  const handlePublish = async () => {
    try {
      await storesApi.update(storeId(), { visibility: 'public' })
      loadStore()
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to publish store")
    }
  }

  const handleUnpublish = async () => {
    try {
      await storesApi.update(storeId(), { visibility: 'private' })
      loadStore()
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to unpublish store")
    }
  }

  return (
    <>
      <Title>{store()?.name || "Store"} - Entaprenua</Title>
      <Meta name="description" content="Manage your store" />
      
      <div class="min-h-screen bg-background">
        <div class="border-b">
          <div class="container mx-auto px-4 py-6">
            <Flex class="items-center gap-4">
              <A href={routes.stores}>
                <Button variant="ghost" size="icon">
                  <ArrowLeftIcon class="size-5" />
                </Button>
              </A>
              <div class="flex-1">
                <Heading level={1} class="text-2xl font-bold">
                  {isLoading() ? <Skeleton class="h-8 w-48" /> : store()?.name}
                </Heading>
                <Text class="text-muted-foreground">
                  Store Details
                </Text>
              </div>
              <Flex class="gap-2">
                <Show when={store()?.domain || store()?.subdomain}>
                  <Button variant="outline" class="gap-2" as="a" href={`https://${store()?.domain || store()?.subdomain}`} target="_blank">
                    <ExternalLinkIcon class="size-4" />
                    Visit
                  </Button>
                </Show>
                <Button variant="outline" class="gap-2" onClick={() => navigate(routes.builderStore(storeId()))}>
                  <CodeIcon class="size-4" />
                  Build
                </Button>
                <Button class="gap-2" onClick={() => navigate(routes.admin)}>
                  <SettingsIcon class="size-4" />
                  Manage
                </Button>
              </Flex>
            </Flex>
          </div>
        </div>

        <div class="container mx-auto px-4 py-8 max-w-4xl">
          <Show when={isLoading()}>
            <Flex class="flex-col items-center justify-center py-16">
              <LoaderIcon class="size-8 animate-spin mb-4" />
              <Text class="text-muted-foreground">Loading store...</Text>
            </Flex>
          </Show>

          <Show when={error() && !isLoading()}>
            <Card class="border-destructive">
              <CardContent class="pt-6">
                <Flex class="flex-col items-center text-center py-8">
                  <AlertCircleIcon class="size-12 text-destructive mb-4" />
                  <Heading level={3} class="mb-2">{error()}</Heading>
                  <Button variant="outline" onClick={() => navigate(routes.stores)}>
                    Back to Stores
                  </Button>
                </Flex>
              </CardContent>
            </Card>
          </Show>

          <Show when={!isLoading() && !error() && store()}>
            <Flex class="flex-col gap-6">
              <Grid cols={1} colsSm={2} class="gap-4">
                <Card>
                  <CardHeader>
                    <CardTitle class="text-lg">Quick Actions</CardTitle>
                    <CardDescription>
                      Manage your store content
                    </CardDescription>
                  </CardHeader>
                  <CardContent class="flex flex-col gap-2">
                    <Button variant="outline" class="w-full justify-between gap-2" onClick={() => navigate(routes.adminProducts)}>
                      <Flex class="items-center gap-2">
                        <ShoppingCartIcon class="size-4" />
                        <span>Products</span>
                      </Flex>
                      <ChevronRightIcon class="size-4" />
                    </Button>
                    <Button variant="outline" class="w-full justify-between gap-2" onClick={() => navigate(routes.adminCategories)}>
                      <Flex class="items-center gap-2">
                        <SearchIcon class="size-4" />
                        <span>Categories</span>
                      </Flex>
                      <ChevronRightIcon class="size-4" />
                    </Button>
                    <Button variant="outline" class="w-full justify-between gap-2" onClick={() => navigate(routes.adminOrders)}>
                      <Flex class="items-center gap-2">
                        <PackageIcon class="size-4" />
                        <span>Orders</span>
                      </Flex>
                      <ChevronRightIcon class="size-4" />
                    </Button>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle class="text-lg">Status</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <Flex class="flex-col gap-3">
                      <Flex class="justify-between items-center">
                        <Text variant="body2">Visibility</Text>
                        <Badge variant={store()?.visibility === 'public' ? "default" : "secondary"}>
                          {store()?.visibility || 'private'}
                        </Badge>
                      </Flex>
                      <Flex class="justify-between items-center">
                        <Text variant="body2">Template</Text>
                        <Badge variant="outline">
                          {store()?.isTemplate ? "Yes" : "No"}
                        </Badge>
                      </Flex>
                      <Flex class="justify-between items-center">
                        <Text variant="body2">Maintenance Mode</Text>
                        <Badge variant={store()?.isInMaintenanceMode ? "warning" : "secondary"}>
                          {store()?.isInMaintenanceMode ? "On" : "Off"}
                        </Badge>
                      </Flex>
                    </Flex>
                  </CardContent>
                  <CardFooter class="flex-col gap-2">
                    <Show when={store()?.visibility === 'public'}>
                      <Button variant="outline" class="w-full" onClick={handleUnpublish}>
                        Unpublish Store
                      </Button>
                    </Show>
                    <Show when={store()?.visibility !== 'public'}>
                      <Button class="w-full" onClick={handlePublish}>
                        Publish Store
                      </Button>
                    </Show>
                  </CardFooter>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle class="text-lg">Domain</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <Flex class="flex-col gap-3">
                      <Flex class="justify-between items-center">
                        <Text variant="body2">Custom Domain</Text>
                        <Text>{store()?.domain || "Not set"}</Text>
                      </Flex>
                      <Flex class="justify-between items-center">
                        <Text variant="body2">Subdomain</Text>
                        <Text>{store()?.subdomain 
                          ? `${store()?.subdomain}.entaprenua.com` 
                          : "Not set"
                        }</Text>
                      </Flex>
                    </Flex>
                  </CardContent>
                  <CardFooter>
                    <Button variant="outline" class="w-full gap-2" onClick={() => navigate(routes.storeSettings(storeId()))}>
                      <GlobeIcon class="size-4" />
                      Configure Domain
                    </Button>
                  </CardFooter>
                </Card>
              </Grid>

              <Card>
                <CardHeader>
                  <CardTitle class="text-lg">Quick Actions</CardTitle>
                </CardHeader>
                <CardContent class="flex flex-col gap-3">
                  <Button variant="outline" class="w-full gap-2" onClick={() => navigate(routes.storeBuild(storeId()))}>
                    <CodeIcon class="size-4" />
                    Build / Export
                  </Button>
                  <Button variant="outline" class="w-full gap-2" onClick={() => navigate(routes.storeUpload(storeId()))}>
                    <PackageIcon class="size-4" />
                    Upload Code
                  </Button>
                  <Button variant="outline" class="w-full gap-2" onClick={() => navigate(routes.storeSettings(storeId()))}>
                    <GlobeIcon class="size-4" />
                    Configure Domain
                  </Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle class="text-lg">Details</CardTitle>
                </CardHeader>
                <CardContent>
                  <Flex class="flex-col gap-3">
                    <Flex class="justify-between items-center">
                      <Text variant="body2" class="text-muted-foreground">Description</Text>
                      <Text>{store()?.description || "No description"}</Text>
                    </Flex>
                    <Flex class="justify-between items-center">
                      <Text variant="body2" class="text-muted-foreground">Created</Text>
                      <Text>{store()?.insertedAt 
                        ? new Date(store()?.insertedAt!).toLocaleDateString() 
                        : "Unknown"
                      }</Text>
                    </Flex>
                    <Flex class="justify-between items-center">
                      <Text variant="body2" class="text-muted-foreground">Last Updated</Text>
                      <Text>{store()?.updatedAt 
                        ? new Date(store()?.updatedAt!).toLocaleDateString() 
                        : "Unknown"
                      }</Text>
                    </Flex>
                  </Flex>
                </CardContent>
              </Card>

              <Card class="border-destructive/50">
                <CardHeader>
                  <CardTitle class="text-lg text-destructive">Danger Zone</CardTitle>
                  <CardDescription>
                    Irreversible and destructive actions
                  </CardDescription>
                </CardHeader>
                <CardFooter>
                  <Button 
                    variant="destructive" 
                    class="w-full gap-2" 
                    onClick={() => setShowDeleteDialog(true)}
                  >
                    <Trash2Icon class="size-4" />
                    Delete Store
                  </Button>
                </CardFooter>
              </Card>
            </Flex>
          </Show>
        </div>
      </div>

      <Dialog open={showDeleteDialog()} onOpenChange={(open) => !open && setShowDeleteDialog(false)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Delete Store</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete "{store()?.name}"? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDeleteDialog(false)}>Cancel</Button>
            <Button variant="destructive" onClick={handleDelete} disabled={isDeleting()}>
              <Show when={isDeleting()} fallback="Delete Store">
                <LoaderIcon class="size-4 animate-spin mr-2" />
                Deleting...
              </Show>
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  )
}
