import { createSignal, createMemo, For, Show, onMount } from "solid-js"
import { A, useNavigate } from "@solidjs/router"
import { Title, Meta } from "@solidjs/meta"
import { Query, QueryBoundary } from "~/components/ui/query"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "~/components/ui/dialog"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "~/components/ui/card"
import { Button } from "~/components/ui/button"
import { Flex, Grid, Badge, Text, Heading, Skeleton, TextField, TextFieldInput, TextFieldLabel } from "~/components/ui"
import { Pagination } from "~/components/ui/pagination"
import { storesApi } from "~/lib/api"
import { routes } from "~/lib/utils/routes"
import type { Store } from "~/lib/types"
import StoreIcon from "lucide-solid/icons/store"
import PlusIcon from "lucide-solid/icons/plus"
import SearchIcon from "lucide-solid/icons/search"
import SettingsIcon from "lucide-solid/icons/settings"
import Trash2Icon from "lucide-solid/icons/trash-2"
import MoreVerticalIcon from "lucide-solid/icons/more-vertical"
import ExternalLinkIcon from "lucide-solid/icons/external-link"
import CopyIcon from "lucide-solid/icons/copy"
import PlayIcon from "lucide-solid/icons/play"
import AlertCircleIcon from "lucide-solid/icons/alert-circle"

interface StoreCardProps {
  store: Store
  onDelete: (id: string) => void
  onManage: (id: string) => void
  onBuild: (id: string) => void
  onDuplicate: (id: string) => void
  onVisit: (store: Store) => void
}

function StoreCard(props: StoreCardProps) {
  const store = () => props.store
  const [showMenu, setShowMenu] = createSignal(false)
  const [menuRef, setMenuRef] = createSignal<HTMLDivElement | null>(null)

  const toggleMenu = (e: MouseEvent) => {
    e.stopPropagation()
    setShowMenu(!showMenu())
  }

  const handleClickOutside = () => {
    setShowMenu(false)
  }

  const statusBadge = () => {
    if (store().isInMaintenanceMode) {
      return <Badge variant="warning">Maintenance</Badge>
    }
    return store().visibility === 'public' 
      ? <Badge class="bg-green-500">Active</Badge> 
      : <Badge variant="secondary">Inactive</Badge>
  }

  return (
    <Card class="overflow-hidden hover:shadow-md transition-shadow group">
      <div class="aspect-video bg-gradient-to-br from-muted to-muted/50 relative">
        <div class="absolute inset-0 flex items-center justify-center">
          <StoreIcon class="size-12 text-muted-foreground/30" />
        </div>
        {statusBadge()}
        <div class="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors flex items-center justify-center opacity-0 group-hover:opacity-100">
          <Button variant="secondary" size="sm" onClick={() => props.onManage(store().id)}>
            <PlayIcon class="size-4 mr-1" />
            Open Builder
          </Button>
        </div>
      </div>
      <CardHeader class="p-4 pb-2">
        <Flex class="items-start justify-between gap-2">
          <div class="flex-1 min-w-0">
            <CardTitle class="text-lg truncate">{store().name}</CardTitle>
            <Text variant="caption" class="text-muted-foreground">
              {store().domain || store().subdomain || "No domain set"}
            </Text>
          </div>
          <div class="relative" ref={setMenuRef}>
            <Button variant="ghost" size="icon" class="size-8" onClick={toggleMenu}>
              <MoreVerticalIcon class="size-4" />
            </Button>
            <Show when={showMenu()}>
              <div class="absolute right-0 top-full mt-1 w-48 bg-background border rounded-md shadow-lg z-50 py-1">
                <button
                  class="w-full px-3 py-2 text-left text-sm hover:bg-accent flex items-center gap-2"
                  onClick={() => {
                    props.onManage(store().id)
                    setShowMenu(false)
                  }}
                >
                  <SettingsIcon class="size-4" />
                  Manage Store
                </button>
                <button
                  class="w-full px-3 py-2 text-left text-sm hover:bg-accent flex items-center gap-2"
                  onClick={() => {
                    props.onBuild(store().id)
                    setShowMenu(false)
                  }}
                >
                  <CopyIcon class="size-4" />
                  Build / Export
                </button>
                <button
                  class="w-full px-3 py-2 text-left text-sm hover:bg-accent flex items-center gap-2"
                  onClick={() => {
                    props.onDuplicate(store().id)
                    setShowMenu(false)
                  }}
                >
                  <CopyIcon class="size-4" />
                  Duplicate
                </button>
                <Show when={store().domain || store().subdomain}>
                  <button
                    class="w-full px-3 py-2 text-left text-sm hover:bg-accent flex items-center gap-2"
                    onClick={() => {
                      props.onVisit(store())
                      setShowMenu(false)
                    }}
                  >
                    <ExternalLinkIcon class="size-4" />
                    Visit Store
                  </button>
                </Show>
                <div class="border-t my-1" />
                <button
                  class="w-full px-3 py-2 text-left text-sm hover:bg-accent flex items-center gap-2 text-destructive"
                  onClick={() => {
                    props.onDelete(store().id)
                    setShowMenu(false)
                  }}
                >
                  <Trash2Icon class="size-4" />
                  Delete
                </button>
              </div>
            </Show>
          </div>
        </Flex>
      </CardHeader>
      <CardContent class="p-4 pt-0">
        <Text variant="body2" class="text-muted-foreground line-clamp-2">
          {store().description || "No description"}
        </Text>
        <Flex class="mt-3 gap-2">
          <Show when={store().isTemplate}>
            <Badge variant="outline">Template</Badge>
          </Show>
          <Badge variant="secondary" class="text-xs">
            {store().visibility || 'private'}
          </Badge>
        </Flex>
      </CardContent>
      <CardFooter class="p-4 pt-0 flex gap-2">
        <Button variant="outline" size="sm" class="flex-1 gap-2" onClick={() => props.onManage(store().id)}>
          <SettingsIcon class="size-4" />
          Manage
        </Button>
        <Button variant="ghost" size="sm" class="gap-2" onClick={() => props.onBuild(store().id)}>
          <CopyIcon class="size-4" />
        </Button>
      </CardFooter>
    </Card>
  )
}

function StoreCardSkeleton() {
  return (
    <Card class="overflow-hidden">
      <div class="aspect-video bg-muted animate-pulse" />
      <CardContent class="p-4">
        <Skeleton class="h-5 w-3/4 mb-2" />
        <Skeleton class="h-4 w-1/2 mb-2" />
        <Skeleton class="h-4 w-full" />
      </CardContent>
      <CardFooter class="p-4 pt-0 flex gap-2">
        <Skeleton class="h-8 flex-1 rounded-md" />
        <Skeleton class="h-8 w-8 rounded-md" />
      </CardFooter>
    </Card>
  )
}

function EmptyStoresState() {
  const navigate = useNavigate()
  return (
    <Flex class="flex-col items-center justify-center py-16 text-center">
      <StoreIcon class="size-16 text-muted-foreground mb-4" />
      <Heading level={3} class="mb-2">No Stores Yet</Heading>
      <Text class="text-muted-foreground mb-6 max-w-md">
        Create your first store to start selling online. You can also browse our templates to get started quickly.
      </Text>
      <Flex class="gap-3">
        <A href={routes.newStore}>
          <Button class="gap-2">
            <PlusIcon class="size-4" />
            Create Store
          </Button>
        </A>
        <A href={routes.templates}>
          <Button variant="outline">
            Browse Templates
          </Button>
        </A>
      </Flex>
    </Flex>
  )
}

function ErrorState(props: { message: string; onRetry: () => void }) {
  return (
    <Flex class="flex-col items-center justify-center py-16 text-center">
      <AlertCircleIcon class="size-16 text-destructive mb-4" />
      <Heading level={3} class="mb-2">Failed to Load Stores</Heading>
      <Text class="text-muted-foreground mb-4 max-w-md">
        {props.message}
      </Text>
      <Button variant="outline" onClick={props.onRetry}>
        Try Again
      </Button>
    </Flex>
  )
}

function DeleteConfirmDialog(props: {
  isOpen: boolean
  storeName: string
  onConfirm: () => void
  onCancel: () => void
}) {
  return (
    <Dialog open={props.isOpen} onOpenChange={(open) => !open && props.onCancel()}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Delete Store</DialogTitle>
          <DialogDescription>
            Are you sure you want to delete "{props.storeName}"? This action cannot be undone and all store data will be permanently lost.
          </DialogDescription>
        </DialogHeader>
        <DialogFooter>
          <Button variant="outline" onClick={props.onCancel}>Cancel</Button>
          <Button variant="destructive" onClick={props.onConfirm}>Delete Store</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

function DuplicateDialog(props: {
  isOpen: boolean
  storeName: string
  onConfirm: (newName: string) => void
  onCancel: () => void
}) {
  const [newName, setNewName] = createSignal("")

  onMount(() => {
    setNewName(`${props.storeName} (Copy)`)
  })

  return (
    <Dialog open={props.isOpen} onOpenChange={(open) => !open && props.onCancel()}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Duplicate Store</DialogTitle>
          <DialogDescription>
            Create a copy of "{props.storeName}". This will include all products, categories, and pages.
          </DialogDescription>
        </DialogHeader>
        <div class="py-4">
          <TextField>
            <TextFieldLabel>New Store Name</TextFieldLabel>
            <TextFieldInput
              value={newName()}
              onInput={(e) => setNewName(e.currentTarget.value)}
              placeholder="Enter store name"
            />
          </TextField>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={props.onCancel}>Cancel</Button>
          <Button onClick={() => props.onConfirm(newName())} disabled={!newName().trim()}>Duplicate</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

type SortOption = "newest" | "oldest" | "name-asc" | "name-desc" | "updated"
type StatusFilter = "all" | "active" | "inactive" | "maintenance"

function StoresContent() {
  const navigate = useNavigate()
  const [mounted, setMounted] = createSignal(false)
  const [searchQuery, setSearchQuery] = createSignal("")
  const [sortBy, setSortBy] = createSignal<SortOption>("newest")
  const [statusFilter, setStatusFilter] = createSignal<StatusFilter>("all")
  const [page, setPage] = createSignal(0)
  const [totalPages, setTotalPages] = createSignal(1)
  const [deleteId, setDeleteId] = createSignal<string | null>(null)
  const [deleteName, setDeleteName] = createSignal("")
  const [duplicateId, setDuplicateId] = createSignal<string | null>(null)
  const [duplicateName, setDuplicateName] = createSignal("")
  const [isDeleting, setIsDeleting] = createSignal(false)
  const [isDuplicating, setIsDuplicating] = createSignal(false)

  onMount(() => {
    setMounted(true)
  })

  const fetchStores = async (): Promise<Store[]> => {
    try {
      console.log("[Stores] Fetching stores with params:", { page: page(), search: searchQuery(), status: statusFilter(), sortBy: sortBy() })
      const response = await storesApi.getAll({
        page: page(),
        size: 12,
        search: searchQuery() || undefined,
        status: statusFilter() !== "all" ? statusFilter() as any : undefined,
        sortBy: sortBy() === 'newest' || sortBy() === 'oldest' ? 'created' : 
                sortBy() === 'name-asc' || sortBy() === 'name-desc' ? 'name' : 'updated',
        sortOrder: sortBy().includes('asc') || sortBy() === 'newest' ? 'desc' : 'asc'
      })
      console.log("[Stores] API Response:", response)
      console.log("[Stores] Total pages:", response.totalPages)
      console.log("[Stores] Stores content:", response.content)
      setTotalPages(response.totalPages || 1)
      return response.content || []
    } catch (error) {
      console.error("[Stores] Error fetching stores:", error)
      setTotalPages(1)
      return []
    }
  }

  const handleDelete = (id: string, name: string) => {
    setDeleteId(id)
    setDeleteName(name)
  }

  const confirmDelete = async () => {
    const id = deleteId()
    if (!id) return
    
    setIsDeleting(true)
    try {
      await storesApi.delete(id)
      window.location.reload()
    } catch (err) {
      alert("Failed to delete store")
    } finally {
      setIsDeleting(false)
      setDeleteId(null)
    }
  }

  const handleManage = (id: string) => {
    navigate(routes.admin)
  }

  const handleBuild = (id: string) => {
    navigate(routes.builderStore(id))
  }

  const handleDuplicate = (id: string, name: string) => {
    setDuplicateId(id)
    setDuplicateName(name)
  }

  const confirmDuplicate = async () => {
    const id = duplicateId()
    const name = duplicateName()
    if (!id || !name) return

    setIsDuplicating(true)
    try {
      await storesApi.duplicate(id, name)
      window.location.reload()
    } catch (err) {
      alert("Failed to duplicate store")
    } finally {
      setIsDuplicating(false)
      setDuplicateId(null)
    }
  }

  const handleVisit = (store: Store) => {
    const url = store.domain || store.subdomain
    if (url) {
      window.open(`https://${url}`, '_blank')
    }
  }

  return (
    <>
      <div class="mb-6">
        <Flex class="gap-4 flex-col sm:flex-row">
          <div class="relative flex-1">
            <SearchIcon class="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground pointer-events-none" />
            <input
              type="search"
              placeholder="Search stores..."
              value={searchQuery()}
              onInput={(e) => setSearchQuery(e.currentTarget.value)}
              class="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 pl-10"
            />
          </div>
          <select
            class="h-10 px-3 rounded-md border bg-background text-sm"
            value={sortBy()}
            onChange={(e) => setSortBy(e.currentTarget.value as SortOption)}
          >
            <option value="newest">Newest First</option>
            <option value="oldest">Oldest First</option>
            <option value="name-asc">Name (A-Z)</option>
            <option value="name-desc">Name (Z-A)</option>
            <option value="updated">Recently Updated</option>
          </select>
        </Flex>
        <Flex class="gap-2 mt-3 flex-wrap">
          <Button
            variant={statusFilter() === "all" ? "default" : "outline"}
            size="sm"
            onClick={() => setStatusFilter("all")}
          >
            All
          </Button>
          <Button
            variant={statusFilter() === "active" ? "default" : "outline"}
            size="sm"
            onClick={() => setStatusFilter("active")}
          >
            Active
          </Button>
          <Button
            variant={statusFilter() === "inactive" ? "default" : "outline"}
            size="sm"
            onClick={() => setStatusFilter("inactive")}
          >
            Inactive
          </Button>
          <Button
            variant={statusFilter() === "maintenance" ? "default" : "outline"}
            size="sm"
            onClick={() => setStatusFilter("maintenance")}
          >
            Maintenance
          </Button>
        </Flex>
      </div>

      <Show when={mounted()} fallback={
        <Grid cols={1} colsSm={2} colsLg={3} colsXl={4} class="gap-6">
          <For each={[1, 2, 3, 4, 5, 6]}>
            {() => <StoreCardSkeleton />}
          </For>
        </Grid>
      }>
        <Query
          queryFn={fetchStores}
          queryKey={["stores"]}
          enabled={true}
          staleTime={0}
        >
          <QueryBoundary
            loadingFallback={
              <Grid cols={1} colsSm={2} colsLg={3} colsXl={4} class="gap-6">
                <For each={[1, 2, 3, 4, 5, 6]}>
                  {() => <StoreCardSkeleton />}
                </For>
              </Grid>
            }
          >
            {(data) => {
              const stores = (data as Store[]) ?? []
              return (
              <Show when={stores.length > 0} fallback={<EmptyStoresState />}>
                <Grid cols={1} colsSm={2} colsLg={3} colsXl={4} class="gap-6">
                  <For each={stores}>
                    {(store) => (
                      <StoreCard
                        store={store}
                        onDelete={(id) => handleDelete(id, store.name)}
                        onManage={handleManage}
                        onBuild={handleBuild}
                        onDuplicate={(id) => handleDuplicate(id, store.name)}
                        onVisit={handleVisit}
                      />
                    )}
                  </For>
                </Grid>
              </Show>
              )
            }}
          </QueryBoundary>
        </Query>
      </Show>

      <Show when={totalPages() > 1}>
        <Pagination
          page={page()}
          totalPages={totalPages()}
          onPageChange={setPage}
          class="justify-center mt-8"
        />
      </Show>

      <DeleteConfirmDialog
        isOpen={!!deleteId()}
        storeName={deleteName()}
        onConfirm={confirmDelete}
        onCancel={() => setDeleteId(null)}
      />

      <DuplicateDialog
        isOpen={!!duplicateId()}
        storeName={duplicateName()}
        onConfirm={confirmDuplicate}
        onCancel={() => setDuplicateId(null)}
      />
    </>
  )
}

export default function StoresPage() {
  return (
    <>
      <Title>My Stores - Entaprenua</Title>
      <Meta name="description" content="Manage your e-commerce stores" />
      
      <div class="min-h-screen bg-background">
        <div class="border-b">
          <div class="container mx-auto px-4 py-8">
            <Flex class="items-center justify-between gap-4">
              <div>
                <Heading level={1} class="text-3xl font-bold mb-2">My Stores</Heading>
                <Text class="text-muted-foreground">
                  Create and manage your e-commerce stores
                </Text>
              </div>
              <Flex class="gap-3">
                <A href={routes.templates}>
                  <Button variant="outline" class="gap-2">
                    Browse Templates
                  </Button>
                </A>
                <A href={routes.newStore}>
                  <Button class="gap-2">
                    <PlusIcon class="size-4" />
                    New Store
                  </Button>
                </A>
              </Flex>
            </Flex>
          </div>
        </div>

        <div class="container mx-auto px-4 py-8">
          <StoresContent />
        </div>
      </div>
    </>
  )
}
