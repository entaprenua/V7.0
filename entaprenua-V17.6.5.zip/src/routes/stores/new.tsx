import { createSignal, createMemo, For, Show, onCleanup, onMount } from "solid-js"
import { A, useNavigate, useSearchParams } from "@solidjs/router"
import { Title, Meta } from "@solidjs/meta"
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "~/components/ui/card"
import { Button } from "~/components/ui/button"
import { Flex, Grid, Badge, Text, Heading, TextField, TextFieldLabel, TextFieldInput, TextFieldErrorMessage, TextFieldTextArea, Progress } from "~/components/ui"
import { Query, QueryBoundary, useQueryState, QueryLoading } from "~/components/ui/query"
import { storesApi } from "~/lib/api"
import { routes } from "~/lib/utils/routes"
import type { Store } from "~/lib/types"
import StoreIcon from "lucide-solid/icons/store"
import ArrowLeftIcon from "lucide-solid/icons/arrow-left"
import ArrowRightIcon from "lucide-solid/icons/arrow-right"
import CheckIcon from "lucide-solid/icons/check"
import LayoutTemplateIcon from "lucide-solid/icons/layout-template"
import GlobeIcon from "lucide-solid/icons/globe"
import LoaderIcon from "lucide-solid/icons/loader"

type StoreType = "clone" | "template"

interface CloneOption {
  id: string
  name: string
  description: string
  image: string
  isTemplate: boolean
}

const STEPS = [
  { id: 1, title: "Choose Type", description: "Select how you want to start" },
  { id: 2, title: "Store Details", description: "Name and describe your store" },
  { id: 3, title: "Domain", description: "Set up your store domain" },
  { id: 4, title: "Review", description: "Review and create your store" },
]

function StepIndicator(props: { currentStep: number }) {
  return (
    <Flex class="justify-center mb-8">
      <For each={STEPS}>{(step) => (
        <Flex class="items-center">
          <div class="flex flex-col items-center">
            <div 
              class={`size-10 rounded-full flex items-center justify-center text-sm font-medium transition-colors ${
                step.id < props.currentStep 
                  ? "bg-green-500 text-white" 
                  : step.id === props.currentStep 
                    ? "bg-primary text-primary-foreground" 
                    : "bg-muted text-muted-foreground"
              }`}
            >
              <Show when={step.id < props.currentStep} fallback={step.id}>
                <CheckIcon class="size-5" />
              </Show>
            </div>
            <Text variant="caption" class="mt-2 hidden sm:block">{step.title}</Text>
          </div>
          <Show when={step.id < STEPS.length}>
            <div 
              class={`w-12 sm:w-24 h-0.5 mx-2 transition-colors ${
                step.id < props.currentStep ? "bg-green-500" : "bg-muted"
              }`} 
            />
          </Show>
        </Flex>
      )}</For>
    </Flex>
  )
}

export default function NewStorePage() {
  const navigate = useNavigate()
  const [searchParams] = useSearchParams<{ templateId?: string }>()
  
  const [currentStep, setCurrentStep] = createSignal(1)
  const [storeType, setStoreType] = createSignal<StoreType>("clone")
  const [selectedTemplate, setSelectedTemplate] = createSignal<string | null>(searchParams.templateId || null)
  const [cloneFromStoreId, setCloneFromStoreId] = createSignal<string | null>(null)
  const [name, setName] = createSignal("")
  const [description, setDescription] = createSignal("")
  const [domainType, setDomainType] = createSignal<"subdomain" | "custom">("subdomain")
  const [subdomain, setSubdomain] = createSignal("")
  const [customDomain, setCustomDomain] = createSignal("")
  const [isSubmitting, setIsSubmitting] = createSignal(false)
  const [error, setError] = createSignal<string | null>(null)
  const [nameAvailable, setNameAvailable] = createSignal<boolean | null>(null)
  const [isCheckingName, setIsCheckingName] = createSignal(false)
  const [mounted, setMounted] = createSignal(false)

  const fetchMyStores = async (): Promise<Store[]> => {
    try {
      const response = await storesApi.getAll({ size: 50, includeTemplates: true })
      return response.content || []
    } catch (e) {
      console.error("Failed to fetch stores", e)
      return []
    }
  }
  
  onMount(() => {
    setMounted(true)
    if (searchParams.templateId) {
      setSelectedTemplate(searchParams.templateId)
      setStoreType("template")
    }
  })
  
  let nameCheckTimeout: ReturnType<typeof setTimeout> | undefined

  onCleanup(() => {
    if (nameCheckTimeout) clearTimeout(nameCheckTimeout)
  })

  const handleNameChange = (value: string) => {
    setName(value)
    setNameAvailable(null)
    
    if (nameCheckTimeout) clearTimeout(nameCheckTimeout)
    
    if (value.length < 3) return
    
    nameCheckTimeout = setTimeout(async () => {
      setIsCheckingName(true)
      try {
        const result = await storesApi.checkNameExists(value)
        if (result) {
          setNameAvailable(!result.exists)
        }
      } catch (e) {
        console.error("Name validation failed", e)
      } finally {
        setIsCheckingName(false)
      }
    }, 500)
  }

  const isStep1Valid = () => {
    if (storeType() === "clone") {
      return cloneFromStoreId() !== null
    }
    return selectedTemplate() !== null
  }
  const isStep2Valid = () => name().trim().length >= 3 && nameAvailable() !== false
  const isStep3Valid = () => {
    if (domainType() === "subdomain") {
      return subdomain().trim().length >= 3
    }
    return customDomain().trim().length >= 3
  }

  const canProceed = () => {
    switch (currentStep()) {
      case 1: return isStep1Valid()
      case 2: return isStep2Valid()
      case 3: return isStep3Valid()
      default: return true
    }
  }

  const nextStep = () => {
    if (canProceed() && currentStep() < 4) {
      setCurrentStep(currentStep() + 1)
    }
  }

  const prevStep = () => {
    if (currentStep() > 1) {
      setCurrentStep(currentStep() - 1)
    }
  }

  const handleSubmit = async () => {
    if (!name().trim()) {
      setError("Store name is required")
      return
    }

    setIsSubmitting(true)
    setError(null)

    try {
      let newStore: Store | null = null

      if ((storeType() === "clone" && cloneFromStoreId()) || (storeType() === "template" && selectedTemplate())) {
        // Clone from existing store or template
        const sourceId = storeType() === "clone" ? cloneFromStoreId()! : selectedTemplate()!
        newStore = await storesApi.cloneStore(sourceId, { name: name() })
      } else {
        // Create new store (not from clone/template)
        setError("Please select a store to clone or template")
        setIsSubmitting(false)
        return
      }
      
      if (newStore) {
        navigate(routes.builderStore(newStore.id))
      } else {
        setError("Failed to create store")
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "An error occurred")
    } finally {
      setIsSubmitting(false)
    }
  }

  const generateSubdomain = () => {
    const base = name().toLowerCase().replace(/[^a-z0-9]/g, '')
    setSubdomain(base || "mystore")
  }

  return (
    <>
      <Title>Create New Store - Entaprenua</Title>
      <Meta name="description" content="Create a new e-commerce store" />
      
      <div class="min-h-screen bg-background">
        <div class="border-b">
          <div class="container mx-auto px-4 py-6">
            <Flex class="items-center gap-4">
              <A href={routes.stores}>
                <Button variant="ghost" size="icon">
                  <ArrowLeftIcon class="size-5" />
                </Button>
              </A>
              <div>
                <Heading level={1} class="text-2xl font-bold">Create New Store</Heading>
                <Text class="text-muted-foreground">
                  Step {currentStep()}: {STEPS[currentStep() - 1].title}
                </Text>
              </div>
            </Flex>
          </div>
        </div>

        <div class="container mx-auto px-4 py-8 max-w-4xl">
          <StepIndicator currentStep={currentStep()} />

          <Show when={error()}>
            <div class="mb-6 p-4 rounded-lg bg-destructive/10 text-destructive">
              <Flex class="items-center gap-2">
                <Text>{error()}</Text>
                <Button variant="ghost" size="sm" onClick={() => setError(null)}>Dismiss</Button>
              </Flex>
            </div>
          </Show>

          <Show when={currentStep() === 1}>
            <Flex class="flex-col items-center text-center mb-8">
              <Heading level={2} class="mb-2">Start a New Store</Heading>
              <Text class="text-muted-foreground max-w-md">
                Choose a template from the marketplace, clone from your stores, or upload your own code
              </Text>
            </Flex>

            <div class="space-y-8 max-w-4xl mx-auto">
              <div class="text-left">
                <Text variant="subtitle1" class="font-semibold mb-4 block">Upload Your Code</Text>
                <Text variant="caption" class="text-muted-foreground mb-4 block">
                  Upload a ZIP file containing your SolidStart project
                </Text>
                <Button variant="outline" onClick={() => navigate(routes.newStoreUpload)}>
                  Upload Code
                </Button>
              </div>

              <div class="border-t pt-8">
                <Text variant="subtitle1" class="font-semibold mb-4 block">Browse Templates</Text>
                <Text variant="caption" class="text-muted-foreground mb-4 block">
                  Select from our marketplace templates
                </Text>
                <Button variant="outline" onClick={() => navigate(routes.templates)}>
                  Browse Templates
                </Button>
                <Show when={selectedTemplate()}>
                  <div class="mt-4 p-4 rounded-lg bg-green-50 border border-green-200">
                    <Flex class="items-center gap-2">
                      <CheckIcon class="size-5 text-green-600" />
                      <Text variant="body2" class="text-green-700">
                        Template selected (ID: {selectedTemplate()})
                      </Text>
                      <Button variant="ghost" size="sm" onClick={() => setSelectedTemplate(null)}>
                        Clear
                      </Button>
                    </Flex>
                  </div>
                </Show>
              </div>

              <div class="border-t pt-8">
                <Text variant="subtitle1" class="font-semibold mb-4 block">Or Clone from Your Stores</Text>
                <Text variant="caption" class="text-muted-foreground mb-4 block">
                  Select one of your existing stores to duplicate
                </Text>
                
                <Show when={mounted()}>
                  <Query
                    queryKey={["myStores"]}
                    queryFn={fetchMyStores}
                  >
                    <QueryBoundary
                      loadingFallback={
                        <Flex class="justify-center py-8">
                          <LoaderIcon class="size-6 animate-spin" />
                        </Flex>
                      }
                    >
                      {(myStores) => {
                        const stores = (myStores as Store[]) ?? []
                        return (
                          <>
                            <Show when={stores.length === 0}>
                              <Card class="p-8 text-center">
                                <Text variant="body2" class="text-muted-foreground mb-4">
                                  You don't have any stores yet. Create your first store or browse templates above.
                                </Text>
                                <Button variant="outline" onClick={() => navigate(routes.stores)}>
                                  Go to My Stores
                                </Button>
                              </Card>
                            </Show>

                            <Show when={stores.length > 0}>
                              <div class="grid gap-3 max-h-[300px] overflow-y-auto">
                                <For each={stores}>{(store) => (
                                  <Card 
                                    class={`cursor-pointer transition-all hover:shadow-lg ${
                                      cloneFromStoreId() === store.id ? "ring-2 ring-primary" : ""
                                    }`}
                                    onClick={() => {
                                      setCloneFromStoreId(store.id)
                                      setStoreType("clone")
                                      setSelectedTemplate(null)
                                    }}
                                  >
                                    <CardContent class="p-4 flex items-center justify-between">
                                      <Flex class="items-center gap-3">
                                        <div class="size-10 rounded-lg bg-muted flex items-center justify-center">
                                          <StoreIcon class="size-5 text-muted-foreground" />
                                        </div>
                                        <div>
                                          <Text variant="body2" class="font-medium">{store.name}</Text>
                                          <Text variant="caption" class="text-muted-foreground">
                                            {store.description || "No description"}
                                          </Text>
                                        </div>
                                      </Flex>
                                      <Show when={cloneFromStoreId() === store.id}>
                                        <CheckIcon class="size-5 text-primary" />
                                      </Show>
                                    </CardContent>
                                  </Card>
                                )}</For>
                              </div>
                            </Show>
                          </>
                        )
                      }}
                    </QueryBoundary>
                  </Query>
                </Show>
              </div>
            </div>
          </Show>

          <Show when={currentStep() === 2}>
            <Card class="max-w-2xl mx-auto">
              <CardHeader>
                <CardTitle>Store Details</CardTitle>
                <CardDescription>
                  Give your store a name and description
                </CardDescription>
              </CardHeader>
              <CardContent class="space-y-6">
                <TextField>
                  <TextFieldLabel>Store Name *</TextFieldLabel>
                  <TextFieldInput
                    placeholder="My Awesome Store"
                    value={name()}
                    onInput={(e) => handleNameChange(e.currentTarget.value)}
                  />
                  <Show when={isCheckingName()}>
                    <Flex class="items-center gap-2 mt-1">
                      <LoaderIcon class="size-3 animate-spin" />
                      <Text variant="caption" class="text-muted-foreground">Checking availability...</Text>
                    </Flex>
                  </Show>
                  <Show when={nameAvailable() === true && name().length >= 3}>
                    <Text class="text-xs text-green-600 mt-1">Store name is available</Text>
                  </Show>
                  <Show when={nameAvailable() === false}>
                    <TextFieldErrorMessage>This store name is already taken</TextFieldErrorMessage>
                  </Show>
                </TextField>

                <TextField>
                  <TextFieldLabel>Description</TextFieldLabel>
                  <TextFieldTextArea
                    placeholder="Tell customers about your store..."
                    value={description()}
                    onInput={(e: any) => setDescription(e.currentTarget.value)}
                    rows={4}
                  />
                </TextField>

                <div class="p-4 rounded-lg bg-muted">
                  <Flex class="items-center gap-3">
                    <LayoutTemplateIcon class="size-5 text-muted-foreground" />
                    <div>
                      <Text variant="body2" class="font-medium">
                        {storeType() === "clone" ? "Clone from Existing Store" : "Template"}
                      </Text>
                      <Text variant="caption" class="text-muted-foreground">
                        {storeType() === "clone" 
                          ? "Duplicate an existing store" 
                          : "Start from a marketplace template"}
                      </Text>
                    </div>
                  </Flex>
                </div>
              </CardContent>
            </Card>
          </Show>

          <Show when={currentStep() === 3}>
            <Card class="max-w-2xl mx-auto">
              <CardHeader>
                <CardTitle>Domain Setup</CardTitle>
                <CardDescription>
                  Choose how customers will find your store
                </CardDescription>
              </CardHeader>
              <CardContent class="space-y-6">
                <Flex class="gap-4">
                  <Button
                    variant={domainType() === "subdomain" ? "default" : "outline"}
                    class="flex-1"
                    onClick={() => setDomainType("subdomain")}
                  >
                    <GlobeIcon class="size-4 mr-2" />
                    Subdomain
                  </Button>
                  <Button
                    variant={domainType() === "custom" ? "default" : "outline"}
                    class="flex-1"
                    onClick={() => setDomainType("custom")}
                  >
                    <GlobeIcon class="size-4 mr-2" />
                    Custom Domain
                  </Button>
                </Flex>

                <Show when={domainType() === "subdomain"}>
                  <TextField>
                    <TextFieldLabel>Subdomain</TextFieldLabel>
                    <Flex class="gap-2">
                      <TextFieldInput
                        placeholder="mystore"
                        value={subdomain()}
                        onInput={(e) => setSubdomain(e.currentTarget.value)}
                      />
                      <div class="px-3 py-2 bg-muted rounded-md text-sm text-muted-foreground">
                        .entaprenua.com
                      </div>
                    </Flex>
                    <Text variant="caption" class="text-muted-foreground mt-1">
                      Your store will be at: {subdomain() || "mystore"}.entaprenua.com
                    </Text>
                    <Button variant="link" size="sm" onClick={generateSubdomain} class="mt-1">
                      Generate from store name
                    </Button>
                  </TextField>
                </Show>

                <Show when={domainType() === "custom"}>
                  <TextField>
                    <TextFieldLabel>Custom Domain</TextFieldLabel>
                    <TextFieldInput
                      placeholder="www.mystore.com"
                      value={customDomain()}
                      onInput={(e) => setCustomDomain(e.currentTarget.value)}
                    />
                    <Text variant="caption" class="text-muted-foreground mt-1">
                      You'll need to configure DNS records to point to Entaprenua
                    </Text>
                  </TextField>
                </Show>
              </CardContent>
            </Card>
          </Show>

          <Show when={currentStep() === 4}>
            <Card class="max-w-2xl mx-auto">
              <CardHeader>
                <CardTitle>Review & Create</CardTitle>
                <CardDescription>
                  Review your store details before creating
                </CardDescription>
              </CardHeader>
              <CardContent class="space-y-6">
                <div class="rounded-lg border p-4 space-y-3">
                  <Flex class="justify-between items-center">
                    <Text variant="caption" class="text-muted-foreground">Store Name</Text>
                    <Text weight="medium">{name()}</Text>
                  </Flex>
                  <Flex class="justify-between items-center">
                    <Text variant="caption" class="text-muted-foreground">Description</Text>
                    <Text>{description() || "No description"}</Text>
                  </Flex>
                  <Flex class="justify-between items-center">
                    <Text variant="caption" class="text-muted-foreground">Starting From</Text>
                    <Badge variant="outline">
                      {storeType() === "clone" ? "Clone from existing store" : "Template"}
                    </Badge>
                  </Flex>
                  <Flex class="justify-between items-center">
                    <Text variant="caption" class="text-muted-foreground">Domain</Text>
                    <Text>
                      {domainType() === "subdomain" 
                        ? `${subdomain() || name().toLowerCase().replace(/[^a-z0-9]/g, '-')}.entaprenua.com`
                        : customDomain() || "Not set"
                      }
                    </Text>
                  </Flex>
                </div>
              </CardContent>
              <CardFooter>
                <Text variant="caption" class="text-muted-foreground">
                  After creating your store, you can customize it with our visual builder and export it to SolidStart or NextJS.
                </Text>
              </CardFooter>
            </Card>
          </Show>

          <Flex class="justify-between mt-8">
            <Button 
              variant="outline" 
              onClick={prevStep}
              disabled={currentStep() === 1}
              class="gap-2"
            >
              <ArrowLeftIcon class="size-4" />
              Back
            </Button>
            
            <Show when={currentStep() < 4}>
              <Button 
                onClick={nextStep}
                disabled={!canProceed()}
                class="gap-2"
              >
                Continue
                <ArrowRightIcon class="size-4" />
              </Button>
            </Show>
            
            <Show when={currentStep() === 4}>
              <Button 
                onClick={handleSubmit}
                disabled={isSubmitting()}
                class="gap-2"
              >
                <Show when={isSubmitting()}>
                  <LoaderIcon class="size-4 animate-spin" />
                  Creating...
                </Show>
                <Show when={!isSubmitting()}>
                  <CheckIcon class="size-4" />
                  Create Store
                </Show>
              </Button>
            </Show>
          </Flex>
        </div>
      </div>
    </>
  )
}
