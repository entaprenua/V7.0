import { For, Show } from "solid-js"
import { Text } from "~/components/ui/text"
import { Flex } from "~/components/ui/flex"
import { Box } from "~/components/ui/box"
import { Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from "~/components/ui/table"
import type { OrderItem } from "~/lib/types"

interface OrderItemsSectionProps {
  items: OrderItem[] | null | undefined
  currency?: string
}

export function OrderItemsSection(props: OrderItemsSectionProps) {
  const formatPrice = (price: number | null | undefined) => {
    if (price == null) return "-"
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: props.currency || "USD",
    }).format(price)
  }

  return (
    <Box class="flex flex-col gap-2">
      <Text class="font-medium">Order Items</Text>
      <Show
        when={props.items && props.items.length > 0}
        fallback={
          <Text class="text-muted-foreground">No items</Text>
        }
      >
        <Box class="border rounded-lg overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Product</TableHead>
                <TableHead class="text-right">Price</TableHead>
                <TableHead class="text-right">Qty</TableHead>
                <TableHead class="text-right">Total</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              <For each={props.items}>
                {(item) => (
                  <TableRow>
                    <TableCell>
                      <Text>{item.productName}</Text>
                    </TableCell>
                    <TableCell class="text-right">
                      <Text>{formatPrice(item.price)}</Text>
                    </TableCell>
                    <TableCell class="text-right">
                      <Text>{item.quantity}</Text>
                    </TableCell>
                    <TableCell class="text-right">
                      <Text weight="medium">{formatPrice(item.subtotal)}</Text>
                    </TableCell>
                  </TableRow>
                )}
              </For>
            </TableBody>
          </Table>
        </Box>
      </Show>
    </Box>
  )
}
