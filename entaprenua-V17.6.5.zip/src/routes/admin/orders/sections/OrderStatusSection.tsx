import { For, Show } from "solid-js"
import { useOrderEditor, ORDER_STATUS_TRANSITIONS } from "../order-editor-context"
import { Badge } from "~/components/ui/badge"
import { Button } from "~/components/ui/button"
import { Label } from "~/components/ui/label"
import { Flex } from "~/components/ui/flex"
import { ORDER_STATUS_LABELS, ORDER_STATUS_COLORS, type OrderStatus } from "~/lib/api/orders"

export function OrderStatusSection() {
  const { formData, updateField, initialOrder, isQuickEdit } = useOrderEditor()

  const currentStatus = () => initialOrder?.status || "pending"
  const validTransitions = () => ORDER_STATUS_TRANSITIONS[currentStatus()] || []

  return (
    <Flex class="flex-col gap-4">
      <Label>Current Status</Label>
      <Badge variant={ORDER_STATUS_COLORS[currentStatus()] as any} class="w-fit">
        {ORDER_STATUS_LABELS[currentStatus()]}
      </Badge>

      <Show when={!isQuickEdit() || validTransitions().length > 0}>
        <Label>Update Status</Label>
        <Show
          when={!isQuickEdit()}
          fallback={
            <Flex class="flex-wrap gap-2">
              <For each={validTransitions()}>
                {(status) => (
                  <Button
                    variant={formData.status === status ? "default" : "outline"}
                    size="sm"
                    onClick={() => updateField("status", status)}
                  >
                    {ORDER_STATUS_LABELS[status]}
                  </Button>
                )}
              </For>
            </Flex>
          }
        >
          <select
            class="flex h-10 w-full items-center justify-between rounded-md border border-input bg-transparent px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
            value={formData.status}
            onChange={(e) => updateField("status", e.currentTarget.value as OrderStatus)}
          >
            <For each={Object.entries(ORDER_STATUS_LABELS)}>
              {([value, label]) => (
                <option value={value}>{label}</option>
              )}
            </For>
          </select>
        </Show>
      </Show>
    </Flex>
  )
}
