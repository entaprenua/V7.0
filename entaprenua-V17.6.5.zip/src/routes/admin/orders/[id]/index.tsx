import { createSignal, Show, For, onMount, createMemo } from "solid-js"
import { A, useParams, useNavigate } from "@solidjs/router"
import { Title, Meta } from "@solidjs/meta"
import { Button } from "~/components/ui/button"
import { Text, Heading } from "~/components/ui/text"
import { Badge } from "~/components/ui/badge"
import { Flex, Grid, Box, Card, CardContent, CardHeader, CardTitle } from "~/components/ui"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "~/components/ui/dialog"
import { TextFieldTextArea } from "~/components/ui/text-field"
import { useAdminPanel } from "~/lib/stores/admin-panel"
import { ordersApi, ORDER_STATUS_LABELS, ORDER_STATUS_COLORS, type OrderStatus } from "~/lib/api/orders"
import type { Order } from "~/lib/types"
import { routes } from "~/lib/utils/routes"
import ArrowLeft from "lucide-solid/icons/arrow-left"
import ShoppingCart from "lucide-solid/icons/shopping-cart"
import Printer from "lucide-solid/icons/printer"
import { api, getCsrfToken } from "~/lib/api/client"

const STATUS_TRANSITIONS: Record<OrderStatus, OrderStatus[]> = {
  pending: ['confirmed', 'processing', 'cancelled', 'payment_failed'],
  confirmed: ['processing', 'cancelled'],
  processing: ['shipped', 'on_hold', 'cancelled'],
  on_hold: ['processing', 'cancelled'],
  shipped: ['delivered', 'returned'],
  delivered: ['returned', 'refunded'],
  cancelled: ['refunded'],
  refunded: [],
  returned: ['refunded'],
  payment_failed: ['pending', 'cancelled'],
}

function getAllowedTransitions(currentStatus: OrderStatus): OrderStatus[] {
  return STATUS_TRANSITIONS[currentStatus] || []
}

export default function OrderDetailPage() {
  const params = useParams()
  const navigate = useNavigate()
  const admin = useAdminPanel()
  const storeId = createMemo(() => admin().currentStore?.id)

  const [order, setOrder] = createSignal<Order | null>(null)
  const [isLoading, setIsLoading] = createSignal(true)
  const [error, setError] = createSignal<string | null>(null)
  const [showStatusDialog, setShowStatusDialog] = createSignal(false)
  const [newStatus, setNewStatus] = createSignal<OrderStatus | null>(null)
  const [isUpdating, setIsUpdating] = createSignal(false)
  const [notes, setNotes] = createSignal("")
  const [isSavingNotes, setIsSavingNotes] = createSignal(false)
  const [showDeleteDialog, setShowDeleteDialog] = createSignal(false)
  const [isDeleting, setIsDeleting] = createSignal(false)

  const fetchOrder = async () => {
    const sid = storeId()
    const orderId = params.id
    if (!sid || !orderId) return
    setIsLoading(true)
    try {
      const orderData = await ordersApi.getById(sid, orderId)
      if (orderData) {
        setOrder(orderData)
        setNotes(orderData.notes || "")
      } else {
        setError("Order not found")
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load order")
    } finally {
      setIsLoading(false)
    }
  }

  onMount(fetchOrder)

  const formatPrice = (price: number | null | undefined, currency?: string) => {
    if (price == null) return '-'
    return new Intl.NumberFormat('en-US', { 
      style: 'currency', 
      currency: currency || 'USD' 
    }).format(price)
  }

  const formatDate = (date: string | null | undefined) => {
    if (!date) return '-'
    return new Date(date).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    })
  }

  const handleUpdateStatus = async () => {
    const status = newStatus()
    const sid = storeId()
    const orderId = params.id
    if (!status || !sid || !orderId) return

    const currentOrder = order()
    if (currentOrder) {
      const allowedTransitions = getAllowedTransitions(currentOrder.status)
      if (!allowedTransitions.includes(status)) {
        alert(`Cannot change status from ${ORDER_STATUS_LABELS[currentOrder.status]} to ${ORDER_STATUS_LABELS[status]}`)
        return
      }
    }

    setIsUpdating(true)
    try {
      await ordersApi.updateStatus(sid, orderId, status)
      setShowStatusDialog(false)
      fetchOrder()
    } catch (err) {
      console.error("Failed to update status", err)
    } finally {
      setIsUpdating(false)
    }
  }

  const handleSaveNotes = async () => {
    const sid = storeId()
    const orderId = params.id
    if (!sid || !orderId) return

    setIsSavingNotes(true)
    try {
      const csrfToken = getCsrfToken()
      await api.put(
        `/stores/${sid}/orders/${orderId}`,
        { notes: notes() },
        csrfToken || undefined
      )
      fetchOrder()
    } catch (err) {
      console.error("Failed to save notes", err)
    } finally {
      setIsSavingNotes(false)
    }
  }

  const handleDelete = async () => {
    const sid = storeId()
    const orderId = params.id
    if (!sid || !orderId) return

    setIsDeleting(true)
    try {
      await ordersApi.delete(sid, orderId)
      navigate(routes.adminOrders)
    } catch (err) {
      console.error("Failed to delete order", err)
      setIsDeleting(false)
    }
  }

  const allowedTransitions = createMemo(() => {
    const currentOrder = order()
    if (!currentOrder) return []
    return getAllowedTransitions(currentOrder.status)
  })

  return (
    <>
      <Title>Order {order()?.orderNumber || ''} - Store Admin</Title>
      <Meta name="description" content="Order details" />
      
      <div class="min-h-screen bg-background">
        <div class="border-b">
          <div class="container mx-auto px-4 py-6">
            <Flex class="items-center gap-4">
              <A href={routes.adminOrders}>
                <Button variant="ghost" size="icon">
                  <ArrowLeft class="size-5" />
                </Button>
              </A>
              <div class="flex-1">
                <Heading level={1} class="text-2xl font-bold">
                  Order {order()?.orderNumber || 'Loading...'}
                </Heading>
                <Text class="text-muted-foreground">
                  {order() ? formatDate(order()!.insertedAt) : ''}
                </Text>
              </div>
              <Flex class="gap-2">
                <Button variant="outline" class="gap-2" onClick={() => window.print()}>
                  <Printer class="size-4" />
                  Print
                </Button>
                <Button variant="destructive" class="gap-2" onClick={() => setShowDeleteDialog(true)}>
                  Delete
                </Button>
                <Button class="gap-2" onClick={() => { setNewStatus(order()?.status || null); setShowStatusDialog(true) }}>
                  Update Status
                </Button>
              </Flex>
            </Flex>
          </div>
        </div>

        <div class="container mx-auto px-4 py-8">
          <Show when={isLoading()}>
            <Flex class="flex-col items-center justify-center py-16">
              <div class="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent" />
              <Text class="text-muted-foreground mt-4">Loading order...</Text>
            </Flex>
          </Show>

          <Show when={error() && !isLoading()}>
            <Card class="border-destructive">
              <CardContent class="pt-6">
                <Flex class="flex-col items-center text-center py-8">
                  <Text class="text-destructive mb-4">{error()}</Text>
                  <Button variant="outline" onClick={() => navigate(routes.adminOrders)}>
                    Back to Orders
                  </Button>
                </Flex>
              </CardContent>
            </Card>
          </Show>

          <Show when={!isLoading() && !error() && order()}>
            <Grid cols={1} colsLg={3} class="gap-6">
              <div class="col-span-2 space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle class="flex items-center gap-2">
                      <ShoppingCart class="size-5" />
                      Order Items
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div class="space-y-4">
                      <For each={order()?.items || []}>
                        {(item) => (
                          <Flex class="items-center gap-4 p-4 border rounded-lg">
                            <div class="flex-1">
                              <Text weight="medium">{item.productName}</Text>
                              <Text variant="caption" class="text-muted-foreground">
                                Qty: {item.quantity} × {formatPrice(item.price, order()?.currency)}
                              </Text>
                            </div>
                            <Text weight="medium">
                              {formatPrice(item.subtotal, order()?.currency)}
                            </Text>
                          </Flex>
                        )}
                      </For>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Shipping Address</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <Show when={order()?.shippingAddress} fallback={<Text class="text-muted-foreground">No shipping address</Text>}>
                      <div class="space-y-1">
                        <Text>{order()?.shippingAddress?.firstName} {order()?.shippingAddress?.lastName}</Text>
                        <Text class="text-muted-foreground">{order()?.shippingAddress?.addressLine1}</Text>
                        <Show when={order()?.shippingAddress?.addressLine2}>
                          <Text class="text-muted-foreground">{order()?.shippingAddress?.addressLine2}</Text>
                        </Show>
                        <Text class="text-muted-foreground">
                          {order()?.shippingAddress?.city}, {order()?.shippingAddress?.state} {order()?.shippingAddress?.postalCode}
                        </Text>
                        <Text class="text-muted-foreground">{order()?.shippingAddress?.country}</Text>
                      </div>
                    </Show>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Billing Address</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <Show when={order()?.billingAddress} fallback={<Text class="text-muted-foreground">No billing address</Text>}>
                      <div class="space-y-1">
                        <Text>{order()?.billingAddress?.firstName} {order()?.billingAddress?.lastName}</Text>
                        <Text class="text-muted-foreground">{order()?.billingAddress?.addressLine1}</Text>
                        <Text class="text-muted-foreground">
                          {order()?.billingAddress?.city}, {order()?.billingAddress?.state} {order()?.billingAddress?.postalCode}
                        </Text>
                        <Text class="text-muted-foreground">{order()?.billingAddress?.country}</Text>
                      </div>
                    </Show>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Order Notes</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <Flex class="flex-col gap-2">
                      <TextFieldTextArea
                        placeholder="Add notes about this order..."
                        value={notes()}
                        onInput={(e) => setNotes((e.target as HTMLTextAreaElement).value)}
                        rows={4}
                      />
                      <Button 
                        variant="outline" 
                        size="sm" 
                        class="self-end"
                        onClick={handleSaveNotes}
                        disabled={isSavingNotes() || notes() === (order()?.notes || "")}
                      >
                        {isSavingNotes() ? 'Saving...' : 'Save Notes'}
                      </Button>
                    </Flex>
                  </CardContent>
                </Card>
              </div>

              <div class="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Order Summary</CardTitle>
                  </CardHeader>
                  <CardContent class="space-y-3">
                    <Flex class="justify-between">
                      <Text>Subtotal</Text>
                      <Text>{formatPrice(order()?.subtotal, order()?.currency)}</Text>
                    </Flex>
                    <Flex class="justify-between">
                      <Text>Tax</Text>
                      <Text>{formatPrice(order()?.tax, order()?.currency)}</Text>
                    </Flex>
                    <Flex class="justify-between">
                      <Text>Shipping</Text>
                      <Text>{formatPrice(order()?.shippingCost, order()?.currency)}</Text>
                    </Flex>
                    <Flex class="justify-between">
                      <Text>Discount</Text>
                      <Text>-{formatPrice(order()?.discount, order()?.currency)}</Text>
                    </Flex>
                    <div class="border-t pt-3">
                      <Flex class="justify-between">
                        <Text weight="semibold">Total</Text>
                        <Text weight="bold" class="text-lg">{formatPrice(order()?.total, order()?.currency)}</Text>
                      </Flex>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Status</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <Badge variant={ORDER_STATUS_COLORS[order()!.status] as any} class="text-sm">
                      {ORDER_STATUS_LABELS[order()!.status]}
                    </Badge>
                    <Show when={order()?.trackingNumber}>
                      <div class="mt-4">
                        <Text variant="caption" class="text-muted-foreground">Tracking Number</Text>
                        <Text>{order()?.trackingNumber}</Text>
                      </div>
                    </Show>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Order Info</CardTitle>
                  </CardHeader>
                  <CardContent class="space-y-3">
                    <div>
                      <Text variant="caption" class="text-muted-foreground">Order ID</Text>
                      <Text>{order()?.id}</Text>
                    </div>
                    <div>
                      <Text variant="caption" class="text-muted-foreground">Created</Text>
                      <Text>{formatDate(order()?.insertedAt)}</Text>
                    </div>
                    <Show when={order()?.paidAt}>
                      <div>
                        <Text variant="caption" class="text-muted-foreground">Paid</Text>
                        <Text>{formatDate(order()?.paidAt)}</Text>
                      </div>
                    </Show>
                    <Show when={order()?.shippedAt}>
                      <div>
                        <Text variant="caption" class="text-muted-foreground">Shipped</Text>
                        <Text>{formatDate(order()?.shippedAt)}</Text>
                      </div>
                    </Show>
                    <Show when={order()?.deliveredAt}>
                      <div>
                        <Text variant="caption" class="text-muted-foreground">Delivered</Text>
                        <Text>{formatDate(order()?.deliveredAt)}</Text>
                      </div>
                    </Show>
                  </CardContent>
                </Card>
              </div>
            </Grid>
          </Show>
        </div>
      </div>

      <Dialog open={showStatusDialog()} onOpenChange={(open) => !open && setShowStatusDialog(false)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Update Order Status</DialogTitle>
            <DialogDescription>
              Current status: {order() ? ORDER_STATUS_LABELS[order()!.status] : ''}
            </DialogDescription>
          </DialogHeader>
          <div class="py-4">
            <Flex class="flex-col gap-2">
              <Text variant="caption" class="text-muted-foreground">
                Select new status (valid transitions only):
              </Text>
              <Flex class="flex-wrap gap-2">
                <For each={Object.entries(ORDER_STATUS_LABELS)}>
                  {([value, label]) => {
                    const isAllowed = allowedTransitions().includes(value as OrderStatus)
                    return (
                      <Button
                        variant={newStatus() === value ? "default" : "outline"}
                        size="sm"
                        disabled={!isAllowed}
                        onClick={() => setNewStatus(value as OrderStatus)}
                        title={!isAllowed ? `Cannot transition from ${ORDER_STATUS_LABELS[order()!.status]} to ${label}` : undefined}
                      >
                        {label}
                      </Button>
                    )
                  }}
                </For>
              </Flex>
            </Flex>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowStatusDialog(false)}>Cancel</Button>
            <Button onClick={handleUpdateStatus} disabled={isUpdating() || !newStatus()}>
              {isUpdating() ? 'Updating...' : 'Update Status'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={showDeleteDialog()} onOpenChange={(open) => !open && setShowDeleteDialog(false)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Delete Order</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete this order? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDeleteDialog(false)}>Cancel</Button>
            <Button variant="destructive" onClick={handleDelete} disabled={isDeleting()}>
              {isDeleting() ? 'Deleting...' : 'Delete Order'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  )
}
