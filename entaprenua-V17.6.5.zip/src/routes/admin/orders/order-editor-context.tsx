import { createContext, useContext, ParentComponent, createSignal, createEffect, Accessor } from "solid-js"
import { createStore } from "solid-js/store"
import { ordersApi, type OrderStatus } from "~/lib/api/orders"
import type { Order } from "~/lib/types"

export type OrderFormData = {
  status: OrderStatus
  notes: string | null
  trackingNumber: string | null
}

export type OrderFormErrors = {
  status?: string
}

export const ORDER_STATUS_TRANSITIONS: Record<OrderStatus, OrderStatus[]> = {
  pending: ["confirmed", "processing", "cancelled", "payment_failed"],
  confirmed: ["processing", "cancelled"],
  processing: ["shipped", "on_hold", "cancelled"],
  on_hold: ["processing", "cancelled"],
  shipped: ["delivered", "returned"],
  delivered: ["returned", "refunded"],
  cancelled: ["refunded"],
  returned: ["refunded"],
  refunded: [],
  payment_failed: ["pending", "cancelled"],
}

type OrderEditorContextValue = {
  mode: Accessor<"edit" | "quick-edit">
  storeId: Accessor<string | undefined>
  isQuickEdit: Accessor<boolean>
  initialOrder: Order | null | undefined
  
  formData: OrderFormData
  setFormData: (data: Partial<OrderFormData>) => void
  updateField: <K extends keyof OrderFormData>(field: K, value: OrderFormData[K]) => void
  
  errors: OrderFormErrors
  validate: () => boolean
  getValidTransitions: () => OrderStatus[]
  
  isSaving: Accessor<boolean>
  
  save: () => Promise<Order | null>
  
  reset: () => void
}

const OrderEditorContext = createContext<OrderEditorContextValue>()

const defaultFormData: OrderFormData = {
  status: "pending",
  notes: null,
  trackingNumber: null,
}

type OrderEditorProviderProps = {
  storeId: string
  mode?: "edit" | "quick-edit"
  initialOrder?: Order | null
  onSaved?: (order: Order) => void
  isQuickEdit?: boolean
}

export const OrderEditorProvider: ParentComponent<OrderEditorProviderProps> = (props) => {
  const resolvedMode = () => props.mode ?? "edit"
  const isQuickEdit = () => props.isQuickEdit ?? false
  
  const [formData, setFormDataStore] = createStore<OrderFormData>({ ...defaultFormData })
  
  const [isSaving, setIsSaving] = createSignal(false)

  const [errors, setErrors] = createStore<OrderFormErrors>({})

  const validate = (): boolean => {
    const newErrors: OrderFormErrors = {}
    
    if (!formData.status) {
      newErrors.status = "Status is required"
    }
    
    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  createEffect(() => {
    if (props.initialOrder) {
      setFormDataStore({
        status: props.initialOrder.status || "pending",
        notes: props.initialOrder.notes ?? null,
        trackingNumber: props.initialOrder.trackingNumber ?? null,
      })
    }
  })

  const getValidTransitions = (): OrderStatus[] => {
    const currentStatus = props.initialOrder?.status || "pending"
    return ORDER_STATUS_TRANSITIONS[currentStatus] || []
  }

  const updateField = <K extends keyof OrderFormData>(field: K, value: OrderFormData[K]) => {
    setFormDataStore(field, value)
    
    if (field === "status" && errors.status) {
      setErrors("status", undefined)
    }
  }

  const setFormData = (data: Partial<OrderFormData>) => {
    setFormDataStore(data)
  }

  const save = async (): Promise<Order | null> => {
    if (!validate()) {
      return null
    }

    setIsSaving(true)
    try {
      const orderId = props.initialOrder?.id
      if (!orderId) {
        console.error("No order ID for update")
        return null
      }

      const apiResponse = await ordersApi.updateStatus(props.storeId, orderId, formData.status)
      const result = apiResponse.data ?? null

      if (result) {
        props.onSaved?.(result)
      }
      return result
    } catch (error) {
      console.error("Failed to save order:", error)
      return null
    } finally {
      setIsSaving(false)
    }
  }

  const reset = () => {
    setFormDataStore({ ...defaultFormData })
    setErrors({})
  }

  const value: OrderEditorContextValue = {
    mode: resolvedMode,
    storeId: () => props.storeId,
    isQuickEdit,
    initialOrder: props.initialOrder,
    formData,
    setFormData,
    updateField,
    errors,
    validate,
    getValidTransitions,
    isSaving,
    save,
    reset,
  }

  return (
    <OrderEditorContext.Provider value={value}>
      {props.children}
    </OrderEditorContext.Provider>
  )
}

export const useOrderEditor = () => {
  const context = useContext(OrderEditorContext)
  if (!context) {
    throw new Error("useOrderEditor must be used within an OrderEditorProvider")
  }
  return context
}
