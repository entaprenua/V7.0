import { createMemo, createSignal, For, Show, JSX } from "solid-js"
import { useNavigate } from "@solidjs/router"
import { ColumnDef } from "@tanstack/solid-table"
import { DataTableServer, FilterConfig } from "~/components/ui/data-table-server"
import { ordersApi, ORDER_STATUS_LABELS, ORDER_STATUS_COLORS, type OrderStatus } from "~/lib/api/orders"
import { useAdminPanel } from "~/lib/stores/admin-panel"

import { Button } from "~/components/ui/button"
import { Text } from "~/components/ui/text"
import { Badge } from "~/components/ui/badge"
import { Flex } from "~/components/ui/flex"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "~/components/ui/dialog"
import { EyeIcon, RotateCwIcon } from "~/icons"
import type { Order } from "~/lib/types"
import { formatCurrency } from "~/lib/utils"

const STATUS_OPTIONS = [
  { value: "pending", label: "Pending" },
  { value: "confirmed", label: "Confirmed" },
  { value: "processing", label: "Processing" },
  { value: "on_hold", label: "On Hold" },
  { value: "shipped", label: "Shipped" },
  { value: "delivered", label: "Delivered" },
  { value: "cancelled", label: "Cancelled" },
  { value: "refunded", label: "Refunded" },
  { value: "returned", label: "Returned" },
  { value: "payment_failed", label: "Payment Failed" },
]

const SORT_OPTIONS = [
  { value: "created-desc", label: "Newest First" },
  { value: "created-asc", label: "Oldest First" },
  { value: "total-desc", label: "Total: High to Low" },
  { value: "total-asc", label: "Total: Low to High" },
]

const FILTERS: FilterConfig[] = [
  {
    key: "search",
    label: "Orders",
    type: "search",
    placeholder: "Search orders..."
  },
  {
    key: "status",
    label: "Status",
    type: "select",
    options: STATUS_OPTIONS,
    placeholder: "All Status"
  },
  {
    key: "sortBy",
    label: "Sort",
    type: "select",
    options: SORT_OPTIONS,
    placeholder: "Sort by"
  }
]

const COLUMNS: ColumnDef<Order>[] = [
  {
    id: "orderNumber",
    header: "Order #",
    cell: (info) => {
      return <Text weight="medium">{info.row.original.orderNumber}</Text>
    }
  },
  {
    id: "status",
    header: "Status",
    enableSorting: false,
    cell: (info) => {
      const order = info.row.original
      return (
        <Badge variant={ORDER_STATUS_COLORS[order.status] as any}>
          {ORDER_STATUS_LABELS[order.status]}
        </Badge>
      )
    }
  },
  {
    id: "customer",
    header: "Customer",
    enableSorting: false,
    cell: (info) => {
      const order = info.row.original
      return (
        <Text>
          {order.billingAddress ? 
            `${order.billingAddress.firstName} ${order.billingAddress.lastName}` : 
            'Guest'
          }
        </Text>
      )
    }
  },
  {
    id: "items",
    header: "Items",
    enableSorting: false,
    cell: (info) => {
      return <Text>{info.row.original.items?.length || 0} items</Text>
    }
  },
  {
    id: "total",
    header: "Total",
    cell: (info) => {
      const order = info.row.original
      return <Text weight="medium">{formatCurrency(order.total, order.currency)}</Text>
    }
  },
  {
    id: "insertedAt",
    header: "Date",
    cell: (info) => {
      const date = info.row.original.insertedAt
      if (!date) return <Text>-</Text>
      return (
        <Text variant="caption">
          {new Date(date).toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'short',
            day: 'numeric',
          })}
        </Text>
      )
    }
  }
]

function OrderQuickStatusUpdate(props: { order: Order; onUpdate: () => void }) {
  const [showDialog, setShowDialog] = createSignal(false)
  const [newStatus, setNewStatus] = createSignal<OrderStatus | null>(null)
  const [isUpdating, setIsUpdating] = createSignal(false)
  const admin = useAdminPanel()
  const storeId = createMemo(() => admin().currentStore?.id)

  const handleUpdate = async () => {
    const status = newStatus()
    const sid = storeId()
    if (!status || !sid || !props.order.id) return

    setIsUpdating(true)
    try {
      await ordersApi.updateStatus(sid, props.order.id, status)
      setShowDialog(false)
      props.onUpdate()
    } catch (err) {
      console.error("Failed to update order status", err)
    } finally {
      setIsUpdating(false)
    }
  }

  return (
    <>
      <Button 
        variant="ghost" 
        size="icon" 
        class="h-8 w-8"
        onClick={() => { setNewStatus(props.order.status); setShowDialog(true) }}
      >
        <RotateCwIcon class="size-4" />
      </Button>
      
      <Dialog open={showDialog()} onOpenChange={(open) => !open && setShowDialog(false)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Update Order Status</DialogTitle>
            <DialogDescription>
              Change the status of this order
            </DialogDescription>
          </DialogHeader>
          <div class="py-4">
            <Flex class="flex-wrap gap-2">
              <For each={Object.entries(ORDER_STATUS_LABELS)}>
                {([value, label]) => (
                  <Button
                    variant={newStatus() === value ? "default" : "outline"}
                    size="sm"
                    onClick={() => setNewStatus(value as OrderStatus)}
                  >
                    {label}
                  </Button>
                )}
              </For>
            </Flex>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDialog(false)}>Cancel</Button>
            <Button onClick={handleUpdate} disabled={isUpdating() || !newStatus()}>
              {isUpdating() ? 'Updating...' : 'Update Status'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  )
}

export default function OrdersPage() {
  const navigate = useNavigate()
  const admin = useAdminPanel()
  
  const storeId = createMemo(() => admin().currentStore?.id)

  const fetchOrders = async (params: {
    page: number
    pageSize: number
    sortField?: string
    sortDirection?: "asc" | "desc"
    filters: Record<string, string>
  }) => {
    if (!storeId()) return { data: [], total: 0 }

    const sortBy = params.filters.sortBy || 'created-desc'
    const [sort, order] = sortBy.split('-')
    
    const response = await ordersApi.getAll(storeId()!, {
      page: params.page,
      size: params.pageSize,
      status: params.filters.status as OrderStatus,
      search: params.filters.search,
      sortBy: sort as 'created' | 'updated' | 'total',
      sortOrder: order as 'asc' | 'desc'
    })
    
    return { data: response.content ?? [], total: response.totalElements ?? 0 }
  }

  const renderRowActions = (order: Order): JSX.Element => {
    return (
      <Flex class="gap-1">
        <Button variant="ghost" size="icon" class="h-8 w-8" onClick={() => navigate(`/admin/orders/${order.id}`)}>
          <EyeIcon class="size-4" />
        </Button>
        <OrderQuickStatusUpdate 
          order={order} 
          onUpdate={() => window.location.reload()} 
        />
      </Flex>
    )
  }

  const renderMobileCell = (order: Order, columnId: string): JSX.Element => {
    switch (columnId) {
      case "orderNumber":
        return <Text weight="medium">{order.orderNumber}</Text>
      case "status":
        return (
          <Badge variant={ORDER_STATUS_COLORS[order.status] as any}>
            {ORDER_STATUS_LABELS[order.status]}
          </Badge>
        )
      case "customer":
        return (
          <Text>
            {order.billingAddress ? 
              `${order.billingAddress.firstName} ${order.billingAddress.lastName}` : 
              'Guest'
            }
          </Text>
        )
      case "items":
        return <Text>{order.items?.length || 0} items</Text>
      case "total":
        return <Text weight="medium">{formatCurrency(order.total, order.currency)}</Text>
      case "insertedAt":
        if (!order.insertedAt) return <Text>-</Text>
        return (
          <Text variant="caption">
            {new Date(order.insertedAt).toLocaleDateString('en-US', {
              year: 'numeric',
              month: 'short',
              day: 'numeric',
            })}
          </Text>
        )
      default:
        return <></>
    }
  }

  return (
    <Flex class="flex-col gap-4 p-4">
      <Flex class="justify-between items-center">
        <Text class="text-2xl font-semibold">Orders</Text>
      </Flex>

      <DataTableServer
        queryKey={["orders", storeId() as string]}
        fetchData={fetchOrders}
        columns={COLUMNS}
        filters={FILTERS}
        defaultPageSize={20}
        getRowId={(order) => order.id}
        renderRowActions={renderRowActions}
        renderCell={renderMobileCell}
      />
    </Flex>
  )
}
