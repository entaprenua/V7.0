import { createSignal, onMount, For, Show, type JSX } from "solid-js"
import { A } from "@solidjs/router"
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "~/components/ui/card"
import { Button } from "~/components/ui/button"
import { Flex, Grid, Text, Heading } from "~/components/ui"
import { useAdminPanel } from "~/lib/stores/admin-panel"
import { routes } from "~/lib/utils/routes"
import { formatCurrency } from "~/lib/utils"
import {
  ShoppingCartIcon,
  ImageIcon,
  SettingsIcon,
  PlusIcon,
  ArrowRightIcon,
  HomeIcon,
} from "~/icons"


function StatCard(props: { title: string; value: number | string; href: string }) {
  return (
    <A href={props.href}>
      <Card class="hover:border-primary/50 transition-colors cursor-pointer">
        <CardContent class="pt-6">
          <Text variant="caption" class="text-muted-foreground">{props.title}</Text>
          <Heading level={3} class="mt-1">{props.value}</Heading>
        </CardContent>
      </Card>
    </A>
  )
}

function QuickAction(props: { title: string; description: string; href: string; icon: JSX.Element }) {
  return (
    <A href={props.href}>
      <Card class="hover:border-primary/50 transition-colors cursor-pointer h-full">
        <CardContent class="pt-6">
          <Flex class="flex-col items-center text-center gap-3">
            <div class="size-12 rounded-full bg-primary/10 flex items-center justify-center text-primary">
              {props.icon}
            </div>
            <div>
              <Text variant="subtitle2" class="font-semibold">{props.title}</Text>
              <Text variant="caption" class="text-muted-foreground">{props.description}</Text>
            </div>
          </Flex>
        </CardContent>
      </Card>
    </A>
  )
}

export default function AdminDashboard() {
  const adminPanel = useAdminPanel()
  const actions = adminPanel as Record<string, any>
  const state = adminPanel()

  onMount(() => {
    actions.loadStores()
  })

  const quickActions = [
    { title: "Add Product", description: "Create new product", href: routes.adminNewProduct, icon: <PlusIcon class="size-5" /> },
    { title: "Upload Media", description: "Upload images", href: routes.adminMedia, icon: <ImageIcon class="size-5" /> },
    { title: "Store Settings", description: "Configure store", href: routes.adminSettings, icon: <SettingsIcon class="size-5" /> },
  ]

  return (
      <div class="p-6 space-y-6">
        <Flex class="items-center justify-between">
          <div>
            <Heading level={2}>Dashboard</Heading>
            <Text variant="body2" class="text-muted-foreground">
              Managing: <span class="font-medium">{state.currentStore?.name || "No store selected"}</span>
            </Text>
          </div>
          <Show when={state.currentStore}>
            <A href={routes.adminNewProduct}>
              <Button><PlusIcon class="size-4 mr-2" />Add Product</Button>
            </A>
          </Show>
        </Flex>

        <Show when={state.currentStore} fallback={
          <Card>
            <CardContent class="py-12 text-center">
              <HomeIcon class="size-12 text-muted-foreground mx-auto mb-4" />
              <Heading level={4} class="mb-2">No Store Selected</Heading>
              <Text variant="body2" class="text-muted-foreground mb-4">
                Create or select a store to manage products, categories, and orders.
              </Text>
              <A href={routes.stores}><Button variant="outline">Go to My Sites</Button></A>
            </CardContent>
          </Card>
        }>
          <Grid cols={1} colsSm={2} colsLg={4} class="gap-4">
            <StatCard title="Products" value={state.products.length} href={routes.adminProducts} />
            <StatCard title="Categories" value={state.categories.length} href={routes.adminCategories} />
            <StatCard title="Orders" value={state.orders.length} href={routes.adminOrders} />
            <StatCard title="Media" value={state.media.length} href={routes.adminMedia} />
          </Grid>

          <div>
            <Heading level={4} class="mb-4">Quick Actions</Heading>
            <Grid cols={1} colsSm={3} class="gap-4">
              <For each={quickActions}>{(action) => <QuickAction {...action} />}</For>
            </Grid>
          </div>

          <Show when={state.products.length > 0}>
            <Card>
              <CardHeader class="flex flex-row items-center justify-between">
                <CardTitle>Recent Products</CardTitle>
                <A href={routes.adminProducts} class="text-sm text-primary hover:underline">
                  View All <ArrowRightIcon class="size-3 inline ml-1" />
                </A>
              </CardHeader>
              <CardContent>
                <div class="space-y-3">
                  <For each={state.products.slice(0, 5)}>{(product) => (
                    <A href={routes.adminProduct(product.id)}>
                      <Flex class="items-center gap-3 p-2 rounded-md hover:bg-accent transition-colors">
                        <div class="size-10 rounded bg-muted flex items-center justify-center">
                          <ShoppingCartIcon class="size-4 text-muted-foreground" />
                        </div>
                        <div class="flex-1 min-w-0">
                          <Text variant="body2" class="font-medium truncate">{product.name}</Text>
                          <Text variant="caption" class="text-muted-foreground">{product.stockQuantity} in stock</Text>
                        </div>
                        <Text variant="body2" class="font-medium">{formatCurrency(product.price || "0")}</Text>
                      </Flex>
                    </A>
                  )}</For>
                </div>
              </CardContent>
            </Card>
          </Show>
        </Show>
      </div>
  )
}
