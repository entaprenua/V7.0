import { useNavigate, useParams } from "@solidjs/router"
import { Query, QueryBoundary } from "~/components/ui/query"
import { categoriesApi } from "~/lib/api/categories"
import { useAdminPanel } from "~/lib/stores/admin-panel"
import CategoryForm from "../CategoryForm"
import { routes } from "~/lib/utils/routes"
import type { Category } from "~/lib/types"

export default function CategoryEdit() {
  const navigate = useNavigate()
  const params = useParams()
  const admin = useAdminPanel()

  const categoryId = () => params.id
  const storeId = () => admin().currentStore?.id

  const queryKey = () => ["category", categoryId()]

  const handleSaved = (category: Category) => {
    // Category saved successfully
  }

  const handleDeleted = () => {
    navigate(routes.adminCategories)
  }

  return (
    <Query queryKey={queryKey()} queryFn={() => categoriesApi.getById(storeId()!, categoryId()!, true)}>
      <QueryBoundary
        loadingFallback={<div>Loading...</div>}
      >
        {(categoryResponse) => {
          const category = (categoryResponse as any)?.data ?? categoryResponse
          return (
            <CategoryForm
              storeId={storeId()!}
              mode="edit"
              initialData={category}
              onSaved={handleSaved}
              onDeleted={handleDeleted}
            />
          )
        }}
      </QueryBoundary>
    </Query>
  )
}
