import { Show } from "solid-js"
import { useNavigate } from "@solidjs/router"
import { useQueryClient } from "@tanstack/solid-query"
import { CategoryEditorProvider, useCategoryEditor } from "./category-editor-context"
import { useAdminPanel } from "~/lib/stores/admin-panel"
import { CategoryBasicInfoSection, CategoryVisibilitySection, CategoryImageSection, CategorySubcategoriesSection, CategoryProductsSection } from "./sections"
import { Flex } from "~/components/ui/flex"
import { Box } from "~/components/ui/box"
import { Button } from "~/components/ui/button"
import { Card, CardHeader, CardTitle, CardContent } from "~/components/ui/card"
import { SaveIcon, Trash2Icon } from "~/icons"
import { AdminHeader } from "~/components/ui/header"
import { routes } from "~/lib/utils/routes"
import type { Category } from "~/lib/types"

export type CategoryFormProps = {
  storeId: string
  mode: "create" | "edit"
  initialData?: Category
  onSaved?: (category: Category) => void
  onDeleted?: () => void
}

function CategoryFormContent() {
  const navigate = useNavigate()
  const queryClient = useQueryClient()
  const admin = useAdminPanel()
  const {
    mode,
    isSaving,
    isUploading,
    isDeleting,
    save,
    delete: deleteCategory,
    initialCategory,
  } = useCategoryEditor()

  const isLoading = () => isSaving() || isUploading()

  const handleSave = async () => {
    const result = await save()
    if (result) {
      if (initialCategory?.id) {
        admin.updateCategory(initialCategory.id, result)
      }
      
      const storeId = admin().currentStore?.id
      if (storeId) {
        // Invalidate to trigger fresh fetch
        await queryClient.invalidateQueries({ queryKey: ["categories", storeId], exact: false })
      }
      if (result.id) {
        queryClient.setQueryData(["category", result.id], result)
      }
      if (mode() === "create") {
        navigate(routes.adminCategories)
      }
    }
  }

  const handleDelete = async () => {
    const success = await deleteCategory()
    if (success) {
      navigate(routes.adminCategories)
    }
  }

  return (
    <Flex class="flex-col gap-6 p-6 max-w-4xl mx-auto">
      <AdminHeader
        title={mode() === "create" ? "Create Category" : "Edit Category"}
        description={mode() === "create" ? "Add a new category to your store" : "Update category details"}
        onBack={() => navigate(routes.adminCategories)}
        showHome
        actions={
          <Flex class="gap-2">
            <Show when={mode() === "edit"}>
              <Button variant="destructive" onClick={handleDelete} disabled={isDeleting()}>
                <Trash2Icon />
                {isDeleting() ? "Deleting..." : "Delete"}
              </Button>
            </Show>
            <Button onClick={handleSave} disabled={isLoading()}>
              <SaveIcon />
              {isLoading() 
                ? (mode() === "create" ? "Creating..." : "Saving...")
                : (mode() === "create" ? "Create Category" : "Save")
              }
            </Button>
          </Flex>
        }
      />

      <Flex class="flex-col lg:flex-row gap-6">
        <Box class="flex-1">
          <Card>
            <CardHeader>
              <CardTitle>Basic Information</CardTitle>
            </CardHeader>
            <CardContent class="flex flex-col gap-4">
              <CategoryBasicInfoSection />
            </CardContent>
          </Card>

          <Card class="mt-6">
            <CardContent class="p-6">
              <CategoryImageSection />
            </CardContent>
          </Card>

          <Card class="mt-6">
            <CardContent class="p-6">
              <CategorySubcategoriesSection />
            </CardContent>
          </Card>

          <Card class="mt-6">
            <CardContent class="p-6">
              <CategoryProductsSection />
            </CardContent>
          </Card>
        </Box>

        <Box class="w-full lg:w-80">
          <Card>
            <CardHeader>
              <CardTitle>Status</CardTitle>
            </CardHeader>
            <CardContent class="flex flex-col gap-4">
              <CategoryVisibilitySection />
            </CardContent>
          </Card>
        </Box>
      </Flex>
    </Flex>
  )
}

export default function CategoryForm(props: CategoryFormProps) {
  const handleSaved = (category: Category) => {
    props.onSaved?.(category)
  }

  const handleDeleted = () => {
    props.onDeleted?.()
  }

  return (
    <CategoryEditorProvider
      storeId={props.storeId}
      mode={props.mode}
      initialCategory={props.initialData}
      onSaved={handleSaved}
      onDeleted={handleDeleted}
    >
      <CategoryFormContent />
    </CategoryEditorProvider>
  )
}
