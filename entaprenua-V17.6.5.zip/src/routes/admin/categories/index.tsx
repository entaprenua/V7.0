import { Show, createMemo, JSX } from "solid-js"
import { useNavigate } from "@solidjs/router"
import { ColumnDef } from "@tanstack/solid-table"
import { DataTableServer, FilterConfig } from "~/components/ui/data-table-server"
import { categoriesApi } from "~/lib/api/categories"
import { useAdminPanel } from "~/lib/stores/admin-panel"
import { Image, ImageImg, ImageFallback } from "~/components/ui/image"
import { Button } from "~/components/ui/button"
import { Text } from "~/components/ui/text"
import { Badge } from "~/components/ui/badge"
import { Flex } from "~/components/ui/flex"
import { Trash2Icon, PlusIcon, EyeIcon, PencilIcon } from "~/icons"
import { CategoryQuickEdit } from "./category-quick-edit"
import type { Category } from "~/lib/types"

const FILTERS: FilterConfig[] = [
  {
    key: "search",
    label: "Categories",
    type: "search",
    placeholder: "Search categories..."
  },
  {
    key: "level",
    label: "Level",
    type: "select",
    options: [
      { value: "1", label: "Primary" },
      { value: "2", label: "Secondary" },
      { value: "3", label: "Tertiary" },
    ],
    placeholder: "All Levels"
  },
  {
    key: "visibility",
    label: "Visibility",
    type: "select",
    options: [
      { value: "public", label: "Public" },
      { value: "private", label: "Private" },
      { value: "draft", label: "Draft" },
    ],
    placeholder: "All Visibility"
  }
]

const LEVEL_LABELS: Record<number, string> = {
  1: "Primary",
  2: "Secondary",
  3: "Tertiary",
}

const COLUMNS: ColumnDef<Category>[] = [
  {
    id: "image",
    header: "Image",
    enableSorting: false,
    cell: (info) => {
      const imageUrl = info.row.original.image
      return <Show when={imageUrl} fallback={
        <div class="h-12 w-12 bg-muted rounded flex items-center justify-center">
          <Text class="text-muted-foreground text-xs">No img</Text>
        </div>
      }>
        <Image class="h-12 w-12 object-cover rounded">
          <ImageImg src={imageUrl!} />
          <ImageFallback />
        </Image>
      </Show>
    }
  },
  {
    id: "name",
    header: "Name",
    cell: (info) => {
      const category = info.row.original
      return <Flex class="flex-col gap-0.5">
        <Text class="font-medium">{category.name}</Text>
        <Text class="text-xs text-muted-foreground">ID: {category.id.slice(0, 8)}</Text>
      </Flex>
    }
  },
  {
    id: "level",
    header: "Level",
    cell: (info) => {
      const level = info.row.original.level
      return <Badge variant="outline">{level ? LEVEL_LABELS[level] || level : "-"}</Badge>
    }
  },
  {
    id: "childrenCount",
    header: "Children",
    enableSorting: false,
    cell: (info) => {
      const subcategories = info.row.original.subcategories
      const count = subcategories?.length ?? 0
      return <Text>{count}</Text>
    }
  },
  {
    id: "visibility",
    header: "Visibility",
    cell: (info) => {
      return <Badge variant="outline">{info.row.original.visibility || "draft"}</Badge>
    }
  }
]

export default function Categories() {
  const navigate = useNavigate()
  const admin = useAdminPanel()
  
  const storeId = createMemo(() => admin().currentStore?.id)

  const fetchCategories = async (params: {
    page: number
    pageSize: number
    sortField?: string
    sortDirection?: "asc" | "desc"
    filters: Record<string, string>
  }) => {
    if (!storeId()) return { data: [], total: 0 }
    
    const response = await categoriesApi.getAll(
      storeId()!,
      params.page,
      params.pageSize,
      {
        search: params.filters.search,
        level: params.filters.level ? parseInt(params.filters.level) : undefined,
      }
    )
    return { data: response.content ?? [], total: response.totalElements ?? 0 }
  }

  const renderRowActions = (category: Category): JSX.Element => {
    const handleDelete = async () => {
      if (confirm("Delete this category?")) {
        await admin.deleteCategory(category.id)
      }
    }
    return (
      <Flex class="gap-1">
        <CategoryQuickEdit category={category} />
        <Button variant="ghost" size="icon" class="h-8 w-8" onClick={() => navigate(`/admin/categories/${category.id}`)}>
          <EyeIcon />
        </Button>
        <Button variant="ghost" size="icon" class="h-8 w-8" onClick={handleDelete}>
          <Trash2Icon />
        </Button>
      </Flex>
    )
  }

  const renderMobileCell = (category: Category, columnId: string): JSX.Element => {
    switch (columnId) {
      case "image": {
        const imageUrl = category.image
        return <Show when={imageUrl} fallback={
          <div class="h-10 w-10 bg-muted rounded flex items-center justify-center">
            <Text class="text-muted-foreground text-xs">No img</Text>
          </div>
        }>
          <Image class="h-10 w-10 object-cover rounded">
            <ImageImg src={imageUrl!} />
            <ImageFallback />
          </Image>
        </Show>
      }
      case "name":
        return <Flex class="flex-col gap-0.5">
          <Text class="font-medium">{category.name}</Text>
          <Text class="text-xs text-muted-foreground">ID: {category.id.slice(0, 8)}</Text>
        </Flex>
      case "level":
        return <Badge variant="outline">{category.level ? LEVEL_LABELS[category.level] || category.level : "-"}</Badge>
      case "childrenCount":
        return <Text>{category.subcategories?.length ?? 0}</Text>
      case "visibility":
        return <Badge variant="outline">{category.visibility || "draft"}</Badge>
      default:
        return <></>
    }
  }

  return (
    <Flex class="flex-col gap-4 p-4">
      <Flex class="justify-between items-center">
        <Text class="text-2xl font-semibold">Categories</Text>
        <Button onClick={() => navigate("/admin/categories/new")}>
          <PlusIcon /> Add Category
        </Button>
      </Flex>

      <DataTableServer
        queryKey={["categories", storeId() as string]}
        fetchData={fetchCategories}
        columns={COLUMNS}
        filters={FILTERS}
        defaultPageSize={20}
        getRowId={(category) => category.id}
        renderRowActions={renderRowActions}
        renderCell={renderMobileCell}
      />
    </Flex>
  )
}
