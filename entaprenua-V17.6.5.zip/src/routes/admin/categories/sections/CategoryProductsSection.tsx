import { For, Show, createSignal, createEffect, onMount } from "solid-js"
import { useCategoryEditor } from "../category-editor-context"
import { productsApi } from "~/lib/api/products"
import { Card, CardHeader, CardTitle, CardContent } from "~/components/ui/card"
import { Flex } from "~/components/ui/flex"
import { Box } from "~/components/ui/box"
import { TextField, TextFieldInput, TextFieldLabel } from "~/components/ui/text-field"
import { Checkbox } from "~/components/ui/checkbox"
import { Image, ImageImg, ImageFallback } from "~/components/ui/image"
import { Spinner } from "~/components/ui/spinner"
import type { Product } from "~/lib/types"

export function CategoryProductsSection() {
  const { initialCategory, selectedProductIds, toggleProduct, storeId } = useCategoryEditor()
  
  const [products, setProducts] = createSignal<Product[]>([])
  const [loading, setLoading] = createSignal(true)
  const [search, setSearch] = createSignal("")
  
  const categoryId = () => initialCategory?.id
  
  // Load products when category ID is available
  createEffect(async () => {
    const id = categoryId()
    const sid = storeId()
    if (!id || !sid) {
      setLoading(false)
      return
    }
    
    setLoading(true)
    try {
      // Use getAll with categoryId filter - server returns isMappedToCategory flag
      const response = await productsApi.getAll(sid, 0, 100, { categoryId: id })
      const prods = response.content ?? []
      setProducts(prods)
      
      // Initialize selectedProductIds with products where isMappedToCategory = true
      const mappedIds = prods.filter(p => (p as any).isMappedToCategory).map(p => p.id)
      mappedIds.forEach(prodId => {
        if (!selectedProductIds().includes(prodId)) {
          toggleProduct(prodId)
        }
      })
    } catch (error) {
      console.error("Failed to load products:", error)
    } finally {
      setLoading(false)
    }
  })
  
  const filteredProducts = () => {
    const searchTerm = search().toLowerCase()
    if (!searchTerm) return products()
    return products().filter(p => p.name.toLowerCase().includes(searchTerm))
  }
  
  const selectedCount = () => selectedProductIds().length
  
  return (
    <Card>
      <CardHeader>
        <Flex class="justify-between items-center">
          <Box>
            <CardTitle>Products</CardTitle>
            <CardContent class="text-sm text-muted-foreground p-0 pt-1">
              Select products to include in this category
            </CardContent>
          </Box>
          <Show when={selectedCount() > 0}>
            <Box class="text-sm text-muted-foreground">
              {selectedCount()} selected
            </Box>
          </Show>
        </Flex>
      </CardHeader>
      <CardContent class="flex flex-col gap-4">
        <TextField>
          <TextFieldLabel class="sr-only">Search</TextFieldLabel>
          <TextFieldInput
            placeholder="Search products..."
            value={search()}
            onInput={(e) => setSearch(e.currentTarget.value)}
          />
        </TextField>
        
        <Show when={loading()}>
          <Flex class="justify-center py-8">
            <Spinner />
          </Flex>
        </Show>
        
        <Show when={!loading() && filteredProducts().length === 0}>
          <Flex class="flex-col items-center justify-center py-8 text-muted-foreground border-2 border-dashed rounded-lg">
            <Box class="text-sm">No products available</Box>
            <Box class="text-xs">Create products to add them here</Box>
          </Flex>
        </Show>
        
        <Show when={!loading() && filteredProducts().length > 0}>
          <Flex class="flex-col gap-2 max-h-[400px] overflow-y-auto">
            <For each={filteredProducts()}>
              {(product) => {
                const isSelected = () => selectedProductIds().includes(product.id)
                const isMapped = () => (product as any).isMappedToCategory
                return (
                  <Flex 
                    class={`items-center gap-3 p-2 rounded-lg border transition-colors ${
                      isSelected() ? "bg-muted border-input" : "bg-background hover:bg-muted/50"
                    }`}
                  >
                    <Checkbox
                      checked={isSelected()}
                      onChange={() => toggleProduct(product.id)}
                    />
                    <Show when={product.image} fallback={
                      <Box class="w-10 h-10 bg-muted rounded flex items-center justify-center">
                        <Box class="text-xs text-muted-foreground">No img</Box>
                      </Box>
                    }>
                      <Image class="w-10 h-10 object-cover rounded">
                        <ImageImg src={product.image!} />
                        <ImageFallback />
                      </Image>
                    </Show>
                    <Flex class="flex-1 flex-col">
                      <Box class="font-medium text-sm">{product.name}</Box>
                      <Box class="text-xs text-muted-foreground">
                        {product.price ? `$${product.price}` : "No price"}
                      </Box>
                    </Flex>
                    <Show when={isMapped()}>
                      <Box class="text-xs text-muted-foreground">(current)</Box>
                    </Show>
                  </Flex>
                )
              }}
            </For>
          </Flex>
        </Show>
      </CardContent>
    </Card>
  )
}
