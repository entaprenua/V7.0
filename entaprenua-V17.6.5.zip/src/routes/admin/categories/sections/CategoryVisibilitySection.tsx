import { useCategoryEditor } from "../category-editor-context"
import { Label } from "~/components/ui/label"
import { Badge } from "~/components/ui/badge"
import { Flex } from "~/components/ui/flex"
import { Box } from "~/components/ui/box"

export function CategoryVisibilitySection() {
  const { formData, updateField, mode } = useCategoryEditor()

  const getStatusVariant = () => {
    if (formData.visibility === "public") return "success"
    if (formData.visibility === "private") return "secondary"
    return "outline"
  }

  const getStatusLabel = () => {
    if (formData.visibility === "public") return "Published"
    if (formData.visibility === "private") return "Private"
    return "Draft"
  }

  return (
    <>
      <Box class="flex flex-col gap-2">
        <Label>Visibility</Label>
        <select
          class="flex h-10 w-full items-center justify-between rounded-md border border-input bg-transparent px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
          value={formData.visibility}
          onChange={(e) => updateField("visibility", e.currentTarget.value as "public" | "private" | "draft")}
        >
          <option value="draft">Draft</option>
          <option value="private">Private</option>
          <option value="public">Public</option>
        </select>
      </Box>

      <Flex class="flex-col gap-2">
        <Label>Status</Label>
        <Badge variant={getStatusVariant()}>
          {getStatusLabel()}
        </Badge>
      </Flex>
    </>
  )
}
