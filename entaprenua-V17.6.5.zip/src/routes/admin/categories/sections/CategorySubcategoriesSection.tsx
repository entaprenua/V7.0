import { For, Show, createSignal, createEffect } from "solid-js"
import { useCategoryEditor } from "../category-editor-context"
import { categoriesApi } from "~/lib/api/categories"
import { Card, CardHeader, CardTitle, CardContent } from "~/components/ui/card"
import { Flex } from "~/components/ui/flex"
import { Box } from "~/components/ui/box"
import { TextField, TextFieldInput, TextFieldLabel } from "~/components/ui/text-field"
import { Checkbox } from "~/components/ui/checkbox"
import { Image, ImageImg, ImageFallback } from "~/components/ui/image"
import { Spinner } from "~/components/ui/spinner"
import type { Category } from "~/lib/types"

export function CategorySubcategoriesSection() {
  const { initialCategory, selectedChildIds, toggleChildCategory, formData, storeId } = useCategoryEditor()
  
  const [categories, setCategories] = createSignal<Category[]>([])
  const [loading, setLoading] = createSignal(true)
  const [search, setSearch] = createSignal("")
  
  // Hide section if category level is 3 (can't have children)
  const canHaveChildren = () => (formData.level ?? 1) < 3
  const categoryId = () => initialCategory?.id
  
  // Load categories when category ID is available
  createEffect(async () => {
    const id = categoryId()
    const sid = storeId()
    if (!id || !sid || !canHaveChildren()) {
      setLoading(false)
      return
    }
    
    setLoading(true)
    try {
      const response = await categoriesApi.getAll(sid, 0, 100, { parentId: id })
      const cats = response.content ?? []
      setCategories(cats)
      
      // Initialize selectedChildIds with categories where isMappedToParent = true
      const mappedIds = cats.filter(c => c.isMappedToParent).map(c => c.id)
      mappedIds.forEach(catId => {
        if (!selectedChildIds().includes(catId)) {
          toggleChildCategory(catId)
        }
      })
    } catch (error) {
      console.error("Failed to load subcategories:", error)
    } finally {
      setLoading(false)
    }
  })
  
  const filteredCategories = () => {
    const searchTerm = search().toLowerCase()
    if (!searchTerm) return categories()
    return categories().filter(c => c.name.toLowerCase().includes(searchTerm))
  }
  
  const selectedCount = () => selectedChildIds().length
  
  return (
    <Show when={canHaveChildren()} fallback={
      <Card>
        <CardHeader>
          <CardTitle>Subcategories</CardTitle>
        </CardHeader>
        <CardContent>
          <Box class="text-sm text-muted-foreground">
            Tertiary categories cannot have subcategories
          </Box>
        </CardContent>
      </Card>
    }>
      <Card>
        <CardHeader>
          <Flex class="justify-between items-center">
            <Box>
              <CardTitle>Subcategories</CardTitle>
              <CardContent class="text-sm text-muted-foreground p-0 pt-1">
                Select child categories
              </CardContent>
            </Box>
            <Show when={selectedCount() > 0}>
              <Box class="text-sm text-muted-foreground">
                {selectedCount()} selected
              </Box>
            </Show>
          </Flex>
        </CardHeader>
        <CardContent class="flex flex-col gap-4">
          <TextField>
            <TextFieldLabel class="sr-only">Search</TextFieldLabel>
            <TextFieldInput
              placeholder="Search subcategories..."
              value={search()}
              onInput={(e) => setSearch(e.currentTarget.value)}
            />
          </TextField>
          
          <Show when={loading()}>
            <Flex class="justify-center py-8">
              <Spinner />
            </Flex>
          </Show>
          
          <Show when={!loading() && filteredCategories().length === 0}>
            <Flex class="flex-col items-center justify-center py-8 text-muted-foreground border-2 border-dashed rounded-lg">
              <Box class="text-sm">No subcategories available</Box>
              <Box class="text-xs">Create child categories to add them here</Box>
            </Flex>
          </Show>
          
          <Show when={!loading() && filteredCategories().length > 0}>
            <Flex class="flex-col gap-2 max-h-[400px] overflow-y-auto">
              <For each={filteredCategories()}>
                {(category) => {
                  const isSelected = () => selectedChildIds().includes(category.id)
                  return (
                    <Flex 
                      class={`items-center gap-3 p-2 rounded-lg border transition-colors ${
                        isSelected() ? "bg-muted border-input" : "bg-background hover:bg-muted/50"
                      }`}
                    >
                      <Checkbox
                        checked={isSelected()}
                        onChange={() => toggleChildCategory(category.id)}
                      />
                      <Show when={category.image} fallback={
                        <Box class="w-10 h-10 bg-muted rounded flex items-center justify-center">
                          <Box class="text-xs text-muted-foreground">No img</Box>
                        </Box>
                      }>
                        <Image class="w-10 h-10 object-cover rounded">
                          <ImageImg src={category.image!} />
                          <ImageFallback />
                        </Image>
                      </Show>
                      <Flex class="flex-1 flex-col">
                        <Box class="font-medium text-sm">{category.name}</Box>
                        <Box class="text-xs text-muted-foreground">
                          Level {category.level}
                        </Box>
                      </Flex>
                      <Show when={category.isMappedToParent}>
                        <Box class="text-xs text-muted-foreground">(current child)</Box>
                      </Show>
                    </Flex>
                  )
                }}
              </For>
            </Flex>
          </Show>
        </CardContent>
      </Card>
    </Show>
  )
}
