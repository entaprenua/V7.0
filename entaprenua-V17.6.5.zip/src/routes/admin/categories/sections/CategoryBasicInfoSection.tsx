import { useCategoryEditor } from "../category-editor-context"
import { TextField, TextFieldInput, TextFieldLabel, TextFieldErrorMessage } from "~/components/ui/text-field"

const LEVEL_OPTIONS = [
  { value: 1, label: "Primary" },
  { value: 2, label: "Secondary" },
  { value: 3, label: "Tertiary" },
]

export function CategoryBasicInfoSection() {
  const { formData, updateField, errors } = useCategoryEditor()

  return (
    <>
      <TextField>
        <TextFieldLabel>Category Name *</TextFieldLabel>
        <TextFieldInput
          value={formData.name}
          onInput={(e) => updateField("name", e.currentTarget.value)}
          placeholder="Enter category name"
          class={errors.name ? "border-destructive" : undefined}
        />
        {errors.name && <TextFieldErrorMessage>{errors.name}</TextFieldErrorMessage>}
      </TextField>

      <TextField>
        <TextFieldLabel>Level</TextFieldLabel>
        <select
          class="flex h-10 w-full items-center justify-between rounded-md border border-input bg-transparent px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
          value={formData.level ?? 1}
          onChange={(e) => updateField("level", parseInt(e.currentTarget.value) as 1 | 2 | 3)}
        >
          {LEVEL_OPTIONS.map((option) => (
            <option value={option.value}>{option.label}</option>
          ))}
        </select>
      </TextField>
    </>
  )
}
