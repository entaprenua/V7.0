import { Show } from "solid-js"
import { useCategoryEditor } from "../category-editor-context"
import { FileField, FileFieldTrigger, FileFieldHiddenInput } from "~/components/ui/file-field"
import { Image, ImageImg, ImageFallback } from "~/components/ui/image"
import { Button } from "~/components/ui/button"
import { Box } from "~/components/ui/box"
import { Text } from "~/components/ui/text"
import { Flex } from "~/components/ui/flex"
import { Card, CardHeader, CardTitle, CardContent } from "~/components/ui/card"
import { cn } from "~/lib/utils"
import { ImageIcon, Trash2Icon, PlusIcon } from "~/icons"

export function CategoryImageSection() {
  const { categoryImage, setCategoryImage } = useCategoryEditor()

  const previewUrl = () => {
    const img = categoryImage()
    if (!img) return null
    if (img.url.startsWith("blob:")) return img.url
    if (img.url.startsWith("http")) return img.url
    return `/api/v1/media/${img.url}`
  }

  const handleFileSelect = (event: Event | undefined) => {
    const target = event?.target as HTMLInputElement | null
    const files = target?.files
    if (!files || files.length === 0) return

    const file = files[0]
    const url = URL.createObjectURL(file)
    setCategoryImage({ url, type: "image", file, isNew: true })
  }

  const handleDelete = () => {
    const img = categoryImage()
    if (img?.isNew && img.url.startsWith("blob:")) {
      URL.revokeObjectURL(img.url)
    }
    setCategoryImage(null)
  }

  return (
    <Card>
      <CardHeader>
        <Flex class="justify-between items-center">
          <Box>
            <CardTitle>Category Image</CardTitle>
            <Text class="text-sm text-muted-foreground">
              Image for this category
            </Text>
          </Box>
          <Show when={!categoryImage()}>
            <FileField
              onChange={handleFileSelect}
              accept="image/*"
              multiple={false}
            >
              <FileFieldTrigger as={Button} size="sm">
                <PlusIcon /> Add Image
              </FileFieldTrigger>
              <FileFieldHiddenInput />
            </FileField>
          </Show>
        </Flex>
      </CardHeader>
      <CardContent>
        <Show
          when={categoryImage()}
          fallback={
            <Flex class="flex-col items-center justify-center py-12 border-2 border-dashed rounded-lg">
              <ImageIcon class="text-muted-foreground mb-2 size-8" />
              <Text class="text-muted-foreground">No category image</Text>
              <FileField
                onChange={handleFileSelect}
                accept="image/*"
                multiple={false}
              >
                <FileFieldTrigger as={Button} variant="outline" size="sm" class="mt-2">
                  Upload Image
                </FileFieldTrigger>
                <FileFieldHiddenInput />
              </FileField>
            </Flex>
          }
        >
          <Box class="relative inline-block">
            <Box
              class={cn(
                "w-[200px] h-[200px] rounded-lg overflow-hidden border",
                !categoryImage() && "border-dashed"
              )}
            >
              <Image class="size-full object-cover">
                <ImageImg src={previewUrl()!} />
                <ImageFallback>
                  <Flex class="size-full items-center justify-center bg-muted">
                    <ImageIcon class="text-muted-foreground" />
                  </Flex>
                </ImageFallback>
              </Image>
            </Box>
            <Button
              variant="destructive"
              size="icon"
              class="absolute top-2 right-2"
              onClick={handleDelete}
            >
              <Trash2Icon />
            </Button>
          </Box>
        </Show>

        <Text class="text-xs text-muted-foreground mt-4">
          Supported: JPG, PNG, GIF, WebP.
        </Text>
      </CardContent>
    </Card>
  )
}
