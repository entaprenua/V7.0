import { createContext, useContext, ParentComponent, createSignal, createEffect, Accessor, createMemo } from "solid-js"
import { createStore } from "solid-js/store"
import { categoriesApi } from "~/lib/api/categories"
import { mediaApi } from "~/lib/api/media"
import type { Category } from "~/lib/types"

export type CategoryFormData = {
  name: string
  level: number | null
  visibility: "public" | "private" | "draft"
  image: string | null
}

export type CategoryFormErrors = {
  name?: string
}

type CategoryEditorMode = "create" | "edit" | "quick-edit"

type CategoryImage = {
  url: string
  type: string
  file?: File
  isNew?: boolean
}

type CategoryEditorContextValue = {
  mode: Accessor<CategoryEditorMode>
  storeId: Accessor<string | undefined>
  isQuickEdit: Accessor<boolean>
  initialCategory: Category | null | undefined
  
  formData: CategoryFormData
  setFormData: (data: Partial<CategoryFormData>) => void
  updateField: <K extends keyof CategoryFormData>(field: K, value: CategoryFormData[K]) => void
  
  categoryImage: Accessor<CategoryImage | null>
  setCategoryImage: (image: CategoryImage | null) => void
  
  // Subcategory selections
  selectedChildIds: Accessor<string[]>
  toggleChildCategory: (id: string) => void
  
  // Product selections  
  selectedProductIds: Accessor<string[]>
  toggleProduct: (id: string) => void
  
  errors: CategoryFormErrors
  validate: () => boolean
  
  isSaving: Accessor<boolean>
  isUploading: Accessor<boolean>
  isDeleting: Accessor<boolean>
  
  save: () => Promise<Category | null>
  delete: () => Promise<boolean>
  
  reset: () => void
}

const CategoryEditorContext = createContext<CategoryEditorContextValue>()

const defaultFormData: CategoryFormData = {
  name: "",
  level: 1,
  visibility: "draft",
  image: null,
}

type CategoryEditorProviderProps = {
  storeId: string
  mode?: CategoryEditorMode
  initialCategory?: Category | null
  onSaved?: (category: Category) => void
  onDeleted?: () => void
  isQuickEdit?: boolean
}

export const CategoryEditorProvider: ParentComponent<CategoryEditorProviderProps> = (props) => {
  const resolvedMode = () => props.mode ?? "edit"
  const isQuickEdit = () => props.isQuickEdit ?? false
  
  const [formData, setFormDataStore] = createStore<CategoryFormData>({ ...defaultFormData })
  const [categoryImage, setCategoryImageState] = createSignal<CategoryImage | null>(null)
  
  // Subcategory and product selections
  const [selectedChildIds, setSelectedChildIds] = createSignal<string[]>([])
  const [selectedProductIds, setSelectedProductIds] = createSignal<string[]>([])
  
  const [isSaving, setIsSaving] = createSignal(false)
  const [isUploading, setIsUploading] = createSignal(false)
  const [isDeleting, setIsDeleting] = createSignal(false)

  const [errors, setErrors] = createStore<CategoryFormErrors>({})

  const validate = (): boolean => {
    const newErrors: CategoryFormErrors = {}
    
    if (!formData.name.trim()) {
      newErrors.name = "Category name is required"
    }
    
    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  createEffect(() => {
    if (props.initialCategory) {
      setFormDataStore({
        name: props.initialCategory.name || "",
        level: props.initialCategory.level ?? 1,
        visibility: (props.initialCategory.visibility as "public" | "private" | "draft") || "draft",
        image: props.initialCategory.image ?? null,
      })
      
      if (props.initialCategory.image) {
        setCategoryImageState({ url: props.initialCategory.image, type: "image", isNew: false })
      }
    }
  })

  const updateField = <K extends keyof CategoryFormData>(field: K, value: CategoryFormData[K]) => {
    setFormDataStore(field, value)
    
    if (field === "name" && errors.name) {
      setErrors("name", undefined)
    }
  }

  const setFormData = (data: Partial<CategoryFormData>) => {
    setFormDataStore(data)
  }

  const setCategoryImage = (image: CategoryImage | null) => {
    setCategoryImageState(image)
  }
  
  // Toggle subcategory selection
  const toggleChildCategory = (id: string) => {
    setSelectedChildIds((prev) => {
      if (prev.includes(id)) {
        return prev.filter((childId) => childId !== id)
      }
      return [...prev, id]
    })
  }
  
  // Toggle product selection
  const toggleProduct = (id: string) => {
    setSelectedProductIds((prev) => {
      if (prev.includes(id)) {
        return prev.filter((productId) => productId !== id)
      }
      return [...prev, id]
    })
  }

  const uploadCategoryImage = async (): Promise<string | null> => {
    const img = categoryImage()
    if (!img) return null
    
    if (!img.isNew) return img.url
    if (!img.file) return img.url

    setIsUploading(true)
    try {
      const response = await mediaApi.upload([img.file], props.storeId)
      if (response.urls && response.urls.length > 0) {
        const serverUrl = response.urls[0]
        setCategoryImageState({ url: serverUrl, type: img.type, isNew: false })
        return serverUrl
      }
    } catch (error) {
      console.error("Failed to upload category image:", error)
    } finally {
      setIsUploading(false)
    }
    return img.url
  }

  const save = async (): Promise<Category | null> => {
    if (!validate()) {
      return null
    }

    setIsSaving(true)
    try {
      // Upload new image if exists
      const uploadedImage = await uploadCategoryImage()

      // Compute diffs for explicit add/remove
      const originalChildIds = props.initialCategory?.subcategories?.map(c => c.id) ?? []
      const currentChildIds = selectedChildIds()
      
      const addedChildren = currentChildIds.filter(id => !originalChildIds.includes(id))
      const removedChildren = originalChildIds.filter(id => !currentChildIds.includes(id))

      const categoryData: Partial<Category> = {
        storeId: props.storeId,
        name: formData.name,
        level: formData.level,
        visibility: formData.visibility,
        image: uploadedImage || formData.image,
      }

      // Add explicit diff for subcategories and products
      if (addedChildren.length > 0) {
        (categoryData as any).addChildren = addedChildren
      }
      if (removedChildren.length > 0) {
        (categoryData as any).removeChildren = removedChildren
      }
      if (selectedProductIds().length > 0) {
        // For products, we need to determine added/removed
        // This will be handled by the products section when implemented
      }

      // Use create with id for upsert (update existing category)
      if (resolvedMode() === "edit" && props.initialCategory?.id) {
        categoryData.id = props.initialCategory.id
      }

      const result = await categoriesApi.create(props.storeId, categoryData)

      if (result) {
        props.onSaved?.(result)
      }
      return result
    } catch (error) {
      console.error("Failed to save category:", error)
      return null
    } finally {
      setIsSaving(false)
    }
  }

  const deleteCategory = async (): Promise<boolean> => {
    if (!props.initialCategory?.id) return false
    if (!confirm("Are you sure you want to delete this category? This action cannot be undone.")) {
      return false
    }

    setIsDeleting(true)
    try {
      await categoriesApi.delete(props.storeId, props.initialCategory.id)
      props.onDeleted?.()
      return true
    } catch (error) {
      console.error("Failed to delete category:", error)
      return false
    } finally {
      setIsDeleting(false)
    }
  }

  const reset = () => {
    setFormDataStore({ ...defaultFormData })
    setCategoryImageState(null)
    setErrors({})
  }

  const value: CategoryEditorContextValue = {
    mode: resolvedMode,
    storeId: () => props.storeId,
    isQuickEdit,
    initialCategory: props.initialCategory,
    formData,
    setFormData,
    updateField,
    categoryImage,
    setCategoryImage,
    selectedChildIds,
    toggleChildCategory,
    selectedProductIds,
    toggleProduct,
    errors,
    validate,
    isSaving,
    isUploading,
    isDeleting,
    save,
    delete: deleteCategory,
    reset,
  }

  return (
    <CategoryEditorContext.Provider value={value}>
      {props.children}
    </CategoryEditorContext.Provider>
  )
}

export const useCategoryEditor = () => {
  const context = useContext(CategoryEditorContext)
  if (!context) {
    throw new Error("useCategoryEditor must be used within a CategoryEditorProvider")
  }
  return context
}
