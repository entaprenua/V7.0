import { useNavigate } from "@solidjs/router"
import { useAdminPanel } from "~/lib/stores/admin-panel"
import { routes } from "~/lib/utils/routes"
import CategoryForm from "../CategoryForm"
import type { Category } from "~/lib/types"

export default function CategoryCreate() {
  const navigate = useNavigate()
  const admin = useAdminPanel()

  const handleSaved = (category: Category) => {
    navigate(routes.adminCategories)
  }

  return (
    <CategoryForm
      storeId={admin().currentStore?.id!}
      mode="create"
      onSaved={handleSaved}
    />
  )
}
