import { Show } from "solid-js"
import { useQueryClient } from "@tanstack/solid-query"
import {
  Dialog,
  DialogTrigger,
  DialogContent,
  DialogHeader,
  DialogFooter,
  DialogTitle,
  DialogDescription,
  DialogCloseButton,
} from "~/components/ui/dialog"
import { Button } from "~/components/ui/button"
import { Text } from "~/components/ui/text"
import { Label } from "~/components/ui/label"
import { Flex } from "~/components/ui/flex"
import { Box } from "~/components/ui/box"
import { Image, ImageImg, ImageFallback } from "~/components/ui/image"
import { Badge } from "~/components/ui/badge"
import { Spinner } from "~/components/ui/spinner"
import { SaveIcon, PencilIcon } from "~/icons"
import { useAdminPanel } from "~/lib/stores/admin-panel"
import { CategoryEditorProvider, useCategoryEditor } from "./category-editor-context"
import type { Category } from "~/lib/types"

type CategoryQuickEditProps = {
  category: Category
}

const LEVEL_OPTIONS = [
  { value: 1, label: "Primary" },
  { value: 2, label: "Secondary" },
  { value: 3, label: "Tertiary" },
]

function QuickEditForm() {
  const { formData, updateField, isSaving, save } = useCategoryEditor()
  const queryClient = useQueryClient()
  const admin = useAdminPanel()

  const handleSave = async () => {
    const result = await save()
    if (result) {
      if (result.id) {
        admin.updateCategory(result.id, result)
      }
      
      const storeId = admin().currentStore?.id
      if (storeId) {
        queryClient.setQueriesData(
          { queryKey: ["categories", storeId], exact: false },
          (old: any) => {
            if (!old) return old
            if (Array.isArray(old)) {
              return old.map((c: any) => c.id === result.id ? { ...c, ...result } : c)
            }
            if (old?.content) {
              return { ...old, content: old.content.map((c: any) => c.id === result.id ? { ...c, ...result } : c) }
            }
            return old
          }
        )
      }
      if (result.id) {
        queryClient.setQueryData(["category", result.id], result)
      }
    }
  }

  return (
    <>
      <DialogHeader>
        <DialogTitle>Quick Edit Category</DialogTitle>
        <DialogDescription>
          Update basic category details.
        </DialogDescription>
      </DialogHeader>

      <Flex class="flex-col gap-6 py-4">
        <Flex class="items-center gap-4">
          <Box class="shrink-0">
            <Show
              when={formData.image}
              fallback={
                <Flex class="h-20 w-20 items-center justify-center border-2 border-dashed rounded-lg">
                  <Text class="text-muted-foreground text-xs">No img</Text>
                </Flex>
              }
            >
              <Image class="h-20 w-20 object-cover rounded-lg">
                <ImageImg src={formData.image!} />
                <ImageFallback />
              </Image>
            </Show>
          </Box>
          <Box class="flex-1">
            <Text class="font-medium">{formData.name}</Text>
            <Text class="text-xs text-muted-foreground">ID: {formData.name}</Text>
            <Text class="text-xs text-muted-foreground mt-1">
              To change image, use the full editor
            </Text>
          </Box>
        </Flex>

        <div>
          <Label>Name</Label>
          <input
            class="flex h-10 w-full items-center justify-between rounded-md border border-input bg-transparent px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 mt-1"
            value={formData.name}
            onInput={(e) => updateField("name", e.currentTarget.value)}
            placeholder="Category name"
          />
        </div>

        <div>
          <Label>Level</Label>
          <select
            class="flex h-10 w-full items-center justify-between rounded-md border border-input bg-transparent px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 mt-1"
            value={formData.level ?? 1}
            onChange={(e) => updateField("level", parseInt(e.currentTarget.value) as 1 | 2 | 3)}
          >
            {LEVEL_OPTIONS.map((option) => (
              <option value={option.value}>{option.label}</option>
            ))}
          </select>
        </div>

        <div>
          <Label>Visibility</Label>
          <select
            class="flex h-10 w-full items-center justify-between rounded-md border border-input bg-transparent px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 mt-1"
            value={formData.visibility}
            onChange={(e) => updateField("visibility", e.currentTarget.value as "public" | "private" | "draft")}
          >
            <option value="draft">Draft</option>
            <option value="private">Private</option>
            <option value="public">Public</option>
          </select>
        </div>

        <Flex class="items-center gap-2">
          <Label>Status:</Label>
          <Badge variant={formData.visibility === "public" ? "success" : "secondary"}>
            {formData.visibility === "public" ? "Published" : "Draft"}
          </Badge>
        </Flex>
      </Flex>

      <DialogFooter>
        <DialogCloseButton as={Button} variant="outline">Cancel</DialogCloseButton>
        <DialogCloseButton as={Button} onClick={handleSave} disabled={isSaving()}>
          <Show when={isSaving()} fallback={<><SaveIcon /> Save Changes</>}>
            <Spinner size="sm" /> Saving...
          </Show>
        </DialogCloseButton>
      </DialogFooter>
    </>
  )
}

export function CategoryQuickEdit(props: CategoryQuickEditProps) {
  const admin = useAdminPanel()
  const storeId = () => admin().currentStore?.id

  return (
    <Show when={storeId()} fallback={null}>
      <Dialog>
        <DialogTrigger as={Button} variant="ghost" size="icon" class="h-8 w-8">
          <PencilIcon />
        </DialogTrigger>
        
        <DialogContent>
          <CategoryEditorProvider
            storeId={storeId()!}
            mode="edit"
            isQuickEdit={true}
            initialCategory={props.category}
          >
            <QuickEditForm />
          </CategoryEditorProvider>
        </DialogContent>
      </Dialog>
    </Show>
  )
}
