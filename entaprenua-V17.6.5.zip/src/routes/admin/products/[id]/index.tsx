import { useNavigate, useParams } from "@solidjs/router"
import { Query, QueryBoundary } from "~/components/ui/query"
import { productsApi } from "~/lib/api/products"
import { useAdminPanel } from "~/lib/stores/admin-panel"
import ProductForm from "../ProductForm"
import { routes } from "~/lib/utils/routes"
import type { Product } from "~/lib/types"

export default function ProductEdit() {
  const navigate = useNavigate()
  const params = useParams()
  const admin = useAdminPanel()

  const productId = () => params.id
  const storeId = () => admin().currentStore?.id

  const queryKey = () => ["product", productId()]

  const handleSaved = (product: Product) => {
    // Product saved successfully
  }

  const handleDeleted = () => {
    navigate(routes.adminProducts)
  }

  return (
    <Query queryKey={queryKey()} queryFn={() => productsApi.getById(storeId()!, productId()!, true, true)}>
      <QueryBoundary
        loadingFallback={<div>Loading...</div>}
      >
        {(product) => {
          const productData = (product as any)?.data ?? product
          return (
            <ProductForm
              storeId={storeId()!}
              mode="edit"
              initialData={{
                product: productData,
                media: productData?.media ?? [],
                metadata: productData?.metadata ?? {},
                image: productData?.image ?? null,
              }}
              onSaved={handleSaved}
              onDeleted={handleDeleted}
            />
          )
        }}
      </QueryBoundary>
    </Query>
  )
}
