import { Show } from "solid-js"
import { useQueryClient } from "@tanstack/solid-query"
import {
  Dialog,
  DialogTrigger,
  DialogContent,
  DialogHeader,
  DialogFooter,
  DialogTitle,
  DialogDescription,
  DialogCloseButton,
} from "~/components/ui/dialog"
import { Button } from "~/components/ui/button"
import { Text } from "~/components/ui/text"
import { Label } from "~/components/ui/label"
import { Flex } from "~/components/ui/flex"
import { Box } from "~/components/ui/box"
import { Image, ImageImg, ImageFallback } from "~/components/ui/image"
import { TextField, TextFieldInput, TextFieldLabel } from "~/components/ui/text-field"
import { Badge } from "~/components/ui/badge"
import { Spinner } from "~/components/ui/spinner"
import { SaveIcon, PencilIcon } from "~/icons"
import { useAdminPanel } from "~/lib/stores/admin-panel"
import { ProductEditorProvider, useProductEditor } from "./product-editor-context"
import type { Product, ProductDto } from "~/lib/types"

type ProductQuickEditProps = {
  product: Product
}

function QuickEditForm() {
  const { initialProduct, formData, updateField, nameExistsWarning, isSaving, save } = useProductEditor()
  const queryClient = useQueryClient()
  const admin = useAdminPanel()

  const handleSave = async () => {
    const result = await save()
    if (result) {
      // Update admin panel store (used by other components)
      if (initialProduct?.id) {
        admin.updateProduct(initialProduct.id, result)
      }
      
      // Update products list cache directly for immediate UI update
      const storeId = admin().currentStore?.id
      if (storeId) {
        queryClient.setQueriesData(
          { queryKey: ["products", storeId], exact: false },
          (old: any) => {
            if (!old) return old
            // Handle both direct array and paged response formats
            if (Array.isArray(old)) {
              return old.map((p: any) => p.id === result.id ? { ...p, ...result } : p)
            }
            if (old?.content) {
              return { ...old, content: old.content.map((p: any) => p.id === result.id ? { ...p, ...result } : p) }
            }
            return old
          }
        )
      }
      // Update single product cache for full editor page
      if (result.id) {
        queryClient.setQueryData(["product", result.id], result)
      }
    }
  }

  return (
    <>
      <DialogHeader>
        <DialogTitle>Quick Edit Product</DialogTitle>
        <DialogDescription>
          Update basic product details. For media and metadata, use the full editor.
        </DialogDescription>
      </DialogHeader>

      <Flex class="flex-col gap-6 py-4">
        {/* Product Image */}
        <Flex class="items-center gap-4">
          <Box class="shrink-0">
            <Show
              when={initialProduct?.image}
              fallback={
                <Flex class="h-20 w-20 items-center justify-center border-2 border-dashed rounded-lg">
                  <Text class="text-muted-foreground text-xs">No img</Text>
                </Flex>
              }
            >
              <Image class="h-20 w-20 object-cover rounded-lg">
                <ImageImg src={initialProduct!.image as string} />
                <ImageFallback />
              </Image>
            </Show>
          </Box>
          <Box class="flex-1">
            <Text class="font-medium">{formData.name}</Text>
            <Text class="text-xs text-muted-foreground">ID: {initialProduct?.id?.slice(0, 8)}</Text>
            <Text class="text-xs text-muted-foreground mt-1">
              To change image, use the full editor
            </Text>
          </Box>
        </Flex>

        {/* Name */}
        <TextField>
          <TextFieldLabel>Product Name</TextFieldLabel>
          <TextFieldInput
            value={formData.name}
            onInput={(e) => updateField("name", e.currentTarget.value)}
            placeholder="Product name"
          />
          <Show when={nameExistsWarning()}>
            <Text class="text-sm text-amber-600 mt-1">{nameExistsWarning()}</Text>
          </Show>
        </TextField>

        {/* Pricing */}
        <Flex class="flex-col sm:flex-row gap-4">
          <TextField class="flex-1">
            <TextFieldLabel>Price</TextFieldLabel>
            <TextFieldInput
              type="number"
              step="0.01"
              min="0"
              value={formData.price}
              onInput={(e) => updateField("price", e.currentTarget.value)}
              placeholder="0.00"
            />
          </TextField>

          <TextField class="flex-1">
            <TextFieldLabel>Compare at Price</TextFieldLabel>
            <TextFieldInput
              type="number"
              step="0.01"
              min="0"
              value={formData.compareToPrice}
              onInput={(e) => updateField("compareToPrice", e.currentTarget.value)}
              placeholder="0.00"
            />
          </TextField>
        </Flex>

        {/* Stock Quantity */}
        <TextField>
          <TextFieldLabel>Stock Quantity</TextFieldLabel>
          <TextFieldInput
            type="number"
            min="0"
            value={formData.stockQuantity}
            onInput={(e) => updateField("stockQuantity", parseInt(e.currentTarget.value) || 0)}
            placeholder="0"
          />
        </TextField>

        {/* Visibility */}
        <Box>
          <Label>Visibility</Label>
          <select
            class="mt-1 flex h-10 w-full items-center justify-between rounded-md border border-input bg-transparent px-3 py-2 text-sm ring-offset-background"
            value={formData.visibility}
            onChange={(e) => updateField("visibility", e.currentTarget.value as "public" | "private" | "draft")}
          >
            <option value="draft">Draft</option>
            <option value="private">Private</option>
            <option value="public">Public</option>
          </select>
        </Box>

        {/* Status */}
        <Flex class="items-center gap-2">
          <Label>Status:</Label>
          <Badge variant={formData.visibility === "public" ? "success" : "secondary"}>
            {formData.visibility === "public" ? "Published" : "Draft"}
          </Badge>
        </Flex>
      </Flex>

      <DialogFooter>
        <DialogCloseButton as={Button} variant="outline">Cancel</DialogCloseButton>
        <DialogCloseButton as={Button} onClick={handleSave} disabled={isSaving()}>
          <Show when={isSaving()} fallback={<><SaveIcon /> Save Changes</>}>
            <Spinner size="sm" /> Saving...
          </Show>
        </DialogCloseButton>
      </DialogFooter>
    </>
  )
}

export function ProductQuickEdit(props: ProductQuickEditProps) {
  const admin = useAdminPanel()
  const storeId = () => admin().currentStore?.id

  return (
    <Show when={storeId()} fallback={null}>
      <Dialog>
        <DialogTrigger as={Button} variant="ghost" size="icon" class="h-8 w-8">
          <PencilIcon />
        </DialogTrigger>
        
        <DialogContent>
          <ProductEditorProvider
            storeId={storeId()!}
            mode="edit"
            isQuickEdit={true}
            initialProduct={props.product as unknown as ProductDto}
          >
            <QuickEditForm />
          </ProductEditorProvider>
        </DialogContent>
      </Dialog>
    </Show>
  )
}
