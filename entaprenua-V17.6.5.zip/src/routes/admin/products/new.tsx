import { useNavigate } from "@solidjs/router"
import { useAdminPanel } from "~/lib/stores/admin-panel"
import { routes } from "~/lib/utils/routes"
import ProductForm from "./ProductForm"
import type { Product } from "~/lib/types"

export default function ProductCreate() {
  const navigate = useNavigate()
  const admin = useAdminPanel()

  const handleSaved = (product: Product) => {
    navigate(routes.adminProducts)
  }

  return (
    <ProductForm
      storeId={admin().currentStore?.id!}
      mode="create"
      onSaved={handleSaved}
    />
  )
}
