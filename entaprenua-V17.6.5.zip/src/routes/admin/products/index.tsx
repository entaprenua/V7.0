import { Show, createMemo, JSX, createSignal, createEffect } from "solid-js"
import { useNavigate } from "@solidjs/router"
import { ColumnDef } from "@tanstack/solid-table"
import { QueryClient, useQueryClient } from "@tanstack/solid-query"
import { DataTableServer, FilterConfig } from "~/components/ui/data-table-server"
import { productsApi, ProductFilters } from "~/lib/api/products"
import { useAdminPanel } from "~/lib/stores/admin-panel"

import { Image, ImageImg, ImageFallback } from "~/components/ui/image"
import { Button } from "~/components/ui/button"
import { Text } from "~/components/ui/text"
import { Badge } from "~/components/ui/badge"
import { Flex } from "~/components/ui/flex"
import { Input } from "~/components/ui/input"
import { Trash2Icon, PlusIcon, EyeIcon, PencilIcon } from "~/icons"
import { ProductQuickEdit } from "./product-quick-edit"
import type { Product } from "~/lib/types"
import { formatCurrency } from "~/lib/utils"
import { getProductStockStatus } from "~/lib/utils/product"

const FILTERS: FilterConfig[] = [
  {
    key: "search",
    label: "Products",
    type: "search",
    placeholder: "Search products..."
  },
  {
    key: "status",
    label: "Status",
    type: "select",
    options: [
      { value: "out_of_stock", label: "Out of Stock" },
      { value: "low_stock", label: "Low Stock" },
      { value: "not_tracked", label: "Not Tracked" }
    ],
    placeholder: "Filter by status"
  },
  {
    key: "visibility",
    label: "Visibility",
    type: "select",
    options: [
      { value: "public", label: "Public" },
      { value: "private", label: "Private" },
      { value: "draft", label: "Draft" }
    ],
    placeholder: "All Visibility"
  }
]

const COLUMNS: ColumnDef<Product>[] = [
  {
    id: "image",
    header: "Image",
    enableSorting: false,
    cell: (info) => {
      const imageUrl = info.row.original.image
      return <Show when={imageUrl} fallback={
        <div class="h-12 w-12 bg-muted rounded flex items-center justify-center">
          <Text class="text-muted-foreground text-xs">No img</Text>
        </div>
      }>
        <Image class="h-12 w-12 object-cover rounded">
          <ImageImg src={imageUrl!} />
          <ImageFallback />
        </Image>
      </Show>
    }
  },
  {
    id: "name",
    header: "Name",
    cell: (info) => {
      const product = info.row.original
      return <Flex class="flex-col gap-0.5">
        <Text class="font-medium">{product.name}</Text>
        <Text class="text-xs text-muted-foreground">ID: {product.id.slice(0, 8)}</Text>
      </Flex>
    }
  },
  {
    id: "price",
    header: "Price",
    cell: (info) => {
      const price = info.row.original.price
      return <Show when={price != null} fallback={<Text class="text-muted-foreground">-</Text>}>
        <Text class="font-medium">
          {formatCurrency(price!)}
        </Text>
      </Show>
    }
  },
  {
    id: "compareToPrice",
    header: "Compare",
    enableSorting: false,
    cell: (info) => {
      const price = info.row.original.compareToPrice
      return <Show when={price != null} fallback={<Text class="text-muted-foreground">-</Text>}>
        <Text class="text-muted-foreground">
          {formatCurrency(price!)}
        </Text>
      </Show>
    }
  },
  {
    id: "stockQuantity",
    header: "Stock",
    enableSorting: false,
    cell: (info) => {
      const product = info.row.original
      return <Show when={product.trackInventory} fallback={<Text class="text-muted-foreground">-</Text>}>
        <Text>{product.stockQuantity}</Text>
      </Show>
    }
  },
  {
    id: "status",
    header: "Status",
    enableSorting: false,
    cell: (info) => {
      const status = getProductStockStatus(info.row.original)
      return <Badge variant={status.variant}>{status.label}</Badge>
    }
  },
  {
    id: "visibility",
    header: "Visibility",
    cell: (info) => {
      return <Badge variant="outline">{info.row.original.visibility || "draft"}</Badge>
    }
  }
]

/**
 * Inline stock edit component for products table.
 * Allows quick stock quantity updates without leaving the table.
 * - Enter key saves changes
 * - Escape key reverts changes
 * - Blur (click away) also saves
 * - Optimistic updates via admin-panel store
 */
function InlineStockEdit(props: { product: Product }) {
  const [localStock, setLocalStock] = createSignal(0)
  const [isUpdating, setIsUpdating] = createSignal(false)
  const admin = useAdminPanel()
  const queryClient = useQueryClient()

  createEffect(() => {
    const stock = props.product.stockQuantity
    setLocalStock(stock)
  })

  const save = async () => {
    const newValue = localStock()
    const currentStock = props.product.stockQuantity
    if (newValue !== currentStock) {
      setIsUpdating(true)
      try {
        await admin.updateProduct(props.product.id, { 
          storeId: props.product.storeId,
          name: props.product.name,
          stockQuantity: newValue 
        })
        // Invalidate queries to refresh table with fresh server data
        await queryClient.invalidateQueries({ queryKey: ["products"] })
      } catch (err) {
        // Revert on error
        setLocalStock(currentStock)
        console.error("Failed to update stock:", err)
      } finally {
        setIsUpdating(false)
      }
    }
  }

  const handleKeyDown = (e: KeyboardEvent) => {
    if (e.key === "Enter") {
      e.preventDefault()
      save()
    } else if (e.key === "Escape") {
      e.preventDefault()
      setLocalStock(props.product.stockQuantity)
    }
  }

  return (
    <Show when={props.product.trackInventory} fallback={<Text class="text-muted-foreground">-</Text>}>
      <Input
        type="number"
        class="w-20 h-8"
        value={localStock()}
        min={0}
        disabled={isUpdating()}
        onInput={(e) => setLocalStock(parseInt(e.currentTarget.value) || 0)}
        onBlur={save}
        onKeyDown={handleKeyDown}
      />
    </Show>
  )
}

export default function Products() {
  const navigate = useNavigate()
  const admin = useAdminPanel()
  
  const storeId = createMemo(() => admin().currentStore?.id)

  const fetchProducts = async (params: {
    page: number
    pageSize: number
    sortField?: string
    sortDirection?: "asc" | "desc"
    filters: Record<string, string>
  }) => {
    if (!storeId()) return { data: [], total: 0 }
    
    // Use getAll with all filters (including search) - server handles everything
    const response = await productsApi.getAll(
      storeId()!,
      params.page,
      params.pageSize,
      {
        search: params.filters.search,
        status: params.filters.status as ProductFilters["status"],
        visibility: params.filters.visibility as ProductFilters["visibility"],
        sortBy: params.sortField as ProductFilters["sortBy"],
        sortOrder: params.sortDirection
      }
    )
    
    return { data: response.content ?? [], total: response.totalElements ?? 0 }
  }

  const renderRowActions = (product: Product): JSX.Element => {
    const handleDelete = async () => {
      if (confirm("Delete this product?")) {
        await admin.deleteProduct(product.id)
      }
    }
    return (
      <Flex class="gap-1">
        <ProductQuickEdit product={product} />
        <Button variant="ghost" size="icon" class="h-8 w-8" onClick={() => navigate(`/admin/products/${product.id}`)}>
          <EyeIcon />
        </Button>
        <Button variant="ghost" size="icon" class="h-8 w-8" onClick={handleDelete}>
          <Trash2Icon />
        </Button>
      </Flex>
    )
  }

  const renderMobileCell = (product: Product, columnId: string): JSX.Element => {
    switch (columnId) {
      case "image": {
        const imageUrl = product.image
        return <Show when={imageUrl} fallback={
          <div class="h-10 w-10 bg-muted rounded flex items-center justify-center">
            <Text class="text-muted-foreground text-xs">No img</Text>
          </div>
        }>
          <Image class="h-10 w-10 object-cover rounded">
            <ImageImg src={imageUrl!} />
            <ImageFallback />
          </Image>
        </Show>
      }
      case "name":
        return <Flex class="flex-col gap-0.5">
          <Text class="font-medium">{product.name}</Text>
          <Text class="text-xs text-muted-foreground">ID: {product.id.slice(0, 8)}</Text>
        </Flex>
      case "price":
        if (product.price == null) return <Text class="text-muted-foreground">-</Text>
        return <Text class="font-medium">
          {formatCurrency(product.price)}
        </Text>
      case "compareToPrice":
        if (product.compareToPrice == null) return <Text class="text-muted-foreground">-</Text>
        return <Text class="text-muted-foreground">
          {formatCurrency(product.compareToPrice)}
        </Text>
      case "stockQuantity":
        if (!product.trackInventory) return <Text class="text-muted-foreground">-</Text>
        return <Text>{product.stockQuantity}</Text>
      case "status": {
        const status = getProductStockStatus(product)
        return <Badge variant={status.variant}>{status.label}</Badge>
      }
      case "visibility":
        return <Badge variant="outline">{product.visibility || "draft"}</Badge>
      default:
        return <></>
    }
  }

  return (
    <Flex class="flex-col gap-4 p-4">
      <Flex class="justify-between items-center">
        <Text class="text-2xl font-semibold">Products</Text>
        <Button onClick={() => navigate("/admin/products/new")}>
          <PlusIcon /> Add Product
        </Button>
      </Flex>

      <DataTableServer
        queryKey={["products", storeId() as string]}
        fetchData={fetchProducts}
        columns={COLUMNS}
        filters={FILTERS}
        defaultPageSize={20}
        getRowId={(product) => product.id}
        renderRowActions={renderRowActions}
        renderCell={renderMobileCell}
        inlineEditColumn={{
          columnId: "stockQuantity",
          render: (product) => <InlineStockEdit product={product} />
        }}
      />
    </Flex>
  )
}
