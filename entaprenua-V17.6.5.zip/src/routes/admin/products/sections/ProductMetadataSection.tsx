import { For, createMemo } from "solid-js"
import { useProductEditor } from "../product-editor-context"
import { TextField, TextFieldInput, TextFieldLabel, TextFieldTextArea } from "~/components/ui/text-field"
import { Button } from "~/components/ui/button"
import { Box } from "~/components/ui/box"
import { Flex } from "~/components/ui/flex"
import { Card, CardHeader, CardTitle, CardContent } from "~/components/ui/card"
import { PlusIcon, Trash2Icon } from "~/icons"

const MAX_KEY_LENGTH = 100

export function ProductMetadataSection() {
  const { productMetadata, updateProductMetadata, removeProductMetadata } = useProductEditor()

  const hasMetadata = () => Object.keys(productMetadata).length > 0

  return (
    <Card>
      <CardHeader>
        <Flex class="justify-between items-center">
          <Box>
            <CardTitle>Product Metadata</CardTitle>
            <CardContent class="text-sm text-muted-foreground p-0 pt-1">
              Add custom properties for schema.org and product details
            </CardContent>
          </Box>
          <Button size="sm" variant="outline" onClick={() => {
            const id = crypto.randomUUID()
            updateProductMetadata(id, { key: "", value: "" })
          }}>
            <PlusIcon /> Add Field
          </Button>
        </Flex>
      </CardHeader>
      <CardContent>
        <Flex class="flex-col gap-3">
          <For each={Object.keys(productMetadata)}>
            {(id) => (
              <MetadataRow id={id} />
            )}
          </For>
          {!hasMetadata() && (
            <Flex class="flex-col items-center justify-center py-8 text-muted-foreground border-2 border-dashed rounded-lg">
              <Box class="text-sm mb-2">No metadata fields added</Box>
              <Box class="text-xs">Click "Add Field" to add custom properties like brand, material, or detailed descriptions</Box>
            </Flex>
          )}
        </Flex>
      </CardContent>
    </Card>
  )
}

function MetadataRow(props: { id: string }) {
  const { productMetadata, updateProductMetadata, removeProductMetadata } = useProductEditor()
  
  const data = createMemo(() => productMetadata[props.id])
  
  const keyLength = createMemo(() => data()?.key?.length ?? 0)
  const valueLength = createMemo(() => data()?.value?.length ?? 0)
  
  const isKeyTooLong = createMemo(() => keyLength() > MAX_KEY_LENGTH)
  
  return (
    <Flex class="items-start gap-2 p-3 border rounded-lg bg-background hover:bg-muted/30 transition-colors">
      <TextField class="flex-1 min-w-0">
        <Flex class="justify-between items-center mb-1">
          <TextFieldLabel class="text-xs">Key</TextFieldLabel>
          <Box class={`text-xs ${isKeyTooLong() ? "text-destructive" : "text-muted-foreground"}`}>
            {keyLength()}/{MAX_KEY_LENGTH}
          </Box>
        </Flex>
        <TextFieldInput
          value={data()?.key ?? ""}
          onInput={(e) => updateProductMetadata(props.id, { key: e.currentTarget.value.slice(0, MAX_KEY_LENGTH) })}
          placeholder="e.g., brand, material, calories"
          class={isKeyTooLong() ? "border-destructive focus-visible:ring-destructive" : ""}
        />
      </TextField>
      <TextField class="flex-[2] min-w-0">
        <Flex class="justify-between items-center mb-1">
          <TextFieldLabel class="text-xs">Value</TextFieldLabel>
          <Box class="text-xs text-muted-foreground">
            {valueLength()} characters
          </Box>
        </Flex>
        <TextFieldTextArea
          value={data()?.value ?? ""}
          onInput={(e) => updateProductMetadata(props.id, { value: e.currentTarget.value })}
          placeholder="Enter value or detailed description..."
          class="min-h-[60px] resize-y"
        />
      </TextField>
      <Button
        variant="ghost"
        size="icon"
        class="mt-6 flex-shrink-0 text-muted-foreground hover:text-destructive"
        onClick={() => removeProductMetadata(props.id)}
        title="Remove metadata field"
      >
        <Trash2Icon />
      </Button>
    </Flex>
  )
}
