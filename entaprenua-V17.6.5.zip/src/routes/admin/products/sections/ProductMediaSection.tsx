import { createMemo, For, Show, createEffect } from "solid-js"
import { createStore, produce } from "solid-js/store"
import { useProductEditor, ProductMediaEntry } from "../product-editor-context"
import { Media } from "~/components/ui/media"
import { Collection, CollectionView } from "~/components/ui/collection"
import { FileField, FileFieldTrigger, FileFieldHiddenInput } from "~/components/ui/file-field"
import { Button } from "~/components/ui/button"
import { Box } from "~/components/ui/box"
import { Text } from "~/components/ui/text"
import { Flex } from "~/components/ui/flex"
import { Card, CardHeader, CardTitle, CardContent } from "~/components/ui/card"
import { cn, createUniqueId, getFileType } from "~/lib/utils"
import { PlusIcon, Trash2Icon, ImageIcon } from "~/icons"

const MAX_FILES_DEFAULT = 15

export function ProductMediaSection() {
  const { productMedia, setProductMedia, updateProductMedia, productImage, setProductImage, isUploading } = useProductEditor()

  const mediaList = createMemo(() => {
    return Object.values(productMedia).filter(m => !m.isDeleted)
  })

  const canAddMore = createMemo(() => mediaList().length < MAX_FILES_DEFAULT)

  const handleFileSelect = (event: Event | undefined) => {
    const target = event?.target as HTMLInputElement | null
    const files = target?.files
    if (!files || !canAddMore()) return

    const fileArray = Array.from(files)
    const remaining = MAX_FILES_DEFAULT - mediaList().length
    const filesToAdd = fileArray.slice(0, remaining)

    const newMedia: Record<string, ProductMediaEntry> = {}
    filesToAdd.forEach((file) => {
      const id = createUniqueId()
      const url = URL.createObjectURL(file)
      newMedia[id] = {
        id,
        url,
        type: getFileType(file) || "image",
        isNew: true,
        isDeleted: false,
        file,
      }
    })

    setProductMedia(produce((s) => { Object.assign(s, newMedia) }))
  }

  const handleMediaDelete = (id: string) => {
    const entry = productMedia[id]
    if (!entry) return

    if (entry.isNew) {
      URL.revokeObjectURL(productMedia[id].url)
      setProductMedia(produce((s) => { delete s[id] }))
    } else {
      updateProductMedia(id, { isDeleted: true })
    }
  }

  const getMediaUrl = (url: string) => {
    if (url.startsWith("blob:")) return url
    if (url.startsWith("http")) return url
    return `/api/v1/media/${url}`
  }

  return (
    <Card>
      <CardHeader>
        <Flex class="justify-between items-center">
          <Box>
            <CardTitle>Product Media</CardTitle>
            <Text class="text-sm text-muted-foreground">
              {mediaList().length} / {MAX_FILES_DEFAULT} files
            </Text>
          </Box>
          <Show when={canAddMore()}>
            <FileField
              onChange={handleFileSelect}
              accept="image/*,video/*,audio/*"
              multiple
            >
              <FileFieldTrigger as={Button} size="sm" disabled={isUploading()}>
                <PlusIcon /> Add Media
              </FileFieldTrigger>
              <FileFieldHiddenInput />
            </FileField>
          </Show>
        </Flex>
      </CardHeader>
      <CardContent>
        <Show
          when={mediaList().length > 0}
          fallback={
            <Flex class="flex-col items-center justify-center py-12 border-2 border-dashed rounded-lg">
              <ImageIcon class="text-muted-foreground mb-2" />
              <Text class="text-muted-foreground">No media files</Text>
              <Show when={canAddMore()}>
                <FileField
                  onChange={handleFileSelect}
                  accept="image/*,video/*,audio/*"
                  multiple
                >
                  <FileFieldTrigger as={Button} variant="outline" size="sm" class="mt-2">
                    Upload Media
                  </FileFieldTrigger>
                  <FileFieldHiddenInput />
                </FileField>
              </Show>
            </Flex>
          }
        >
          <Collection
            data={mediaList()}
            layout="horizontal-grid"
            columns={4}
            gap={4}
          >
            <CollectionView class="max-h-[400px] overflow-auto">
              {(item) => (
                <MediaItem
                  item={item}
                  onDelete={() => handleMediaDelete(item.id)}
                  getMediaUrl={getMediaUrl}
                />
              )}
            </CollectionView>
          </Collection>
        </Show>

        <Text class="text-xs text-muted-foreground mt-4">
          Supported: Images (JPG, PNG, GIF, WebP), Videos (MP4, WebM), Audio (MP3, WAV). Max {MAX_FILES_DEFAULT} files.
        </Text>
      </CardContent>
    </Card>
  )
}

type MediaItemProps = {
  item: ProductMediaEntry
  onDelete: () => void
  getMediaUrl: (url: string) => string
}

function MediaItem(props: MediaItemProps) {
  const isImage = () => props.item.type === "image"
  
  return (
    <Box class="relative group">
      <Box
        class={cn(
          "aspect-square rounded-lg overflow-hidden border",
          props.item.isDeleted && "opacity-50"
        )}
      >
        <Show when={isImage()} fallback={
          <Media
            src={props.getMediaUrl(props.item.url)}
            type="video"
            class="size-full object-cover"
            controls={true}
          />
        }>
          <Media
            src={props.getMediaUrl(props.item.url)}
            type="image"
            class="size-full object-cover"
          />
        </Show>
      </Box>

      <Show when={props.item.isNew}>
        <Box class="absolute top-2 left-2">
          <Text class="text-xs bg-success text-success-foreground px-2 py-0.5 rounded">New</Text>
        </Box>
      </Show>

      <Button
        variant="destructive"
        size="icon"
        class="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity"
        onClick={props.onDelete}
      >
        <Trash2Icon />
      </Button>
    </Box>
  )
}
