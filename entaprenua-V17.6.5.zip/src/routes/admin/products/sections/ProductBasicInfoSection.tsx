import { Show } from "solid-js"
import { useProductEditor } from "../product-editor-context"
import { TextField, TextFieldInput, TextFieldLabel, TextFieldErrorMessage } from "~/components/ui/text-field"
import { Flex } from "~/components/ui/flex"
import { Text } from "~/components/ui/text"

export function ProductBasicInfoSection() {
  const { formData, updateField, nameExistsWarning, errors } = useProductEditor()

  return (
    <>
      <TextField>
        <TextFieldLabel>Product Name *</TextFieldLabel>
        <TextFieldInput
          value={formData.name}
          onInput={(e) => updateField("name", e.currentTarget.value)}
          placeholder="Enter product name"
          class={errors.name ? "border-destructive" : undefined}
        />
        <Show when={errors.name}>
          <TextFieldErrorMessage>{errors.name}</TextFieldErrorMessage>
        </Show>
        <Show when={nameExistsWarning()}>
          <Text class="text-sm text-amber-600 mt-1">{nameExistsWarning()}</Text>
        </Show>
      </TextField>

      <TextField>
        <TextFieldLabel>Description</TextFieldLabel>
        <TextFieldInput
          value={formData.description}
          onInput={(e) => updateField("description", e.currentTarget.value)}
          placeholder="Enter product description"
        />
      </TextField>

      <TextField>
        <TextFieldLabel>SKU</TextFieldLabel>
        <TextFieldInput
          value={formData.sku}
          onInput={(e) => updateField("sku", e.currentTarget.value)}
          placeholder="Enter product SKU"
        />
      </TextField>

      <Flex class="flex-col sm:flex-row gap-4">
        <TextField class="flex-1">
          <TextFieldLabel>Price</TextFieldLabel>
          <TextFieldInput
            type="number"
            step="0.01"
            min="0"
            value={formData.price}
            onInput={(e) => updateField("price", e.currentTarget.value)}
            placeholder="0.00"
            class={errors.price ? "border-destructive" : undefined}
          />
          <Show when={errors.price}>
            <TextFieldErrorMessage>{errors.price}</TextFieldErrorMessage>
          </Show>
        </TextField>

        <TextField class="flex-1">
          <TextFieldLabel>Compare at Price</TextFieldLabel>
          <TextFieldInput
            type="number"
            step="0.01"
            min="0"
            value={formData.compareToPrice}
            onInput={(e) => updateField("compareToPrice", e.currentTarget.value)}
            placeholder="0.00"
          />
        </TextField>
      </Flex>
    </>
  )
}
