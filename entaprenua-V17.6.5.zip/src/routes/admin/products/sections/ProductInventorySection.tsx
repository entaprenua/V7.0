import { Show } from "solid-js"
import { useProductEditor } from "../product-editor-context"
import { Switch } from "~/components/ui/switch"
import { TextField, TextFieldInput, TextFieldLabel } from "~/components/ui/text-field"
import { Label } from "~/components/ui/label"
import { Flex } from "~/components/ui/flex"
import { Box } from "~/components/ui/box"
import { Text } from "~/components/ui/text"

export function ProductInventorySection() {
  const { formData, updateField } = useProductEditor()

  return (
    <>
      <Flex class="items-center justify-between">
        <Box>
          <Label>Track Inventory</Label>
          <Text class="text-sm text-muted-foreground">Keep track of stock levels</Text>
        </Box>
        <Switch
          checked={formData.trackInventory}
          onChange={(checked) => updateField("trackInventory", checked)}
        />
      </Flex>

      <Show when={formData.trackInventory}>
        <TextField>
          <TextFieldLabel>Stock Quantity</TextFieldLabel>
          <TextFieldInput
            type="number"
            min="0"
            value={formData.stockQuantity}
            onInput={(e) => updateField("stockQuantity", parseInt(e.currentTarget.value) || 0)}
          />
        </TextField>

        <Flex class="flex-col sm:flex-row gap-4">
          <TextField class="flex-1">
            <TextFieldLabel>Low Stock Threshold</TextFieldLabel>
            <TextFieldInput
              type="number"
              min="0"
              value={formData.lowStockThreshold}
              onInput={(e) => updateField("lowStockThreshold", parseInt(e.currentTarget.value) || 0)}
            />
          </TextField>

          <TextField class="flex-1">
            <TextFieldLabel>Out of Stock Threshold</TextFieldLabel>
            <TextFieldInput
              type="number"
              min="0"
              value={formData.outOfStockThreshold}
              onInput={(e) => updateField("outOfStockThreshold", parseInt(e.currentTarget.value) || 0)}
            />
          </TextField>
        </Flex>
      </Show>

      <Flex class="items-center justify-between">
        <Box>
          <Label>Allow Backorder</Label>
          <Text class="text-sm text-muted-foreground">Allow orders when out of stock</Text>
        </Box>
        <Switch
          checked={formData.allowBackorder}
          onChange={(checked) => updateField("allowBackorder", checked)}
        />
      </Flex>
    </>
  )
}
