import { Show } from "solid-js"
import { useNavigate } from "@solidjs/router"
import { useQueryClient } from "@tanstack/solid-query"
import { useProductEditor, ProductEditorProvider } from "./product-editor-context"
import { useAdminPanel } from "~/lib/stores/admin-panel"
import {
  ProductBasicInfoSection,
  ProductInventorySection,
  ProductImageSection,
  ProductMediaSection,
  ProductMetadataSection,
  ProductVisibilitySection,
} from "./sections"
import { Flex } from "~/components/ui/flex"
import { Box } from "~/components/ui/box"
import { Button } from "~/components/ui/button"
import { Card, CardHeader, CardTitle, CardContent } from "~/components/ui/card"
import { SaveIcon, Trash2Icon } from "~/icons"
import { AdminHeader } from "~/components/ui/header"
import { routes } from "~/lib/utils/routes"
import type { Product, ProductDto, Media } from "~/lib/types"

export type ProductFormProps = {
  storeId: string
  mode: "create" | "edit"
  initialData?: {
    product?: ProductDto
    media?: Media[]
    metadata?: Record<string, string>
    image?: string | null
  }
  onSaved?: (product: Product) => void
  onDeleted?: () => void
}

function ProductFormContent() {
  const navigate = useNavigate()
  const queryClient = useQueryClient()
  const admin = useAdminPanel()
  const {
    mode,
    isSaving,
    isUploading,
    isDeleting,
    save,
    delete: deleteProduct,
    initialProduct,
  } = useProductEditor()

  const isLoading = () => isSaving() || isUploading()

  const handleSave = async () => {
    const result = await save()
    if (result) {
      // Update admin panel store (used by other components)
      if (initialProduct?.id) {
        admin.updateProduct(initialProduct.id, result)
      }
      
      // Update products list cache directly for immediate UI update
      const storeId = admin().currentStore?.id
      if (storeId) {
        queryClient.setQueriesData(
          { queryKey: ["products", storeId], exact: false },
          (old: any) => {
            if (!old) return old
            // Handle both direct array and paged response formats
            if (Array.isArray(old)) {
              return old.map((p: any) => p.id === result.id ? { ...p, ...result } : p)
            }
            if (old?.content) {
              return { ...old, content: old.content.map((p: any) => p.id === result.id ? { ...p, ...result } : p) }
            }
            return old
          }
        )
      }
      // Update single product cache for full editor page
      if (result.id) {
        queryClient.setQueryData(["product", result.id], result)
      }
      if (mode() === "create") {
        navigate(routes.adminProducts)
      }
    }
  }

  const handleDelete = async () => {
    const success = await deleteProduct()
    if (success) {
      navigate(routes.adminProducts)
    }
  }

  return (
    <Flex class="flex-col gap-6 p-6 max-w-4xl mx-auto">
      <AdminHeader
        title={mode() === "create" ? "Create Product" : "Edit Product"}
        description={mode() === "create" ? "Add a new product to your store" : "Update product details"}
        onBack={() => navigate(routes.adminProducts)}
        showHome
        actions={
          <Flex class="gap-2">
            <Show when={mode() === "edit"}>
              <Button variant="destructive" onClick={handleDelete} disabled={isDeleting()}>
                <Trash2Icon />
                {isDeleting() ? "Deleting..." : "Delete"}
              </Button>
            </Show>
            <Button onClick={handleSave} disabled={isLoading()}>
              <SaveIcon />
              {isLoading() 
                ? (mode() === "create" ? "Creating..." : "Saving...")
                : (mode() === "create" ? "Create Product" : "Save")
              }
            </Button>
          </Flex>
        }
      />

      <Flex class="flex-col lg:flex-row gap-6">
        <Box class="flex-1">
          {/* Basic Information */}
          <Card>
            <CardHeader>
              <CardTitle>Basic Information</CardTitle>
            </CardHeader>
            <CardContent class="flex flex-col gap-4">
              <ProductBasicInfoSection />
            </CardContent>
          </Card>

          {/* Product Image */}
          <Card class="mt-6">
            <CardContent class="p-6">
              <ProductImageSection />
            </CardContent>
          </Card>

          {/* Inventory */}
          <Card class="mt-6">
            <CardHeader>
              <CardTitle>Inventory</CardTitle>
            </CardHeader>
            <CardContent class="flex flex-col gap-4">
              <ProductInventorySection />
            </CardContent>
          </Card>

          {/* Product Media */}
          <Card class="mt-6">
            <CardContent class="p-6">
              <ProductMediaSection />
            </CardContent>
          </Card>

          {/* Metadata */}
          <Card class="mt-6">
            <CardContent class="p-6">
              <ProductMetadataSection />
            </CardContent>
          </Card>
        </Box>

        {/* Status Sidebar */}
        <Box class="w-full lg:w-80">
          <Card>
            <CardHeader>
              <CardTitle>Status</CardTitle>
            </CardHeader>
            <CardContent class="flex flex-col gap-4">
              <ProductVisibilitySection />
            </CardContent>
          </Card>
        </Box>
      </Flex>
    </Flex>
  )
}

export default function ProductForm(props: ProductFormProps) {
  const handleSaved = (product: Product) => {
    props.onSaved?.(product)
  }

  const handleDeleted = () => {
    props.onDeleted?.()
  }

  return (
    <ProductEditorProvider
      storeId={props.storeId}
      mode={props.mode}
      initialProduct={props.initialData?.product}
      initialMedia={props.initialData?.media}
      initialMetadata={props.initialData?.metadata}
      initialImage={props.initialData?.image}
      onSaved={handleSaved}
      onDeleted={handleDeleted}
    >
      <ProductFormContent />
    </ProductEditorProvider>
  )
}
