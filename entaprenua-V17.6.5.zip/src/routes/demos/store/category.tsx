import {
  CategoryList,
  CategoryListView,
  Category,
  CategoryImage,
  CategoryName,
  CategoryLevel,
  CategoryDepth,
  CategorySlug,
  CategoryTreeView,
  CategorySidebarView,
  CategoryFilterTreeView,
  CategoryMegaMenuView,
  CategoryBreadcrumbView,
} from "~/components/ui/category"
import { Flex } from "~/components/ui/flex"
import { Text } from "~/components/ui/text"
import { Paper } from "~/components/ui/paper"
import { Link } from "~/components/ui/link"
import { 
  Sidebar, 
  SidebarContent, 
  SidebarGroup, 
  SidebarGroupLabel,
  SidebarProvider 
} from "~/components/ui/sidebar"

const TEST_STORE_ID = "019c0000-0000-0000-0000-000000000010"

function GridDemo() {
  return (
    <Paper class="p-6 border rounded-xl">
      <Text variant="h3" class="font-semibold mb-4">Category Grid (Codeless)</Text>
      <Text variant="body2" class="text-muted-foreground mb-4">
        Grid layout with customizable cards.
      </Text>
      <CategoryList storeId={TEST_STORE_ID} layout="vertical-grid" columns={4} gap={6}>
        <CategoryListView>
          <Paper class="border rounded-xl overflow-hidden hover:shadow-lg transition-shadow">
            <CategoryImage class="w-full h-32 object-cover" />
            <Flex class="flex-col p-4 gap-2">
              <CategoryName class="font-semibold" />
              <Flex class="items-center gap-2">
                <Text variant="caption" class="text-muted-foreground">Level</Text>
                <CategoryLevel class="bg-muted px-2 py-0.5 rounded text-xs" />
              </Flex>
            </Flex>
          </Paper>
        </CategoryListView>
      </CategoryList>
    </Paper>
  )
}

function TreeViewDemo() {
  return (
    <Paper class="p-6 border rounded-xl">
      <Text variant="h3" class="font-semibold mb-2">Expandable Category Tree</Text>
      <Text variant="body2" class="text-muted-foreground mb-4">
        Click to expand/collapse children. Fully codeless - atomic components infer context.
      </Text>
      <CategoryTreeView storeId={TEST_STORE_ID}>
        <div class="flex items-center gap-3 p-2 rounded hover:bg-muted transition-colors">
          <CategoryImage class="size-8 rounded object-cover" />
          <CategoryName class="flex-1 font-medium" />
          <CategoryLevel class="text-xs text-muted-foreground bg-muted px-2 py-0.5 rounded" />
        </div>
      </CategoryTreeView>
    </Paper>
  )
}

function SimpleListDemo() {
  return (
    <Paper class="p-6 border rounded-xl">
      <Text variant="h3" class="font-semibold mb-4">Simple List (Codeless)</Text>
      <Text variant="body2" class="text-muted-foreground mb-4">
        Vertical list with images and names.
      </Text>
      <CategoryList storeId={TEST_STORE_ID}>
        <CategoryListView class="flex flex-col gap-2">
          <Flex class="items-center gap-4 p-3 border rounded-lg hover:bg-muted transition-colors">
            <CategoryImage class="w-12 h-12 rounded object-cover" />
            <CategoryName class="flex-1 font-medium" />
            <CategoryLevel class="text-xs text-muted-foreground" />
          </Flex>
        </CategoryListView>
      </CategoryList>
    </Paper>
  )
}

function HorizontalScrollDemo() {
  return (
    <Paper class="p-6 border rounded-xl">
      <Text variant="h3" class="font-semibold mb-4">Horizontal Scroll (Codeless)</Text>
      <Text variant="body2" class="text-muted-foreground mb-4">
        Scrollable row of categories.
      </Text>
      <CategoryList storeId={TEST_STORE_ID} layout="row" gap={4}>
        <CategoryListView class="flex gap-4 overflow-x-auto pb-2">
          <Paper class="border rounded-lg overflow-hidden hover:shadow-md transition-shadow shrink-0 w-40">
            <CategoryImage class="w-full h-24 object-cover" />
            <Flex class="p-2 justify-center">
              <CategoryName class="text-sm font-medium truncate" />
            </Flex>
          </Paper>
        </CategoryListView>
      </CategoryList>
    </Paper>
  )
}

function SidebarDemo() {
  return (
    <Paper class="p-6 border rounded-xl">
      <Text variant="h3" class="font-semibold mb-2">Category Sidebar</Text>
      <Text variant="body2" class="text-muted-foreground mb-4">
        Sidebar navigation with expand/collapse. Integrates with Sidebar system.
      </Text>
      <SidebarProvider defaultOpen>
        <Sidebar>
          <SidebarContent>
            <SidebarGroup>
              <SidebarGroupLabel>Store Navigation</SidebarGroupLabel>
              <CategorySidebarView storeId={TEST_STORE_ID} expanded>
                <div class="flex items-center gap-2 w-full">
                  <CategoryImage class="size-5 rounded" />
                  <span class="flex-1 truncate"><CategoryName /></span>
                  <CategoryLevel class="text-xs text-muted-foreground" />
                </div>
              </CategorySidebarView>
            </SidebarGroup>
          </SidebarContent>
        </Sidebar>
      </SidebarProvider>
    </Paper>
  )
}

function MegaMenuDemo() {
  return (
    <Paper class="p-6 border rounded-xl">
      <Text variant="h3" class="font-semibold mb-2">Mega Menu Navigation</Text>
      <Text variant="body2" class="text-muted-foreground mb-4">
        Hover to expand dropdown menus.
      </Text>
      <div class="border rounded-lg p-2">
        <CategoryMegaMenuView storeId={TEST_STORE_ID} orientation="horizontal">
          <div class="flex items-center gap-2">
            <CategoryImage class="size-6 rounded" />
            <span class="text-sm font-medium"><CategoryName /></span>
          </div>
        </CategoryMegaMenuView>
      </div>
    </Paper>
  )
}

function FilterDemo() {
  return (
    <Paper class="p-6 border rounded-xl">
      <Text variant="h3" class="font-semibold mb-2">Filter Tree with Checkboxes</Text>
      <Text variant="body2" class="text-muted-foreground mb-4">
        Multi-select with parent-child checkbox behavior.
      </Text>
      <CategoryFilterTreeView storeId={TEST_STORE_ID}>
        {(item, checked, onCheck) => (
          <label class="flex items-center gap-3 py-1.5 px-2 rounded hover:bg-muted cursor-pointer w-full">
            <input
              type="checkbox"
              checked={checked()}
              onChange={(e) => onCheck(item.id ?? "", e.currentTarget.checked)}
              class="rounded border-input"
            />
            <CategoryImage class="size-5 rounded" />
            <span class="text-sm flex-1"><CategoryName /></span>
          </label>
        )}
      </CategoryFilterTreeView>
    </Paper>
  )
}

export default function CategoryDemo() {
  return (
    <div class="min-h-screen bg-background">
      <header class="sticky top-0 z-50 bg-white border-b shadow-sm">
        <Flex class="max-w-7xl mx-auto px-6 py-4 items-center justify-between">
          <Link href="demos/store" class="text-2xl font-bold text-primary">
            TechStore
          </Link>
          <Flex class="items-center gap-4">
            <Link href="demos/store" class="text-sm font-medium">
              Products
            </Link>
            <Link href="demos/store/category" class="text-sm font-medium text-primary">
              Categories
            </Link>
          </Flex>
        </Flex>
      </header>

      <div class="bg-primary text-primary-foreground py-16">
        <div class="max-w-7xl mx-auto px-6">
          <Text variant="h1" class="font-bold text-white text-4xl mb-4">
            Shop by Category
          </Text>
          <Text variant="body1" class="text-white/80 text-lg max-w-2xl">
            Browse our products organized by category. Built with atomic, codeless components.
          </Text>
        </div>
      </div>

      <div class="max-w-7xl mx-auto px-6 py-12 space-y-8">
        <Text variant="h2" class="font-bold">Category Components Demo</Text>
        <Text variant="body1" class="text-muted-foreground max-w-3xl">
          This demo showcases the new atomic category components with tree view variants.
          Tree views use single API call (tree=true) with client-side rendering.
        </Text>

        <SidebarDemo />
        <MegaMenuDemo />
        <TreeViewDemo />
        <FilterDemo />
        <GridDemo />
        <SimpleListDemo />
        <HorizontalScrollDemo />
      </div>

      <div class="max-w-7xl mx-auto px-6 py-12 border-t">
        <Text variant="h3" class="font-semibold mb-4">Codeless Usage</Text>
        <Paper class="p-6 border rounded-xl">
          <pre class="text-sm text-muted-foreground overflow-x-auto">
            {`// Fully codeless - just add storeId
<CategoryTreeView storeId="..." />

// With atomic components - context inferred automatically
<CategoryTreeView storeId="...">
  <CategoryImage class="size-8 rounded" />
  <CategoryName class="font-medium" />
  <CategoryLevel />
</CategoryTreeView>

// Grid view
<CategoryList storeId="..." layout="vertical-grid" columns={4}>
  <CategoryListView />
</CategoryList>`}
          </pre>
        </Paper>
      </div>
    </div>
  )
}
