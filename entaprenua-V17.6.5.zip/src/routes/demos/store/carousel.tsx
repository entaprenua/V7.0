import { Index, createEffect, createResource, createSignal } from "solid-js"
import { heroesApi } from "~/lib/api/heroes" 
import { Card, CardContent } from "~/components/ui/card"
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious
} from "~/components/ui/carousel"
import type { Hero } from "~/lib/types"
 
export default function CarouselDemo() {
  const [items, setItems] = createSignal<Hero[]>([]) 
  const [heroes] = createResource(async() => heroesApi.getActiveByStoreId('019c0000-0000-0000-0000-000000000010'))
  createEffect(() => {
    if(heroes()) {
      setItems(heroes() as Hero[])
    }
  })
  return (
    <Carousel class="w-full max-w-xs">
      <CarouselContent>
        <Index each={items()}>
          {(item, index) => (
            <CarouselItem>
              <div class="p-1">
                <Card>
                  <CardContent class="flex aspect-square items-center justify-center p-6">
                    <span class="text-4xl font-semibold">{item().id}</span>
                  </CardContent>
                </Card>
              </div>
            </CarouselItem>
          )}
        </Index>
      </CarouselContent>
      <CarouselPrevious />
      <CarouselNext />
    </Carousel>
  )
}
