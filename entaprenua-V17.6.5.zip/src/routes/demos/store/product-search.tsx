import {
  ProductSearchProvider,
  ProductSearch,
  useProductSearch,
  ProductImage,
  ProductName,
  ProductPrice,
} from "~/components/ui/product"
import { Search, SearchControl, SearchInput, SearchPortal, SearchContent, SearchListbox, SearchNoResult } from "~/components/ui/search"
import { Flex } from "~/components/ui/flex"
import { Text } from "~/components/ui/text"
import { Paper } from "~/components/ui/paper"

const TEST_STORE_ID = "019c0000-0000-0000-0000-000000000010"

function SearchDemo() {
  const search = useProductSearch()

  return (
    <Paper class="p-6 border rounded-xl">
      <Text variant="h3" class="font-semibold mb-4">Product Search</Text>
      <Text variant="body2" class="text-muted-foreground mb-4">
        Type to search for products. Uses Kobalte Search primitives.
      </Text>

      <ProductSearch
        class="w-full max-w-md"
        itemComponent={
          <Flex class="items-center gap-3">
            <ProductImage class="size-8 rounded object-cover" />
            <Text class="font-medium text-sm"><ProductName /></Text>
            <Text class="text-xs text-muted-foreground"><ProductPrice /></Text>
          </Flex>
        }
      >
        <SearchControl>
          <SearchInput
            placeholder="Search products..."
            class="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
          />
        </SearchControl>
        <SearchContent class="z-50 w-full max-w-md mt-2 origin-top-left rounded-md border bg-popover p-4 text-popover-foreground shadow-lg">
          <SearchListbox class="max-h-80 overflow-y-auto space-y-1" />
          <SearchNoResult class="px-4 py-2 text-sm text-muted-foreground">
            No products found
          </SearchNoResult>
        </SearchContent>
      </ProductSearch>

    </Paper>
  )
}

export default function ProductSearchDemo() {
  return (
    <div class="min-h-screen bg-background p-8">
      <div class="max-w-2xl mx-auto">
        <Text variant="h1" class="font-bold text-3xl mb-8">Product Search Demo</Text>

        <ProductSearchProvider storeId={TEST_STORE_ID}>
          <SearchDemo />
        </ProductSearchProvider>
      </div>
    </div>
  )
}
