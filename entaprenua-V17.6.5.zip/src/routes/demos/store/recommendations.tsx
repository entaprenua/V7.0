import {
  RecommendationsRoot,
  RecommendationsTitle,
  RecommendationsCarousel,
  RecommendationsCarouselContent,
  RecommendationsCarouselItem,
  RecommendationsCarouselPrevious,
  RecommendationsCarouselNext,
  RecommendationsCarouselDots,
  RecommendationsGrid,
} from "~/components/ui/recommendations"
import { Product, ProductImage, ProductName, ProductPrice } from "~/components/ui/product"
import { Flex } from "~/components/ui/flex"
import { Text } from "~/components/ui/text"
import { Paper } from "~/components/ui/paper"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "~/components/ui/tabs"
import { Button } from "~/components/ui/button"

function CarouselDemo() {
  return (
    <RecommendationsRoot type="personalized" limit={10}>
      <RecommendationsCarousel autoplay loop>
        <RecommendationsCarouselContent>
          <RecommendationsCarouselItem basis="basis-1/2 md:basis-1/3 lg:basis-1/4">
            <Product>
              <ProductImage class="rounded-lg aspect-square object-cover mb-2" />
              <ProductName class="font-medium text-sm line-clamp-1" />
              <ProductPrice />
            </Product>
          </RecommendationsCarouselItem>
        </RecommendationsCarouselContent>
        <RecommendationsCarouselPrevious class="absolute left-2 top-1/2 -translate-y-1/2 z-20 bg-white/80 hover:bg-white rounded-full p-2 shadow-lg" />
        <RecommendationsCarouselNext class="absolute right-2 top-1/2 -translate-y-1/2 z-20 bg-white/80 hover:bg-white rounded-full p-2 shadow-lg" />
        <RecommendationsCarouselDots class="absolute bottom-2 left-1/2 -translate-x-1/2 z-20" />
      </RecommendationsCarousel>
    </RecommendationsRoot>
  )
}

function GridDemo() {
  return (
    <RecommendationsRoot type="newest" limit={12}>
      <RecommendationsTitle class="text-2xl font-bold mb-4" />
      <RecommendationsGrid layout="vertical-grid" columns={4} gap={4}>
        <Product>
          <ProductImage class="rounded-lg aspect-square object-cover mb-2" />
          <ProductName class="font-medium text-sm line-clamp-1" />
          <ProductPrice />
        </Product>
      </RecommendationsGrid>
    </RecommendationsRoot>
  )
}

function GridWithCustomContentDemo() {
  return (
    <RecommendationsRoot type="related" limit={8}>
      <RecommendationsTitle class="text-2xl font-bold mb-4" />
      <RecommendationsGrid layout="vertical-grid" columns={4} gap={6}>
        <Product>
          <div class="group cursor-pointer">
            <ProductImage class="rounded-lg aspect-square object-cover mb-3 group-hover:opacity-90 transition-opacity" />
            <ProductName class="font-semibold mb-1" />
            <Text variant="body2" class="text-muted-foreground line-clamp-2 mb-2">
              This is a description of the product that spans multiple lines.
            </Text>
            <ProductPrice class="text-lg font-bold text-primary" />
          </div>
        </Product>
      </RecommendationsGrid>
    </RecommendationsRoot>
  )
}

function RowDemo() {
  return (
    <RecommendationsRoot type="bought_together" limit={6}>
      <RecommendationsTitle class="text-2xl font-bold mb-4" />
      <RecommendationsGrid layout="row" gap={4}>
        <Product>
          <Flex class="gap-4 items-center">
            <ProductImage class="w-24 h-24 rounded-lg object-cover flex-shrink-0" />
            <div class="flex-1 min-w-0">
              <ProductName class="font-medium line-clamp-1" />
              <ProductPrice class="text-primary font-bold" />
            </div>
          </Flex>
        </Product>
      </RecommendationsGrid>
    </RecommendationsRoot>
  )
}

export default function RecommendationsDemo() {
  return (
    <div class="min-h-screen bg-background">
      <header class="bg-white border-b shadow-sm">
        <Flex class="max-w-7xl mx-auto px-6 py-4 items-center justify-between">
          <Text variant="h2" class="font-bold">Component Demos</Text>
          <Flex class="items-center gap-4">
            <Button variant="ghost" as="a" href="/demos/store">Products</Button>
            <Button variant="ghost" as="a" href="/demos/store/hero">Hero</Button>
            <Button variant="ghost" as="a" href="/demos/store/category">Categories</Button>
            <Button variant="ghost" as="a" href="/demos/store/cart">Cart</Button>
          </Flex>
        </Flex>
      </header>

      <div class="bg-primary text-primary-foreground py-16">
        <div class="max-w-7xl mx-auto px-6">
          <Text variant="h1" class="font-bold text-white text-4xl mb-4">
            Recommendations Component Demo
          </Text>
          <Text variant="body1" class="text-white/80 text-lg max-w-2xl">
            Showcase of all recommendations layouts and variations using zero-code components.
          </Text>
        </div>
      </div>

      <div class="max-w-7xl mx-auto px-6 py-12">
        <Tabs defaultValue="carousel" class="w-full">
          <Flex class="items-center justify-between mb-8">
            <Text variant="h2" class="font-bold">Recommendations Layouts</Text>
            <TabsList>
              <TabsTrigger value="carousel">Carousel</TabsTrigger>
              <TabsTrigger value="grid">Grid</TabsTrigger>
              <TabsTrigger value="grid-custom">Grid Custom</TabsTrigger>
              <TabsTrigger value="row">Row</TabsTrigger>
            </TabsList>
          </Flex>

          <TabsContent value="carousel">
            <Paper class="border rounded-xl overflow-hidden">
              <Text variant="h3" class="font-semibold p-4 border-b">Carousel Layout</Text>
              <div class="p-6">
                <CarouselDemo />
              </div>
            </Paper>
          </TabsContent>

          <TabsContent value="grid">
            <Paper class="border rounded-xl overflow-hidden">
              <Text variant="h3" class="font-semibold p-4 border-b">Grid Layout</Text>
              <div class="p-6">
                <GridDemo />
              </div>
            </Paper>
          </TabsContent>

          <TabsContent value="grid-custom">
            <Paper class="border rounded-xl overflow-hidden">
              <Text variant="h3" class="font-semibold p-4 border-b">Grid with Custom Content</Text>
              <div class="p-6">
                <GridWithCustomContentDemo />
              </div>
            </Paper>
          </TabsContent>

          <TabsContent value="row">
            <Paper class="border rounded-xl overflow-hidden">
              <Text variant="h3" class="font-semibold p-4 border-b">Row Layout</Text>
              <div class="p-6">
                <RowDemo />
              </div>
            </Paper>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
