import { Index, Show } from "solid-js"
import { Query, QueryBoundary } from "~/components/ui/query"
import { heroesApi } from "~/lib/api/heroes"
import { Card, CardContent } from "~/components/ui/card"
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious
} from "~/components/ui/carousel"

import type { Hero } from "~/lib/types"

function TestCarousel() {
  return (
    <Query
      queryFn={async () => heroesApi.getActiveByStoreId('019c0000-0000-0000-0000-000000000010')}
      queryKey={["test-hero"]}
    >
      <QueryBoundary loadingFallback={<div>Loading...</div>}>
        {(data) => (
        <Show when={(data as Hero[])?.[0]?.items} fallback={<div>No items</div>}>   
          {(items) => (
              <Carousel class="w-full max-w-xs">
                <CarouselContent>
                  <Index each={items()}>
                    {(item) => (
                      <CarouselItem>
                        <div class="p-1">
                          <Card>
                            <CardContent class="flex aspect-square items-center justify-center p-6">
                              <span class="text-4xl font-semibold">{item().title}</span>
                            </CardContent>
                          </Card>
                        </div>
                      </CarouselItem>
                    )}
                  </Index>
                </CarouselContent>
                <CarouselPrevious />
                <CarouselNext />
              </Carousel>
            )}
          </Show>
        )}
      </QueryBoundary>
    </Query>
  )
}
export default function QueryCarouselDemo() {
  return (
    <div class="p-8">
    <h1 class="text-2xl font-bold mb-4">Query + Carousel Test</h1>
      <TestCarousel />
    </div>
  )
}
