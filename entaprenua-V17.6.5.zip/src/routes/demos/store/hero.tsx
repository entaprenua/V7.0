import {
  HeroRoot,
  HeroCarousel,
  HeroCarouselContent,
  HeroCarouselItem,
  HeroCarouselPrevious,
  HeroCarouselNext,
  HeroCarouselDots,
  HeroItems,
  HeroItem,
  HeroBackground,
  HeroContent,
  HeroTitle,
  HeroSubtitle,
  HeroDescription,
  HeroCtaPrimary,
  HeroCtaSecondary,
  HeroSkeleton,
} from "~/components/ui/hero"
import { Flex } from "~/components/ui/flex"
import { Text } from "~/components/ui/text"
import { Paper } from "~/components/ui/paper"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "~/components/ui/tabs"
import { Button } from "~/components/ui/button"

function CarouselDemo() {
  return (
    <HeroRoot>
      <HeroCarousel autoplay>
        <HeroCarouselContent>
          <HeroCarouselItem>
            <HeroBackground />
            <HeroContent>
              <HeroSubtitle class="text-sm uppercase tracking-wider mb-2" />
              <HeroTitle class="text-4xl md:text-6xl font-bold mb-4" />
              <HeroDescription class="text-lg max-w-xl mb-6" />
              <Flex class="gap-3">
                <HeroCtaPrimary />
                <HeroCtaSecondary />
              </Flex>
            </HeroContent>
          </HeroCarouselItem>
        </HeroCarouselContent>
        <HeroCarouselPrevious class="absolute left-4 top-1/2 -translate-y-1/2 z-20 bg-white/80 hover:bg-white rounded-full p-2 shadow-lg" />
        <HeroCarouselNext class="absolute right-4 top-1/2 -translate-y-1/2 z-20 bg-white/80 hover:bg-white rounded-full p-2 shadow-lg" />
        <HeroCarouselDots class="absolute bottom-4 left-1/2 -translate-x-1/2 z-20" />
      </HeroCarousel>
    </HeroRoot>
  )
}

function CarouselWithCustomContentDemo() {
  return (
    <HeroRoot>
      <HeroCarousel autoplay>
        <HeroCarouselContent>
          <HeroCarouselItem aspectRatio="21/9" maxHeight={400}>
            <HeroContent contentPosition="center">
              <HeroTitle class="text-5xl font-bold text-white mb-4" />
              <HeroCtaPrimary />
            </HeroContent>
          </HeroCarouselItem>
        </HeroCarouselContent>
      </HeroCarousel>
    </HeroRoot>
  )
}

function GridDemo() {
  return (
    <HeroRoot>
      <HeroItems layout="vertical-grid" columns={2} gap={4}>
        <HeroItem>
          <HeroBackground />
          <HeroContent contentPosition="center">
            <HeroTitle class="text-2xl font-bold" />
            <HeroCtaPrimary />
          </HeroContent>
        </HeroItem>
      </HeroItems>
    </HeroRoot>
  )
}

function StackDemo() {
  return (
    <HeroRoot>
      <HeroItems layout="column" gap={6}>
        <HeroItem aspectRatio="21/9">
          <HeroBackground />
          <HeroContent contentPosition="center">
            <HeroTitle class="text-3xl font-bold" />
            <HeroDescription />
            <HeroCtaPrimary />
          </HeroContent>
        </HeroItem>
      </HeroItems>
    </HeroRoot>
  )
}

function AutoDetectDemo() {
  return (
    <HeroRoot>
      <HeroItem aspectRatio="16/9">
        <HeroBackground />
        <HeroContent contentPosition="center">
          <HeroSubtitle />
          <HeroTitle class="text-4xl font-bold mb-4" />
          <HeroDescription class="text-lg mb-6" />
          <Flex class="gap-3">
            <HeroCtaPrimary />
            <HeroCtaSecondary />
          </Flex>
        </HeroContent>
      </HeroItem>
    </HeroRoot>
  )
}

function LoadingDemo() {
  return (
    <div>
      <Text variant="h3" class="font-semibold mb-4">Loading State</Text>
      <HeroSkeleton class="w-full" />
    </div>
  )
}

export default function HeroDemo() {
  return (
    <div class="min-h-screen bg-background">
      <header class="bg-white border-b shadow-sm">
        <Flex class="max-w-7xl mx-auto px-6 py-4 items-center justify-between">
          <Text variant="h2" class="font-bold">Component Demos</Text>
          <Flex class="items-center gap-4">
            <Button variant="ghost" as="a" href="/demos/store">Products</Button>
            <Button variant="ghost" as="a" href="/demos/store/category">Categories</Button>
            <Button variant="ghost" as="a" href="/demos/store/cart">Cart</Button>
          </Flex>
        </Flex>
      </header>
      
      <div class="bg-primary text-primary-foreground py-16">
        <div class="max-w-7xl mx-auto px-6">
          <Text variant="h1" class="font-bold text-white text-4xl mb-4">
            Hero Component Demo
          </Text>
          <Text variant="body1" class="text-white/80 text-lg max-w-2xl">
            Showcase of all hero layouts and variations using zero-code components.
          </Text>
        </div>
      </div>

      <div class="max-w-7xl mx-auto px-6 py-12">
        <Tabs defaultValue="carousel" class="w-full">
          <Flex class="items-center justify-between mb-8">
            <Text variant="h2" class="font-bold">Hero Layouts</Text>
            <TabsList>
              <TabsTrigger value="carousel">Carousel</TabsTrigger>
              <TabsTrigger value="carousel-custom">Carousel Custom</TabsTrigger>
              <TabsTrigger value="grid">Grid</TabsTrigger>
              <TabsTrigger value="stack">Stack</TabsTrigger>
              <TabsTrigger value="loading">Loading</TabsTrigger>
            </TabsList>
          </Flex>

          <TabsContent value="carousel">
            <Paper class="border rounded-xl overflow-hidden">
              <Text variant="h3" class="font-semibold p-4 border-b">Carousel Layout</Text>
              <CarouselDemo />
            </Paper>
          </TabsContent>

          <TabsContent value="carousel-custom">
            <Paper class="border rounded-xl overflow-hidden">
              <Text variant="h3" class="font-semibold p-4 border-b">Carousel with Custom Content</Text>
              <CarouselWithCustomContentDemo />
            </Paper>
          </TabsContent>

          <TabsContent value="grid">
            <Paper class="border rounded-xl overflow-hidden">
              <Text variant="h3" class="font-semibold p-4 border-b">Grid Layout</Text>
              <GridDemo />
            </Paper>
          </TabsContent>

          <TabsContent value="stack">
            <Paper class="border rounded-xl overflow-hidden">
              <Text variant="h3" class="font-semibold p-4 border-b">Stack Layout</Text>
              <StackDemo />
            </Paper>
          </TabsContent>

          <TabsContent value="loading">
            <Paper class="border rounded-xl overflow-hidden p-6">
              <LoadingDemo />
            </Paper>
          </TabsContent>
        </Tabs>
      </div>

      <div class="max-w-7xl mx-auto px-6 py-12 border-t">
        <Text variant="h2" class="font-bold mb-8">Auto-Detect Layout</Text>
        <Paper class="border rounded-xl overflow-hidden">
          <Text variant="h3" class="font-semibold p-4 border-b">Uses Hero Config from Database</Text>
          <AutoDetectDemo />
        </Paper>
      </div>
    </div>
  )
}
