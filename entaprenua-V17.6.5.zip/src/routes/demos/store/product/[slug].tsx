import {
  Product,
  ProductImage,
  ProductName,
  ProductDescription,
  ProductPrice,
  ProductComparePrice,
  ProductStockBadge,
  ProductStockCount,
  ProductQuantityActions,
  ProductAddToCartTrigger,
  ProductBackLink,
} from "~/components/ui/product"
import { Flex } from "~/components/ui/flex"
import { Paper } from "~/components/ui/paper"
import { Text } from "~/components/ui/text"
import { Link } from "~/components/ui/link"

export default function ProductDetail() {
  return (
    <div class="min-h-screen bg-background p-8">
      <div class="max-w-7xl mx-auto">
        <Link href="/demos/store" class="text-sm text-muted-foreground hover:text-foreground mb-6 inline-block">
          ← Back to Products
        </Link>

        <Product>
          <Flex class="flex-col lg:flex-row gap-10">
            <div class="flex-1">
              <ProductImage class="w-full h-[500px] object-cover rounded-xl" />
            </div>

            <div class="flex-1">
              <Paper class="p-8 border rounded-xl">
                <ProductName class="text-3xl font-bold mb-3" />

                <Flex class="items-center gap-4 mb-6">
                  <ProductPrice class="text-4xl font-bold" />
                  <ProductComparePrice class="text-xl" />
                </Flex>

                <Flex class="items-center gap-3 mb-6">
                  <ProductStockBadge />
                  <ProductStockCount class="text-sm text-muted-foreground" />
                </Flex>

                <ProductDescription class="text-base text-muted-foreground mb-8 leading-relaxed" />

                <Flex class="items-center gap-4 mb-6">
                  <Text class="text-sm font-medium">Quantity:</Text>
                  <ProductQuantityActions />
                </Flex>

                <ProductAddToCartTrigger class="w-full text-lg py-4 font-semibold" />
              </Paper>
            </div>
          </Flex>
        </Product>
      </div>
    </div>
  )
}
