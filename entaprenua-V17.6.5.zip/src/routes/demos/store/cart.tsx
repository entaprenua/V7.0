import {
  CartProvider,
  CartItems,
  CartSummary,
  CartEmpty,
  CartCheckoutTrigger,
  CartClearTrigger,
} from "~/components/ui/cart"
import { Flex } from "~/components/ui/flex"
import { Text } from "~/components/ui/text"
import { Button } from "~/components/ui/button"
import { Link } from "~/components/ui/link"

export default function CartPage() {
  return (
    <CartProvider>
      <div class="min-h-screen bg-background">
        <header class="bg-white border-b shadow-sm">
          <Flex class="max-w-7xl mx-auto px-6 py-4 items-center justify-between">
            <Link href="/demos/store" class="text-2xl font-bold text-primary">
              TechStore
            </Link>
            <Link href="/demos/store">
              <Button variant="ghost">Continue Shopping</Button>
            </Link>
          </Flex>
        </header>

        <div class="max-w-7xl mx-auto px-6 py-12">
          <Text variant="h1" class="font-bold mb-8">Shopping Cart</Text>
          
          <Flex class="flex-col lg:flex-row gap-12">
            <div class="flex-1">
              <CartItems />
              <CartEmpty>
                <Flex class="flex-col items-center justify-center min-h-[30vh] gap-4">
                  <svg xmlns="http://www.w3.org/2000/svg" class="size-16 text-muted-foreground" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1" d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z" />
                  </svg>
                  <Text variant="h3" class="text-muted-foreground">Your cart is empty</Text>
                  <Link href="/store">
                    <Button>Continue Shopping</Button>
                  </Link>
                </Flex>
              </CartEmpty>
            </div>

            <div class="lg:w-80">
              <CartSummary>
                <div class="border rounded-xl p-6 space-y-4">
                  <Flex class="justify-between">
                    <Text>Subtotal</Text>
                    <Text class="font-medium">$0.00</Text>
                  </Flex>
                  <Flex class="justify-between">
                    <Text>Shipping</Text>
                    <Text class="text-muted-foreground">Calculated at checkout</Text>
                  </Flex>
                  <div class="border-t pt-4">
                    <Flex class="justify-between">
                      <Text class="font-bold">Total</Text>
                      <Text class="font-bold text-lg">$0.00</Text>
                    </Flex>
                  </div>
                </div>
              </CartSummary>
              <CartCheckoutTrigger class="w-full mt-4" />
              <CartClearTrigger class="w-full mt-2 text-sm" />
            </div>
          </Flex>
        </div>
      </div>
    </CartProvider>
  )
}
