import { Show, createSignal, createEffect, Suspense } from "solid-js"
import { useNavigate, useSearchParams, A } from "@solidjs/router"
import {
  CategorySidebarView,
  CategoryName,
  CategoryImage,
  useCategory,
} from "~/components/ui/category"
import {
  ProductList,
  ProductListView,
  Product,
  ProductImage,
  ProductName,
  ProductPrice,
  ProductComparePrice,
  ProductStockBadge,
  ProductAddToCartTrigger,
} from "~/components/ui/product"
import { CartProvider, CartIcon, CartSheet } from "~/components/ui/cart"
import { 
  SidebarProvider, 
  Sidebar, 
  SidebarContent, 
  SidebarGroup, 
  SidebarGroupLabel,
  SidebarHeader,
  SidebarInset,
  SidebarTrigger,
  SidebarSeparator,
} from "~/components/ui/sidebar"
import { Flex } from "~/components/ui/flex"
import { Text } from "~/components/ui/text"
import { Paper } from "~/components/ui/paper"
import { Button } from "~/components/ui/button"
import { Skeleton } from "~/components/ui/skeleton"
import { Sheet, SheetContent, SheetTrigger } from "~/components/ui/sheet"
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from "~/components/ui/dropdown-menu"
import { MenuIcon, SearchIcon, UserIcon, ChevronDownIcon } from "~/components/ui/icons"

const TEST_STORE_ID = "019c0000-0000-0000-0000-000000000010"

function StoreHeader() {
  return (
    <header class="sticky top-0 z-50 bg-white border-b shadow-sm">
      <Flex class="max-w-7xl mx-auto px-4 h-16 items-center justify-between">
        <Flex class="items-center gap-4">
          <A href="/demos/m-shop" class="text-2xl font-bold text-primary">
            M-Shop
          </A>
          <Show when={false}>
            <div class="hidden md:flex relative">
              <input 
                type="search" 
                placeholder="Search products..."
                class="w-80 pl-10 pr-4 py-2 border rounded-full text-sm focus:outline-none focus:ring-2 focus:ring-primary/20"
              />
              <SearchIcon class="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
            </div>
          </Show>
        </Flex>
        
        <Flex class="items-center gap-2">
          <CartIcon class="cursor-pointer" />
        </Flex>
      </Flex>
    </header>
  )
}

function CategoryNavItem(props: { isMobile?: boolean }) {
  const category = useCategory()
  const navigate = useNavigate()
  
  const handleClick = () => {
    const slug = category.slug()
    if (slug) {
      navigate(`/demos/m-shop?category=${encodeURIComponent(slug)}`)
    }
  }
  
  return (
    <div 
      class="flex items-center gap-2 py-2 px-3 rounded-md cursor-pointer hover:bg-accent transition-colors"
      onClick={handleClick}
    >
      <Show when={category.image()}>
        <CategoryImage class="size-5 rounded shrink-0" />
      </Show>
      <span class="flex-1 text-sm truncate">
        <CategoryName />
      </span>
    </div>
  )
}

function StoreSidebar(props: { open?: boolean; onOpenChange?: (open: boolean) => void }) {
  return (
    <Sidebar>
      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel class="text-xs uppercase tracking-wider text-muted-foreground">
            Categories
          </SidebarGroupLabel>
          <CategorySidebarView 
            storeId={TEST_STORE_ID} 
            expanded
          >
            <CategoryNavItem />
          </CategorySidebarView>
        </SidebarGroup>
        
        <SidebarSeparator class="my-4" />
        
        <SidebarGroup>
          <SidebarGroupLabel class="text-xs uppercase tracking-wider text-muted-foreground">
            Shop
          </SidebarGroupLabel>
          <div class="space-y-1 px-3">
            <A 
              href="/demos/m-shop" 
              class="flex items-center gap-2 py-2 px-3 rounded-md text-sm hover:bg-accent transition-colors"
              activeClass="bg-accent"
            >
              All Products
            </A>
            <A 
              href="/demos/m-shop?sale=true" 
              class="flex items-center gap-2 py-2 px-3 rounded-md text-sm hover:bg-accent transition-colors"
              activeClass="bg-accent"
            >
              <span>On Sale</span>
            </A>
            <A 
              href="/demos/m-shop?new=true" 
              class="flex items-center gap-2 py-2 px-3 rounded-md text-sm hover:bg-accent transition-colors"
              activeClass="bg-accent"
            >
              <span>New Arrivals</span>
            </A>
          </div>
        </SidebarGroup>
      </SidebarContent>
    </Sidebar>
  )
}

function ProductCard() {
  return (
    <Product class="block h-full">
      <Paper class="border rounded-xl overflow-hidden hover:shadow-lg transition-all duration-300 h-full flex flex-col group">
        <div class="relative">
          <ProductImage class="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300" />
          <div class="absolute top-3 right-3">
            <ProductStockBadge class="bg-white/90 backdrop-blur-sm" />
          </div>
        </div>
        <Flex class="flex-1 flex-col p-4 gap-2">
          <ProductName class="font-medium text-sm line-clamp-2 flex-1" />
          <Flex class="items-center gap-2">
            <ProductPrice class="text-lg font-bold" />
            <ProductComparePrice class="text-sm text-muted-foreground" />
          </Flex>
          <ProductAddToCartTrigger class="w-full" />
        </Flex>
      </Paper>
    </Product>
  )
}

function ProductsGrid() {
  const [searchParams] = useSearchParams()
  const categorySlug = () => searchParams.category
  
  return (
    <div class="space-y-6">
      <div class="flex items-center justify-between">
        <Show
          when={categorySlug()}
          fallback={<Text variant="h2" class="font-bold">All Products</Text>}
        >
          <div>
            <Text variant="h2" class="font-bold capitalize">{decodeURIComponent(categorySlug()!)}</Text>
            <Text variant="body2" class="text-muted-foreground">Browse our collection</Text>
          </div>
        </Show>
        <Show when={false}>
          <select class="border rounded-md px-3 py-2 text-sm">
            <option>Sort by: Featured</option>
            <option>Price: Low to High</option>
            <option>Price: High to Low</option>
            <option>Newest</option>
          </select>
        </Show>
      </div>
      
      <Show
        when={categorySlug()}
        fallback={
          <ProductList layout="vertical-grid" columns={4} gap={6}>
            <ProductListView>
              <ProductCard />
            </ProductListView>
          </ProductList>
        }
      >
        <ProductList 
          layout="vertical-grid" 
          columns={4} 
          gap={6}
          filters={{ categorySlug: categorySlug()! }}
        >
          <ProductListView>
            <ProductCard />
          </ProductListView>
        </ProductList>
      </Show>
    </div>
  )
}

function LoadingSkeleton() {
  return (
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
      <For each={[1, 2, 3, 4, 5, 6, 7, 8]}>
        {() => (
          <Paper class="border rounded-xl overflow-hidden">
            <Skeleton class="w-full h-48" />
            <div class="p-4 space-y-2">
              <Skeleton class="h-4 w-3/4" />
              <Skeleton class="h-4 w-1/2" />
              <Skeleton class="h-10 w-full" />
            </div>
          </Paper>
        )}
      </For>
    </div>
  )
}

import { For } from "solid-js"

export default function MShopStore() {
  const [sidebarOpen, setSidebarOpen] = createSignal(false)
  
  return (
    <CartProvider>
      <SidebarProvider>
        <div class="min-h-screen bg-background">
          <StoreHeader />
          
          <div class="flex">
            {/* Desktop Sidebar */}
            <div class="hidden md:block w-64 shrink-0">
              <StoreSidebar />
            </div>
            
            {/* Mobile Sidebar */}
            <div class="md:hidden">
              <Sheet open={sidebarOpen()} onOpenChange={setSidebarOpen}>
                <SheetContent side="left" class="w-72 p-0">
                  <StoreSidebar />
                </SheetContent>
              </Sheet>
            </div>
            
            {/* Main Content */}
            <main class="flex-1 p-6">
              <div class="max-w-6xl mx-auto">
                <Suspense fallback={<LoadingSkeleton />}>
                  <ProductsGrid />
                </Suspense>
              </div>
            </main>
          </div>
          
          <CartSheet />
        </div>
      </SidebarProvider>
    </CartProvider>
  )
}
