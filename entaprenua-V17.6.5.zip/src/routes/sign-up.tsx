import { createSignal, Show, type JSX } from "solid-js"
import { A, useNavigate } from "@solidjs/router"
import { Title, Meta } from "@solidjs/meta"
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
  CardFooter,
} from "~/components/ui/card"
import { Button } from "~/components/ui/button"
import { Flex, Grid, Separator, Text, Heading, Paragraph } from "~/components/ui"
import { TextField, TextFieldInput, TextFieldLabel, TextFieldErrorMessage } from "~/components/ui/text-field"
import { IdentityProviderButtons } from "~/components/ui/auth"
import { useAuth } from "~/lib/guards/auth"
import { routes } from "~/lib/utils/routes"
import {
  validateEmailFormat,
  getPasswordStrength,
  validatePasswordMatch,
  validateUsername,
  getStrengthColor,
  getStrengthLabel,
} from "~/lib/utils/validation"
import {
  ArrowLeftIcon,
  CheckIcon,
  EyeIcon,
  EyeOffIcon,
} from "~/icons"

type AuthLayoutProps = {
  children: JSX.Element
  title: string
  description: string
  showBack?: boolean
}

function AuthLayout(props: AuthLayoutProps) {
  return (
    <div class="min-h-screen flex">
      {/* Left side - Decorative */}
      <div class="hidden lg:flex lg:w-1/2 bg-gradient-to-br from-primary/20 via-primary/5 to-secondary/20 relative">
        <div class="absolute inset-0 bg-grid-pattern opacity-5" />
        <div class="relative z-10 flex flex-col justify-center items-center w-full p-12">
          <Flex flexDirection="col" class="items-center text-center max-w-md">
            <div class="size-20 rounded-full bg-primary/10 flex items-center justify-center mb-6">
              <svg class="size-10 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z" />
              </svg>
            </div>
            <Heading level={2} class="text-3xl font-bold mb-4">
              Build Your Store Without Code
            </Heading>
            <Paragraph class="text-muted-foreground">
              Create beautiful, production-ready e-commerce storefronts with our visual page builder. 
              Generate NextJS or SolidStart applications with a single click.
            </Paragraph>
            <Grid cols={2} class="gap-4 mt-8 w-full">
              <div class="flex items-center gap-2 text-sm text-muted-foreground">
                <CheckIcon class="size-4 text-green-600" />
                <span>150+ Components</span>
              </div>
              <div class="flex items-center gap-2 text-sm text-muted-foreground">
                <CheckIcon class="size-4 text-green-600" />
                <span>Multi-Framework</span>
              </div>
              <div class="flex items-center gap-2 text-sm text-muted-foreground">
                <CheckIcon class="size-4 text-green-600" />
                <span>Schema.org SEO</span>
              </div>
              <div class="flex items-center gap-2 text-sm text-muted-foreground">
                <CheckIcon class="size-4 text-green-600" />
                <span>Enterprise Security</span>
              </div>
            </Grid>
          </Flex>
        </div>
      </div>

      {/* Right side - Form */}
      <div class="flex-1 flex items-center justify-center p-6 lg:p-12 bg-background">
        <div class="w-full max-w-md">
          <Show when={props.showBack}>
            <A href={routes.home} class="inline-flex items-center text-sm text-muted-foreground hover:text-foreground mb-6">
              <ArrowLeftIcon class="size-4 mr-1" />
              Back to home
            </A>
          </Show>
          
          {props.children}
        </div>
      </div>
    </div>
  )
}

function SignUpPageContent() {
  const navigate = useNavigate()
  const { register } = useAuth()
  
  const [email, setEmail] = createSignal("")
  const [username, setUsername] = createSignal("")
  const [password, setPassword] = createSignal("")
  const [confirmPassword, setConfirmPassword] = createSignal("")
  const [acceptTerms, setAcceptTerms] = createSignal(false)
  const [isLoading, setIsLoading] = createSignal(false)
  const [error, setError] = createSignal<string | null>(null)
  const [showPassword, setShowPassword] = createSignal(false)
  const [showConfirmPassword, setShowConfirmPassword] = createSignal(false)

  const passwordStrength = () => getPasswordStrength(password())

  const emailValid = () => validateEmailFormat(email()).isValid
  const usernameValid = () => validateUsername(username()).isValid
  const passwordValid = () => passwordStrength().isValid
  const passwordsMatch = () => validatePasswordMatch(password(), confirmPassword()).isValid
  
  const isValid = () => {
    return emailValid() && usernameValid() && passwordValid() && passwordsMatch() && acceptTerms()
  }

  const getStrengthColorClass = () => {
    const s = passwordStrength().strength
    if (s === 'weak') return "text-red-500"
    if (s === 'fair') return "text-yellow-500"
    if (s === 'good') return "text-orange-500"
    return "text-green-500"
  }

  const handleSubmit = async (e: Event) => {
    e.preventDefault()
    if (!isValid()) return
    
    setIsLoading(true)
    setError(null)
    
    try {
      await register(email(), password(), username())
      navigate(routes.stores)
    } catch (err) {
      setError(err instanceof Error ? err.message : "Registration failed")
    }
    
    setIsLoading(false)
  }

  return (
    <Card class="border-0 shadow-none">
      <CardHeader class="text-center pb-6">
        <CardTitle class="text-2xl font-bold">Create your account</CardTitle>
        <CardDescription>Start building your e-commerce store today</CardDescription>
      </CardHeader>
      <form onSubmit={handleSubmit}>
        <CardContent class="space-y-4">
          <TextField>
            <TextFieldLabel>Email</TextFieldLabel>
            <TextFieldInput
              type="email"
              value={email()}
              onInput={(e) => setEmail(e.currentTarget.value)}
              placeholder="you@example.com"
            />
            <Show when={!validateEmailFormat(email()).isValid && email()}>
              <TextFieldErrorMessage>Please enter a valid email</TextFieldErrorMessage>
            </Show>
          </TextField>
          
          <TextField>
            <TextFieldLabel>Username</TextFieldLabel>
            <TextFieldInput
              value={username()}
              onInput={(e) => setUsername(e.currentTarget.value)}
              placeholder="johndoe"
            />
            <Show when={!validateUsername(username()).isValid && username()}>
              <TextFieldErrorMessage>{validateUsername(username()).error}</TextFieldErrorMessage>
            </Show>
          </TextField>
          
          <TextField>
            <TextFieldLabel>Password</TextFieldLabel>
            <div class="relative">
              <TextFieldInput
                type={showPassword() ? "text" : "password"}
                value={password()}
                onInput={(e) => setPassword(e.currentTarget.value)}
                placeholder="Create a strong password"
                class="pr-10"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword())}
                class="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
              >
                <Show when={showPassword()} fallback={<EyeIcon class="size-4" />}>
                  <EyeOffIcon class="size-4" />
                </Show>
              </button>
            </div>
            <Show when={password()}>
              <Flex class="items-center gap-2 mt-1">
                <div class="flex-1 h-1.5 rounded-full bg-muted overflow-hidden">
                  <div 
                    class="h-full transition-all"
                    style={{
                      width: `${passwordStrength().score * 20}%`,
                      "background-color": passwordStrength().strength === 'weak' ? '#ef4444' : 
                                          passwordStrength().strength === 'fair' ? '#eab308' : 
                                          passwordStrength().strength === 'good' ? '#f97316' : '#22c55e'
                    }}
                  />
                </div>
                <Text class={`text-xs ${getStrengthColorClass()}`}>
                  {getStrengthLabel(passwordStrength().strength)}
                </Text>
              </Flex>
            </Show>
          </TextField>
          
          <TextField>
            <TextFieldLabel>Confirm Password</TextFieldLabel>
            <div class="relative">
              <TextFieldInput
                type={showConfirmPassword() ? "text" : "password"}
                value={confirmPassword()}
                onInput={(e) => setConfirmPassword(e.currentTarget.value)}
                placeholder="Confirm your password"
                class="pr-10"
              />
              <button
                type="button"
                onClick={() => setShowConfirmPassword(!showConfirmPassword())}
                class="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
              >
                <Show when={showConfirmPassword()} fallback={<EyeIcon class="size-4" />}>
                  <EyeOffIcon class="size-4" />
                </Show>
              </button>
            </div>
            <Show when={!validatePasswordMatch(password(), confirmPassword()).isValid && confirmPassword()}>
              <TextFieldErrorMessage>Passwords do not match</TextFieldErrorMessage>
            </Show>
          </TextField>

          <Flex class="items-start gap-2">
            <input
              type="checkbox"
              id="acceptTerms"
              checked={acceptTerms()}
              onChange={(e) => setAcceptTerms(e.currentTarget.checked)}
              class="mt-1 size-4 rounded border-gray-300"
            />
            <label for="acceptTerms" class="text-sm text-muted-foreground">
              I agree to the{" "}
              <a href="/terms" class="text-primary hover:underline">Terms of Service</a>{" "}
              and{" "}
              <a href="/privacy" class="text-primary hover:underline">Privacy Policy</a>
            </label>
          </Flex>

          <Show when={error()}>
            <div class="p-3 rounded-lg bg-destructive/10 text-destructive text-sm">
              {error()}
            </div>
          </Show>
        </CardContent>
        <CardFooter class="flex-col gap-4 pt-4">
          <Button 
            type="submit" 
            class="w-full" 
            disabled={isLoading() || !isValid()}
          >
            {isLoading() ? "Creating account..." : "Create Account"}
          </Button>
          
          <div class="relative w-full">
            <div class="absolute inset-0 flex items-center">
              <Separator class="w-full" />
            </div>
            <div class="relative flex justify-center text-xs uppercase">
              <span class="bg-background px-2 text-muted-foreground">Or continue with</span>
            </div>
          </div>
          
          <IdentityProviderButtons />
          
          <Text class="text-sm text-center text-muted-foreground">
            Already have an account?{" "}
            <A href={routes.logIn} class="text-primary hover:underline font-medium">
              Sign in
            </A>
          </Text>
        </CardFooter>
      </form>
    </Card>
  )
}

export default function SignUpPage() {
  return (
    <>
      <Title>Sign Up - Entaprenua</Title>
      <Meta name="description" content="Create your Entaprenua account" />
      
      <AuthLayout
        title="Sign Up"
        description="Create your account"
        showBack={true}
      >
        <SignUpPageContent />
      </AuthLayout>
    </>
  )
}
