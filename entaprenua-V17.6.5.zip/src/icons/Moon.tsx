import  MoonIcon  from "lucide-solid/icons/moon"      

export default MoonIcon 

