import CutIcon  from "lucide-solid/icons/scissors"


export default CutIcon
