import  ArrowLeftIcon from "lucide-solid/icons/arrow-left"

export default ArrowLeftIcon 
