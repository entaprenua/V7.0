import ShieldUserIcon  from "lucide-solid/icons/shield-user"

export default ShieldUserIcon
