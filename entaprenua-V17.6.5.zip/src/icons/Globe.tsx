import GlobeIcon  from "lucide-solid/icons/globe"      

export default GlobeIcon 

