import EyeIcon  from "lucide-solid/icons/eye"      

export default EyeIcon 

