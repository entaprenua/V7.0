import MoreHorizIcon  from "lucide-solid/icons/ellipsis"      

export default MoreHorizIcon 

