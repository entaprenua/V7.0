import PanelRightIcon from "lucide-solid/icons/panel-right"
export default PanelRightIcon
