import ChevronRightIcon  from "lucide-solid/icons/chevron-right"      

export default ChevronRightIcon

