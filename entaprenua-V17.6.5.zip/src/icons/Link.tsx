import LinkIcon  from "lucide-solid/icons/link"      

export default LinkIcon 

