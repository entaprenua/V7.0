import Trash2Icon  from "lucide-solid/icons/trash-2"

export default Trash2Icon 
