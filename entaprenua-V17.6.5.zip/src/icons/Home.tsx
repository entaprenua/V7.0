import HomeIcon  from "lucide-solid/icons/home"

export default HomeIcon
