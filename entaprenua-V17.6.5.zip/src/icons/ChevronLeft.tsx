import ChevronLeftIcon  from "lucide-solid/icons/chevron-left"      

export default ChevronLeftIcon

