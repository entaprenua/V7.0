import ClipboardIcon  from "lucide-solid/icons/clipboard"


export default ClipboardIcon 
