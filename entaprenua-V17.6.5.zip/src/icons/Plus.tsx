import  PlusIcon  from "lucide-solid/icons/plus"

export default PlusIcon 
