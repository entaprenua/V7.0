import CopyIcon from "lucide-solid/icons/copy"

export default CopyIcon
