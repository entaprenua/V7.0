import UserIcon from "lucide-solid/icons/user"      

export default UserIcon 

