import SunIcon  from "lucide-solid/icons/sun"      

export default SunIcon 

