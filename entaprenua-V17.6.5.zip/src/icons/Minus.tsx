import   MinusIcon  from "lucide-solid/icons/minus"

export default MinusIcon 
