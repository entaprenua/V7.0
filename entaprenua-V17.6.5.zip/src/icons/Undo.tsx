import UndoIcon  from "lucide-solid/icons/undo"      

export default UndoIcon 

