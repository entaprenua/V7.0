import PaletteIcon from "lucide-solid/icons/palette"      

export default PaletteIcon 

