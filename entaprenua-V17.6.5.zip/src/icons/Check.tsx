import CheckIcon from "lucide-solid/icons/check"

export default CheckIcon 
