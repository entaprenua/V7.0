import  MailIcon  from "lucide-solid/icons/mail"      

export default MailIcon 

