import  BellIcon  from "lucide-solid/icons/bell"      

export default BellIcon 

