import PanelLeftIcon  from "lucide-solid/icons/panel-left"

export default PanelLeftIcon 
