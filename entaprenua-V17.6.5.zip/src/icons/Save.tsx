import  SaveIcon  from "lucide-solid/icons/save"      

export default SaveIcon 

