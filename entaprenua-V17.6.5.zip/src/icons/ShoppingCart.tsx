import  ShoppingCartIcon from "lucide-solid/icons/shopping-cart"      

export default ShoppingCartIcon 

