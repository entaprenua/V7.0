import ImagesIcon  from "lucide-solid/icons/images"

export default ImagesIcon

