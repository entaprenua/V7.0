import ImageIcon  from "lucide-solid/icons/image"

export default ImageIcon
