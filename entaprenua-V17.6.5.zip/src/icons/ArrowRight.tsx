import  ArrowRightIcon from "lucide-solid/icons/arrow-right"

export default ArrowRightIcon 

