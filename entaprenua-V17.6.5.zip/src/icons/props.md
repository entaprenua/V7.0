-------lucide-solid--------
Ref: https://lucide.dev/guide/packages/lucide-solid
color -> string currentcolor, 
strokeWidth: => number  defualt 24 
size => number default 2
absoluteStrokeWidth: boolean

------@tabler/icons-solidjs-------
Ref: https://tabler.io/docs/icons/libraries/solidjs
size -> number default 24
color -> string -> default currentColor
size -> number default 2
