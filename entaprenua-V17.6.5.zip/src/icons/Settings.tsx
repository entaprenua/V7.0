import  SettingsIcon from  "lucide-solid/icons/settings"      

export default SettingsIcon 

