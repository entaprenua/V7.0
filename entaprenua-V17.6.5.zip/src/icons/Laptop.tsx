import LaptopIcon from "lucide-solid/icons/laptop-minimal"

export default LaptopIcon
