import CrossIcon  from "lucide-solid/icons/x"

export default CrossIcon 
