import SearchIcon  from "lucide-solid/icons/search"

export default SearchIcon 
