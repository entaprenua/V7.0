import RotateCwIcon  from "lucide-solid/icons/rotate-cw"

export default RotateCwIcon 
