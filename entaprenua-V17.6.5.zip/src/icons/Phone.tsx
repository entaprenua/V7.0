import PhoneIcon from "lucide-solid/icons/phone"


export default PhoneIcon 
