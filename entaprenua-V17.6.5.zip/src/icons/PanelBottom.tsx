import PanelBottomIcon  from "lucide-solid/icons/panel-bottom"

export default PanelBottomIcon 
