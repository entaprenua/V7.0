import ChevronUpIcon  from "lucide-solid/icons/chevron-up"      

export default ChevronUpIcon

