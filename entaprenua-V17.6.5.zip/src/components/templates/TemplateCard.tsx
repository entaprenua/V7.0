import { For, Show } from "solid-js"
import { Card, CardContent, CardFooter } from "~/components/ui/card"
import { Button } from "~/components/ui/button"
import { Flex, Badge, Text } from "~/components/ui"
import type { Store } from "~/lib/types"
import EyeIcon from "lucide-solid/icons/eye"
import DownloadIcon from "lucide-solid/icons/download"
import ShoppingCartIcon from "lucide-solid/icons/shopping-cart"
import LayoutTemplateIcon from "lucide-solid/icons/layout-template"

interface TemplateCardProps {
  template: Store
  onUse?: (template: Store) => void
  onBuy?: (template: Store) => void
  onPreview?: (template: Store) => void
}

const DEFAULT_PREVIEW = "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=800&h=600&fit=crop"

export function TemplateCard(props: TemplateCardProps) {
  const template = () => props.template

  const isFree = () => !template()?.price || template()?.price === 0

  return (
    <Card class="group overflow-hidden hover:shadow-lg transition-all duration-300">
      <div class="aspect-[4/3] bg-gradient-to-br from-muted to-muted/50 relative overflow-hidden">
        <img
          src={template().logo || DEFAULT_PREVIEW}
          alt={`${template().name} preview`}
          class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          loading="lazy"
        />
        <div class="absolute inset-0 bg-black/0 group-hover:bg-black/40 transition-colors duration-300 flex items-center justify-center opacity-0 group-hover:opacity-100">
          <Button variant="secondary" size="sm" class="gap-2" onClick={() => props.onPreview?.(template())}>
            <EyeIcon class="size-4" />
            Preview
          </Button>
        </div>
        <Show when={isFree()}>
          <Badge class="absolute top-3 right-3 bg-green-500">Free</Badge>
        </Show>
        <Show when={!isFree()}>
          <Badge class="absolute top-3 right-3 bg-primary">
            ${template()?.price?.toFixed(2)}
          </Badge>
        </Show>
      </div>
      <CardContent class="p-4">
        <Flex class="items-start justify-between gap-2 mb-2">
          <div class="size-10 rounded-lg bg-muted flex items-center justify-center shrink-0">
            <Show when={template().logo} fallback={
              <LayoutTemplateIcon class="size-5 text-muted-foreground" />
            }>
              <img src={template().logo!} alt="" class="size-8 rounded-lg object-contain" />
            </Show>
          </div>
          <div class="flex-1 min-w-0">
            <Text variant="subtitle1" class="font-semibold truncate">{template().name}</Text>
            <Text variant="caption" class="text-muted-foreground line-clamp-2">
              {template().description || "A beautiful store template"}
            </Text>
          </div>
        </Flex>
      </CardContent>
      <CardFooter class="p-4 pt-0 flex gap-2">
        <Button variant="outline" size="sm" class="flex-1 gap-2" onClick={() => props.onPreview?.(template())}>
          <EyeIcon class="size-4" />
          Preview
        </Button>
        <Show when={isFree()}>
          <Button size="sm" class="gap-2" onClick={() => props.onUse?.(template())}>
            <DownloadIcon class="size-4" />
            Use Free
          </Button>
        </Show>
        <Show when={!isFree()}>
          <Button size="sm" class="gap-2" onClick={() => props.onBuy?.(template())}>
            <ShoppingCartIcon class="size-4" />
            Buy Now
          </Button>
        </Show>
      </CardFooter>
    </Card>
  )
}

export function TemplateCardSkeleton() {
  return (
    <Card class="overflow-hidden">
      <div class="aspect-[4/3] bg-muted animate-pulse" />
      <CardContent class="p-4">
        <Flex class="items-start gap-2 mb-2">
          <div class="size-10 rounded-lg bg-muted" />
          <div class="flex-1">
            <div class="h-4 w-3/4 bg-muted rounded mb-2" />
            <div class="h-3 w-1/2 bg-muted rounded" />
          </div>
        </Flex>
      </CardContent>
      <CardFooter class="p-4 pt-0 flex gap-2">
        <div class="h-8 flex-1 bg-muted rounded-md" />
        <div class="h-8 w-20 bg-muted rounded-md" />
      </CardFooter>
    </Card>
  )
}
