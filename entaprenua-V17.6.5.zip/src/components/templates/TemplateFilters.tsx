import { For } from "solid-js"
import { Text } from "~/components/ui"
import SearchIcon from "lucide-solid/icons/search"

interface Category {
  id: string
  label: string
}

interface TemplateFiltersProps {
  selectedCategory: string
  onSelectCategory: (id: string) => void
  searchQuery: string
  onSearchChange: (query: string) => void
  sortBy: string
  onSortChange: (sort: string) => void
  totalResults: number
  categories?: Category[]
}

const DEFAULT_CATEGORIES: Category[] = [
  { id: "all", label: "All Templates" },
  { id: "ecommerce", label: "E-Commerce" },
  { id: "fashion", label: "Fashion" },
  { id: "electronics", label: "Electronics" },
  { id: "food", label: "Food & Grocery" },
  { id: "beauty", label: "Beauty" },
  { id: "furniture", label: "Furniture" },
]

export function TemplateFilters(props: TemplateFiltersProps) {
  const categories = () => props.categories || DEFAULT_CATEGORIES

  return (
    <div class="space-y-4">
      <div class="flex flex-col sm:flex-row gap-4">
        <div class="relative flex-1">
          <SearchIcon class="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground pointer-events-none" />
          <input
            type="search"
            placeholder="Search templates..."
            value={props.searchQuery}
            onInput={(e) => props.onSearchChange(e.currentTarget.value)}
            class="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 pl-10"
            aria-label="Search templates"
          />
        </div>
        <select
          class="h-10 px-3 rounded-md border bg-background text-sm"
          value={props.sortBy}
          onChange={(e) => props.onSortChange(e.currentTarget.value)}
          aria-label="Sort templates"
        >
          <option value="newest">Newest</option>
          <option value="price-low">Price: Low to High</option>
          <option value="price-high">Price: High to Low</option>
          <option value="name">Name</option>
        </select>
      </div>
      <div class="flex flex-wrap gap-2" role="tablist" aria-label="Template categories">
        <For each={categories()}>{(category) => (
          <button
            role="tab"
            aria-selected={props.selectedCategory === category.id}
            class={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
              props.selectedCategory === category.id
                ? "bg-primary text-primary-foreground"
                : "bg-muted hover:bg-muted/80"
            }`}
            onClick={() => props.onSelectCategory(category.id)}
          >
            {category.label}
          </button>
        )}</For>
      </div>
      <Text variant="body2" class="text-muted-foreground">
        {props.totalResults} template{props.totalResults !== 1 ? "s" : ""} found
      </Text>
    </div>
  )
}

export { DEFAULT_CATEGORIES }
export type { Category, TemplateFiltersProps }
