import { createContext, useContext, type JSX, createMemo } from "solid-js"
import { createStore, produce } from "solid-js/store"
import type { User, UserRole, Permission } from "~/lib/types"

type AuthContextValue = {
  user: User | null
  token: string | null
  refreshToken: string | null
  isAuthenticated: boolean
  isLoading: boolean
  error: string | null
  permissions: string[]
  setUser: (user: User | null) => void
  setToken: (token: string | null) => void
  setRefreshToken: (refreshToken: string | null) => void
  setIsLoading: (isLoading: boolean) => void
  setError: (error: string | null) => void
  setPermissions: (permissions: string[]) => void
  hasRole: (role: UserRole | UserRole[]) => boolean
  hasPermission: (permission: string | string[]) => boolean
  clear: () => void
}

const AuthUIContext = createContext<AuthContextValue | undefined>()

export const useAuthUI = (): AuthContextValue | undefined => 
  useContext(AuthUIContext)

type AuthUIProviderProps = {
  initialUser?: User | null
  initialToken?: string | null
  initialPermissions?: string[]
  children?: JSX.Element
}

export const AuthUIProvider = (props: AuthUIProviderProps) => {
  const [state, setState] = createStore<{
    user: User | null
    token: string | null
    refreshToken: string | null
    isLoading: boolean
    error: string | null
    permissions: string[]
  }>({
    user: props.initialUser ?? null,
    token: props.initialToken ?? null,
    refreshToken: null,
    isLoading: false,
    error: null,
    permissions: props.initialPermissions ?? [],
  })

  const isAuthenticated = createMemo(() => !!state.token && !!state.user)

  const hasRole = (role: UserRole | UserRole[]): boolean => {
    if (!state.user) return false
    const roles = Array.isArray(role) ? role : [role]
    return state.user.role ? roles.includes(state.user.role as UserRole) : false
  }

  const hasPermission = (permission: string | string[]): boolean => {
    if (!state.user) return false
    const perms = Array.isArray(permission) ? permission : [permission]
    return perms.some(p => state.permissions.includes(p))
  }

  const value: AuthContextValue = {
    get user() { return state.user },
    get token() { return state.token },
    get refreshToken() { return state.refreshToken },
    get isAuthenticated() { return isAuthenticated() },
    get isLoading() { return state.isLoading },
    get error() { return state.error },
    get permissions() { return state.permissions },
    setUser: (user) => setState("user", user),
    setToken: (token) => setState("token", token),
    setRefreshToken: (refreshToken) => setState("refreshToken", refreshToken),
    setIsLoading: (isLoading) => setState("isLoading", isLoading),
    setError: (error) => setState("error", error),
    setPermissions: (permissions) => setState("permissions", permissions),
    hasRole,
    hasPermission,
    clear: () => setState({
      user: null,
      token: null,
      refreshToken: null,
      isLoading: false,
      error: null,
      permissions: [],
    }),
  }

  return (
    <AuthUIContext.Provider value={value}>
      {props.children}
    </AuthUIContext.Provider>
  )
}

export type PasswordResetStateValue = {
  email: string
  token: string | null
  status: 'idle' | 'requesting' | 'token_sent' | 'resetting' | 'success' | 'error'
  error: string | null
}

type PasswordResetContextValue = {
  state: PasswordResetStateValue
  setEmail: (email: string) => void
  setToken: (token: string | null) => void
  setStatus: (status: PasswordResetStateValue['status']) => void
  setError: (error: string | null) => void
  reset: () => void
}

const PasswordResetContext = createContext<PasswordResetContextValue | undefined>()

export const usePasswordReset = (): PasswordResetContextValue | undefined =>
  useContext(PasswordResetContext)

type PasswordResetProviderProps = {
  children?: JSX.Element
}

export const PasswordResetProvider = (props: PasswordResetProviderProps) => {
  const [state, setState] = createStore<PasswordResetStateValue>({
    email: '',
    token: null,
    status: 'idle',
    error: null,
  })

  const value: PasswordResetContextValue = {
    get state() { return state },
    setEmail: (email) => setState("email", email),
    setToken: (token) => setState("token", token),
    setStatus: (status) => setState("status", status),
    setError: (error) => setState("error", error),
    reset: () => setState({
      email: '',
      token: null,
      status: 'idle',
      error: null,
    }),
  }

  return (
    <PasswordResetContext.Provider value={value}>
      {props.children}
    </PasswordResetContext.Provider>
  )
}

export type EmailVerificationStateValue = {
  token: string | null
  status: 'idle' | 'verifying' | 'success' | 'error'
  error: string | null
}

type EmailVerificationContextValue = {
  state: EmailVerificationStateValue
  setToken: (token: string | null) => void
  setStatus: (status: EmailVerificationStateValue['status']) => void
  setError: (error: string | null) => void
  reset: () => void
}

const EmailVerificationContext = createContext<EmailVerificationContextValue | undefined>()

export const useEmailVerification = (): EmailVerificationContextValue | undefined =>
  useContext(EmailVerificationContext)

type EmailVerificationProviderProps = {
  children?: JSX.Element
}

export const EmailVerificationProvider = (props: EmailVerificationProviderProps) => {
  const [state, setState] = createStore<EmailVerificationStateValue>({
    token: null,
    status: 'idle',
    error: null,
  })

  const value: EmailVerificationContextValue = {
    get state() { return state },
    setToken: (token) => setState("token", token),
    setStatus: (status) => setState("status", status),
    setError: (error) => setState("error", error),
    reset: () => setState({
      token: null,
      status: 'idle',
      error: null,
    }),
  }

  return (
    <EmailVerificationContext.Provider value={value}>
      {props.children}
    </EmailVerificationContext.Provider>
  )
}

export type SessionStateValue = {
  sessions: any[]
  isLoading: boolean
  error: string | null
}

type SessionContextValue = {
  state: SessionStateValue
  setSessions: (sessions: any[]) => void
  removeSession: (sessionId: string) => void
  setIsLoading: (isLoading: boolean) => void
  setError: (error: string | null) => void
  reset: () => void
}

const SessionContext = createContext<SessionContextValue | undefined>()

export const useSession = (): SessionContextValue | undefined =>
  useContext(SessionContext)

type SessionProviderProps = {
  children?: JSX.Element
}

export const SessionProvider = (props: SessionProviderProps) => {
  const [state, setState] = createStore<SessionStateValue>({
    sessions: [],
    isLoading: false,
    error: null,
  })

  const value: SessionContextValue = {
    get state() { return state },
    setSessions: (sessions) => setState("sessions", sessions),
    removeSession: (sessionId) => {
      setState(produce((s) => {
        s.sessions = s.sessions.filter(sess => sess.id !== sessionId)
      }))
    },
    setIsLoading: (isLoading) => setState("isLoading", isLoading),
    setError: (error) => setState("error", error),
    reset: () => setState({
      sessions: [],
      isLoading: false,
      error: null,
    }),
  }

  return (
    <SessionContext.Provider value={value}>
      {props.children}
    </SessionContext.Provider>
  )
}
