import {
  Show, splitProps, Switch, Match, createContext, useContext,
  type JSX, createMemo, For, createSignal, createEffect, on,
} from "solid-js"
import { PaymentProvider, usePayment, CheckoutProvider, useCheckout, RefundProvider, useRefund } from "./payment-context"
import { Query, QueryBoundary, useQueryState } from "./query"
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from "./card"
import { Button } from "./button"
import { Flex } from "./flex"
import { Grid } from "./grid"
import { Badge } from "./badge"
import { Text } from "./text"
import { TextField, TextFieldInput, TextFieldLabel, TextFieldErrorMessage } from "./text-field"
import { Progress } from "./progress"
import { Skeleton } from "./skeleton"
import { Separator } from "./separator"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogTrigger } from "./dialog"
import { cn } from "~/lib/utils"
import { paymentsApi, paymentMethodsApi, refundsApi } from "~/lib/api/payments"
import { useAuth } from "~/lib/guards/auth"
import type { 
  Payment, PaymentMethod, PaymentStatus, RefundReason, 
  CreatePaymentRequest, RefundPaymentRequest 
} from "~/lib/types"

const STATUS_COLORS: Record<PaymentStatus, string> = {
  PENDING: "bg-yellow-100 text-yellow-800",
  PROCESSING: "bg-blue-100 text-blue-800",
  SUCCEEDED: "bg-green-100 text-green-800",
  FAILED: "bg-red-100 text-red-800",
  CANCELLED: "bg-gray-100 text-gray-800",
  REFUNDED: "bg-purple-100 text-purple-800",
  PARTIALLY_REFUNDED: "bg-orange-100 text-orange-800",
}

const STATUS_LABELS: Record<PaymentStatus, string> = {
  PENDING: "Pending",
  PROCESSING: "Processing",
  SUCCEEDED: "Completed",
  FAILED: "Failed",
  CANCELLED: "Cancelled",
  REFUNDED: "Refunded",
  PARTIALLY_REFUNDED: "Partially Refunded",
}

const CARD_BRAND_ICONS: Record<string, string> = {
  visa: "VISA",
  mastercard: "MC",
  amex: "AMEX",
  discover: "DISC",
}

type PaymentRootProps = {
  paymentId?: string
  orderId?: string
  data?: Payment
  queryFn?: () => Promise<any>
  queryKey?: unknown[]
  errorFallback?: JSX.Element
  loadingFallback?: JSX.Element
  class?: string
  children?: JSX.Element
}

const PaymentRoot = (props: PaymentRootProps) => {
  const [local, others] = splitProps(props, [
    "paymentId", "orderId", "data", "queryFn", "queryKey",
    "errorFallback", "loadingFallback", "class", "children"
  ])

  if (local.data) {
    return (
      <PaymentProvider initialPayment={local.data}>
        <div class={local.class} {...others}>
          {local.children}
        </div>
      </PaymentProvider>
    )
  }

  const queryFn = local.queryFn ?? (local.paymentId 
    ? async () => {
        const auth = useAuth()
        const result = await paymentsApi.getById(local.paymentId!, auth.token()!)
        return result.data
      }
    : undefined
  )

  return (
    <Query queryFn={queryFn!} queryKey={local.queryKey ?? ["payment", local.paymentId]}>
      <QueryBoundary
        loadingFallback={local.loadingFallback ?? <PaymentSkeleton />}
        errorFallback={local.errorFallback}
      >
        <PaymentRootContent class={local.class} {...others}>
          {local.children}
        </PaymentRootContent>
      </QueryBoundary>
    </Query>
  )
}

const PaymentRootContent = (props: any) => {
  const query = useQueryState()
  return (
    <PaymentProvider initialPayment={query?.data as Payment}>
      <div class={props.class} {...props}>
        {props.children}
      </div>
    </PaymentProvider>
  )
}

type PaymentFieldProps = {
  class?: string
  label?: string
}

const PaymentId = (props: PaymentFieldProps) => {
  const payment = usePayment()
  return (
    <Show when={payment?.payment?.id}>
      <Text class={props.class}>{props.label ?? payment!.payment!.id}</Text>
    </Show>
  )
}

const PaymentAmount = (props: PaymentFieldProps) => {
  const payment = usePayment()
  const formatted = createMemo(() => {
    const amount = payment?.payment?.amount ?? 0
    const currency = payment?.payment?.currency ?? 'USD'
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency,
    }).format(amount)
  })
  return (
    <Show when={payment?.payment}>
      <Text class={props.class}>{props.label ?? formatted()}</Text>
    </Show>
  )
}

const PaymentStatusBadge = (props: PaymentFieldProps) => {
  const payment = usePayment()
  const status = () => payment?.payment?.status as PaymentStatus | undefined

  return (
    <Show when={status()}>
      <Badge
        class={cn(STATUS_COLORS[status()!], props.class)}
        round
      >
        {props.label ?? STATUS_LABELS[status()!]}
      </Badge>
    </Show>
  )
}

const PaymentCardInfo = (props: PaymentFieldProps) => {
  const payment = usePayment()
  const cardBrand = () => payment?.payment?.cardBrand
  const cardLast4 = () => payment?.payment?.cardLast4

  return (
    <Show when={cardBrand() || cardLast4()}>
      <Flex class={cn("items-center gap-2", props.class)}>
        <Show when={cardBrand()}>
          <span class="text-xs font-bold bg-muted px-2 py-1 rounded">
            {CARD_BRAND_ICONS[cardBrand()!] ?? cardBrand()!.toUpperCase()}
          </span>
        </Show>
        <Show when={cardLast4()}>
          <span class="text-muted-foreground">****{cardLast4()}</span>
        </Show>
      </Flex>
    </Show>
  )
}

const PaymentDate = (props: PaymentFieldProps) => {
  const payment = usePayment()
  const formatted = createMemo(() => {
    const date = payment?.payment?.insertedAt
    if (!date) return ''
    return new Intl.DateTimeFormat('en-US', {
      dateStyle: 'medium',
      timeStyle: 'short',
    }).format(new Date(date))
  })
  return (
    <Show when={payment?.payment?.insertedAt}>
      <Text class={cn("text-muted-foreground text-sm", props.class)}>
        {props.label ?? formatted()}
      </Text>
    </Show>
  )
}

const PaymentReceiptUrl = (props: { class?: string; children?: JSX.Element }) => {
  const payment = usePayment()
  return (
    <Show when={payment?.payment?.receiptUrl}>
      <a
        href={payment!.payment!.receiptUrl!}
        target="_blank"
        rel="noopener noreferrer"
        class={cn("text-primary hover:underline text-sm", props.class)}
      >
        {props.children ?? "View Receipt"}
      </a>
    </Show>
  )
}

type PaymentActionProps = {
  class?: string
  onClick?: (e: MouseEvent) => void
  children?: JSX.Element
  onSuccess?: (result: any) => void
  onError?: (error: Error) => void
}

const PaymentRefundTrigger = (props: PaymentActionProps) => {
  const payment = usePayment()
  const auth = useAuth()
  const [isDialogOpen, setIsDialogOpen] = createSignal(false)

  const canRefund = () => {
    const p = payment?.payment
    return p && (p.status === 'SUCCEEDED' || p.status === 'PARTIALLY_REFUNDED')
  }

  return (
    <Show when={canRefund()}>
      <Dialog open={isDialogOpen()} onOpenChange={setIsDialogOpen}>
        <DialogTrigger>
          <Button variant="outline" class={props.class} onClick={props.onClick}>
            {props.children ?? "Refund"}
          </Button>
        </DialogTrigger>
        <DialogContent>
          <RefundDialogContent
            paymentId={payment!.payment!.id}
            maxAmount={payment!.payment!.amount - (payment!.payment!.amountRefunded ?? 0)}
            currency={payment!.payment!.currency}
            onSuccess={(result) => {
              setIsDialogOpen(false)
              props.onSuccess?.(result)
            }}
            onError={props.onError}
          />
        </DialogContent>
      </Dialog>
    </Show>
  )
}

type RefundDialogContentProps = {
  paymentId: string
  maxAmount: number
  currency: string
  onSuccess?: (result: any) => void
  onError?: (error: Error) => void
}

const RefundDialogContent = (props: RefundDialogContentProps) => {
  const auth = useAuth()
  const [amount, setAmount] = createSignal(props.maxAmount)
  const [reason, setReason] = createSignal<RefundReason | null>(null)
  const [description, setDescription] = createSignal('')
  const [isProcessing, setIsProcessing] = createSignal(false)
  const [error, setError] = createSignal<string | null>(null)

  const handleRefund = async () => {
    setIsProcessing(true)
    setError(null)
    try {
      const result = await refundsApi.create({
        paymentId: props.paymentId,
        amount: amount(),
        reason: reason() ?? undefined,
        description: description() || undefined,
      }, auth.token()!)
      
      if (result.success) {
        props.onSuccess?.(result)
      } else {
        setError(result.error ?? "Refund failed")
      }
    } catch (e) {
      const err = e as Error
      setError(err.message)
      props.onError?.(err)
    } finally {
      setIsProcessing(false)
    }
  }

  return (
    <>
      <DialogHeader>
        <DialogTitle>Process Refund</DialogTitle>
        <DialogDescription>
          Maximum refundable: {new Intl.NumberFormat('en-US', {
            style: 'currency',
            currency: props.currency,
          }).format(props.maxAmount)}
        </DialogDescription>
      </DialogHeader>
      <Flex flexDirection="col" class="gap-4 py-4">
        <TextField>
          <TextFieldLabel>Amount</TextFieldLabel>
          <TextFieldInput
            type="number"
            value={amount()}
            onInput={(e) => setAmount(parseFloat(e.currentTarget.value) || 0)}
            max={props.maxAmount}
            min={0}
            step={0.01}
          />
        </TextField>
        <TextField>
          <TextFieldLabel>Reason</TextFieldLabel>
          <select
            class="flex h-10 w-full rounded-md border border-input bg-transparent px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
            value={reason() ?? ''}
            onChange={(e) => setReason(e.currentTarget.value as RefundReason || null)}
          >
            <option value="">Select reason</option>
            <option value="REQUESTED_BY_CUSTOMER">Requested by Customer</option>
            <option value="DUPLICATE">Duplicate</option>
            <option value="FRAUDULENT">Fraudulent</option>
          </select>
        </TextField>
        <TextField>
          <TextFieldLabel>Description (optional)</TextFieldLabel>
          <TextFieldInput
            value={description()}
            onInput={(e) => setDescription(e.currentTarget.value)}
          />
        </TextField>
        <Show when={error()}>
          <Text class="text-destructive text-sm">{error()}</Text>
        </Show>
      </Flex>
      <DialogFooter>
        <Button
          variant="destructive"
          onClick={handleRefund}
          disabled={isProcessing() || amount() <= 0 || amount() > props.maxAmount}
        >
          {isProcessing() ? "Processing..." : "Confirm Refund"}
        </Button>
      </DialogFooter>
    </>
  )
}

const PaymentCancelTrigger = (props: PaymentActionProps) => {
  const payment = usePayment()
  const auth = useAuth()
  const [isLoading, setIsLoading] = createSignal(false)

  const canCancel = () => {
    const p = payment?.payment
    return p && (p.status === 'PENDING' || p.status === 'PROCESSING')
  }

  const handleCancel = async () => {
    if (!payment?.payment?.id) return
    setIsLoading(true)
    try {
      const result = await paymentsApi.cancel(payment.payment.id, auth.token()!)
      if (result.success) {
        props.onSuccess?.(result.data)
      } else {
        props.onError?.(new Error("Failed to cancel payment"))
      }
    } catch (e) {
      props.onError?.(e as Error)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Show when={canCancel()}>
      <Button
        variant="outline"
        class={props.class}
        onClick={(e) => {
          props.onClick?.(e)
          handleCancel()
        }}
        disabled={isLoading()}
      >
        {props.children ?? (isLoading() ? "Cancelling..." : "Cancel Payment")}
      </Button>
    </Show>
  )
}

type PaymentListProps = {
  storeId?: string
  userId?: string
  data?: Payment[]
  queryKey?: unknown[]
  class?: string
  renderItem?: (payment: Payment) => JSX.Element
  children?: JSX.Element
}

const PaymentList = (props: PaymentListProps) => {
  const [local, others] = splitProps(props, [
    "storeId", "userId", "data", "queryKey", "class", "renderItem", "children"
  ])
  const auth = useAuth()

  const queryFn = async () => {
    if (local.storeId) {
      const result = await paymentsApi.getByStoreId(local.storeId, 0, 50, auth.token()!)
      return result.content
    }
    if (local.userId) {
      const result = await paymentsApi.getByUserId(local.userId, 0, 50, auth.token()!)
      return result.content
    }
    return []
  }

  return (
    <Query queryFn={queryFn} queryKey={local.queryKey ?? ["payments", local.storeId, local.userId]}>
      <QueryBoundary loadingFallback={<PaymentListSkeleton />}>
        <PaymentListContent 
          data={local.data} 
          class={local.class} 
          renderItem={local.renderItem}
        >
          {local.children}
        </PaymentListContent>
      </QueryBoundary>
    </Query>
  )
}

type PaymentListContentProps = {
  data?: Payment[]
  class?: string
  renderItem?: (payment: Payment) => JSX.Element
  children?: JSX.Element
}

const PaymentListContent = (props: PaymentListContentProps) => {
  const query = useQueryState()
  const payments = createMemo(() => props.data ?? (query?.data as Payment[] | undefined) ?? [])

  const defaultRenderItem = (payment: Payment) => (
    <PaymentRoot data={payment}>
      <Card>
        <CardHeader>
          <Flex justifyContent="space-between" alignItems="center">
            <CardTitle class="text-base">
              <PaymentAmount />
            </CardTitle>
            <PaymentStatusBadge />
          </Flex>
          <CardDescription>
            <PaymentId label={`ID: ${payment.id}`} />
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Flex flexDirection="col" class="gap-2">
            <PaymentCardInfo />
            <PaymentDate />
          </Flex>
        </CardContent>
      </Card>
    </PaymentRoot>
  )

  return (
    <Show when={payments().length > 0} fallback={
      <Flex class="justify-center items-center min-h-[30vh]">
        <Text class="text-muted-foreground">No payments found</Text>
      </Flex>
    }>
      <Flex flexDirection="col" class={cn("gap-4", props.class)}>
        <For each={payments()}>
          {(payment) => props.renderItem?.(payment) ?? defaultRenderItem(payment)}
        </For>
      </Flex>
    </Show>
  )
}

type PaymentMethodCardProps = {
  method: PaymentMethod
  class?: string
  onSelect?: (method: PaymentMethod) => void
  isSelected?: boolean
}

const PaymentMethodCard = (props: PaymentMethodCardProps) => {
  const isCard = () => props.method.type === 'CARD'
  const isBank = () => props.method.type === 'BANK_ACCOUNT'

  return (
    <Card
      class={cn(
        "cursor-pointer transition-all",
        props.isSelected && "ring-2 ring-primary",
        props.class
      )}
      onClick={() => props.onSelect?.(props.method)}
    >
      <CardContent class="p-4">
        <Flex justifyContent="space-between" alignItems="center">
          <Flex class="gap-3 items-center">
            <Show when={isCard()}>
              <div class="bg-muted px-2 py-1 rounded text-xs font-bold">
                {CARD_BRAND_ICONS[props.method.cardBrand ?? ''] ?? props.method.cardBrand?.toUpperCase() ?? 'CARD'}
              </div>
              <div>
                <Text class="font-medium">****{props.method.cardLast4}</Text>
                <Text class="text-xs text-muted-foreground">
                  Expires {props.method.cardExpMonth}/{props.method.cardExpYear}
                </Text>
              </div>
            </Show>
            <Show when={isBank()}>
              <div class="bg-muted px-2 py-1 rounded text-xs font-bold">BANK</div>
              <div>
                <Text class="font-medium">{props.method.bankName}</Text>
                <Text class="text-xs text-muted-foreground">****{props.method.bankLast4}</Text>
              </div>
            </Show>
            <Show when={!isCard() && !isBank()}>
              <div class="bg-muted px-2 py-1 rounded text-xs font-bold">
                {props.method.type}
              </div>
            </Show>
          </Flex>
          <Show when={props.method.isDefault}>
            <Badge variant="secondary" class="text-xs">Default</Badge>
          </Show>
        </Flex>
      </CardContent>
    </Card>
  )
}

type PaymentMethodListProps = {
  storeId: string
  data?: PaymentMethod[]
  class?: string
  onSelect?: (method: PaymentMethod) => void
  selectedId?: string
}

const PaymentMethodList = (props: PaymentMethodListProps) => {
  const [local, others] = splitProps(props, ["storeId", "data", "class", "onSelect", "selectedId"])
  const auth = useAuth()
  const query = useQueryState()

  const methods = createMemo(() => local.data ?? (query?.data as PaymentMethod[] | undefined) ?? [])

  return (
    <Flex flexDirection="col" class={cn("gap-3", local.class)}>
      <For each={methods()}>
        {(method) => (
          <PaymentMethodCard
            method={method}
            isSelected={local.selectedId === method.id}
            onSelect={local.onSelect}
          />
        )}
      </For>
    </Flex>
  )
}

type CheckoutFormProps = {
  storeId: string
  cartId: string
  total: number
  currency?: string
  class?: string
  onSuccess?: (result: { orderId: string; paymentId: string }) => void
  onError?: (error: Error) => void
}

const CheckoutForm = (props: CheckoutFormProps) => {
  const auth = useAuth()
  const [selectedMethodId, setSelectedMethodId] = createSignal<string | null>(null)
  const [isProcessing, setIsProcessing] = createSignal(false)
  const [error, setError] = createSignal<string | null>(null)

  const handleCheckout = async () => {
    if (!auth.token()) {
      setError("Please log in to continue")
      return
    }

    setIsProcessing(true)
    setError(null)

    try {
      const paymentRequest: CreatePaymentRequest = {
        orderId: props.cartId,
        userId: auth.user()!.id,
        storeId: props.storeId,
        amount: props.total,
        currency: props.currency ?? 'USD',
      }

      const result = await paymentsApi.createPaymentIntent(paymentRequest, auth.token()!)

      if (result.success && result.paymentId) {
        props.onSuccess?.({
          orderId: props.cartId,
          paymentId: result.paymentId!,
        })
      } else {
        setError(result.error ?? "Payment failed")
        props.onError?.(new Error(result.error ?? "Payment failed"))
      }
    } catch (e) {
      const err = e as Error
      setError(err.message)
      props.onError?.(err)
    } finally {
      setIsProcessing(false)
    }
  }

  return (
    <CheckoutProvider>
      <Card class={props.class}>
        <CardHeader>
          <CardTitle>Checkout</CardTitle>
          <CardDescription>
            Total: {new Intl.NumberFormat('en-US', {
              style: 'currency',
              currency: props.currency ?? 'USD',
            }).format(props.total)}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Flex flexDirection="col" class="gap-4">
            <Query
              queryFn={async () => {
                const result = await paymentMethodsApi.getAll(props.storeId, auth.token()!)
                return result.data ?? []
              }}
              queryKey={["payment-methods", props.storeId]}
            >
              <QueryBoundary loadingFallback={<Skeleton class="h-20 w-full" />}>
                <PaymentMethodList
                  storeId={props.storeId}
                  selectedId={selectedMethodId() ?? undefined}
                  onSelect={(method) => setSelectedMethodId(method.id)}
                />
              </QueryBoundary>
            </Query>
            <Show when={error()}>
              <Text class="text-destructive text-sm">{error()}</Text>
            </Show>
          </Flex>
        </CardContent>
        <CardFooter>
          <Button
            class="w-full"
            onClick={handleCheckout}
            disabled={isProcessing() || props.total <= 0}
          >
            {isProcessing() ? "Processing..." : `Pay ${new Intl.NumberFormat('en-US', {
              style: 'currency',
              currency: props.currency ?? 'USD',
            }).format(props.total)}`}
          </Button>
        </CardFooter>
      </Card>
    </CheckoutProvider>
  )
}

const PaymentSkeleton = (props: { class?: string }) => (
  <Card class={props.class}>
    <CardHeader>
      <Flex justifyContent="space-between">
        <Skeleton class="h-6 w-24" />
        <Skeleton class="h-6 w-20 rounded-full" />
      </Flex>
      <Skeleton class="h-4 w-32 mt-2" />
    </CardHeader>
    <CardContent>
      <Flex flexDirection="col" class="gap-2">
        <Skeleton class="h-4 w-full" />
        <Skeleton class="h-4 w-3/4" />
      </Flex>
    </CardContent>
  </Card>
)

const PaymentListSkeleton = (props: { class?: string }) => (
  <Flex flexDirection="col" class={cn("gap-4", props.class)}>
    <For each={[1, 2, 3]}>
      {() => <PaymentSkeleton />}
    </For>
  </Flex>
)

export type {
  PaymentRootProps,
  PaymentFieldProps,
  PaymentActionProps,
  PaymentListProps,
  PaymentMethodCardProps,
  CheckoutFormProps,
}

export {
  PaymentRoot,
  PaymentProvider,
  PaymentId,
  PaymentAmount,
  PaymentStatusBadge,
  PaymentCardInfo,
  PaymentDate,
  PaymentReceiptUrl,
  PaymentRefundTrigger,
  PaymentCancelTrigger,
  PaymentList,
  PaymentMethodCard,
  PaymentMethodList,
  CheckoutForm,
  CheckoutProvider,
  RefundProvider,
  usePayment,
  useCheckout,
  useRefund,
  PaymentSkeleton,
  PaymentListSkeleton,
  STATUS_COLORS,
  STATUS_LABELS,
}
