import * as SCPrimitives from "@kobalte/core/segmented-control"

const SegmentedControl = SCPrimitives.Root
const SegmentedControlLabel = SCPrimitives.Label
const SegmentedControlDescription = SCPrimitives.Description
const SegmentedControlErrorMessage = SCPrimitives.ErrorMessage
const SegmentedControlIndicator = SCPrimitives.Indicator

const SegmentedControlItem = SCPrimitives.Item
const SegmentedControlItemInput = SCPrimitives.ItemInput
const SegmentedControlItemControl = SCPrimitives.ItemControl
const SegmentedControlItemIndicator = SCPrimitives.ItemIndicator
const SegmentedControlItemLabel = SCPrimitives.ItemLabel
const SegmentedControlItemDescription  = SCPrimitives.ItemDescription



export { 
   SegmentedControl,
   SegmentedControlLabel,
   SegmentedControlDescription,
   SegmentedControlErrorMessage,
   SegmentedControlIndicator,
   SegmentedControlItem,
   SegmentedControlItemInput,
   SegmentedControlItemControl,
   SegmentedControlItemIndicator,
   SegmentedControlItemLabel,
   SegmentedControlItemDescription,
}


