import type { JSX, ValidComponent } from "solid-js"
import { splitProps, mergeProps, Show } from "solid-js"
 
import * as ButtonPrimitive from "@kobalte/core/button"
import type { PolymorphicProps } from "@kobalte/core/polymorphic"
import type { VariantProps } from "class-variance-authority"
import { cva } from "class-variance-authority"
 
import { cn } from "~/lib/utils"

/* [&-svg]:size-5 -> set sizes of icons
 * * Originaly it was not allowing pointer events on svg so we changed that*/
const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50  /*[&_svg]:size-5 [&_svg]:shrink-0*/",
  {
    variants: {
      variant: {
        default: "bg-primary text-primary-foreground hover:bg-primary/90",
        destructive: "bg-destructive text-destructive-foreground hover:bg-destructive/90",
        outline: "border border-input hover:bg-accent hover:text-accent-foreground",
        secondary: "bg-secondary text-secondary-foreground hover:bg-secondary/80",
        ghost: "hover:bg-accent hover:text-accent-foreground",
        link: "text-primary underline-offset-4 hover:underline"
      },
      size: {
        default: "h-10 px-4 py-2",
        sm: "h-9 px-3 text-xs",
        lg: "h-11 px-8",
        icon: "size-10"
      }
    },
    defaultVariants: {
      variant: "default",
      size: "default"
    }
  }
)
 
type ButtonProps<T extends ValidComponent = "button"> = ButtonPrimitive.ButtonRootProps<T> &
  VariantProps<typeof buttonVariants> & {
     class?: string | undefined;
     children?: JSX.Element
     enabled?: boolean 
     href?: string
  }
 
const Button = <T extends ValidComponent = "button">(
  rawProps: PolymorphicProps<T, ButtonProps<T>>
) => {
  const props = mergeProps({
    enabled: true
  }, rawProps)
  const [local, others] = splitProps(props as ButtonProps, [ "enabled", "variant", "size", "class", "children"])

  return (
     <ButtonPrimitive.Root
       class={cn(buttonVariants({ variant: local.variant?? "outline", size: local.size }),"hover:cursor-pointer", local.class)}
      disabled={!local.enabled} 
     {...others} 
     > 
     {local.children} 
   </ButtonPrimitive.Root>
  )
}
 
export type { ButtonProps }
export { Button, buttonVariants }
