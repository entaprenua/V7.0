import { Show, For, createSignal, type JSX } from "solid-js"
import { useCart, type CartItemContextData } from "./cart-context"
import { Button } from "../button"
import { Text } from "../text"
import { Checkbox } from "../checkbox"
import { Flex } from "../flex"
import { Input } from "../input"
import { ImageImg, ImageFallback, Image } from "../image"
import { Link } from "../link"
import { cn } from "~/lib/utils"

// ============================================================================
// Cart Icon with Badge
// ============================================================================

const CartIcon = (props: { class?: string }) => {
  const cart = useCart()

  return (
    <Link href="/store/cart" class={cn("relative inline-flex", props.class)}>
      <Button variant="ghost">
        <svg xmlns="http://www.w3.org/2000/svg" class="size-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z" />
        </svg>
      </Button>
      <Show when={cart.count() > 0}>
        <span class="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
          {cart.count()}
        </span>
      </Show>
    </Link>
  )
}

type CartItemProps = {
  class?: string
  item?: CartItemContextData
  children?: JSX.Element
}

const CartItem = (props: CartItemProps) => {
  const cart = useCart()
  const item = () => props.item ?? cart.items()[0]
  const cartItem = item()

  return (
    <div class={cn("flex gap-4 p-4 border rounded-lg", props.class)}>
      <CartItemCheckbox item={cartItem} />
      <div class="flex-1">
        <CartItemImage item={cartItem} class="w-20 h-20 object-cover rounded" />
        <div>
          <CartItemName item={cartItem} class="font-medium" />
          <CartItemPrice item={cartItem} class="font-bold" />
        </div>
      </div>
      <CartItemQuantity item={cartItem} />
      <CartItemSubtotal item={cartItem} class="font-bold" />
      <CartItemRemove item={cartItem} />
    </div>
  )
}

const CartItemCheckbox = (props: { item?: CartItemContextData; class?: string }) => {
  const cart = useCart()
  const item = () => props.item

  return (
    <Checkbox
      checked={item()?.selected ?? false}
      class={cn("size-5", props.class)}
      onChange={() => item()?.id && cart.toggleSelected(item()!.id)}
    />
  )
}

const CartItemImage = (props: { item?: CartItemContextData; class?: string }) => {
  const item = () => props.item

  return (
    <Show when={item()?.image} fallback={<div class={cn("bg-muted", props.class)} />}>
      <Image class={cn("relative", props.class)}>
        <ImageImg src={item()?.image} alt={item()?.name} />
        <ImageFallback>No image</ImageFallback>
      </Image>
    </Show>
  )
}

const CartItemName = (props: { item?: CartItemContextData; class?: string }) => {
  const item = () => props.item

  return <Text class={props.class}>{item()?.name ?? "Product"}</Text>
}

const CartItemPrice = (props: { item?: CartItemContextData; class?: string }) => {
  const item = () => props.item
  const price = () => item()?.price ?? 0

  return (
    <Text class={props.class}>
      ${typeof price() === "number" ? price().toFixed(2) : "0.00"}
    </Text>
  )
}

const CartItemQuantity = (props: { item?: CartItemContextData; class?: string }) => {
  const cart = useCart()
  const item = () => props.item
  const quantity = () => item()?.quantity ?? 1

  const handleChange = (e: Event) => {
    const target = e.target as HTMLInputElement
    const val = parseInt(target.value, 10)
    if (item()?.id && !isNaN(val) && val > 0) {
      cart.updateQuantity(item()!.id, val)
    }
  }

  return (
    <Input
      type="number"
      min="1"
      value={quantity()}
      class={cn("w-16", props.class)}
      onInput={handleChange}
    />
  )
}

const CartItemSubtotal = (props: { item?: CartItemContextData; class?: string }) => {
  const item = () => props.item
  const subtotal = () => item()?.subtotal ?? 0

  return (
    <Text class={props.class}>
      ${typeof subtotal() === "number" ? subtotal().toFixed(2) : "0.00"}
    </Text>
  )
}

const CartItemRemove = (props: { item?: CartItemContextData; class?: string }) => {
  const cart = useCart()
  const item = () => props.item

  return (
    <Button
      variant="ghost"
      size="sm"
      class={props.class}
      onClick={() => item()?.id && cart.removeItem(item()!.id)}
    >
      Remove
    </Button>
  )
}

// ============================================================================
// Cart Items List
// ============================================================================

type CartItemsProps = {
  class?: string
  children?: (item: CartItemContextData) => JSX.Element
}

const CartItems = (props: CartItemsProps) => {
  const cart = useCart()

  return (
    <div class={cn("flex flex-col gap-4", props.class)}>
      <For each={cart.items()}>
        {(item) => (
          <CartItem item={item}>
            {props.children ? props.children(item) : <DefaultCartItem item={item} />}
          </CartItem>
        )}
      </For>
    </div>
  )
}

const DefaultCartItem = (props: { item: CartItemContextData }) => (
  <div class="flex gap-4 p-4 border rounded-lg">
    <CartItemCheckbox item={props.item} />
    <CartItemImage item={props.item} class="w-20 h-20 object-cover rounded" />
    <div class="flex-1">
      <CartItemName item={props.item} class="font-medium" />
      <CartItemPrice item={props.item} />
    </div>
    <CartItemQuantity item={props.item} />
    <CartItemSubtotal item={props.item} class="font-bold" />
    <CartItemRemove item={props.item} />
  </div>
)

// ============================================================================
// Cart Summary
// ============================================================================

type CartSummaryProps = {
  class?: string
  children?: JSX.Element
}

const CartSummary = (props: CartSummaryProps) => {
  const cart = useCart()

  return (
    <Show when={!cart.isEmpty()} fallback={<CartEmpty />}>
      <div class={cn("space-y-4", props.class)}>
        {props.children ?? <DefaultCartSummary />}
      </div>
    </Show>
  )
}

const DefaultCartSummary = () => {
  const cart = useCart()

  return (
    <>
      <Flex class="justify-between">
        <Text>Subtotal</Text>
        <Text class="font-medium">${cart.subtotal().toFixed(2)}</Text>
      </Flex>
      <Flex class="justify-between">
        <Text>Items</Text>
        <Text>{cart.count()}</Text>
      </Flex>
      <div class="border-t pt-4">
        <Flex class="justify-between">
          <Text class="font-bold">Total</Text>
          <Text class="font-bold text-lg">${cart.subtotal().toFixed(2)}</Text>
        </Flex>
      </div>
    </>
  )
}

// ============================================================================
// Cart Empty
// ============================================================================

type CartEmptyProps = {
  class?: string
  children?: JSX.Element
}

const CartEmpty = (props: CartEmptyProps) => {
  const cart = useCart()

  return (
    <Show when={cart.isEmpty()}>
      <div class={cn("flex flex-col items-center justify-center min-h-[30vh] gap-2", props.class)}>
        {props.children ?? (
          <>
            <Text variant="h3" class="text-muted-foreground">Your cart is empty</Text>
            <Text variant="body2" class="text-muted-foreground">Add some products to get started</Text>
          </>
        )}
      </div>
    </Show>
  )
}

// ============================================================================
// Cart Count
// ============================================================================

const CartCount = (props: { class?: string }) => {
  const cart = useCart()
  return <Text class={props.class}>{cart.count()}</Text>
}

// ============================================================================
// Cart Subtotal
// ============================================================================

const CartSubtotal = (props: { class?: string }) => {
  const cart = useCart()
  return <Text class={props.class}>${cart.subtotal().toFixed(2)}</Text>
}

// ============================================================================
// Cart Checkout Trigger
// ============================================================================

type CartCheckoutTriggerProps = {
  class?: string
  children?: JSX.Element
}

const CartCheckoutTrigger = (props: CartCheckoutTriggerProps) => {
  const cart = useCart()

  return (
    <Show when={!cart.isEmpty()}>
      <Button class={props.class}>
        {props.children ?? "Proceed to Checkout"}
      </Button>
    </Show>
  )
}

// ============================================================================
// Cart Clear Trigger
// ============================================================================

type CartClearTriggerProps = {
  class?: string
  children?: JSX.Element
}

const CartClearTrigger = (props: CartClearTriggerProps) => {
  const cart = useCart()

  return (
    <Show when={!cart.isEmpty()}>
      <Button
        variant="outline"
        class={props.class}
        onClick={() => cart.clear()}
      >
        {props.children ?? "Clear Cart"}
      </Button>
    </Show>
  )
}

// ============================================================================
// Cart Promo Input
// ============================================================================

type CartPromoInputProps = {
  class?: string
}

const CartPromoInput = (props: CartPromoInputProps) => {
  const [code, setCode] = createSignal("")

  return (
    <Flex class={cn("gap-2", props.class)}>
      <Input
        placeholder="Promo code"
        value={code()}
        onInput={(e) => setCode(e.currentTarget.value)}
      />
      <Button variant="outline">Apply</Button>
    </Flex>
  )
}

// ============================================================================
// Cart Loading
// ============================================================================

const CartLoading = (props: { class?: string }) => {
  return (
    <div class={cn("animate-pulse space-y-4", props.class)}>
      <div class="h-24 bg-muted rounded" />
      <div class="h-24 bg-muted rounded" />
      <div class="h-24 bg-muted rounded" />
    </div>
  )
}

export {
  CartItem,
  CartItems,
  CartSummary,
  CartEmpty,
  CartCount,
  CartSubtotal,
  CartCheckoutTrigger,
  CartClearTrigger,
  CartPromoInput,
  CartLoading,
  CartIcon,
  CartItemCheckbox,
  CartItemImage,
  CartItemName,
  CartItemPrice,
  CartItemQuantity,
  CartItemSubtotal,
  CartItemRemove,
}
