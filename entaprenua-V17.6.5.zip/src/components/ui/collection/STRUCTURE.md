# Collection Components Architecture

## Overview

The `Collection` component is a unified data-fetching and layout system for rendering lists/grids of items. It provides a consistent pattern for item iteration across the entire component system, including Hero, Recommendations, and Product components.

## Design Principles

1. **Unified Pattern** - Single iteration pattern for all list-based components
2. **Layout Flexible** - Multiple layout modes or custom rendering (passthrough)
3. **Context Provider** - `CollectionItemContext` for child component access
4. **Zero-Code Ready** - Works with existing components without explicit data passing
5. **Data or Query** - Accepts either direct data array or fetch function

## How It Works

### Collection

The main component that provides context and handles data:

```tsx
<Collection 
  data={items}           // Direct data array
  layout="vertical-grid" // Optional layout mode
  columns={4}            // For grid layouts
  gap={4}                // Gap between items
>
  <CollectionView>
    {children}
  </CollectionView>
</Collection>
```

### CollectionView

Renders the data with selected layout. When no layout is specified, it renders children for each item (passthrough mode).

```tsx
// With layout
<CollectionView>
  {item => <MyItem item={item} />}  // Function receives item
</CollectionView>

// Without layout (passthrough)
<CollectionView>
  <MyItem />  // Reads from CollectionItemContext
</CollectionView>
```

### CollectionItem

Wraps children in `CollectionItemContext`, providing access to the current item:

```tsx
<CollectionItem item={item} index={0} collection={items}>
  {children}
</CollectionItem>
```

### useCollectionItem

Hook to access the current item in child components:

```tsx
const CollectionItem = useCollectionItem()
// Returns: { item, index, collection, value }
```

## Layout Modes

| Layout | Description |
|--------|-------------|
| `column` | Vertical stack with gap |
| `row` | Horizontal flex with gap |
| `vertical-grid` | CSS Grid, columns vertical |
| `horizontal-grid` | CSS Grid, columns horizontal |
| `virtual` | Virtual scrolling for large lists |
| `undefined` | Passthrough - no layout wrapper, just iteration |

## Passthrough Mode (No Layout)

When `layout` is not specified, `CollectionView` renders items without any layout wrapper. This is useful for:

- **Carousels** - Carousel provides the layout
- **Custom containers** - Parent controls positioning
- **Simple iteration** - Just need item context

```tsx
// Example: Inside a carousel
<CarouselContent>
  <Collection data={items}>
    <CollectionView>
      <CarouselItem>
        {props.children}  // Rendered for each item
      </CarouselItem>
    </CollectionView>
  </Collection>
</CarouselContent>
```

## Integration with Other Components

### Hero Components

Hero uses Collection for item iteration:

```tsx
// HeroCarouselContent
<CarouselContent>
  <Collection data={heroItems()}>
    <CollectionView>
      {props.children}  // HeroCarouselItem
    </CollectionView>
  </Collection>
</CarouselContent>

// HeroItems
<Collection data={items()} layout="vertical-grid">
  <CollectionView>
    {props.children}
  </CollectionView>
</Collection>
```

Hero sections use `useCollectionItem()` to access the current item.

### Recommendations Components

Recommendations uses Collection for item iteration:

```tsx
// RecommendationsCarouselContent
<CarouselContent>
  <Collection data={recommendations.products()}>
    <CollectionView>
      {props.children}  // RecommendationsCarouselItem
    </CollectionView>
  </Collection>
</CarouselContent>
```

### Product Components

Product components use `useCollectionItem()` to auto-detect the current product:

```tsx
// Inside RecommendationsCarouselItem
<Product>
  <ProductImage />    // ← reads from CollectionItemContext
  <ProductName />    // ← reads from CollectionItemContext
  <ProductPrice />   // ← reads from CollectionItemContext
</Product>
```

## Context API

### CollectionContextValue

```typescript
type CollectionContextValue = {
  data: Accessor<any[]>
  layout: Accessor<CollectionLayoutMode | undefined>
  columns: Accessor<CollectionColumnCount>
  gap: Accessor<CollectionGapSize>
}
```

### CollectionItemContext

```typescript
type CollectionItemContext = {
  item: any           // Current item
  collection: any      // Full data array
  index: number       // Current index
  value: any          // Same as item
}
```

### useCollectionItem

```typescript
const useCollectionItem = (): CollectionItemContext | undefined => {
  return useContext(CollectionItemContextInstance)
}
```

## Props Reference

### Collection

```typescript
type CollectionProps = {
  children?: JSX.Element
  errorFallback?: JSX.Element
  loadingFallback?: JSX.Element
  queryFn?: () => Promise<any>       // Fetch function (optional)
  data?: any[]                        // Direct data (alternative to queryFn)
  queryKey?: unknown[]
  enabled?: boolean
  layout?: CollectionLayoutMode       // "column" | "row" | "vertical-grid" | "horizontal-grid" | "virtual"
  columns?: CollectionColumnCount     // 1-12
  gap?: CollectionGapSize             // 0, 1, 2, 3, 4, 5, 6, 8, 10, 12
}
```

### CollectionView

```typescript
type CollectionViewProps = {
  class?: string
  children?: JSX.Element | ((item: any, index: number) => JSX.Element)
}
```

### CollectionItem

```typescript
type CollectionItemProps = {
  item: any
  index: number
  collection: any
  children?: JSX.Element
}
```

## Usage Examples

### Grid Layout

```tsx
<Collection data={products} layout="vertical-grid" columns={4} gap={4}>
  <CollectionView>
    {product => <ProductCard product={product} />}
  </CollectionView>
</Collection>
```

### Without Layout (Passthrough)

```tsx
<Collection data={items}>
  <CollectionView>
    <MyCustomItem />
  </CollectionView>
</Collection>
```

### With Function Children

```tsx
<Collection data={items}>
  <CollectionView>
    {(item, index) => (
      <div class="item">
        <span>{index()}</span>
        <span>{item.name}</span>
      </div>
    )}
  </CollectionView>
</Collection>
```

### Remote Data with Query

```tsx
<Collection 
  queryFn={fetchProducts}
  queryKey={["products"]}
  layout="vertical-grid"
  columns={3}
>
  <CollectionView>
    {product => <ProductCard product={product} />}
  </CollectionView>
</Collection>
```

## CollectionItemContextInstance

For advanced use cases, `CollectionItemContextInstance` is exported for direct context access:

```typescript
import { CollectionItemContextInstance } from "~/components/ui/collection"

// Create a provider manually
<CollectionItemContextInstance.Provider value={contextValue}>
  {children}
</CollectionItemContextInstance.Provider>
```

## Best Practices

1. **Use when multiple items need iteration** - Hero, Recommendations, Product lists
2. **Specify layout when appropriate** - Grid, row, column layouts
3. **Omit layout for custom containers** - Carousels, custom wrappers
4. **Use `useCollectionItem()` in children** - For codeless data access

## Architecture Diagram

```
Collection
├── Query (optional, for remote data)
│   └── QueryBoundary
│       └── CollectionInner
│           └── CollectionContext.Provider
│               └── children
│                   └── CollectionView
│                       ├── Collection (if layout specified)
│                       └── CollectionItem (per item)
│                           └── CollectionItemContext.Provider
│                               └── children
```
