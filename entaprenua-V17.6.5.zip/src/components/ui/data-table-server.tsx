import { For, Show, createSignal, createEffect, createMemo, on, onMount, JSX } from "solid-js"
import { ColumnDef, flexRender, SortingState } from "@tanstack/solid-table"
import { Query, QueryBoundary, defaultQueryClient } from "~/components/ui/query"

import {
  Table,
  TableHeader,
  TableBody,
  TableRow,
  TableHead,
  TableCell,
} from "~/components/ui/table"

import { Button } from "~/components/ui/button"
import { Text } from "~/components/ui/text"
import { Flex } from "~/components/ui/flex"
import { Box } from "~/components/ui/box"
import { Input } from "~/components/ui/input"
import { Checkbox } from "~/components/ui/checkbox"
import { Pagination, PaginationItems, PaginationItem, PaginationEllipsis, PaginationPrevious, PaginationNext } from "~/components/ui/pagination"
import { cn } from "~/lib/utils"

export type { ColumnDef, SortingState }

export interface FilterConfig {
  key: string
  label: string
  type: "search" | "select"
  options?: { value: string; label: string }[]
  placeholder?: string
}

export interface QueryParams {
  page: number
  pageSize: number
  sortField?: string
  sortDirection?: "asc" | "desc"
  filters: Record<string, string>
}

export interface DataTableServerProps<T> {
  columns: ColumnDef<T>[]
  queryKey: any[]
  fetchData: (params: QueryParams) => Promise<{ data: T[], total: number }>
  filters?: FilterConfig[]
  defaultPageSize?: number
  /** Time in ms before data is considered stale. Default 0 = always fetch fresh */
  staleTime?: number
  onRowSelect?: (rows: T[]) => void
  renderRowActions?: (row: T) => JSX
  getRowId?: (row: T) => string
  renderCell?: (row: T, columnId: string) => JSX
  inlineEditColumn?: {
    columnId: string
    render: (row: T) => JSX
  }
}

const PAGE_SIZE_OPTIONS = [10, 20, 50, 100]

export function DataTableServer<T>(props: DataTableServerProps<T>) {
  const [page, setPage] = createSignal(0)
  const [pageSize, setPageSize] = createSignal(props.defaultPageSize || 20)
  const [total, setTotal] = createSignal(0)

  /**
   * Reset page to 0 when storeId changes (e.g., user switches stores).
   * This prevents pagination issues where stale cached data shows wrong page for the new store.
   * Using SolidJS `on()` tracks the storeId without causing unnecessary re-renders.
   */
  on(
    () => props.queryKey[1], // queryKey[1] is typically the storeId
    (newKey, prevKey) => {
      if (prevKey !== undefined && newKey !== prevKey) {
        setPage(0)
      }
    }
  )

  /**
   * On component mount, invalidate existing queries to ensure fresh data.
   * 
   * Problem: When user navigates away from the page and comes back:
   * 1. Local `page` signal resets to 0
   * 2. But TanStack Query may have cached data from page 3
   * 3. This causes stale data to display (wrong page)
   * 
   * Solution: Invalidate queries on mount so they refetch with the correct page.
   */
  onMount(() => {
    defaultQueryClient.invalidateQueries({ queryKey: props.queryKey })
  })
  
  const [sorting, setSorting] = createSignal<SortingState>([])
  const [filters, setFilters] = createSignal<Record<string, string>>({})
  const [selectedRows, setSelectedRows] = createSignal<Set<string>>(new Set())
  const [searchDebounce, setSearchDebounce] = createSignal(0)
  
  /**
   * Separate local state for search input to prevent focus loss.
   * 
   * Problem: When typing in search, the Query component refetches data.
   * If search input value was tied to filters() signal, every keystroke
   * would update filters → trigger refetch → re-render input → lose focus.
   * 
   * Solution: Use separate local state (searchInputValue) for the input's
   * displayed value. Only update filters() after debounce delay.
   * This keeps the input stable while typing.
   */
  const [searchInputValue, setSearchInputValue] = createSignal("")

  const totalPages = createMemo(() => Math.ceil(total() / pageSize()))
  const currentPage = () => page() + 1

  const handleSort = (columnId: string) => {
    const currentSort = sorting()
    const existing = currentSort.find(s => s.id === columnId)
    
    if (existing) {
      if (existing.desc) {
        setSorting(currentSort.map(s => s.id === columnId ? { ...s, desc: false } : s))
      } else {
        setSorting(currentSort.filter(s => s.id !== columnId))
      }
    } else {
      setSorting([{ id: columnId, desc: false }])
    }
    setPage(0)
  }

  const handleFilterChange = (key: string, value: string) => {
    // Update local input state immediately for responsive UI
    if (props.filters?.find(f => f.type === "search" && f.key === key)) {
      setSearchInputValue(value)
    }
    
    setFilters(f => ({ ...f, [key]: value }))
    
    if (props.filters?.find(f => f.type === "search" && f.key === key)) {
      // Debounce the page reset and actual filter for search
      clearTimeout(searchDebounce())
      const timer = setTimeout(() => {
        setPage(0)
      }, 300)
      setSearchDebounce(timer as unknown as number)
    } else {
      setPage(0)
    }
  }

  // Helper to get filter value - uses local state for search, filters for others
  const getFilterValue = (key: string) => {
    const filterConfig = props.filters?.find(f => f.key === key)
    if (filterConfig?.type === "search") {
      return searchInputValue()
    }
    return filters()[key] || ""
  }

  const handleResetFilters = () => {
    setFilters({})
    setSearchInputValue("")
    setPage(0)
  }

  const handlePageChange = (newPage: number) => {
    if (newPage >= 0 && newPage < totalPages()) {
      setPage(newPage)
    }
  }

  const handlePageSizeChange = (newSize: number) => {
    setPageSize(newSize)
    setPage(0)
  }

  const toggleSelectAll = (checked: boolean, data: T[]) => {
    if (checked && data) {
      const newSelected = new Set<string>()
      data.forEach(row => {
        if (props.getRowId) {
          newSelected.add(props.getRowId(row))
        }
      })
      setSelectedRows(newSelected)
    } else {
      setSelectedRows(new Set())
    }
  }

  const toggleSelect = (id: string) => {
    const current = new Set(selectedRows())
    if (current.has(id)) {
      current.delete(id)
    } else {
      current.add(id)
    }
    setSelectedRows(current)
    props.onRowSelect?.(getSelectedData(data() as T[]))
  }

  const getSelectedData = (data: T[]): T[] => {
    return data.filter(row => {
      const id = props.getRowId ? props.getRowId(row) : (row as any).id
      return selectedRows().has(id)
    })
  }

  const queryKey = createMemo(() => [
    ...props.queryKey,
    page(),
    pageSize(),
    sorting(),
    filters()
  ])

  const sortParams = createMemo(() => {
    const sort = sorting()[0]
    return {
      sortField: sort?.id,
      sortDirection: sort?.desc ? "desc" as const : "asc" as const
    }
  })

  // Filters rendered outside Query to prevent input focus loss during refetch
  const Filters = () => (
    <Show when={props.filters && props.filters.length > 0}>
      <Flex class="flex-col sm:flex-row gap-3 flex-wrap">
        <For each={props.filters}>
          {(filter) => (
            <Show when={filter.type === "search"} fallback={
              <select
                class="h-10 px-3 rounded-md border border-input bg-background text-sm min-w-[140px]"
                value={getFilterValue(filter.key)}
                onChange={(e) => handleFilterChange(filter.key, e.currentTarget.value)}
              >
                <option value="">{filter.placeholder || `All ${filter.label}`}</option>
                <For each={filter.options}>
                  {(opt) => <option value={opt.value}>{opt.label}</option>}
                </For>
              </select>
            }>
              <Flex class="items-center gap-2 relative">
                <SearchIcon class="absolute left-3 size-4 text-muted-foreground" />
                <Input
                  placeholder={filter.placeholder || `Search ${filter.label}...`}
                  value={getFilterValue(filter.key)}
                  onInput={(e) => handleFilterChange(filter.key, e.currentTarget.value)}
                  class="pl-9 w-64"
                />
              </Flex>
            </Show>
          )}
        </For>
        <Show when={Object.values(filters()).some(v => v) || searchInputValue()}>
          <Button variant="ghost" size="sm" onClick={handleResetFilters}>
            Reset
          </Button>
        </Show>
      </Flex>
    </Show>
  )

  return (
    <Box class="flex flex-col gap-4">
      {/* Filters - outside Query to prevent focus loss */}
      <Filters />

      <Query
      queryKey={queryKey()}
      queryFn={async () => {
        const response = await props.fetchData({
          page: page(),
          pageSize: pageSize(),
          ...sortParams(),
          filters: filters()
        })
        setTotal(response.total)
        return response.data
      }}
      placeholderData={(previousData) => previousData}
    >
      <QueryBoundary
        loadingFallback={
          <Flex class="items-center justify-center p-8">
            <div class="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent" />
          </Flex>
        }
        errorFallback={(error, retry) => (
          <Flex class="flex-col items-center gap-4 p-8">
            <Text class="text-destructive">Failed to load data: {error.message}</Text>
            <Button variant="outline" onClick={retry}>Retry</Button>
          </Flex>
        )}
      >
        {(data) => {
          const tableData = data as T[]
          
          const isAllSelected = () => {
            if (tableData.length === 0) return false
            return tableData.every(row => {
              const id = props.getRowId ? props.getRowId(row) : (row as any).id
              return selectedRows().has(id)
            })
          }

          return (
            <Box class="flex flex-col gap-4">
              {/* Table - Desktop */}
              <Box class="hidden md:block border rounded-lg overflow-hidden">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead class="w-12">
                        <Checkbox
                          checked={isAllSelected()}
                          onChange={(checked) => toggleSelectAll(checked, tableData)}
                        />
                      </TableHead>
                      <For each={props.columns}>
                        {(column) => (
                          <TableHead
                            class={cn(
                              column.enableSorting !== false && "cursor-pointer select-none"
                            )}
                            onClick={() => column.enableSorting !== false && handleSort(column.id!)}
                          >
                            <Flex class="items-center gap-2">
                              {flexRender(column.header, { get row() { return {} } })}
                              <Show when={column.enableSorting !== false}>
                                <SortIndicator column={column.id!} sorting={sorting()} />
                              </Show>
                            </Flex>
                          </TableHead>
                        )}
                      </For>
                      <Show when={props.renderRowActions}>
                        <TableHead class="w-24">Actions</TableHead>
                      </Show>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                      <Show
                        when={tableData.length > 0}
                        fallback={
                          <TableRow>
                            <TableCell colSpan={props.columns.length + (props.renderRowActions ? 2 : 1)} class="h-24 text-center">
                              <Text class="text-muted-foreground">No results found</Text>
                            </TableCell>
                          </TableRow>
                        }
                      >
                      <For each={tableData}>
                        {(row) => {
                          const rowId = props.getRowId ? props.getRowId(row) : (row as any).id
                          return (
                            <TableRow classList={{ "bg-muted/50": selectedRows().has(rowId) }}>
                              <TableCell>
                                <Checkbox
                                  checked={selectedRows().has(rowId)}
                                  onChange={() => toggleSelect(rowId)}
                                />
                              </TableCell>
                              <For each={props.columns}>
                                {(column) => (
                                  <TableCell>
                                    <Show when={
                                      props.inlineEditColumn?.columnId === column.id
                                    } fallback={
                                      props.renderCell 
                                        ? props.renderCell(row, column.id!)
                                        : flexRender(column.cell, { row })
                                    }>
                                      {props.inlineEditColumn!.render(row)}
                                    </Show>
                                  </TableCell>
                                )}
                              </For>
                              <Show when={props.renderRowActions}>
                                <TableCell>
                                  {props.renderRowActions!(row)}
                                </TableCell>
                              </Show>
                            </TableRow>
                          )
                        }}
                      </For>
                    </Show>
                  </TableBody>
                </Table>
              </Box>

              {/* Cards - Mobile */}
              <Box class="md:hidden flex flex-col gap-3">
                <Show when={tableData.length === 0}>
                  <Flex class="flex-col items-center justify-center py-12">
                    <Text class="text-muted-foreground">No results found</Text>
                  </Flex>
                </Show>
                <For each={tableData}>
                  {(row) => {
                    const rowId = props.getRowId ? props.getRowId(row) : (row as any).id
                    return (
                      <Box class="border rounded-lg p-4 bg-card">
                        <Flex class="items-start gap-3 mb-3">
                          <Show when={props.renderCell && props.renderCell(row, "image")}>
                            {props.renderCell!(row, "image")}
                          </Show>
                          <Flex class="flex-1 flex-col gap-1">
                            <Text class="font-medium">
                              {props.renderCell 
                                ? props.renderCell(row, "name")
                                : flexRender(props.columns[0]?.cell, { row })
                              }
                            </Text>
                            <Show when={props.renderRowActions}>
                              {props.renderRowActions!(row)}
                            </Show>
                          </Flex>
                        </Flex>
                        <Flex class="flex-col gap-2 text-sm">
                          <For each={props.columns.slice(1)}>
                            {(column) => (
                              <Flex class="justify-between">
                                <Text class="text-muted-foreground">
                                  {flexRender(column.header, { get row() { return {} } })}
                                </Text>
                                <Text>
                                  {props.renderCell 
                                    ? props.renderCell(row, column.id!)
                                    : flexRender(column.cell, { row })
                                  }
                                </Text>
                              </Flex>
                            )}
                          </For>
                        </Flex>
                      </Box>
                    )
                  }}
                </For>
              </Box>

              {/* Pagination */}
              <Flex class="flex-col sm:flex-row items-center justify-between gap-4 mt-auto">
                <Flex class="items-center gap-2 text-sm text-muted-foreground">
                  <Text>Showing</Text>
                  <select
                    class="h-8 px-2 rounded-md border border-input bg-background text-sm"
                    value={pageSize()}
                    onChange={(e) => handlePageSizeChange(parseInt(e.currentTarget.value))}
                  >
                    <For each={PAGE_SIZE_OPTIONS}>
                      {(size) => <option value={size}>{size}</option>}
                    </For>
                  </select>
                  <Text>of {total()} items</Text>
                </Flex>

                <Flex class="items-center gap-2">
                  <Show when={totalPages() > 1}>
                    <Pagination
                      class="gap-1"
                      count={totalPages()}
                      page={page() + 1}
                      onPageChange={(p) => handlePageChange(p - 1)}
                      itemComponent={(props) => (
                        <PaginationItem page={props.page}>
                          {props.page}
                        </PaginationItem>
                      )}
                      ellipsisComponent={() => <PaginationEllipsis />}
                    >
                      <PaginationPrevious />
                      <PaginationItems />
                      <PaginationNext />
                    </Pagination>
                  </Show>
                  
                  {/* Jump to page */}
                  <Flex class="items-center gap-2 ml-2 pl-2 border-l">
                    <Text class="text-sm text-muted-foreground">Go to</Text>
                    <input
                      type="number"
                      min="1"
                      max={totalPages()}
                      class="h-8 w-16 px-2 rounded-md border border-input bg-background text-sm text-center"
                      placeholder="#"
                      onKeyDown={(e) => {
                        if (e.key === "Enter") {
                          const value = parseInt(e.currentTarget.value)
                          if (value >= 1 && value <= totalPages()) {
                            handlePageChange(value - 1)
                            e.currentTarget.value = ""
                          }
                        }
                      }}
                    />
                  </Flex>
                </Flex>
              </Flex>
            </Box>
          )
        }}
      </QueryBoundary>
    </Query>
    </Box>
  )
}

function SortIndicator(props: { column: string; sorting: SortingState }) {
  const sort = () => props.sorting.find(s => s.id === props.column)
  return (
    <Show when={sort()}>
      <Text class="text-xs">
        {sort()?.desc ? "↓" : "↑"}
      </Text>
    </Show>
  )
}

function getVisiblePages(current: number, total: number): number[] {
  const delta = 2
  const range: number[] = []
  
  for (let i = Math.max(0, current - delta); i <= Math.min(total - 1, current + delta); i++) {
    range.push(i)
  }
  
  return range
}

function SearchIcon(props: { class?: string }) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      stroke-width="2"
      stroke-linecap="round"
      stroke-linejoin="round"
      class={props.class}
    >
      <circle cx="11" cy="11" r="8" />
      <path d="m21 21-4.3-4.3" />
    </svg>
  )
}
