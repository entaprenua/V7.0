import type { Component, ComponentProps } from "solid-js"
import { splitProps, mergeProps} from "solid-js"
 
import { cn } from "~/lib/utils"

type RadioProps = {
   "size"?: number
} & ComponentProps<"input">




const Radio: Component<RadioProps> = (rawProps) => {
   
   const props = mergeProps({
      size: 4,
   } satisfies RadioProps, rawProps)

   const [local, others ] = splitProps(props, ["class", "size"])


   return (
     <div>
        <input  
	  type="radio"
	  class={cn(`size-${local.size}`, local.class)}
	  {...others} 
	 />
      </div>
   )
 }

export type { RadioProps }
export { Radio }
