import { Show, splitProps, type JSX, createMemo } from "solid-js"
import { useRecommendations } from "./recommendations-context"
import {
  Carousel, CarouselContent, CarouselItem,
  CarouselPrevious, CarouselNext, CarouselDots,
} from "~/components/ui/carousel"
import { Collection, CollectionView, useCollectionItem } from "~/components/ui/collection"
import { cn } from "~/lib/utils"

export type RecommendationsCarouselProps = {
  autoplay?: boolean | { delay: number; stopOnInteraction?: boolean; stopOnMouseEnter?: boolean }
  orientation?: "horizontal" | "vertical"
  showDots?: boolean
  loop?: boolean
  class?: string
  children?: JSX.Element
}

const RecommendationsCarousel = (props: RecommendationsCarouselProps) => {
  const [local] = splitProps(props, [
    "autoplay", "orientation", "showDots", "loop", "class", "children"
  ])

  const carouselOpts = createMemo(() => ({
    loop: local.loop ?? true,
  } as any))

  return (
    <Carousel
      autoplay={local.autoplay}
      orientation={local.orientation ?? "horizontal"}
      showDots={local.showDots ?? true}
      opts={carouselOpts()}
      class={local.class}
    >
      <Show when={props.children} fallback={
        <RecommendationsCarouselContent>
          <RecommendationsCarouselItem />
        </RecommendationsCarouselContent>
      }>
        {props.children}
      </Show>
    </Carousel>
  )
}

export type RecommendationsCarouselContentProps = {
  class?: string
  children?: JSX.Element
}

const RecommendationsCarouselContent = (props: RecommendationsCarouselContentProps) => {
  const recommendations = useRecommendations()

  return (
    <CarouselContent class={cn("-ml-4", props.class)}>
      <Collection data={recommendations.products()}>
        <CollectionView>
          {props.children}
        </CollectionView>
      </Collection>
    </CarouselContent>
  )
}

export type RecommendationsCarouselItemProps = {
  basis?: string
  class?: string
  children?: JSX.Element
}

const RecommendationsCarouselItem = (props: RecommendationsCarouselItemProps) => {
  const [local, others] = splitProps(props, ["basis", "class", "children"])

  return (
    <CarouselItem class={cn("pl-4", local.basis ?? "basis-full", local.class)} {...others}>
      {local.children}
    </CarouselItem>
  )
}

export type RecommendationsCarouselNavigationProps = {
  class?: string
  children?: JSX.Element
}

const RecommendationsCarouselPrevious = (props: RecommendationsCarouselNavigationProps) => {
  const [local] = splitProps(props, ["class", "children"])
  return (
    <CarouselPrevious class={cn("absolute left-4 top-1/2 -translate-y-1/2 z-20", local.class)}>
      {local.children}
    </CarouselPrevious>
  )
}

const RecommendationsCarouselNext = (props: RecommendationsCarouselNavigationProps) => {
  const [local] = splitProps(props, ["class", "children"])
  return (
    <CarouselNext class={cn("absolute right-4 top-1/2 -translate-y-1/2 z-20", local.class)}>
      {local.children}
    </CarouselNext>
  )
}

export type RecommendationsCarouselDotsProps = {
  dotClass?: string
  showLabels?: boolean
  class?: string
}

const RecommendationsCarouselDots = (props: RecommendationsCarouselDotsProps) => {
  const [local] = splitProps(props, ["dotClass", "showLabels", "class"])
  return (
    <CarouselDots
      dotClass={local.dotClass}
      showLabels={local.showLabels}
      class={local.class}
    />
  )
}

export {
  RecommendationsCarousel,
  RecommendationsCarouselContent,
  RecommendationsCarouselItem,
  RecommendationsCarouselPrevious,
  RecommendationsCarouselNext,
  RecommendationsCarouselDots,
}
