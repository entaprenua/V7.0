# Recommendations Components Architecture

## Overview

This directory contains zero-code ready product recommendations components for the visual builder. Components are designed to be fully composable - users can include/exclude sections by simply adding/removing child components. They integrate with existing `Product` components for displaying individual products.

## Design Principles

1. **Zero-Code Ready** - Components work without manual setup; just drop them in and configure via props
2. **Composable** - Sections are separate components that can be included/excluded via children
3. **Auto-Fetching** - Components fetch their own data using storeId from context
4. **Auto-Detection** - Components auto-detect storeId from `useCurrentStoreId()` context
5. **Context-Based** - Uses `CollectionItemContext` from Collection for unified item iteration
6. **Layout Flexibility** - Multiple layout options (carousel, grid, row)
7. **Type Selection** - Users can choose which type of recommendations to display
8. **Product Integration** - Uses existing `Product` components for displaying items
9. **Empty-Safe** - Hides completely when no products exist (no empty state shown)

## Database Schema Alignment

### product_views (tracking)

| Column | Type | Description |
|--------|------|-------------|
| `id` | UUID | Primary key |
| `product_id` | UUID | FK to products |
| `user_id` | UUID | FK to users (nullable for guests) |
| `session_id` | VARCHAR(100) | Session identifier |
| `referrer` | VARCHAR(500) | Referrer URL |
| `user_agent` | VARCHAR(500) | Browser user agent |
| `viewed_at` | TIMESTAMPTZ | View timestamp |

### product_favorites (wishlist)

| Column | Type | Description |
|--------|------|-------------|
| `id` | UUID | Primary key |
| `product_id` | UUID | FK to products |
| `user_id` | UUID | FK to users |
| `created_at` | TIMESTAMPTZ | When added to favorites |

## Server API Alignment

### Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/v1/stores/{storeId}/recommendations` | Get product recommendations |
| POST | `/api/v1/stores/{storeId}/products/{id}/view` | Track product view |
| POST | `/api/v1/stores/{storeId}/products/{id}/favorite` | Add to favorites |
| DELETE | `/api/v1/stores/{storeId}/products/{id}/favorite` | Remove from favorites |

### Get Recommendations

```
GET /api/v1/stores/{storeId}/recommendations?type={type}&limit={limit}
```

**Query Parameters:**
| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| type | string | "personalized" | `personalized`, `popular`, `related`, `bought_together`, `newest` |
| limit | int | 10 | Number of products |

**Headers:**
- `X-Session-Id` - Optional session ID for personalized recommendations

**Response:**
```json
{
  "success": true,
  "data": {
    "products": [...],
    "source": "personalized",
    "fallback": "popular"
  }
}
```

## Directory Structure

```
src/components/ui/recommendations/
├── STRUCTURE.md                       # This file
├── index.ts                           # Barrel exports
├── recommendations-context.tsx         # Context + useRecommendations hook
├── recommendations-root.tsx            # RecommendationsRoot (data fetching)
├── recommendations-sections.tsx         # UI sections (title)
├── recommendations-carousel.tsx        # Carousel variant
├── recommendations-skeleton.tsx        # Loading states
└── recommendations-grid.tsx            # Grid layout (part of root)
```

## Recommendation Types

| Type | Description | Requires Auth |
|------|-------------|---------------|
| `personalized` | Based on user's view/purchase history | No (falls back to popular) |
| `popular` | Most ordered products in last 30 days | No |
| `related` | Products from same categories | No |
| `bought_together` | Frequently ordered together | No |
| `newest` | Most recently added products | No |

## useRecommendations Hook

The `useRecommendations` hook provides access to recommendations state and methods:

```typescript
const useRecommendations = () => {
  // Returns RecommendationContextValue
}
```

### RecommendationContextValue

```typescript
type RecommendationContextValue = {
  // Data
  recommendations: Accessor<{
    products: Product[]
    source: RecommendationSource | null
    fallback: RecommendationSource | null
  } | null>
  products: Accessor<Product[]>
  source: Accessor<RecommendationSource | null>
  fallback: Accessor<RecommendationSource | null>
  currentIndex: Accessor<number>
  
  // Actions
  setProducts: (products: Product[]) => void
  setSource: (source: RecommendationSource | null) => void
  setFallback: (fallback: RecommendationSource | null) => void
  setCurrentIndex: (index: number) => void
  next: () => void
  prev: () => void
  goTo: (index: number) => void
  clear: () => void
}
```

## Collection Integration

Recommendations uses the `Collection` component internally for item iteration, providing `CollectionItemContext`. This allows Product components inside Recommendations to automatically detect the current product.

### How It Works

```tsx
// RecommendationsCarouselContent
<CarouselContent>
  <Collection data={recommendations.products()}>  {/* No layout - custom rendering */}
    <CollectionView>
      {props.children}  {/* Users' carousel item content */}
    </CollectionView>
  </Collection>
</CarouselContent>

// Inside children - Product auto-detects from CollectionItemContext
<Product>
  <ProductImage />    // ← reads from CollectionItemContext
  <ProductName />    // ← reads from CollectionItemContext
  <ProductPrice />   // ← reads from CollectionItemContext
</Product>
```

The `<Product>` component uses `useCollectionItem()` to automatically detect the current item when inside Recommendations.

## Component Hierarchy

### Carousel Layout
```
RecommendationsRoot (fetches recommendations)
└── RecommendationsProvider (context)
    └── RecommendationsCarousel
        ├── RecommendationsCarouselContent
        │   └── Collection
        │       └── CollectionView
        │           └── RecommendationsCarouselItem
        │               └── Product (auto-detects from CollectionItemContext)
        │                   ├── ProductImage
        │                   ├── ProductName
        │                   └── ProductPrice
        ├── RecommendationsCarouselPrevious
        ├── RecommendationsCarouselNext
        └── RecommendationsCarouselDots
```

### Grid Layout
```
RecommendationsRoot
└── RecommendationsProvider
    └── RecommendationsCarousel
        └── RecommendationsCarouselContent
            └── RecommendationsGrid
                └── Collection
                    └── CollectionView
                        └── RecommendationsCarouselItem
                            └── Product
                                ├── ProductImage
                                ├── ProductName
                                └── ProductPrice
```

## Usage Examples

### Carousel

```tsx
<RecommendationsRoot type="personalized" limit={10}>
  <RecommendationsCarousel autoplay loop>
    <RecommendationsCarouselContent>
      <RecommendationsCarouselItem basis="basis-1/2 md:basis-1/3 lg:basis-1/4">
        <Product>
          <ProductImage class="rounded-lg aspect-square object-cover mb-2" />
          <ProductName class="font-medium text-sm line-clamp-1" />
          <ProductPrice />
        </Product>
      </RecommendationsCarouselItem>
    </RecommendationsCarouselContent>
    <RecommendationsCarouselPrevious />
    <RecommendationsCarouselNext />
    <RecommendationsCarouselDots />
  </RecommendationsCarousel>
</RecommendationsRoot>
```

### Grid

```tsx
<RecommendationsRoot type="newest" limit={12}>
  <RecommendationsTitle class="text-2xl font-bold mb-4" />
  <RecommendationsGrid layout="vertical-grid" columns={4} gap={4}>
    <Product>
      <ProductImage class="rounded-lg aspect-square object-cover mb-2" />
      <ProductName class="font-medium text-sm line-clamp-1" />
      <ProductPrice />
    </Product>
  </RecommendationsGrid>
</RecommendationsRoot>
```

### Row Layout

```tsx
<RecommendationsRoot type="bought_together" limit={6}>
  <RecommendationsTitle class="text-2xl font-bold mb-4" />
  <RecommendationsGrid layout="row" gap={4}>
    <Product>
      <Flex class="gap-4 items-center">
        <ProductImage class="w-24 h-24 rounded-lg object-cover flex-shrink-0" />
        <div class="flex-1 min-w-0">
          <ProductName class="font-medium line-clamp-1" />
          <ProductPrice class="text-primary font-bold" />
        </div>
      </Flex>
    </Product>
  </RecommendationsGrid>
</RecommendationsRoot>
```

### With Custom Product Content

```tsx
<RecommendationsRoot type="related" limit={8}>
  <RecommendationsTitle class="text-2xl font-bold mb-4" />
  <RecommendationsGrid layout="vertical-grid" columns={4} gap={6}>
    <Product>
      <div class="group cursor-pointer">
        <ProductImage class="rounded-lg aspect-square object-cover mb-3 group-hover:opacity-90 transition-opacity" />
        <ProductName class="font-semibold mb-1" />
        <Text variant="body2" class="text-muted-foreground line-clamp-2 mb-2">
          Product description here
        </Text>
        <ProductPrice class="text-lg font-bold text-primary" />
      </div>
    </Product>
  </RecommendationsGrid>
</RecommendationsRoot>
```

## Props Reference

### RecommendationsRoot (recommendations-root.tsx)

```typescript
type RecommendationsRootProps = {
  // Data source
  type?: RecommendationType           // Default: "personalized"
  limit?: number                       // Default: 10
  data?: RecommendationResponse        // Direct data (optional)
  
  // Query options
  queryKey?: unknown[]
  enabled?: boolean                   // Default: true
  
  // UI
  class?: string
  children?: JSX.Element
  errorFallback?: JSX.Element
  loadingFallback?: JSX.Element
}
```

**Note:** `storeId` is automatically inferred from `useCurrentStoreId()` context.

### RecommendationsTitle (recommendations-sections.tsx)

```typescript
type RecommendationsTitleProps = {
  class?: string
  level?: "h1" | "h2" | "h3" | "h4"  // Heading level, default: "h2"
  children?: JSX.Element
}
```

### RecommendationsCarousel (recommendations-carousel.tsx)

```typescript
type RecommendationsCarouselProps = {
  // Carousel options
  autoplay?: boolean | { delay: number; stopOnInteraction?: boolean; stopOnMouseEnter?: boolean }
  orientation?: "horizontal" | "vertical"
  showDots?: boolean                 // Default: true
  loop?: boolean                     // Default: true
  
  class?: string
  children?: JSX.Element
}
```

### RecommendationsCarouselContent (recommendations-carousel.tsx)

```typescript
type RecommendationsCarouselContentProps = {
  class?: string
  children?: JSX.Element
}
```

Uses `<Collection>` internally to iterate over products.

### RecommendationsCarouselItem (recommendations-carousel.tsx)

```typescript
type RecommendationsCarouselItemProps = {
  basis?: string                      // Tailwind basis class, default: "basis-full"
  class?: string
  children?: JSX.Element
}
```

**Basis classes for responsive display:**
- Mobile: `basis-1/2` (2 items visible)
- Tablet: `basis-1/3` (3 items visible)
- Desktop: `basis-1/4` (4 items visible)

```tsx
// Responsive carousel
<RecommendationsCarouselItem basis="basis-1/2 md:basis-1/3 lg:basis-1/4">
  {/* content */}
</RecommendationsCarouselItem>
```

### RecommendationsGrid (recommendations-root.tsx)

```typescript
type RecommendationsGridProps = {
  layout?: "column" | "row" | "vertical-grid" | "horizontal-grid" | "virtual"
  columns?: 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12
  gap?: 0 | 1 | 2 | 3 | 4 | 5 | 6 | 8 | 10 | 12
  class?: string
  children?: JSX.Element | ((item: Product, index: number) => JSX.Element)
}
```

### RecommendationsCarouselNavigationProps

```typescript
type RecommendationsCarouselNavigationProps = {
  class?: string
  children?: JSX.Element
}
```

### RecommendationsCarouselDotsProps

```typescript
type RecommendationsCarouselDotsProps = {
  dotClass?: string
  showLabels?: boolean
  class?: string
}
```

## API Functions

### recommendationsApi (lib/api/recommendations.ts)

```typescript
export const recommendationsApi = {
  // Get recommendations
  get: async (
    storeId: string,
    type: RecommendationType = "personalized",
    limit: number = 10,
    sessionId?: string
  ): Promise<RecommendationResponse>
  
  // Track product view
  trackView: async (
    storeId: string,
    productId: string,
    sessionId?: string
  ): Promise<{ tracked: boolean }>
  
  // Add to favorites
  addFavorite: async (
    storeId: string,
    productId: string,
    userId: string
  ): Promise<{ added: boolean }>
  
  // Remove from favorites
  removeFavorite: async (
    storeId: string,
    productId: string,
    userId: string
  ): Promise<{ removed: boolean }>
}
```

## Integration with Product Components

Recommendations use existing `Product` components for displaying each product. The Product component automatically detects the current item from `CollectionItemContext`:

```tsx
<Product>
  <ProductMedia />                    // Gallery of product images
  <ProductName class="font-medium" /> // Product name
  <ProductSku />                      // SKU label
  <ProductPrice class="text-lg font-bold" />
  <ProductComparePrice />
  <ProductStockBadge />
  <ProductAddToCartTrigger />
</Product>
```

**No explicit data passing needed** - Product components read from context automatically when inside Recommendations.

## Empty Handling

Recommendations automatically hide when there are no products to display:

```tsx
// In RecommendationsRoot
<Show when={local.data!.products.length > 0} fallback={null}>
  <RecommendationsProvider initialData={local.data!}>
    {/* children */}
  </RecommendationsProvider>
</Show>
```

This means:
- No empty state message displayed to users
- Section is completely hidden if no recommendations
- Consistent with industry standard (Amazon, Netflix, etc.)

## Display Type Mapping

| Layout Prop | Component Used |
|-------------|----------------|
| Carousel | `<RecommendationsCarousel>` (Embla-based) |
| Grid | `<RecommendationsGrid>` (Collection-based) |

## Loading & Error States

### Skeleton Components

- `RecommendationsSkeleton` - Main skeleton with 4 item placeholders

### Error Handling

- Network errors: Propagated to errorFallback
- 404 errors: Show empty (hidden)
- Failed to load: Error boundary

## Accessibility

- ARIA labels for navigation buttons
- Keyboard navigation (arrow keys for carousel)
- Screen reader announcements for loading states
- Focus management for interactive elements

## Performance Considerations

- TanStack Query for caching
- Lazy loading for product images
- Intersection Observer for viewport-based loading
- Debounced autoplay
