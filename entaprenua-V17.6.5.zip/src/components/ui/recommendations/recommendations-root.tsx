import { Show, splitProps, type JSX, createMemo } from "solid-js"
import { RecommendationsProvider, useRecommendations } from "./recommendations-context"
import { Query, QueryBoundary, useQueryState } from "~/components/ui/query"
import { Collection, CollectionView, type CollectionViewProps } from "~/components/ui/collection"
import { Flex } from "~/components/ui/flex"
import { Skeleton } from "~/components/ui/skeleton"
import { cn } from "~/lib/utils"
import { recommendationsApi, type RecommendationType, type RecommendationResponse } from "~/lib/api/recommendations"
import { useCurrentStoreId } from "~/lib/stores/store-context"
import type { Product } from "~/lib/types"

export type RecommendationsRootProps = {
  type?: RecommendationType
  limit?: number
  data?: RecommendationResponse
  queryKey?: unknown[]
  enabled?: boolean
  errorFallback?: JSX.Element
  loadingFallback?: JSX.Element
  class?: string
  children?: JSX.Element
}

const RecommendationsRoot = (props: RecommendationsRootProps) => {
  const [local, others] = splitProps(props, [
    "type", "limit", "data", "queryKey", "enabled", "errorFallback", "loadingFallback", "class", "children"
  ])

  const contextStoreId = useCurrentStoreId()

  const resolvedStoreId = createMemo(() => {
    return contextStoreId()
  })

  const hasStoreId = createMemo(() => !!resolvedStoreId())

  const queryFn = async () => {
    const sid = resolvedStoreId()
    if (!sid) return null
    return recommendationsApi.get(sid, local.type ?? "personalized", local.limit ?? 10)
  }

  const queryKey = createMemo(() => {
    const sid = resolvedStoreId()
    return local.queryKey ?? ["recommendations", local.type ?? "personalized", sid]
  })

  return (
    <Show when={local.data} fallback={
        <Show when={hasStoreId()} fallback={<RecommendationsSkeleton />}>
          <Query 
            queryFn={queryFn} 
            queryKey={queryKey()}
            enabled={local.enabled ?? true}
          >
            <QueryBoundary 
              loadingFallback={local.loadingFallback ?? <RecommendationsSkeleton />} 
              errorFallback={local.errorFallback}
            >{items => (
               <RecommendationsRootContent 
                  data={items as RecommendationResponse | undefined} 
                  class={local.class}
                >{local.children}
               </RecommendationsRootContent>
              )}
            </QueryBoundary>
           </Query>
        </Show>
      }>
      <Show when={local.data!.products.length > 0} fallback={null}>
        <RecommendationsProvider initialData={local.data!}>
          <div class={local.class} {...others as any}>{local.children}</div>
        </RecommendationsProvider>
      </Show>
    </Show>
  )
}

const RecommendationsRootContent = (props: { data?: RecommendationResponse; class?: string; children?: JSX.Element }) => {
  return (
    <Show when={props.data?.products && props.data.products.length > 0} fallback={null}>
      <RecommendationsProvider initialData={props.data}>
        <div class={props.class}>{props.children}</div>
      </RecommendationsProvider>
    </Show>
  )
}

export type RecommendationsGridProps = {
  class?: string
  children?: JSX.Element | ((item: Product, index: number) => JSX.Element)
  layout?: "column" | "row" | "vertical-grid" | "horizontal-grid" | "virtual"
  columns?: 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12
  gap?: 0 | 1 | 2 | 3 | 4 | 5 | 6 | 8 | 10 | 12
}

const RecommendationsGrid = (props: RecommendationsGridProps) => {
  const recommendations = useRecommendations()
  const items = createMemo(() => recommendations.products())
  const [local] = splitProps(props, ["class", "children", "layout", "columns", "gap"])
  
  return (
    <Collection 
      data={items()} 
      layout={local.layout ?? "vertical-grid"}
      columns={local.columns ?? 4}
      gap={local.gap ?? 4}
    >
      <CollectionView class={local.class}>
        {local.children}
      </CollectionView>
    </Collection>
  )
}

const RecommendationsSkeleton = (props: { class?: string }) => (
  <div class={cn("relative w-full", props.class)}>
    <Flex class="gap-4" wrap>
      {[1, 2, 3, 4].map(() => (
        <div class="flex-none w-64">
          <Skeleton class="h-48 w-full mb-2" />
          <Skeleton class="h-4 w-3/4 mb-1" />
          <Skeleton class="h-4 w-1/2" />
        </div>
      ))}
    </Flex>
  </div>
)

export {
  RecommendationsRoot,
  RecommendationsProvider,
  RecommendationsGrid,
  RecommendationsSkeleton,
  useRecommendations,
}
