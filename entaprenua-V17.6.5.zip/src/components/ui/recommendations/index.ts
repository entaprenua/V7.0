export {
  RecommendationsProvider,
  useRecommendations,
  type RecommendationContextValue,
  type RecommendationsProviderProps,
} from "./recommendations-context"

export {
  RecommendationsRoot,
  RecommendationsGrid,
  RecommendationsSkeleton,
  type RecommendationsRootProps,
  type RecommendationsGridProps,
} from "./recommendations-root"

export {
  RecommendationsTitle,
  type RecommendationsTitleProps,
} from "./recommendations-sections"

export {
  RecommendationsCarousel,
  RecommendationsCarouselContent,
  RecommendationsCarouselItem,
  RecommendationsCarouselPrevious,
  RecommendationsCarouselNext,
  RecommendationsCarouselDots,
  type RecommendationsCarouselProps,
  type RecommendationsCarouselContentProps,
  type RecommendationsCarouselItemProps,
  type RecommendationsCarouselNavigationProps,
  type RecommendationsCarouselDotsProps,
} from "./recommendations-carousel"

export {
  RecommendationsItemSkeleton,
} from "./recommendations-skeleton"
