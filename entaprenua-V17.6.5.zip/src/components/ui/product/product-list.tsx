import { Show, splitProps, type JSX, For, createEffect, createMemo } from "solid-js"
import { A } from "@solidjs/router"
import { Collection, CollectionView, CollectionEmpty, type CollectionViewProps, type CollectionLayoutMode, type CollectionColumnCount, type CollectionGapSize } from "../collection"
import { useQueryState } from "../query"
import { productsApi, type ProductFilters } from "~/lib/api/products"
import { useCurrentStoreId } from "~/lib/stores/store-context"
import type { Product, PagedResponse } from "~/lib/types"
import { ProductProvider, type ProductContextData } from "./product-context"

type ProductListProps = {
  storeId?: string
  categoryId?: string
  filters?: ProductFilters
  searchQuery?: string
  page?: number
  pageSize?: number
  queryKey?: unknown[]
  enabled?: boolean
  errorFallback?: JSX.Element
  loadingFallback?: JSX.Element
  layout?: CollectionLayoutMode
  columns?: CollectionColumnCount
  gap?: CollectionGapSize
  children?: JSX.Element
}

const ProductList = (props: ProductListProps) => {
  const [local] = splitProps(props, [
    "storeId",
    "categoryId",
    "filters",
    "searchQuery",
    "page",
    "pageSize",
    "queryKey",
    "enabled",
    "errorFallback",
    "loadingFallback",
    "layout",
    "columns",
    "gap",
    "children",
  ])

  const contextStoreId = useCurrentStoreId()

  const resolvedStoreId = createMemo(() => local.storeId ?? contextStoreId())

  const queryFn = async (): Promise<Product[] | null> => {
    const storeId = resolvedStoreId()
    if (!storeId) return null

    const page = local.page ?? 0
    const size = local.pageSize ?? 20

    let response: PagedResponse<Product> | null = null

    if (local.searchQuery) {
      response = await productsApi.search(storeId, local.searchQuery, page, size, local.filters)
    } else if (local.categoryId) {
      response = await productsApi.getByCategory(storeId, local.categoryId, page, size)
    } else {
      response = await productsApi.getAll(storeId, page, size, local.filters)
    }

    return response?.content ?? null
  }

  const key = local.searchQuery
    ? ["products", "search", resolvedStoreId(), local.searchQuery, local.filters]
    : local.categoryId
      ? ["products", "category", resolvedStoreId(), local.categoryId]
      : ["products", "list", resolvedStoreId(), local.filters]

  return (
    <Collection
      queryFn={queryFn}
      queryKey={local.queryKey ?? key}
      enabled={local.enabled ?? true}
      layout={local.layout}
      columns={local.columns}
      gap={local.gap}
      loadingFallback={local.loadingFallback ?? <DefaultProductListLoading />}
      errorFallback={local.errorFallback}
    >
      {local.children}
    </Collection>
  )
}

const DefaultProductListLoading = () => (
  <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
    <For each={[1, 2, 3, 4, 5, 6, 7, 8]}>
      {() => (
        <div class="animate-pulse space-y-3 p-4 border rounded-lg">
          <div class="h-48 bg-muted rounded-md" />
          <div class="h-4 bg-muted rounded w-3/4" />
          <div class="h-4 bg-muted rounded w-1/2" />
        </div>
      )}
    </For>
  </div>
)

type ProductListViewProps = {
  class?: string
  children?: JSX.Element
}

// Passed to ProductList(only shows when list is not null)
const ProductListView = (props: ProductListViewProps) => {
  const query = useQueryState()
  const products = createMemo((): Product[] => {
    return (query?.data as Product[]) ?? []
  })
  return (
    <CollectionView class={props.class}>
      {props.children}
    </CollectionView>
  )
}

/* Passsed to ProductList, only shows when product is null */
const ProductListEmptyView = (props: { class?: string; children?: JSX.Element }) => {
  return (
    <CollectionEmpty class={props.class}>
      {props.children ?? <DefaultEmptyMessage />}
    </CollectionEmpty>
  )
}

const DefaultEmptyMessage = () => (
  <div class="flex flex-col items-center justify-center min-h-[30vh] gap-2">
    <span class="text-muted-foreground text-lg">No products found</span>
  </div>
)


export { ProductList, ProductListView, ProductListEmptyView }
export type { ProductListProps, ProductListViewProps }
