const ProductSearch = (props) => {
  return (
    <Search
      itemComponent={props => (
        <Search.Item item={props.item}>
          <SearchItem.Label>
            <Product data={props.item}>
              {props.itemComponent/* Jsx component  ...user passed product primititves*/}
            </Product>
          </SearchItem.Label>
        </Search.Item>
      )}
      {...othersProps}
    >
      {props.children /*....Other search primitives from kobalte*/}
    </ProductSearch>
}

