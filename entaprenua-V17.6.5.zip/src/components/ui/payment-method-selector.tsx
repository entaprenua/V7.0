import { splitProps, For, Show, createContext, useContext, type JSX, createMemo } from "solid-js"
import { cn } from "~/lib/utils"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "./card"
import { Flex } from "./flex"
import { Text } from "./text"
import { Badge } from "./badge"

export type StripePaymentMethodType = 
  | 'card'
  | 'mpesa'
  | 'apple_pay'
  | 'google_pay'
  | 'ach_debit'
  | 'sepa_debit'
  | 'ideal'
  | 'bancontact'
  | 'sofort'
  | 'giropay'
  | 'eps'
  | 'p24'
  | 'alipay'
  | 'wechat_pay'
  | 'grabpay'
  | 'klarna'
  | 'afterpay_clearpay'
  | 'affirm'
  | 'us_bank_account'

type PaymentMethodCategory = 'cards' | 'wallets' | 'bank_transfers' | 'bnpl' | 'regional'

interface PaymentMethodInfo {
  id: StripePaymentMethodType
  name: string
  description: string
  icon: JSX.Element
  category: PaymentMethodCategory
  currencies: string[]
  regions: string[]
  popular?: boolean
}

const PaymentMethodIcons: Record<StripePaymentMethodType, JSX.Element> = {
  card: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" class="size-6">
      <rect x="2" y="5" width="20" height="14" rx="2" />
      <line x1="2" y1="10" x2="22" y2="10" />
      <line x1="6" y1="15" x2="10" y2="15" />
    </svg>
  ),
  mpesa: (
    <svg viewBox="0 0 24 24" fill="currentColor" class="size-6">
      <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 15h-2v-2h2v2zm0-4h-2V7h2v6zm4 4h-2v-2h2v2zm0-4h-2V7h2v6z"/>
    </svg>
  ),
  apple_pay: (
    <svg viewBox="0 0 24 24" fill="currentColor" class="size-6">
      <path d="M17.05 20.28c-.98.95-2.05.8-3.08.35-1.09-.46-2.09-.48-3.24 0-1.44.62-2.2.44-3.06-.35C2.79 15.25 3.51 7.59 9.05 7.31c1.35.07 2.29.74 3.08.8 1.18-.24 2.31-.93 3.57-.84 1.51.12 2.65.72 3.4 1.8-3.12 1.87-2.38 5.98.48 7.13-.57 1.5-1.31 2.99-2.53 4.09zM12.03 7.25c-.15-2.23 1.66-4.07 3.74-4.25.29 2.58-2.34 4.5-3.74 4.25z"/>
    </svg>
  ),
  google_pay: (
    <svg viewBox="0 0 24 24" fill="currentColor" class="size-6">
      <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 17.93c-3.95-.49-7-3.85-7-7.93 0-.62.08-1.21.21-1.79L9 15v1c0 1.1.9 2 2 2v1.93zm6.9-2.54c-.26-.81-1-1.39-1.9-1.39h-1v-3c0-.55-.45-1-1-1H8v-2h2c.55 0 1-.45 1-1V7h2c1.1 0 2-.9 2-2v-.41c2.93 1.19 5 4.06 5 7.41 0 2.08-.8 3.97-2.1 5.39z"/>
    </svg>
  ),
  ach_debit: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" class="size-6">
      <path d="M3 9h18M3 15h18M7 9v6M17 9v6M12 9v6" />
      <rect x="2" y="6" width="20" height="12" rx="1" />
    </svg>
  ),
  sepa_debit: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" class="size-6">
      <circle cx="12" cy="12" r="10" />
      <path d="M12 6v6l4 2" />
    </svg>
  ),
  ideal: (
    <svg viewBox="0 0 24 24" fill="currentColor" class="size-6">
      <circle cx="12" cy="12" r="10" />
      <path fill="white" d="M7 7h5a3 3 0 010 6H9v4H7V7zm2 2v2h3a1 1 0 000-2H9z"/>
    </svg>
  ),
  bancontact: (
    <svg viewBox="0 0 24 24" fill="currentColor" class="size-6">
      <rect x="2" y="4" width="20" height="16" rx="2" />
      <path fill="white" d="M5 8h6l-2 8H3l2-8zm8 0h6l-2 8h-6l2-8z"/>
    </svg>
  ),
  sofort: (
    <svg viewBox="0 0 24 24" fill="currentColor" class="size-6">
      <rect x="2" y="4" width="20" height="16" rx="2" />
      <text x="12" y="14" text-anchor="middle" fill="white" font-size="6" font-weight="bold">S</text>
    </svg>
  ),
  giropay: (
    <svg viewBox="0 0 24 24" fill="currentColor" class="size-6">
      <rect x="2" y="4" width="20" height="16" rx="2" />
      <text x="12" y="14" text-anchor="middle" fill="white" font-size="6" font-weight="bold">G</text>
    </svg>
  ),
  eps: (
    <svg viewBox="0 0 24 24" fill="currentColor" class="size-6">
      <rect x="2" y="4" width="20" height="16" rx="2" />
      <text x="12" y="14" text-anchor="middle" fill="white" font-size="6" font-weight="bold">EPS</text>
    </svg>
  ),
  p24: (
    <svg viewBox="0 0 24 24" fill="currentColor" class="size-6">
      <rect x="2" y="4" width="20" height="16" rx="2" />
      <text x="12" y="14" text-anchor="middle" fill="white" font-size="6" font-weight="bold">P24</text>
    </svg>
  ),
  alipay: (
    <svg viewBox="0 0 24 24" fill="currentColor" class="size-6">
      <path d="M21.4 15.6c-3.1-1.2-5.5-2.3-7.2-3.1.6-1.2 1.1-2.5 1.5-3.9h-4.2V7h5.2V5.5h-5.2V3H9.5v2.5H4.3V7h5.2v1.6H5.5v1.5h8.1c-.3 1-.7 1.9-1.1 2.7-2.3-.8-4.5-1.2-6.5-1.2-3.5 0-5.5 1.5-5.5 3.5 0 2.1 2 3.6 5.2 3.6 2.7 0 5-1 6.9-2.8 2.4 1.3 5.5 2.7 9.2 4.1l.6-1.4zM6 15.5c-2 0-3-.7-3-1.6s1-1.6 3-1.6c1.5 0 3.2.3 5 1-1.5 1.4-3.2 2.2-5 2.2z"/>
    </svg>
  ),
  wechat_pay: (
    <svg viewBox="0 0 24 24" fill="currentColor" class="size-6">
      <path d="M8.5 11a1.5 1.5 0 100-3 1.5 1.5 0 000 3zm7 0a1.5 1.5 0 100-3 1.5 1.5 0 000 3zM12 2C6.48 2 2 6.03 2 11c0 2.76 1.43 5.22 3.65 6.87L5 22l4.47-2.24c.82.16 1.67.24 2.53.24 5.52 0 10-4.03 10-9s-4.48-9-10-9z"/>
    </svg>
  ),
  grabpay: (
    <svg viewBox="0 0 24 24" fill="currentColor" class="size-6">
      <rect x="2" y="4" width="20" height="16" rx="2" />
      <text x="12" y="14" text-anchor="middle" fill="white" font-size="5" font-weight="bold">GRAB</text>
    </svg>
  ),
  klarna: (
    <svg viewBox="0 0 24 24" fill="currentColor" class="size-6">
      <rect x="2" y="4" width="20" height="16" rx="2" />
      <text x="12" y="14" text-anchor="middle" fill="white" font-size="5" font-weight="bold">Klarna</text>
    </svg>
  ),
  afterpay_clearpay: (
    <svg viewBox="0 0 24 24" fill="currentColor" class="size-6">
      <rect x="2" y="4" width="20" height="16" rx="2" />
      <text x="12" y="14" text-anchor="middle" fill="white" font-size="4" font-weight="bold">Afterpay</text>
    </svg>
  ),
  affirm: (
    <svg viewBox="0 0 24 24" fill="currentColor" class="size-6">
      <rect x="2" y="4" width="20" height="16" rx="2" />
      <text x="12" y="14" text-anchor="middle" fill="white" font-size="5" font-weight="bold">Affirm</text>
    </svg>
  ),
  us_bank_account: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" class="size-6">
      <path d="M3 21h18M3 10h18M5 6l7-3 7 3M4 10v11M20 10v11M8 14v3M12 14v3M16 14v3" />
    </svg>
  ),
}

const PAYMENT_METHODS: PaymentMethodInfo[] = [
  {
    id: 'card',
    name: 'Credit / Debit Card',
    description: 'Pay with Visa, Mastercard, Amex, and more',
    icon: PaymentMethodIcons.card,
    category: 'cards',
    currencies: ['USD', 'EUR', 'GBP', 'KES', 'AUD', 'CAD', 'JPY', '*'],
    regions: ['Global'],
    popular: true,
  },
  {
    id: 'apple_pay',
    name: 'Apple Pay',
    description: 'Fast and secure payment with Apple Pay',
    icon: PaymentMethodIcons.apple_pay,
    category: 'wallets',
    currencies: ['USD', 'EUR', 'GBP', 'AUD', 'CAD', '*'],
    regions: ['Global'],
    popular: true,
  },
  {
    id: 'google_pay',
    name: 'Google Pay',
    description: 'Quick checkout with Google Pay',
    icon: PaymentMethodIcons.google_pay,
    category: 'wallets',
    currencies: ['USD', 'EUR', 'GBP', 'AUD', 'CAD', '*'],
    regions: ['Global'],
    popular: true,
  },
  {
    id: 'mpesa',
    name: 'M-Pesa',
    description: 'Pay with M-Pesa mobile money',
    icon: PaymentMethodIcons.mpesa,
    category: 'regional',
    currencies: ['KES'],
    regions: ['Kenya'],
    popular: true,
  },
  {
    id: 'ach_debit',
    name: 'ACH Direct Debit',
    description: 'Pay directly from US bank account',
    icon: PaymentMethodIcons.ach_debit,
    category: 'bank_transfers',
    currencies: ['USD'],
    regions: ['United States'],
  },
  {
    id: 'sepa_debit',
    name: 'SEPA Direct Debit',
    description: 'Pay from European bank account',
    icon: PaymentMethodIcons.sepa_debit,
    category: 'bank_transfers',
    currencies: ['EUR'],
    regions: ['Europe'],
  },
  {
    id: 'ideal',
    name: 'iDEAL',
    description: 'Dutch online banking payment',
    icon: PaymentMethodIcons.ideal,
    category: 'bank_transfers',
    currencies: ['EUR'],
    regions: ['Netherlands'],
  },
  {
    id: 'bancontact',
    name: 'Bancontact',
    description: 'Belgian online banking payment',
    icon: PaymentMethodIcons.bancontact,
    category: 'bank_transfers',
    currencies: ['EUR'],
    regions: ['Belgium'],
  },
  {
    id: 'sofort',
    name: 'Sofort',
    description: 'German online banking payment',
    icon: PaymentMethodIcons.sofort,
    category: 'bank_transfers',
    currencies: ['EUR'],
    regions: ['Germany', 'Austria'],
  },
  {
    id: 'giropay',
    name: 'giropay',
    description: 'German bank transfer',
    icon: PaymentMethodIcons.giropay,
    category: 'bank_transfers',
    currencies: ['EUR'],
    regions: ['Germany'],
  },
  {
    id: 'eps',
    name: 'EPS',
    description: 'Austrian online banking',
    icon: PaymentMethodIcons.eps,
    category: 'bank_transfers',
    currencies: ['EUR'],
    regions: ['Austria'],
  },
  {
    id: 'p24',
    name: 'Przelewy24',
    description: 'Polish online banking',
    icon: PaymentMethodIcons.p24,
    category: 'bank_transfers',
    currencies: ['PLN'],
    regions: ['Poland'],
  },
  {
    id: 'alipay',
    name: 'Alipay',
    description: 'Chinese digital wallet',
    icon: PaymentMethodIcons.alipay,
    category: 'wallets',
    currencies: ['CNY', 'USD', 'EUR'],
    regions: ['China'],
  },
  {
    id: 'wechat_pay',
    name: 'WeChat Pay',
    description: 'Chinese mobile payment',
    icon: PaymentMethodIcons.wechat_pay,
    category: 'wallets',
    currencies: ['CNY', 'USD', 'EUR'],
    regions: ['China'],
  },
  {
    id: 'grabpay',
    name: 'GrabPay',
    description: 'Southeast Asian digital wallet',
    icon: PaymentMethodIcons.grabpay,
    category: 'wallets',
    currencies: ['SGD', 'MYR', 'PHP', 'IDR', 'VND', 'THB'],
    regions: ['Southeast Asia'],
  },
  {
    id: 'klarna',
    name: 'Klarna',
    description: 'Buy now, pay later',
    icon: PaymentMethodIcons.klarna,
    category: 'bnpl',
    currencies: ['USD', 'EUR', 'GBP'],
    regions: ['Global'],
    popular: true,
  },
  {
    id: 'afterpay_clearpay',
    name: 'Afterpay / Clearpay',
    description: 'Pay in 4 installments',
    icon: PaymentMethodIcons.afterpay_clearpay,
    category: 'bnpl',
    currencies: ['USD', 'AUD', 'NZD', 'GBP', 'CAD'],
    regions: ['US', 'Australia', 'UK', 'Canada', 'New Zealand'],
  },
  {
    id: 'affirm',
    name: 'Affirm',
    description: 'Flexible payment plans',
    icon: PaymentMethodIcons.affirm,
    category: 'bnpl',
    currencies: ['USD', 'CAD'],
    regions: ['United States', 'Canada'],
  },
]

const CATEGORY_INFO: Record<PaymentMethodCategory, { name: string; description: string }> = {
  cards: { name: 'Cards', description: 'Pay with your card' },
  wallets: { name: 'Digital Wallets', description: 'Fast checkout with digital wallets' },
  bank_transfers: { name: 'Bank Transfers', description: 'Pay directly from your bank' },
  bnpl: { name: 'Buy Now, Pay Later', description: 'Split your payment' },
  regional: { name: 'Regional', description: 'Local payment methods' },
}

type PaymentMethodSelectorContextValue = {
  selectedMethod: () => StripePaymentMethodType | null
  setSelectedMethod: (method: StripePaymentMethodType) => void
  currency: () => string
  setCurrency: (currency: string) => void
  availableMethods: () => PaymentMethodInfo[]
}

const PaymentMethodSelectorContext = createContext<PaymentMethodSelectorContextValue>()

export const usePaymentMethodSelector = () => {
  const ctx = useContext(PaymentMethodSelectorContext)
  if (!ctx) {
    throw new Error('usePaymentMethodSelector must be used within PaymentMethodSelector')
  }
  return ctx
}

type PaymentMethodSelectorProps = {
  class?: string
  currency?: string
  selectedMethod?: StripePaymentMethodType | null
  onMethodSelect?: (method: StripePaymentMethodType) => void
  onCurrencyChange?: (currency: string) => void
  allowedMethods?: StripePaymentMethodType[]
  showCategories?: boolean
  showPopular?: boolean
  children?: JSX.Element
}

export function PaymentMethodSelector(props: PaymentMethodSelectorProps) {
  const [local, others] = splitProps(props, [
    'class', 'currency', 'selectedMethod', 'onMethodSelect', 'onCurrencyChange',
    'allowedMethods', 'showCategories', 'showPopular', 'children'
  ])

  const selectedMethod = () => local.selectedMethod ?? null

  const currency = () => local.currency ?? 'USD'

  const availableMethods = () => {
    let methods = PAYMENT_METHODS
    
    if (local.allowedMethods) {
      methods = methods.filter(m => local.allowedMethods!.includes(m.id))
    }
    
    return methods
  }

  const setSelectedMethod = (method: StripePaymentMethodType) => {
    local.onMethodSelect?.(method)
  }

  const setCurrency = (curr: string) => {
    local.onCurrencyChange?.(curr)
  }

  const contextValue: PaymentMethodSelectorContextValue = {
    selectedMethod,
    setSelectedMethod,
    currency,
    setCurrency,
    availableMethods,
  }

  return (
    <PaymentMethodSelectorContext.Provider value={contextValue}>
      <div class={cn("space-y-4", local.class)} {...others}>
        {local.children}
      </div>
    </PaymentMethodSelectorContext.Provider>
  )
}

type PaymentMethodGridProps = {
  class?: string
  columns?: 1 | 2 | 3 | 4
}

export function PaymentMethodGrid(props: PaymentMethodGridProps) {
  const ctx = usePaymentMethodSelector()
  
  const gridCols = () => {
    switch (props.columns ?? 2) {
      case 1: return "grid-cols-1"
      case 2: return "grid-cols-1 md:grid-cols-2"
      case 3: return "grid-cols-1 md:grid-cols-2 lg:grid-cols-3"
      case 4: return "grid-cols-1 md:grid-cols-2 lg:grid-cols-4"
    }
  }

  const filteredMethods = createMemo(() => {
    const curr = ctx.currency()
    return ctx.availableMethods().filter(m => 
      m.currencies.includes(curr) || m.currencies.includes('*')
    )
  })

  return (
    <div class={cn("grid gap-3", gridCols(), props.class)}>
      <For each={filteredMethods()}>
        {(method) => (
          <PaymentMethodOption method={method} />
        )}
      </For>
    </div>
  )
}

type PaymentMethodOptionProps = {
  method: PaymentMethodInfo
  class?: string
}

export function PaymentMethodOption(props: PaymentMethodOptionProps) {
  const ctx = usePaymentMethodSelector()
  
  const isSelected = () => ctx.selectedMethod() === props.method.id
  
  const handleSelect = () => {
    ctx.setSelectedMethod(props.method.id)
  }

  return (
    <button
      type="button"
      onClick={handleSelect}
      class={cn(
        "flex items-start gap-3 p-4 rounded-lg border-2 text-left transition-all",
        "hover:border-primary/50 hover:bg-accent/50",
        isSelected() 
          ? "border-primary bg-primary/5 ring-2 ring-primary/20" 
          : "border-border",
        props.class
      )}
    >
      <div class={cn(
        "flex-shrink-0 p-2 rounded-lg",
        isSelected() ? "bg-primary text-primary-foreground" : "bg-muted"
      )}>
        {props.method.icon}
      </div>
      <div class="flex-1 min-w-0">
        <Flex class="items-center gap-2 mb-1">
          <Text class="font-medium">{props.method.name}</Text>
          <Show when={props.method.popular}>
            <Badge variant="secondary" class="text-xs">Popular</Badge>
          </Show>
        </Flex>
        <Text class="text-sm text-muted-foreground">{props.method.description}</Text>
        <Show when={props.method.regions.length > 0 && !props.method.regions.includes('Global')}>
          <Text class="text-xs text-muted-foreground mt-1">
            {props.method.regions.join(', ')}
          </Text>
        </Show>
      </div>
      <Show when={isSelected()}>
        <div class="flex-shrink-0">
          <svg class="size-5 text-primary" fill="currentColor" viewBox="0 0 20 20">
            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd" />
          </svg>
        </div>
      </Show>
    </button>
  )
}

type PaymentMethodCategoriesProps = {
  class?: string
}

export function PaymentMethodCategories(props: PaymentMethodCategoriesProps) {
  const ctx = usePaymentMethodSelector()
  
  const categories = createMemo(() => {
    const cats = new Map<PaymentMethodCategory, PaymentMethodInfo[]>()
    const curr = ctx.currency()
    
    for (const method of ctx.availableMethods()) {
      if (method.currencies.includes(curr) || method.currencies.includes('*')) {
        const existing = cats.get(method.category) ?? []
        existing.push(method)
        cats.set(method.category, existing)
      }
    }
    
    return cats
  })

  return (
    <div class={cn("space-y-6", props.class)}>
      <For each={Array.from(categories().entries())}>
        {([category, methods]) => (
          <div>
            <div class="mb-3">
              <Text class="font-medium">{CATEGORY_INFO[category].name}</Text>
              <Text class="text-sm text-muted-foreground">
                {CATEGORY_INFO[category].description}
              </Text>
            </div>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
              <For each={methods}>
                {(method) => <PaymentMethodOption method={method} />}
              </For>
            </div>
          </div>
        )}
      </For>
    </div>
  )
}

type PaymentMethodPopularProps = {
  class?: string
}

export function PaymentMethodPopular(props: PaymentMethodPopularProps) {
  const ctx = usePaymentMethodSelector()
  
  const popularMethods = createMemo(() => {
    const curr = ctx.currency()
    return ctx.availableMethods()
      .filter(m => 
        m.popular && (m.currencies.includes(curr) || m.currencies.includes('*'))
      )
  })

  return (
    <div class={cn("space-y-3", props.class)}>
      <Text class="font-medium">Popular Payment Methods</Text>
      <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
        <For each={popularMethods()}>
          {(method) => <PaymentMethodOption method={method} />}
        </For>
      </div>
    </div>
  )
}

type PaymentMethodSummaryProps = {
  class?: string
}

export function PaymentMethodSummary(props: PaymentMethodSummaryProps) {
  const ctx = usePaymentMethodSelector()
  
  const selectedMethodInfo = createMemo(() => {
    const selected = ctx.selectedMethod()
    return ctx.availableMethods().find(m => m.id === selected)
  })

  return (
    <Show when={selectedMethodInfo()}>
      <Card class={cn("bg-muted/50", props.class)}>
        <CardContent class="p-4">
          <Flex class="items-center gap-3">
            <div class="p-2 rounded-lg bg-primary text-primary-foreground">
              {selectedMethodInfo()!.icon}
            </div>
            <div>
              <Text class="font-medium">{selectedMethodInfo()!.name}</Text>
              <Text class="text-sm text-muted-foreground">
                {selectedMethodInfo()!.description}
              </Text>
            </div>
          </Flex>
        </CardContent>
      </Card>
    </Show>
  )
}

export { PAYMENT_METHODS, PaymentMethodIcons, CATEGORY_INFO }
export type { PaymentMethodInfo }
