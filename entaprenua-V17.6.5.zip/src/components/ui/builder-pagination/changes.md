- Added PaginationPageProvider to provide current page 
- changed styling of Pagination item from ""size-10 data-[current]:border",
   to  "size-10 data-[current]:rounded-full data-[current]:bg-blue-500"

