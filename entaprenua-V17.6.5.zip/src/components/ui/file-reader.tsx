import { splitProps } from "solid-js"
import { FileField, FileFieldTrigger, FileFieldHiddenInput } from "./file-field"

type FileReaderProps = {
  onChange?: (result: string | ArrayBuffer | null) => void
  readAs?: "text" | "dataUrl" | "arrayBuffer"
}

const FileReader = (props: FileReaderProps & Record<string, any>) => {
  const [local, others] = splitProps(props, ["onChange", "readAs"])

  const handleFileChange = (details: { acceptedFiles: File[] }) => {
    const file = details.acceptedFiles[0]
    if (file) {
      const reader = new (window.FileReader as any)()
      reader.onload = (e: ProgressEvent<FileReader>) => {
        local.onChange?.(e.target?.result ?? null)
      }
      if (local.readAs === "dataUrl") {
        reader.readAsDataURL(file)
      } else if (local.readAs === "arrayBuffer") {
        reader.readAsArrayBuffer(file)
      } else {
        reader.readAsText(file)
      }
    }
  }

  return <FileField onFileChange={handleFileChange} {...others} />
}

const FileReaderTrigger = FileFieldTrigger
const FileReaderHiddenInput = FileFieldHiddenInput

export { FileReader, FileReaderTrigger, FileReaderHiddenInput }
