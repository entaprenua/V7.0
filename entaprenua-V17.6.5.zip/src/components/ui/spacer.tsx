import type { Component, ComponentProps } from "solid-js"
import { splitProps } from "solid-js"

type SpacerProps = ComponentProps<"div"> & {
  width?: any,
  height?: any,
}

export const Spacer: Component<SpacerProps> = (props) => {
    const [local, others ] = splitProps(props, ["width", "height", "style"]) 

    return (
      <div
      style={{
        height: local.height,
	width: local.width,
	...local.style as object,
      }}
      {...others }
      />
   )
}
 

