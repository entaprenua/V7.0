import { Show, splitProps, type JSX, createEffect, createMemo } from "solid-js"
import { useHero } from "./hero-context"
import { HeroBackground, HeroContent, HeroTitle, HeroSubtitle, HeroDescription, HeroCtaPrimary, HeroCtaSecondary, useHeroItem } from "./hero-sections"
import { HeroSkeleton } from "./hero-skeleton"
import {
  Carousel, CarouselContent, CarouselItem,
  CarouselPrevious, CarouselNext, CarouselDots,
  useCarousel,
} from "../carousel"
import { Collection, CollectionItem, CollectionView, useCollectionItem } from "../collection"
import { cn } from "~/lib/utils"
import type { HeroItem } from "~/lib/types"

export type HeroCarouselProps = {
  autoplay?: boolean | { delay: number; stopOnInteraction?: boolean; stopOnMouseEnter?: boolean }
  orientation?: "horizontal" | "vertical"
  showDots?: boolean
  loop?: boolean
  displayType?: string
  autoplayInterval?: number
  showIndicators?: boolean
  class?: string
  children?: JSX.Element
}

const HeroCarousel = (props: HeroCarouselProps) => {
  const hero = useHero()
  const [local] = splitProps(props, [
    "autoplay", "orientation", "showDots", "loop",
    "displayType", "autoplayInterval", "showIndicators", "class", "children"
  ])

  const heroConfig = createMemo(() => hero?.hero())

  const resolvedAutoplay = createMemo(() => {
    if (local.autoplay !== undefined) return local.autoplay
    const h = heroConfig()
    if (h?.autoplay) {
      return { delay: h.autoplayInterval || 5000, stopOnInteraction: true, stopOnMouseEnter: true }
    }
    return false
  })

  const carouselOpts = createMemo(() => ({
    loop: local.loop ?? true,
  } as any))

  return (
    <Carousel
      autoplay={resolvedAutoplay()}
      orientation={local.orientation ?? "horizontal"}
      showDots={local.showDots ?? heroConfig()?.showIndicators ?? true}
      opts={carouselOpts()}
      class={local.class}
    >
      <Show when={props.children} fallback={
        <HeroCarouselContent>
          <HeroCarouselItem />
        </HeroCarouselContent>
      }>
        {props.children}
      </Show>
    </Carousel>
  )
}

export type HeroCarouselContentProps = {
  class?: string
  children?: JSX.Element
}

const HeroCarouselContent = (props: HeroCarouselContentProps) => {
  const hero = useHero()
  const heroItems = createMemo(() => hero?.items() ?? [])

  return (
    <CarouselContent class={cn("-ml-4", props.class)}>
      <Collection data={heroItems()}>
        <CollectionView>
          {props.children}
        </CollectionView>
      </Collection>
    </CarouselContent>
  )
}

export type HeroCarouselItemProps = {
  aspectRatio?: string
  maxHeight?: number
  class?: string
  children?: JSX.Element
}

const HeroCarouselItem = (props: HeroCarouselItemProps) => {
  const hero = useHero()
  const carousel = useCarousel()
  const collectionItem = useCollectionItem()
  const [local, others] = splitProps(props, ["aspectRatio", "maxHeight", "class", "children"])

  const item = createMemo(() => {
    if (collectionItem?.item) {
      return collectionItem.item as HeroItem
    }
    return hero?.items()[carousel.selectedIndex()] ?? null
  })

  const bgStyle = createMemo(() => {
    const i = item()
    if (!i) return {}

    if (i.backgroundType === 'gradient' && i.backgroundGradient) {
      return { background: i.backgroundGradient }
    }
    if (i.backgroundType === 'color' && i.backgroundColor) {
      return { 'background-color': i.backgroundColor }
    }
    if (i.backgroundType === 'image' && i.backgroundImageUrl) {
      return {
        'background-image': `url(${i.backgroundImageUrl})`,
        'background-size': 'cover',
        'background-position': 'center',
      }
    }
    return {}
  })

  const positionClass = createMemo(() => {
    const i = item()
    const pos = i?.contentPosition ?? 'center'
    const map: Record<string, string> = {
      'top-left': 'items-start justify-start text-left',
      'top-center': 'items-start justify-center text-center',
      'top-right': 'items-start justify-end text-right',
      'center-left': 'items-center justify-start text-left',
      'center': 'items-center justify-center text-center',
      'center-right': 'items-center justify-end text-right',
      'bottom-left': 'items-end justify-start text-left',
      'bottom-center': 'items-end justify-center text-center',
      'bottom-right': 'items-end justify-end text-right',
    }
    return map[pos] ?? 'items-center justify-center text-center'
  })

  return (
    <Show when={item()}>
      <CarouselItem class="pl-4">
        <div
          class={cn("relative w-full h-full overflow-hidden", local.class)}
          style={{
            'aspect-ratio': local.aspectRatio ?? '16/9',
            'max-height': local.maxHeight ? `${local.maxHeight}px` : undefined,
          }}
          {...others}
        >
          <div class="absolute inset-0" style={bgStyle()}>
            <Show when={item()!.backgroundType === 'image' && item()!.overlayColor}>
              <div
                class="absolute inset-0"
                style={{
                  'background-color': item()!.overlayColor!,
                  opacity: Number(item()!.overlayOpacity ?? 0.3)
                }}
              />
            </Show>
          </div>

          <div class={cn("relative z-10 p-8 h-full flex", positionClass())}>
            {local.children ?? (
              <>
                <Show when={item()!.subtitle}>
                  <p class="text-sm uppercase tracking-wider mb-2" style={{ color: item()!.subtitleColor ?? 'white' }}>
                    {item()!.subtitle}
                  </p>
                </Show>
                <Show when={item()!.title}>
                  <p class="text-3xl md:text-5xl font-bold mb-4" style={{ color: item()!.titleColor ?? 'white' }}>
                    {item()!.title}
                  </p>
                </Show>
                <Show when={item()!.description}>
                  <p class="text-lg max-w-xl mb-6" style={{ color: item()!.descriptionColor ?? 'white' }}>
                    {item()!.description}
                  </p>
                </Show>
                <div class="flex gap-3">
                  <Show when={item()!.ctaText && item()!.ctaUrl}>
                    <HeroCtaPrimary />
                  </Show>
                  <Show when={item()!.ctaSecondaryText && item()!.ctaSecondaryUrl}>
                    <HeroCtaSecondary />
                  </Show>
                </div>
              </>
            )}
          </div>
        </div>
      </CarouselItem>
    </Show>
  )
}

export type HeroCarouselNavigationProps = {
  class?: string
  children?: JSX.Element
}

const HeroCarouselPrevious = (props: HeroCarouselNavigationProps) => {
  const [local] = splitProps(props, ["class", "children"])
  return (
    <CarouselPrevious class={cn("absolute left-4 top-1/2 -translate-y-1/2 z-20", local.class)}>
      {local.children}
    </CarouselPrevious>
  )
}

const HeroCarouselNext = (props: HeroCarouselNavigationProps) => {
  const [local] = splitProps(props, ["class", "children"])
  return (
    <CarouselNext class={cn("absolute right-4 top-1/2 -translate-y-1/2 z-20", local.class)}>
      {local.children}
    </CarouselNext>
  )
}

export type HeroCarouselDotsProps = {
  dotClass?: string
  showLabels?: boolean
  class?: string
}

const HeroCarouselDots = (props: HeroCarouselDotsProps) => {
  const [local] = splitProps(props, ["dotClass", "showLabels", "class"])
  return (
    <CarouselDots
      dotClass={local.dotClass}
      showLabels={local.showLabels}
      class={local.class}
    />
  )
}

export {
  HeroCarousel,
  HeroCarouselContent,
  HeroCarouselItem,
  HeroCarouselPrevious,
  HeroCarouselNext,
  HeroCarouselDots,
}
