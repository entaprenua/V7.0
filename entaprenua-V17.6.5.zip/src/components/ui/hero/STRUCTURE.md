# Hero Components Architecture

## Overview

This directory contains zero-code ready hero/banner components for the visual builder. Components are designed to be fully composable - users can include/exclude sections by simply adding/removing child components.

## Design Principles

1. **Zero-Code Ready** - All components work without manual setup; just drop them in and configure via props
2. **Composable** - Sections are separate components that can be included/excluded via children
3. **Auto-Fetching** - Components fetch their own data when given storeId/heroId
4. **Auto-Detection** - Sections automatically detect the correct hero item based on context (carousel, collection, or active item)
5. **Context-Based** - Uses `CollectionItemContext` from Collection for unified item iteration
6. **Enterprise-Ready** - Full TypeScript types, error handling, loading states, accessibility
7. **Server-Aligned** - All server endpoints and DB columns are supported
8. **Empty-Safe** - Hides when no items exist

## Database Schema Alignment

### heroes table

| Column | Type | Description |
|--------|------|-------------|
| `id` | UUID | Primary key |
| `store_id` | UUID | FK to stores |
| `name` | VARCHAR(100) | Hero section name |
| `display_type` | VARCHAR(30) | carousel, grid, stack, fade, slide |
| `autoplay` | BOOLEAN | Auto-advance slides |
| `autoplay_interval` | INT | Milliseconds between slides |
| `show_indicators` | BOOLEAN | Show dots/pagination |
| `show_navigation` | BOOLEAN | Show prev/next arrows |
| `aspect_ratio` | VARCHAR(20) | CSS aspect-ratio |
| `max_height` | INT | Max height in pixels |
| `gap` | INT | Gap between items |
| `is_active` | BOOLEAN | Active status |
| `starts_at` | TIMESTAMPTZ | Schedule start |
| `ends_at` | TIMESTAMPTZ | Schedule end |
| `metadata` | JSONB | Custom metadata |

### hero_items table

| Column | Type | Description |
|--------|------|-------------|
| `id` | UUID | Primary key |
| `hero_id` | UUID | FK to heroes |
| `sort_order` | INT | Display order |
| `background_type` | VARCHAR(20) | image, video, color, gradient |
| `background_image_url` | TEXT | Image URL |
| `background_image_alt` | TEXT | Alt text |
| `background_video_url` | TEXT | Video URL |
| `background_color` | VARCHAR(20) | Solid color |
| `background_gradient` | TEXT | CSS gradient |
| `overlay_color` | VARCHAR(20) | Overlay color |
| `overlay_opacity` | DECIMAL(3,2) | 0.00-0.99 |
| `title` | TEXT | Main title |
| `title_color` | VARCHAR(20) | Title text color |
| `subtitle` | TEXT | Subtitle text |
| `subtitle_color` | VARCHAR(20) | Subtitle color |
| `description` | TEXT | Description text |
| `description_color` | VARCHAR(20) | Description color |
| `content_position` | VARCHAR(20) | Flex alignment |
| `text_alignment` | VARCHAR(10) | Text align |
| `cta_text` | VARCHAR(100) | Primary CTA text |
| `cta_url` | TEXT | Primary CTA URL |
| `cta_style` | VARCHAR(30) | primary, outline, ghost |
| `cta_target` | VARCHAR(10) | _self, _blank |
| `cta_secondary_text` | VARCHAR(100) | Secondary CTA text |
| `cta_secondary_url` | TEXT | Secondary CTA URL |
| `cta_secondary_style` | VARCHAR(30) | Secondary CTA style |
| `cta_secondary_target` | VARCHAR(10) | Secondary CTA target |
| `mobile_background_image_url` | TEXT | Mobile image |
| `mobile_content_position` | VARCHAR(20) | Mobile position |
| `hide_on_mobile` | BOOLEAN | Hide on mobile |
| `hide_on_desktop` | BOOLEAN | Hide on desktop |
| `starts_at` | TIMESTAMPTZ | Schedule start |
| `ends_at` | TIMESTAMPTZ | Schedule end |
| `is_active` | BOOLEAN | Active status |
| `metadata` | JSONB | Custom metadata |

## Server API Alignment

### Endpoints (from heroesApi)

| Endpoint | Usage |
|----------|-------|
| `GET /stores/:storeId/heroes` | List all heroes for store |
| `GET /stores/:storeId/heroes/active` | Get active heroes |
| `GET /heroes/:id` | Get hero by ID |
| `POST /stores/:storeId/heroes` | Create hero |
| `PUT /heroes/:id` | Update hero |
| `DELETE /heroes/:id` | Delete hero |

## Directory Structure

```
components/ui/hero/
├── STRUCTURE.md              # This file
├── index.ts                  # Barrel exports
├── hero-context.tsx          # React context for hero state + useHero hook
├── hero-root.tsx             # HeroRoot, HeroItems, HeroItem components
├── hero-sections.tsx         # All hero section components + useHeroItem hook
├── hero-skeleton.tsx         # Loading skeleton components
└── hero-carousel.tsx         # Hero-specific carousel components
```

## useHeroItem Hook

The `useHeroItem` hook provides automatic item detection for hero sections. It checks contexts in the following priority order:

```typescript
const useHeroItem = () => {
  const hero = useHero()
  const collectionItem = useCollectionItem()  // From CollectionItemContext
  const carousel = useCarousel()

  return createMemo(() => {
    // 1. CollectionItem context (HeroItems iteration via Collection)
    if (collectionItem?.item) {
      return collectionItem.item as HeroItem
    }
    // 2. Carousel context (fallback)
    if (carousel) {
      return hero?.items()[carousel.selectedIndex()] ?? hero?.activeItem() ?? null
    }
    // 3. Default to active item
    return hero?.activeItem() ?? null
  })
}
```

### Context Priority

| Priority | Context Source | When Used |
|---------|---------------|-----------|
| 1 | `CollectionItem` (from Collection) | Inside `HeroItems` (grid/stack layouts) |
| 2 | Carousel selected index | Inside `HeroCarouselItem` |
| 3 | `activeItem` | Default fallback |

### How Collection Integration Works

`HeroCarouselContent` and `HeroItems` use the `Collection` component internally:

```tsx
// HeroCarouselContent
<CarouselContent>
  <Collection data={heroItems()}>      {/* No layout - custom rendering */}
    <CollectionView>
      {props.children}                {/* Users' carousel item content */}
    </CollectionView>
  </Collection>
</CarouselContent>

// HeroItems
<Collection data={items()} layout="column">
  <CollectionView>
    {local.children}
  </CollectionView>
</Collection>
```

The `CollectionView` component wraps children in `CollectionItem`, which provides `CollectionItemContext`. Hero sections use `useCollectionItem()` to access the current item.

## Component Hierarchy

### HeroItems Layout (Grid/Stack)
```
HeroRoot (fetches hero by ID or store)
└── HeroProvider (context)
    └── HeroItems
        └── Collection (provides context)
            └── CollectionView
                └── CollectionItem (per item - provides CollectionItemContext)
                    └── HeroItem
                        ├── HeroBackground     ← useHeroItem() → CollectionItem
                        ├── HeroContent
                        │   ├── HeroTitle
                        │   ├── HeroSubtitle
                        │   ├── HeroDescription
                        │   ├── HeroCtaPrimary
                        │   └── HeroCtaSecondary
```

### Carousel Layout
```
HeroRoot
└── HeroProvider
    └── HeroCarousel
        ├── HeroCarouselContent
        │   └── Collection
        │       └── CollectionView
        │           └── HeroCarouselItem
        │               ├── HeroBackground     ← useHeroItem() → CollectionItem
        │               └── HeroContent
        │                   ├── HeroTitle
        │                   ├── HeroSubtitle
        │                   ├── HeroDescription
        │                   ├── HeroCtaPrimary
        │                   └── HeroCtaSecondary
        ├── HeroCarouselPrevious
        ├── HeroCarouselNext
        └── HeroCarouselDots
```

### Single Hero (Auto-Detect)
```
HeroRoot
└── HeroProvider
    └── HeroItem (uses activeItem)
        ├── HeroBackground     ← useHeroItem() → activeItem
        ├── HeroContent
        │   ├── HeroTitle
        │   └── ...
```

## Usage Examples

### Grid Layout (HeroItems)

```tsx
<HeroRoot storeId="123">
  <HeroItems layout="vertical-grid" columns={2} gap={4}>
    <HeroItem>
      <HeroBackground />
      <HeroContent contentPosition="center">
        <HeroTitle class="text-2xl font-bold" />
        <HeroCtaPrimary />
      </HeroContent>
    </HeroItem>
  </HeroItems>
</HeroRoot>
```

### Stack Layout (HeroItems)

```tsx
<HeroRoot storeId="123">
  <HeroItems layout="column" gap={6}>
    <HeroItem aspectRatio="21/9">
      <HeroBackground />
      <HeroContent contentPosition="center">
        <HeroTitle class="text-3xl font-bold" />
        <HeroDescription />
        <HeroCtaPrimary />
      </HeroContent>
    </HeroItem>
  </HeroItems>
</HeroRoot>
```

### Carousel Layout

```tsx
<HeroRoot storeId="123">
  <HeroCarousel autoplay>
    <HeroCarouselContent>
      <HeroCarouselItem>
        <HeroBackground />
        <HeroContent>
          <HeroSubtitle />
          <HeroTitle />
          <HeroDescription />
          <HeroCtaPrimary />
          <HeroCtaSecondary />
        </HeroContent>
      </HeroCarouselItem>
    </HeroCarouselContent>
    <HeroCarouselPrevious />
    <HeroCarouselNext />
    <HeroCarouselDots />
  </HeroCarousel>
</HeroRoot>
```

### Auto-Detect (Single Hero)

The simplest usage - hero sections auto-detect which item to show:

```tsx
<HeroRoot storeId="123">
  <HeroItem>
    <HeroBackground />
    <HeroContent contentPosition="center">
      <HeroSubtitle />
      <HeroTitle class="text-4xl font-bold mb-4" />
      <HeroDescription class="text-lg mb-6" />
      <HeroCtaPrimary />
      <HeroCtaSecondary />
    </HeroContent>
  </HeroItem>
</HeroRoot>
```

### Inline Data

```tsx
<HeroRoot 
  data={{
    id: "1",
    storeId: "123",
    name: "Main Hero",
    displayType: "carousel",
    items: [
      {
        id: "1",
        heroId: "1",
        title: "Welcome",
        ctaText: "Get Started",
        // ...
      }
    ]
  }}
>
  <HeroItem>
    <HeroTitle />
    <HeroCtaPrimary />
  </HeroItem>
</HeroRoot>
```

### Custom Carousel

```tsx
<HeroCarousel
  autoplay={{ delay: 5000 }}
  showDots={true}
  aspectRatio="16/9"
  maxHeight={600}
>
  <HeroCarouselContent>
    <HeroCarouselItem>
      <HeroBackground />
      <HeroContent contentPosition="center">
        <HeroTitle class="text-4xl font-bold" />
        <HeroCtaPrimary ctaText="Shop Now" />
      </HeroContent>
    </HeroCarouselItem>
  </HeroCarouselContent>
  <HeroCarouselPrevious />
  <HeroCarouselNext />
  <HeroCarouselDots />
</HeroCarousel>
```

## Props Reference

### HeroRoot (hero-root.tsx)

```typescript
type HeroRootProps = {
  // Data source
  heroId?: string           // Fetch by ID
  storeId?: string          // Fetch active hero for store
  data?: Hero               // Direct data passing
  
  // Query options
  queryKey?: unknown[]
  enabled?: boolean
  
  // UI options
  class?: string
  children?: JSX.Element
  errorFallback?: JSX.Element
  loadingFallback?: JSX.Element
}
```

### HeroItems (hero-root.tsx)

```typescript
type HeroItemsViewProps = {
  class?: string
  children?: JSX.Element | ((item: HeroItemType, index: number) => JSX.Element)
  layout?: "column" | "row" | "vertical-grid" | "horizontal-grid" | "virtual"
  columns?: 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12
  gap?: 0 | 1 | 2 | 3 | 4 | 5 | 6 | 8 | 10 | 12
}
```

### HeroItem (hero-root.tsx)

```typescript
type HeroItemProps = {
  item?: HeroItemType        // Explicit item (optional)
  aspectRatio?: string
  maxHeight?: number
  class?: string
  children?: JSX.Element
}
```

### Section Components (hero-sections.tsx)

All section components accept:

```typescript
type HeroSectionProps = {
  class?: string             // CSS classes
  label?: string             // Override display text
  children?: JSX.Element     // Override content
}
```

#### Available Sections

| Component | Displays |
|-----------|----------|
| `HeroBackground` | Background image/color/gradient with overlay |
| `HeroContent` | Container with positioning |
| `HeroTitle` | Title text with color |
| `HeroSubtitle` | Subtitle text with color |
| `HeroDescription` | Description text with color |
| `HeroCtaPrimary` | Primary CTA button |
| `HeroCtaSecondary` | Secondary CTA button |

## HeroCarousel Components (hero-carousel.tsx)

### HeroCarousel

```typescript
type HeroCarouselProps = {
  // Carousel options
  autoplay?: boolean | { delay: number; stopOnInteraction?: boolean; stopOnMouseEnter?: boolean }
  orientation?: "horizontal" | "vertical"
  showDots?: boolean
  loop?: boolean
  
  // Layout
  aspectRatio?: string
  maxHeight?: number
  gap?: number
  
  // Hero config (optional, uses HeroContext if not provided)
  displayType?: string
  autoplayInterval?: number
  showIndicators?: boolean
  showNavigation?: boolean
  
  class?: string
  children?: JSX.Element
}
```

### HeroCarouselContent

```typescript
type HeroCarouselContentProps = {
  class?: string
  children?: JSX.Element
}
```

Uses `<Collection>` internally to iterate over hero items. Children are rendered for each item via `CollectionView`.

```tsx
<HeroCarouselContent>
  {props.children}  // Rendered for each item
</HeroCarouselContent>
```

### HeroCarouselItem

```typescript
type HeroCarouselItemProps = {
  item?: HeroItem            // Hero item data (uses CollectionItemContext if not provided)
  aspectRatio?: string
  maxHeight?: number
  class?: string
  children?: JSX.Element
}
```

Note: `aspectRatio` and `maxHeight` are used for styling the item container.
```

### HeroCarouselNavigationProps

```typescript
type HeroCarouselNavigationProps = {
  class?: string
  children?: JSX.Element
}
```

### HeroCarouselDotsProps

```typescript
type HeroCarouselDotsProps = {
  dotClass?: string
  showLabels?: boolean
  class?: string
}
```

## Display Type Mapping

| displayType | Component Used | Description |
|-------------|----------------|-------------|
| `carousel` | `<HeroCarousel>` | Embla-based sliding carousel |
| `grid` | `<HeroItems layout="vertical-grid">` | Grid layout |
| `stack` | `<HeroItems layout="column">` | Vertical stack |
| `fade` | `<HeroCarousel>` with fade option | Fade transition |
| `slide` | `<HeroCarousel>` with slide option | Slide transition (default) |

## Hero Config to Carousel Props Mapping

| Hero Field | Carousel Prop |
|-----------|---------------|
| `autoplay` | `autoplay: { delay: autoplayInterval }` |
| `autoplayInterval` | `autoplay.delay` |
| `showNavigation` | Show `<HeroCarouselPrevious/Next>` |
| `showIndicators` | Show `<HeroCarouselDots>` |
| `aspectRatio` | CSS `aspect-ratio` |
| `maxHeight` | CSS `max-height` |
| `gap` | Collection `gap` option |
| `displayType === 'fade'` | Carousel `opts={{ fade: true }}` |

## Context API

### HeroContextValue

```typescript
type HeroContextValue = {
  // Data
  hero: Hero | null
  items: HeroItem[]
  activeItem: HeroItem | null
  currentIndex: number
  
  // Navigation
  setCurrentIndex: (index: number) => void
  next: () => void
  prev: () => void
  goTo: (index: number) => void
  
  // Actions
  setHero: (hero: Hero | null) => void
  setItems: (items: HeroItem[]) => void
  addItem: (item: HeroItem) => void
  removeItem: (id: string) => void
  clear: () => void
}
```

## Loading & Error States

### Skeleton Components

- `HeroSkeleton` - Single hero skeleton
- `HeroItemSkeleton` - Hero item skeleton

### Empty Handling

Hero components automatically hide when there are no items to display. This is handled at the `HeroRoot` level:

```tsx
// HeroRootContent checks for items before rendering
<Show when={props.data?.items && props.data.items.length > 0} fallback={null}>
  <HeroProvider initialHero={props.data}>
    {/* children */}
  </HeroProvider>
</Show>
```

This means:
- No loading state shown when hero has no items
- No empty state message displayed
- Section is completely hidden if empty

### Error Handling

- Network errors: Show retry button
- 404 errors: Show "Hero not found"

## Accessibility

- ARIA labels for navigation buttons
- Keyboard navigation (arrow keys for carousel)
- Screen reader announcements for slide changes
- Focus management for interactive elements

## Performance Considerations

- TanStack Query for caching
- Lazy loading for background images
- Intersection Observer for viewport-based loading
- Debounced autoplay

## Migration from Old Components

Old components (hero.tsx, hero-context.tsx at root UI level) are deprecated.

```tsx
// OLD (deprecated)
<HeroProvider initialHero={heroData}>
  <Hero>
    <HeroItems />
  </Hero>
</HeroProvider>

// NEW
<HeroRoot data={heroData}>
  <HeroItem>
    <HeroBackground />
    <HeroContent />
  </HeroItem>
</HeroRoot>
```
