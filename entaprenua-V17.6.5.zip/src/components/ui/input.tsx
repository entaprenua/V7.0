import { splitProps, Component, JSX } from "solid-js";
import { clsx } from "clsx";

interface InputProps extends JSX.InputHTMLAttributes<HTMLInputElement> {
  error?: boolean;
}

export const Input: Component<InputProps> = (props) => {
  const [local, others] = splitProps(props, ["error", "class"]);

  return (
    <input
      class={clsx(
        "flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50",
        local.error && "border-red-500",
        local.class
      )}
      {...others}
    />
  );
};
