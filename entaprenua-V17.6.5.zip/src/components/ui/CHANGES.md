# UI Components Change Log

## 2026-02-22

### New Components

#### `carousel/` - Embla-based Carousel

Full-featured carousel with autoplay, navigation, and accessibility support.

```tsx
<Carousel autoplay={{ delay: 3000 }}>
  <CarouselContent>
    <CarouselItem>Slide 1</CarouselItem>
    <CarouselItem>Slide 2</CarouselItem>
  </CarouselContent>
  <CarouselPrevious />
  <CarouselNext />
  <CarouselDots />
</Carousel>
```

**Exports:**
- `Carousel` - Main context provider
- `CarouselContent` - Overflow wrapper
- `CarouselItem` - Individual slide
- `CarouselPrevious` / `CarouselNext` - Navigation buttons
- `CarouselDots` - Dot navigation
- `useCarousel` - Access carousel context
- Types: `CarouselApi`, `CarouselOptionsType`, `CarouselAutoplayOptions`, `CarouselContextValue`

**Features:**
- Horizontal/vertical orientation
- Autoplay with configurable delay
- Keyboard navigation (ArrowLeft/ArrowRight)
- Touch/drag support
- SSR compatible with `isServer` check in demos
- ARIA accessibility attributes

**Dependencies:** `embla-carousel-solid`, `embla-carousel-autoplay`

#### `hero.tsx` + `hero-context.tsx` - Hero Section Components

Dynamic hero sections with background types, positioning, and CTAs.

```tsx
<HeroRoot heroId="hero-1">
  <HeroItems layout="horizontal-grid" columns={1}>
    {(item) => (
      <HeroItem item={item} aspectRatio="16/9" maxHeight={500}>
        {/* Custom content or use defaults */}
      </HeroItem>
    )}
  </HeroItems>
</HeroRoot>
```

**Exports:**
- `HeroRoot` - Data provider (query or direct data)
- `HeroProvider` - Context for single hero
- `HeroItems` - Renders hero items via CollectionView
- `HeroItem` - Single hero slide with background/CTAs
- `HeroSkeleton` - Loading skeleton
- `useHero` - Access hero context

**HeroItem Features:**
- Background types: `gradient`, `color`, `image`
- Image overlay with opacity
- 9 content positions (top/center/bottom × left/center/right)
- Primary and secondary CTAs
- Customizable text colors

#### `search.tsx` - Kobalte Search Component

Search input with autocomplete dropdown using Kobalte primitives.

```tsx
<Search>
  <SearchLabel>Search</SearchLabel>
  <SearchControl>
    <SearchInput placeholder="Type to search..." />
    <SearchIcon />
  </SearchControl>
  <SearchContent>
    <SearchListbox>
      <SearchItem>Option 1</SearchItem>
      <SearchItem>Option 2</SearchItem>
    </SearchListbox>
  </SearchContent>
</Search>
```

**Exports:**
- `Search` - Root component
- `SearchLabel`, `SearchDescription`, `SearchControl`, `SearchIndicator`
- `SearchIcon`, `SearchInput`, `SearchContent`, `SearchPortal`
- `SearchListbox`, `SearchSection`, `SearchItem`, `SearchItemLabel`, `SearchItemDescription`
- `SearchNoResult`, `SearchArrow`
- `filterOptions` - Utility for filtering options

### Updated Components

#### `product-context.tsx` - Uses `lib/stores`

Updated to use centralized cart/wishlist stores from `~/lib/stores` instead of local contexts.

```tsx
// Now imports from lib/stores
import { useCart } from "~/lib/stores"
import { useWishlist } from "~/lib/stores"
```

**New Context Methods:**
- `isInCart()` - Check if product is in cart
- `isInWishlist()` - Check if product is in wishlist

#### `product.tsx` - Enhanced Product Actions

Updated to use `lib/stores` with additional action triggers.

**New Exports:**
- `ProductToggleWishlistTrigger` - Toggle wishlist status
- `ProductQuantityDecrementTrigger` - Decrease quantity
- `ProductQuantityIncrementTrigger` - Increase quantity
- `ProductQuantityInput` - Number input for quantity
- `ProductQuantityActions` - Combined increment/decrement/input

```tsx
<Product data={product}>
  <ProductName />
  <ProductPrice />
  <ProductQuantityActions />
  <ProductToggleWishlistTrigger />
  <ProductAddToCartTrigger />
</Product>
```

#### `cart.tsx` - Uses `lib/stores`

Refactored to use centralized cart store.

**Exports:**
- `Cart` - Wrapper component
- `CartItems` - Renders items with optional `renderItem` prop
- `CartSummary` - Shows content when cart has items
- `CartEmpty` - Shows content when cart is empty
- `CartItemCount` - Display item count
- `CartSubtotal` - Display calculated subtotal
- `CartCheckoutTrigger` - Transfer items to order
- `CartClearTrigger` - Clear all items
- `CartItemCheckbox` - Toggle item selection
- `CartProvider`, `useCart` - Re-exported from `lib/stores`

#### `wishlist.tsx` / `order.tsx` - Simplified

Now re-export from `lib/stores` for consistent access.

```tsx
// wishlist.tsx
export { WishlistProvider, useWishlist } from "~/lib/stores"

// order.tsx
export { OrderProvider, useOrder } from "~/lib/stores"
```

#### `separator.tsx` - Updated to Kobalte

Updated to use `@kobalte/core/separator` with polymorphic support.

```tsx
<Separator orientation="horizontal" class="my-4" />
<Separator orientation="vertical" class="h-full" />
```

#### `index.tsx` - New Entry Point

Added `hero` to exports.

```tsx
export * from "./hero"
```

### Documentation Updates

#### `carousel/README.md`

Comprehensive documentation for carousel usage:
- Installation instructions
- Basic and advanced examples
- Size variants
- Vertical orientation
- Autoplay configuration
- API access with `setApi`
- Props table

---

## 2026-02-21 (Continued)

### Architecture Changes

#### `item-list.ts` - Generic Item List Manager (renamed from `container.ts`)

Renamed and refactored for clarity. The "container" name was vague - this module manages **item lists** for cart, wishlist, and order entities.

**Exports:**
- `ItemListEntry` - Single item in the list (was `ContainerItem`)
- `ItemListSnapshot` - Full state snapshot (was `ContainerValue`)
- `ItemListActions` - CRUD operations (was `ContainerActions`)
- `ItemListState` - Reactive state + actions (was `ContainerState`)
- `createItemList` - Factory function (was `createContainer`)
- `productToEntry` - Convert product to entry (was `productToContainerItem`)
- `toCartItems` - Convert entries to `CartItem[]`
- `toWishlistItems` - Convert entries to `WishlistItem[]`
- `toOrderItems` - Convert entries to `OrderItem[]`

**Usage:**
```tsx
const list = createItemList(undefined, { defaultQuantity: 1, defaultSelected: true })

// Add item
list.add({ productId: 'prod-1', name: 'Product', price: 99.99, quantity: 1, selected: true })

// Update quantity
list.setQuantity('item-1', 3)

// Remove
list.remove('item-1')

// Query
const item = list.find('item-1')
const item = list.findByProductId('prod-1')
const hasIt = list.hasProduct('prod-1')

// Selection
list.toggleSelected('item-1')
list.selectAll()
list.deselectAll()

// Derived state
list.items()        // All items
list.selectedItems() // Selected only
list.count()        // Total count
list.selectedCount() // Selected count
list.subtotal()     // Sum of selected items' subtotals
list.isEmpty()      // Boolean

// Sync from server
list.setSnapshot({ id: 'cart-1', storeId: 'store-1', items: [...] })
```

**Naming Changes:**
| Old | New |
|-----|-----|
| `ContainerItem` | `ItemListEntry` |
| `ContainerValue` | `ItemListSnapshot` |
| `ContainerActions` | `ItemListActions` |
| `ContainerState` | `ItemListState` |
| `createContainer` | `createItemList` |
| `productToContainerItem` | `productToEntry` |
| `setValue` | `setSnapshot` |
| `addItem` | `add` |
| `removeItem` | `remove` |
| `updateItem` | `update` |

#### `stores/` - State Management Contexts

New directory with cart, wishlist, and order stores using `createItemList`.

**Files:**
- `cart.tsx` - `CartProvider`, `useCart()`
- `wishlist.tsx` - `WishlistProvider`, `useWishlist()`
- `order.tsx` - `OrderProvider`, `useOrder()`
- `index.ts` - Exports all

**Cart Store:**
```tsx
// Provider
<CartProvider initialCart={cartData}>
  {children}
</CartProvider>

// Hook
const cart = useCart()
cart.addProduct(product, 2)     // Add product with quantity
cart.sync(serverCart)           // Sync from server response
cart.toCartItems()              // Convert to CartItem[] for API
cart.setQuantity(id, 3)         // Update quantity
cart.remove(id)                 // Remove item
cart.items()                    // All items
cart.subtotal()                 // Calculated subtotal
```

**Wishlist Store:**
```tsx
<WishlistProvider initialWishlist={wishlistData}>
  {children}
</WishlistProvider>

const wishlist = useWishlist()
wishlist.addProduct(product)    // Add (skips if already exists)
wishlist.sync(serverWishlist)
wishlist.toWishlistItems()
wishlist.hasProduct(productId)  // Check if already wishlisted
```

**Order Store:**
```tsx
<OrderProvider initialOrder={orderData}>
  {children}
</OrderProvider>

const order = useOrder()
order.addProduct(product, 1)
order.sync(serverOrder)
order.toOrderItems()
order.setBillingAddress(address)
order.setShippingAddress(address)
order.order()                   // Original order data
```

#### `types/entities.ts` - Updated Entity Types

Updated to match server jOOQ-generated schema exactly.

**New Types:**
- `Address` - Billing/shipping address structure
- `OrderStatus` - `'pending' | 'confirmed' | 'processing' | 'shipped' | 'delivered' | 'cancelled' | 'refunded'`

**Updated Entities:**

| Entity | Changes |
|--------|---------|
| `Cart` | Added `customerId`, `currency`, `total`, `notes`, `lastModifiedBy`; removed `userId`, `sessionId`, `status`, `itemCount` |
| `CartItem` | Added `version`; renamed `productPrice` → `price`; removed `productName` |
| `Order` | Added `orderNumber`, `shippingCost`, `billingAddress`, `shippingAddress`, `trackingNumber`, `paid`, `paidAt`, `shippedAt`, `deliveredAt`, `cancelledAt`, `refundedAt`, `lastModifiedBy`; renamed `shipping` → `shippingCost`; removed `itemCount` |
| `OrderItem` | Added `version`, `updatedAt`; renamed `productPrice` → `price` |
| `Wishlist` | Added `version`; renamed `userId` → `customerId`; removed `name`, `itemCount` |
| `WishlistItem` | Added `updatedAt`, `version`; removed `productName`, `productPrice` |

---

## 2026-02-21

### New Components

#### `payment-method-selector.tsx` - Payment Method Selection

Comprehensive payment method selector supporting 19 Stripe payment methods with currency filtering.

```tsx
// Basic usage
<PaymentMethodSelector
  currency="USD"
  selectedMethod={selectedMethod()}
  onMethodSelect={setSelectedMethod}
>
  <PaymentMethodPopular />
</PaymentMethodSelector>

// Grid layout
<PaymentMethodSelector
  currency="KES"
  selectedMethod={selectedMethod()}
  onMethodSelect={setSelectedMethod}
  allowedMethods={['card', 'mpesa', 'apple_pay']}
>
  <PaymentMethodGrid columns={2} />
</PaymentMethodSelector>

// Category grouping
<PaymentMethodSelector
  currency="EUR"
  selectedMethod={selectedMethod()}
  onMethodSelect={setSelectedMethod}
>
  <PaymentMethodCategories />
</PaymentMethodSelector>
```

**Exports:**
- `PaymentMethodSelector` - Main context provider
- `PaymentMethodGrid` - Grid layout (1-4 columns)
- `PaymentMethodPopular` - Shows popular methods only
- `PaymentMethodCategories` - Grouped by type
- `PaymentMethodOption` - Individual method button
- `PaymentMethodSummary` - Shows selected method
- `usePaymentMethodSelector` - Hook for context access
- `PAYMENT_METHODS` - Full method info array
- `PaymentMethodIcons` - SVG icons map
- `CATEGORY_INFO` - Category metadata
- Types: `StripePaymentMethodType`, `PaymentMethodInfo`, `PaymentMethodCategory`

**Supported Methods (19):**
| Category | Methods |
|----------|---------|
| Cards | Credit/Debit Cards |
| Wallets | Apple Pay, Google Pay, Alipay, WeChat Pay, GrabPay |
| Bank Transfers | ACH, SEPA, iDEAL, Bancontact, Sofort, giropay, EPS, Przelewy24 |
| BNPL | Klarna, Afterpay, Affirm |
| Regional | M-Pesa (Kenya) |

**Features:**
- Currency-based filtering (only shows methods that support selected currency)
- Region information display
- Popular method highlighting
- Category grouping
- Responsive grid layouts
- Accessible button components

#### `text.tsx` - Enterprise Typography System

Complete refactor with polymorphic rendering, semantic elements, and comprehensive styling API.

```tsx
// Basic usage
<Text variant="h1">Heading 1</Text>
<Text variant="body1">Body text</Text>

// Polymorphic - renders as semantic element
<Text variant="h2">Renders as <h2></Text>

// With all styling props
<Text
  variant="body1"
  align="center"
  weight="semibold"
  color="primary"
  transform="uppercase"
  decoration="underline"
  truncate={3}
  italic
  noWrap
  gutterBottom
>
  Styled text
</Text>

// Convenience components
<Heading level={1}>Main Title</Heading>
<Paragraph size="lg">Large paragraph</Paragraph>
<Caption>Small caption text</Caption>
<Overline>SECTION LABEL</Overline>
```

**Exports:**
- `Text` - Main typography component
- `Heading` - Semantic heading (h1-h6)
- `Paragraph` - Paragraph with size variants
- `Caption` - Small text component
- `Overline` - Uppercase label component
- `textVariants` - CVA variants for custom use
- Types: `TextVariant`, `TextAlign`, `TextWeight`, `TextTransform`, `TextDecoration`, `TextColor`, `TextProps`, etc.

**Variants:** `h1`, `h2`, `h3`, `h4`, `h5`, `h6`, `subtitle1`, `subtitle2`, `body1`, `body2`, `caption`, `overline`, `inherit`

**Features:**
- Polymorphic rendering (variant → semantic element mapping)
- Full TypeScript support
- CVA-based variants
- Responsive typography
- Line clamping (truncate)
- Semantic HTML by default

#### `types/index.ts` - Types Entry Point

Added proper TypeScript entry point for types module.

```tsx
export * from "./media"
```

**Exports:** Re-exports all types from `types/media.ts`

### Fixed Components

#### `loading.tsx`

- Self-closing empty `<div />` elements (lines 11, 39)
- Replaced `{props.text && ...}` with `<Show when={props.text}>` (line 12)

#### `sheet/SheetContent.tsx`

- Replaced `ModalContentProps` import with `OverlayHandlers` from `overlay-behavior.tsx`
- Updated to use `createOverlayHandlers()` for consistent overlay behavior

#### `query/index.tsx`

- Fixed `QueryBoundary` to use `<Show>` instead of early return for null checks
- Added `Suspense` wrapper in `QueryProvider` for SSR compatibility

### New Pages

#### `routes/index.tsx` - Production Home Page

Enterprise-grade landing page showcasing platform capabilities.

**Sections:**
- HeaderSection - Sticky navigation with auth
- HeroSection - CTA with gradient background
- FeaturesSection - 6 feature cards with navigation
- ApiShowcaseSection - Backend stats and features
- TechnologyStackSection - Tech stack breakdown
- CTASection - Final call-to-action
- FooterSection - Multi-column footer links

**Features:**
- SEO optimized (Title, Meta)
- Responsive design (mobile-first)
- Accessible (semantic HTML)
- Type-safe components

**Navigation Routes:**
| Feature | Route |
|---------|-------|
| My Sites | `/my-sites` |
| Templates | `/templates` |
| My Modules | `/my-modules` |
| Admin Panel | `/admin-panel` |
| Store Builder | `/site-edit` (disabled) |
| Support | `/support` |
| Documentation | `/docs` |

#### `routes/demos/payment.tsx` - Payment Components Demo

Comprehensive demo showcasing all payment-related components.

**Demos Included:**
1. **PaymentStatusBadgesDemo** - All 7 payment statuses with color coding
2. **PaymentCardDemo** - Single payment cards with full details
3. **PaymentMethodsDemo** - Saved payment methods display
4. **PaymentMethodSelectorDemo** - Interactive payment method selector with currency filtering
5. **PaymentListDemo** - Custom rendered payment list
6. **PaymentSkeletonDemo** - Loading states

**Components Showcased:**
- `PaymentRoot` - Context provider for payment data
- `PaymentAmount` - Formatted currency display
- `PaymentStatusBadge` - Status with color coding
- `PaymentCardInfo` - Card brand and last 4 digits
- `PaymentDate` - Formatted date display
- `PaymentReceiptUrl` - Receipt link
- `PaymentMethodSelector` - Payment method selection with 19 Stripe methods
- `PaymentMethodGrid/Popular/Categories` - Layout variations
- `PaymentSkeleton` / `PaymentListSkeleton` - Loading states

**SSR Safe:**
- Uses `isServer` check for hydration compatibility
- Mounts content after client-side hydration

### App Configuration

#### `app.tsx`

Added providers:
- `MetaProvider` - For SEO meta tags
- `AuthProvider` - For authentication context

### Documentation Added

#### `docs/README.md`
- Documentation index with quick links

#### `docs/pages/home.md`
- Complete home page documentation
- Component architecture
- Section breakdowns
- SEO configuration
- Styling guidelines
- Best practices
- Testing recommendations

### Updated README.md

Updated root README with:
- Comprehensive feature list (Frontend + Backend)
- Full project structure
- Route table
- Tech stack tables
- Documentation links

---

## 2025-02-21

### New Components

#### `query/` - Enterprise Data Fetching
Built on TanStack Query (`@tanstack/solid-query`).

```tsx
<Query queryKey={["users"]} queryFn={fetchUsers}>
  <QueryBoundary>
    {(data) => <UserList users={data} />}
  </QueryBoundary>
</Query>
```

**Exports:**
- `Query` - Main wrapper
- `QueryBoundary` - Suspense + ErrorBoundary
- `QueryLoading` - Loading spinner
- `QueryError` - Error display
- `QueryErrorMessage` - Error message
- `QueryErrorCause` - Error cause
- `QueryTrigger` - Fetch button
- `QueryRetryTrigger` - Retry button
- `QueryCancelTrigger` - Cancel button
- `QueryOverlay` - Loading overlay
- `useQueryState` - Access query state

#### `collection.tsx` - Data Collection with Layouts
Renders fetched data in various layouts (non-virtualized).

```tsx
// With query fetching
<Collection queryFn={fetchProducts} queryKey={["products"]}>
  <CollectionView layout="vertical-grid" columns={3} gap={4}>
    {(item) => <ProductCard product={item} />}
  </CollectionView>
  <CollectionEmpty>No products found</CollectionEmpty>
</Collection>

// With direct data prop
<CollectionView data={items} layout="row" gap={2}>
  {(item) => <Card item={item} />}
</CollectionView>
```

**Exports:**
- `Collection` - Data fetcher wrapper
- `CollectionView` - Layout renderer (accepts `data` prop or infers from `useQueryState`)
- `CollectionItem` - Context provider per item
- `CollectionEmpty` - Empty state
- `useCollection` - Access query state
- `useCollectionItem` - Access current item context

**Layouts:** `column`, `row`, `vertical-grid`, `horizontal-grid`

#### `virtual-layout.tsx` - Virtualized Lists/Grids
High-performance rendering for large datasets using TanStack Virtual.

```tsx
<VirtualLayout
  data={largeArray}
  layout="vertical-grid"
  columns={4}
  gap={4}
  itemHeight={120}
  height="500px"
>
  {(item) => <Card item={item} />}
</VirtualLayout>
```

**Exports:**
- `VirtualLayout` - Unified virtualized layout
- Types: `VirtualLayoutProps`, `LayoutMode`, `ColumnCount`, `GapSize`

**Layouts:** `col`, `row`, `vertical-grid`, `horizontal-grid`

#### `media.tsx` - Unified Media Component
Auto-detects and renders image/video/audio based on source. Infers from `CollectionItem` context when inside `ProductMedia`.

```tsx
// Auto-detect from src extension
<Media src="/video.mp4" />
<Media src="/song.mp3" />
<Media src="/photo.jpg" />

// Explicit type
<Media src="/file" type="video" />

// With ProductMedia - infers src/type/alt from context
<ProductMedia>
  <Media />  {/* infers from collection item */}
</ProductMedia>
```

**Exports:**
- `Media` - Auto-detecting media component (uses `Image`, `Video`, `Audio`)
- `detectMediaType` - Utility function
- Types: `MediaProps`

#### `types/media.ts` - Centralized Media Types
Shared types for media-related components.

**Exports:**
- `MediaType` - `"image" | "video" | "audio" | "document" | "file"`
- `MediaItemProps` - Media item shape matching server `MediaDto`
- `MediaVariants` - Responsive image variants

#### `product.tsx` - ProductMedia Component
Renders media array using `CollectionView`. Media items match server's `MediaDto`.

```tsx
<Product data={product}>
  <ProductMedia layout="horizontal-grid" columns={4} gap={2}>
    {(item) => (
      <Media />  {/* infers src/type/alt from item */}
    )}
  </ProductMedia>
</Product>
```

**Exports:**
- `ProductMedia` - Renders `product.data.media` array via `CollectionView`
- Types: `MediaItemProps`, `MediaType`, `MediaVariants` (re-exported from `types/media`)

#### `category.tsx` - Category Components
Hierarchical category display with tree, list, and menu views.

```tsx
// Tree view (collapsible hierarchy)
<CategoryTreeView data={categories} expanded={false}>
  {(item, level) => (
    <div class="flex items-center gap-2">
      <CategoryImage class="size-6 rounded" />
      <CategoryName />
    </div>
  )}
</CategoryTreeView>

// List view (flat, filterable by level)
<CategoryListView 
  data={categories} 
  level={1} 
  layout="vertical-grid" 
  columns={3}
/>

// Menu view (dropdown navigation)
<CategoryMenu data={categories} orientation="horizontal">
  {(item, hasChildren) => (
    <div class="px-3 py-2 hover:bg-accent">
      {item.name} {hasChildren && "▶"}
    </div>
  )}
</CategoryMenu>

// Breadcrumb
<Category data={category}>
  <CategoryBreadcrumb />
</Category>
```

**Exports:**
- `CategoryRoot` - Data provider (supports query or direct data)
- `CategoryProvider` - Context for single category
- `CategoryName` - Display name
- `CategoryImage` - Display image
- `CategoryLevelBadge` - Badge showing level (Primary/Secondary/Tertiary)
- `CategoryBreadcrumb` - Path display
- `CategoryListView` - Flat list with level filtering
- `CategoryTreeView` - Collapsible tree structure
- `CategoryMenu` - Dropdown navigation
- `useCategory` - Access category context
- Types: `CategoryProps`, `CategoryLevel`, `CategoryContextValue`

#### `overlay-behavior.tsx` - Shared Overlay Behavior
Centralized behavior context for overlay components (Dialog, Popover, Tooltip, etc.).

```tsx
// Used internally by overlay components
<Dialog closeOnEscapeKeyDown={false} showBackdrop>
  <DialogContent />  {/* handlers respect parent settings */}
</Dialog>

// Available props
<OverlayBehavior
  closeOnEscapeKeyDown={boolean}      // default: true
  closeOnInteractOutside={boolean}    // default: true  
  closeOnFocusOutside={boolean}       // default: true
  closeOnPointerDownOutside={boolean} // default: true
  showBackdrop={boolean}              // default: false
>
```

**Exports:**
- `OverlayBehavior` - Context provider
- `useOverlayBehavior` - Access behavior settings
- `createOverlayHandlers` - Generate handlers with preventDefault logic
- Types: `OverlayBehaviorProps`, `OverlayHandlers`, `OverlayBehaviorContextValue`
- Constants: `OVERLAY_BEHAVIOR_KEYS`, `OVERLAY_HANDLER_KEYS`

### Renamed Components

| Old | New | Reason |
|-----|-----|--------|
| `items.tsx` | `collection.tsx` | More descriptive name |
| `Items` | `Collection` | Consistent naming |
| `ItemsItem` | `CollectionItem` | Consistent naming |
| `ItemsLayout` | `CollectionView` | Consistent naming |
| `ItemsEmpty` | `CollectionEmpty` | Consistent naming |
| `useItems` | `useCollection` | Consistent naming |
| `useItemsItem` | `useCollectionItem` | Consistent naming |
| `items` (prop) | `collection` (prop) | Consistent naming |
| `list/` | `wishlist/` | More semantic name |
| `useList` | `useWishlist` | Consistent naming |
| `ListProvider` | `WishlistProvider` | Consistent naming |
| `lazy-lists/` | `virtual-layout.tsx` | Accurate description |
| `product/` | `product.tsx` + `product-context.tsx` | Flattened structure |
| `ProductProvider` | Context split to `product-context.tsx` | Separate concerns |
| `ProductAddToListTrigger` | `ProductAddToWishlistTrigger` | Accurate naming |
| `ProductMakeOrderTrigger` | `ProductOrderTrigger` | Simpler naming |
| `product.value` | `product.data` | More semantic |
| `product.setValue` | `product.update` | More semantic |
| `cart/` | `cart.tsx` + `cart-context.tsx` | Flattened structure |
| `CartItem*` aliases | Removed - use `Product*` directly | Eliminate redundancy |
| `WishlistItem*` aliases | Removed - use `Product*` directly | Eliminate redundancy |
| `order/` | `order.tsx` + `order-context.tsx` | Flattened structure |
| `order.value` | `order.items` | More semantic |
| `wishlist/list-provider.tsx` | `wishlist-context.tsx` | Consistent naming |
| `ProductAbout` | Removed | Rarely used |
| `ProductLabel` | Removed | Use plain elements instead |

### Restructuring

- Flattened 75+ single-file directories to direct `.tsx` files
- Removed redundant `index.ts` files
- Deleted empty directories: `charts`, `data-table`, `lazy-list`
- Deleted all `*.txt` files

### Components Removed

| Component | Replacement |
|-----------|-------------|
| `column` | `<Flex flexDirection="col">` |
| `row` | `<Flex flexDirection="row">` |
| `lazy-lists/` (old) | `virtual-layout.tsx` |
| `ItemsQuery*` aliases | Use `Query*` directly |
| `ProductQuery*` aliases | Use `Query*` directly |
| `ProductActionsQuery*` aliases | Use `Query*` directly |
| `CartQuery*` aliases | Use `Query*` directly |
| `CartItemActionsQuery*` aliases | Use `Query*` directly |
| `CartItem*` aliases | Use `Product*` directly |
| `WishlistItem*` aliases | Use `Product*` directly |
| `ProductAbout` | Removed - rarely used |
| `ProductLabel` | Removed - use plain elements |
| `useList`/`ListProvider` | Use `useWishlist`/`WishlistProvider` |

### Dependencies Added

- `@tanstack/solid-query@5.90.23` - Data fetching
- `@tanstack/solid-virtual@3.13.2` - Virtualization

### Migration Notes

#### Fetch → Query
```tsx
// Before
<Fetch fetcher={fetchData} canFetch>
  <FetchBoundary>{() => useFetch().data}</FetchBoundary>
</Fetch>

// After
<Query queryFn={fetchData} queryKey={["data"]} enabled>
  <QueryBoundary>{(data) => data}</QueryBoundary>
</Query>
```

#### Items → Collection
```tsx
// Before
<Items queryFn={fetchData}>
  <ItemsLayout layout="vertical-grid">
    {(item) => <Card item={item} />}
  </ItemsLayout>
</Items>

// After
<Collection queryFn={fetchData} queryKey={["data"]}>
  <CollectionView layout="vertical-grid" columns={3}>
    {(item) => <Card item={item} />}
  </CollectionView>
</Collection>
```

#### useItemsItem → useCollectionItem
```tsx
// Before
const { item, items, index } = useItemsItem()

// After
const { item, collection, index, value } = useCollectionItem()
```

#### Product changes
```tsx
// Before
<ProductProvider value={data}>
<ProductAddToListTrigger>
<ProductMakeOrderTrigger>
{product.value}
{product.setValue({ quantity: 1 })}

// After
<ProductProvider data={data}>
<ProductAddToWishlistTrigger>
<ProductOrderTrigger>
{product.data}
{product.update({ quantity: 1 })}
```

#### Cart changes
```tsx
// Before
<CartItem>
<CartItemName>
<CartItemPrice>

// After
<Product data={item}>
<ProductName>
<ProductPrice>
```

#### Order changes
```tsx
// Before
order?.setOrder(products)
order?.value

// After
order?.setItems(products)
order?.items
```

### Files Structure (Current)

```
src/components/ui/
├── accordion.tsx
├── alert.tsx
├── alert-dialog.tsx
├── appbar.tsx
├── aspect-ratio.tsx
├── audio.tsx
├── auth.tsx
├── avatar.tsx
├── badge.tsx
├── box.tsx
├── breadcrumb.tsx
├── button/
├── callout.tsx
├── card.tsx
├── carousel/
├── cart.tsx
├── cart-context.tsx
├── category.tsx
├── checkbox.tsx
├── collapsible.tsx
├── collection.tsx
├── color/
├── combobox.tsx
├── context-menu.tsx
├── date-picker.tsx
├── dialog/
├── dialog.tsx
├── divider/
├── drawer.tsx
├── dropdown-menu.tsx
├── file-field/
├── file-reader.tsx
├── flex.tsx
├── grid.tsx
├── hover-card.tsx
├── icon-button.tsx
├── image.tsx
├── label.tsx
├── link.tsx
├── list/
├── loading.tsx
├── media.tsx
├── menubar.tsx
├── modal/
├── modal.tsx
├── navigation-menu.tsx
├── number-field/
├── order.tsx
├── order-context.tsx
├── otp-field.tsx
├── overlay-behavior.tsx
├── paper.tsx
├── pagination.tsx
├── payment-method-selector.tsx    # NEW - Stripe payment method selector
├── payment.tsx
├── payment-context.tsx
├── popover.tsx
├── product.tsx
├── product-context.tsx
├── progress-circle.tsx
├── progress.tsx
├── query/
│   ├── index.tsx
│   ├── Demo.tsx
│   └── README.md
├── radio.tsx
├── radio-group.tsx
├── resizable.tsx
├── search.tsx
├── segmented-control.tsx
├── select/
├── separator.tsx
├── sheet/
├── sidebar/
├── skeleton.tsx
├── slider.tsx
├── spacer.tsx
├── spinner.tsx
├── switch.tsx
├── table.tsx
├── tabs/
├── text.tsx
├── text-field/
├── timeline.tsx
├── toast/
├── toggle.tsx
├── toggle-group.tsx
├── tooltip.tsx
├── types/
│   ├── index.ts                  # NEW - Types entry point
│   └── media.ts
├── video.tsx
├── virtual-layout.tsx
├── wishlist.tsx
└── wishlist-context.tsx
```

### Routes Structure (Current)

```
src/routes/
├── index.tsx                      # Home page (landing)
├── demos/
│   ├── index.tsx                  # Demo index
│   ├── category.tsx               # Category demo
│   ├── payment.tsx                # Payment demo (SSR-safe)
│   └── query.tsx                  # Query demo
└── ... (other routes)
```

### Related Files

- `CHANGES.md` - This file
- `docs/README.md` - Documentation index
- `docs/pages/home.md` - Home page documentation
