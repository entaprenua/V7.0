import type { ValidComponent } from "solid-js"
import { splitProps } from "solid-js"
import type { PolymorphicProps } from "@kobalte/core/polymorphic"
import { Button, type ButtonProps } from "./button"

type IconButtonProps<T extends ValidComponent = "button"> = Omit<ButtonProps<T>, "size">

const IconButton = <T extends ValidComponent = "button">(
  props: PolymorphicProps<T, IconButtonProps<T>>
) => {
  const [_, others] = splitProps(props as ButtonProps, ["size"])

  return <Button size="icon" {...others} />
}

export type { IconButtonProps }
export { IconButton }
