import { Component, Show } from "solid-js";

interface LoadingProps {
  fullScreen?: boolean;
  text?: string;
}

export const Loading: Component<LoadingProps> = (props) => {
  const content = (
    <div class="flex flex-col items-center justify-center gap-3">
      <div class="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
      <Show when={props.text}>
        <p class="text-sm text-gray-500">{props.text}</p>
      </Show>
    </div>
  );

  return (
    <Show
      when={!props.fullScreen}
      fallback={
        <div class="fixed inset-0 flex items-center justify-center bg-white/80 z-50">
          {content}
        </div>
      }
    >
      {content}
    </Show>
  );
};

export const PageLoader: Component<{ text?: string }> = (props) => {
  return (
    <div class="min-h-screen flex items-center justify-center">
      <Loading text={props.text || "Loading..."} />
    </div>
  );
};

export const ButtonLoader: Component = () => {
  return <div class="animate-spin rounded-full h-4 w-4 border-b-2 border-current" />;
};
