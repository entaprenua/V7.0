/*
 * Collection Components
 * 
 * A data-fetching and layout system for rendering lists/grids of items.
 * 
 * Usage:
 *   - Remote fetch: Collection queryFn={fetchFn} layout="grid" columns={4} > CollectionView > children
 *   - Local data: Collection data={array} layout="grid" columns={4} > CollectionView > children
 *   - Static children: Collection > CollectionView > Component (uses useCollectionItem)
 *   - Fallbacks: Collection loadingFallback={...} errorFallback={...}
 * 
 * Flow:
 *   1. Collection wraps TanStack Query (queryFn) OR accepts local data
 *   2. Layout props (layout, columns, gap) passed to Collection
 *   3. CollectionView gets data/layout from Collection context
 *   4. Children: function (item, index) => JSX OR static JSX (wrapped in CollectionItem)
 *   5. CollectionItem provides context: { item, index, collection, value }
 *   6. useCollectionItem() accesses current item in child components
 */

import { Box } from "./box"
import { Flex } from "./flex"
import { Grid } from "./grid"
import { Query, QueryBoundary, useQueryState } from "./query"
import { VirtualLayout } from "./virtual-layout"
import {
  splitProps, Switch, children, createContext, useContext, For, Match, Show, createMemo,
  type JSX, type Accessor,
} from "solid-js"
import { cn } from "~/lib/utils"

// ============================================================================
// Types
// ============================================================================

type CollectionLayoutMode = "column" | "row" | "vertical-grid" | "horizontal-grid" | "virtual"

type CollectionColumnCount = 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12

type CollectionGapSize = 0 | 1 | 2 | 3 | 4 | 5 | 6 | 8 | 10 | 12

const GAP_CLASSES: Record<CollectionGapSize, string> = {
  0: "gap-0",
  1: "gap-1",
  2: "gap-2",
  3: "gap-3",
  4: "gap-4",
  5: "gap-5",
  6: "gap-6",
  8: "gap-8",
  10: "gap-10",
  12: "gap-12",
}

// ============================================================================
// Collection Context
// ============================================================================

type CollectionContextValue = {
  data: Accessor<any[]>
  layout: Accessor<CollectionLayoutMode | undefined>
  columns: Accessor<CollectionColumnCount>
  gap: Accessor<CollectionGapSize>
}

const CollectionContext = createContext<CollectionContextValue>()

const useCollectionContext = (): CollectionContextValue => {
  const ctx = useContext(CollectionContext)
  if (!ctx) {
    throw new Error("CollectionView must be used within Collection")
  }
  return ctx
}

// ============================================================================
// CollectionItem (provides item context)
// ============================================================================

type CollectionItemContext = {
  item: any
  collection: any
  index: number
  value: any
}

const CollectionItemContextInstance = createContext<CollectionItemContext | undefined>()

/**
 * Hook to access the query state from Collection
 * Alias for useQueryState - for accessing query data within Collection
 */
const useCollection = useQueryState

const useCollectionItem = (): CollectionItemContext | undefined => useContext(CollectionItemContextInstance)

type CollectionItemProps = {
  item: any
  index: number
  collection: any
  children?: JSX.Element
}

const CollectionItem = (props: CollectionItemProps) => {
  const value: CollectionItemContext = {
    get index() { return props.index },
    get item() { return props.item },
    get collection() { return props.collection },
    get value() { return props.item },
  }

  return (
    <CollectionItemContextInstance.Provider value={value}>
      {props.children}
    </CollectionItemContextInstance.Provider>
  )
}

// ============================================================================
// Collection (data fetching + layout config)
// ============================================================================

type CollectionProps = {
  children?: JSX.Element
  errorFallback?: JSX.Element
  loadingFallback?: JSX.Element
  /** Function to fetch data remotely */
  queryFn?: () => Promise<any>
  /** Direct data array (alternative to queryFn) */
  data?: any[]
  queryKey?: unknown[]
  enabled?: boolean
  /** Layout mode */
  layout?: CollectionLayoutMode
  /** Number of columns for grid layouts */
  columns?: CollectionColumnCount
  /** Gap between items */
  gap?: CollectionGapSize
}

const Collection = (props: CollectionProps) => {
  const [local] = splitProps(props, [
    "children",
    "errorFallback",
    "loadingFallback",
    "queryFn",
    "data",
    "queryKey",
    "enabled",
    "layout",
    "columns",
    "gap",
  ])

  const layout = () => local.layout
  const columns = () => local.columns ?? 3
  const gap = () => local.gap ?? 4

  // Data accessor - from query or direct
  const resolvedData = (): any[] => local.data ?? []

  // If queryFn is provided, use remote fetch mode
  if (local.queryFn) {
    return (
      <Query
        queryFn={local.queryFn}
        queryKey={local.queryKey ?? ["collection"]}
        enabled={local.enabled ?? true}
      >
        <QueryBoundary
          loadingFallback={local.loadingFallback}
          errorFallback={local.errorFallback}
        >
          <CollectionInner
            data={() => {
              const query = useQueryState()
              return (query?.data as any[]) ?? []
            }}
            layout={layout()}
            columns={columns()}
            gap={gap()}
          >
            {local.children}
          </CollectionInner>
        </QueryBoundary>
      </Query>
    )
  }

  // Direct data mode
  return (
    <CollectionInner
      data={resolvedData}
      layout={layout()}
      columns={columns()}
      gap={gap()}
    >
      {local.children}
    </CollectionInner>
  )
}

// Inner component that provides context
const CollectionInner = (props: {
  data: Accessor<any[]>
  layout: CollectionLayoutMode | undefined
  columns: CollectionColumnCount
  gap: CollectionGapSize
  children?: JSX.Element
}) => {
  const contextValue: CollectionContextValue = {
    data: props.data,
    layout: () => props.layout,
    columns: () => props.columns,
    gap: () => props.gap,
  }

  return (
    <CollectionContext.Provider value={contextValue}>
      {props.children}
    </CollectionContext.Provider>
  )
}

// ============================================================================
// CollectionEmpty
// ============================================================================

type CollectionEmptyProps = {
  class?: string
  children?: JSX.Element
}

const CollectionEmpty = (props: CollectionEmptyProps) => {
  const [local, others] = splitProps(props, ["class", "children"])
  const { data } = useCollectionContext()

  return (
    <Show when={data().length === 0}>
      <Box
        class={cn(
          "flex flex-col justify-center items-center min-h-[30vh] h-full",
          local.class
        )}
        {...others}
      >
        {local.children}
      </Box>
    </Show>
  )
}

// ============================================================================
// CollectionView (renders with layout)
// ============================================================================

/**
 * Renders collection data with layout options
 * Gets data and layout from Collection context
 * 
 * Props:
 *   - class: CSS class for wrapper
 *   - children: JSX.Element OR function (item, index) => JSX
 */
type CollectionViewProps = {
  class?: string
  children?: JSX.Element | ((item: any, index: number) => JSX.Element)
}

const CollectionView = (props: CollectionViewProps) => {
  const [local] = splitProps(props, ["class", "children"])
  const { data, layout, columns, gap } = useCollectionContext()

  const resolvedChildren = children(() => local.children as any)
  const gapClass = createMemo(() => GAP_CLASSES[(gap() ?? 4) as CollectionGapSize] ?? "gap-4")
  /**
   * Renders children:
   * - If children is a function: call it for each item
   * - If children is static JSX: wrap in CollectionItem for context
   */
  const renderContent = () => {
    if (typeof resolvedChildren() === "function") {
      return (
        <For each={data()}>
          {(item: any, index: () => number) =>
            (resolvedChildren() as any)(item, index())
          }
        </For>
      )
    }

    return (
      <For each={data()}>
        {(item: any, index: () => number) => (
          <CollectionItem item={item} index={index()} collection={data()}>
            {local.children as JSX.Element}
          </CollectionItem>
        )}
      </For>
    )
  }

  return (
    <Show when={data().length > 0}>
      <Switch fallback={renderContent()}>
        <Match when={layout() === "virtual"}>
          <VirtualLayout
            data={data()}
            layout={columns() && columns() > 1 ? "vertical-grid" : "col"}
            columns={columns()}
            gap={gap()}
            class={local.class}
          >
            {(item, index) => (resolvedChildren() as any)(item, index())}
          </VirtualLayout>
        </Match>

        <Match when={layout() === "vertical-grid"}>
          <Grid cols={columns()} class={cn(gapClass(), local.class)}>
            {renderContent()}
          </Grid>
        </Match>

        <Match when={layout() === "horizontal-grid"}>
          <Grid cols={columns()} class={cn(gapClass(), local.class)}>
            {renderContent()}
          </Grid>
        </Match>

        <Match when={layout() === "row"}>
          <Flex flexDirection="row" class={cn(gapClass(), local.class)}>
            {renderContent()}
          </Flex>
        </Match>

        <Match when={layout() === "column"}>
          <Flex flexDirection="col" class={cn(gapClass(), local.class)}>
            {renderContent()}
          </Flex>
        </Match>
      </Switch>
    </Show>
  )
}

// ============================================================================
// Exports
// ============================================================================

export {
  Collection,
  CollectionItem,
  CollectionView,
  CollectionEmpty,
  useCollection,
  useCollectionItem,
  CollectionItemContextInstance,
}

export type {
  CollectionLayoutMode,
  CollectionColumnCount,
  CollectionGapSize,
  CollectionViewProps,
  CollectionItemContext,
}
