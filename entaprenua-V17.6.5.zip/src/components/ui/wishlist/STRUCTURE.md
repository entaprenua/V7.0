# Wishlist Components Architecture

## Overview

This directory contains zero-code ready wishlist components for the visual builder. Components are designed to be fully composable - users can include/exclude sections by simply adding/removing child components. They integrate with existing `Product` components for displaying individual products.

## Design Principles

1. **Zero-Code Ready** - Components work without manual setup; just drop them in and configure via props
2. **Composable** - Sections are separate components that can be included/excluded via children
3. **Auto-Fetching** - Components fetch their own data using storeId from context
4. **Auto-Detection** - Components auto-detect storeId from `useCurrentStoreId()` context
5. **Context-Based** - Uses `CollectionItemContext` from Collection for unified item iteration
6. **Empty-Safe** - Hides completely when no products exist (no empty state shown)
7. **Auto-Save** - Wishlist changes are automatically synced to the server

## Backend Alignment

### API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/v1/stores/{storeId}/wishlists` | Get user's wishlist for store |
| POST | `/api/v1/stores/{storeId}/wishlists` | Save wishlist with items |
| DELETE | `/api/v1/stores/{storeId}/wishlists/{id}` | Delete wishlist |

### WishlistResponse Type

```typescript
type WishlistResponse = {
  id: string;
  storeId: string;
  customerId: string;
  items?: WishlistItem[];
  insertedAt?: string;
  updatedAt?: string;
  version?: number;
}
```

## Directory Structure

```
src/components/ui/wishlist/
├── STRUCTURE.md              # This file
├── index.ts                  # Barrel exports
├── wishlist-context.tsx      # Context + useWishlist hook
├── wishlist-root.tsx         # WishlistRoot, WishlistGrid
└── wishlist-skeleton.tsx     # Loading states
```

## useWishlist Hook

The `useWishlist` hook provides access to wishlist state and methods:

```typescript
const useWishlist = () => {
  // Returns WishlistStore
}
```

### WishlistStore

Extends `ItemListState` with wishlist-specific methods:

```typescript
type WishlistStore = ItemListState & {
  // State
  sync: (wishlist: WishlistResponse) => void
  addProduct: (product: ProductInput) => void
  toWishlistItems: () => WishlistItem[]
  
  // Actions
  save: () => Promise<void>           // Manual save
  isLoading: () => boolean
  error: () => string | null
  
  // Inherited from ItemListState
  items: Accessor<ItemListEntry[]>
  count: Accessor<number>
  isEmpty: Accessor<boolean>
  add: (item) => void
  remove: (id) => void
  clear: () => void
  hasProduct: (productId) => boolean
  // ... more
}
```

## Component Hierarchy

### Wishlist Page Layout
```
WishlistRoot (auto-fetches wishlist)
└── WishlistProvider (context)
    └── WishlistGrid
        └── Collection
            └── CollectionView
                └── WishlistItem (via children)
                    └── Product (auto-detects from context)
                        ├── ProductImage
                        ├── ProductName
                        └── ProductRemoveFromWishlistTrigger
```

## Usage Examples

### Simple Wishlist Page

```tsx
<WishlistRoot>
  <WishlistGrid columns={4} gap={4}>
    <Product>
      <ProductImage class="rounded-lg aspect-square object-cover mb-2" />
      <ProductName class="font-medium text-sm line-clamp-1" />
      <ProductPrice />
      <ProductRemoveFromWishlistTrigger class="text-red-500">
        Remove
      </ProductRemoveFromWishlistTrigger>
    </Product>
  </WishlistGrid>
</WishlistRoot>
```

### Row Layout

```tsx
<WishlistRoot>
  <WishlistGrid layout="row" gap={4}>
    <Product>
      <Flex class="gap-4 items-center">
        <ProductImage class="w-24 h-24 rounded-lg object-cover" />
        <div class="flex-1">
          <ProductName class="font-medium" />
          <ProductPrice class="text-primary font-bold" />
        </div>
        <ProductRemoveFromWishlistTrigger />
      </Flex>
    </Product>
  </WishlistGrid>
</WishlistRoot>
```

### With Custom Content

```tsx
<WishlistRoot>
  <WishlistGrid columns={3} gap={6}>
    <Product>
      <div class="group relative">
        <ProductImage class="rounded-lg aspect-square object-cover mb-3 group-hover:opacity-90 transition-opacity" />
        <ProductName class="font-semibold mb-1" />
        <ProductPrice class="text-lg font-bold text-primary mb-2" />
        <Flex class="gap-2">
          <ProductAddToCartTrigger class="flex-1" />
          <ProductRemoveFromWishlistTrigger class="text-red-500" />
        </Flex>
      </div>
    </Product>
  </WishlistGrid>
</WishlistRoot>
```

### Empty Wishlist

When the wishlist is empty, the `WishlistRoot` renders nothing (hidden), following the industry standard.

## Props Reference

### WishlistRoot (wishlist-root.tsx)

```typescript
type WishlistRootProps = {
  data?: WishlistResponse           // Direct data passing (optional)
  class?: string
  children?: JSX.Element
}
```

**Note:** `storeId` is automatically inferred from `useCurrentStoreId()` context.

### WishlistGrid (wishlist-root.tsx)

```typescript
type WishlistGridProps = {
  layout?: "column" | "row" | "vertical-grid" | "horizontal-grid"
  columns?: 1 | 2 | 3 | 4 | 5 | 6
  gap?: 0 | 1 | 2 | 3 | 4 | 5 | 6 | 8 | 10 | 12
  class?: string
  children?: JSX.Element
}
```

### WishlistSkeleton (wishlist-skeleton.tsx)

```typescript
type WishlistSkeletonProps = {
  class?: string
  children?: JSX.Element
}
```

Shows default skeleton with 4 item placeholders if no children provided.

### WishlistItemSkeleton (wishlist-skeleton.tsx)

```typescript
// Simple skeleton for single item
<WishlistItemSkeleton class="custom-class" />
```

## API Functions

### wishlistsApi (lib/api/wishlists.ts)

```typescript
export const wishlistsApi = {
  // Get user's wishlist for store
  get: async (storeId: string): Promise<WishlistResponse>
  
  // Save wishlist with items
  save: async (storeId: string, wishlist: Partial<WishlistResponse>): Promise<WishlistResponse>
  
  // Delete wishlist
  delete: async (storeId: string, wishlistId: string): Promise<{ deleted: boolean }>
}
```

## Integration with Product Components

Wishlist uses existing `Product` components for displaying each product. The Product component can include wishlist-specific triggers:

```tsx
<Product>
  <ProductImage />
  <ProductName />
  <ProductPrice />
  <ProductAddToWishlistTrigger />     // Add to wishlist
  <ProductRemoveFromWishlistTrigger /> // Remove from wishlist
  <ProductToggleWishlistTrigger />      // Toggle (smart button)
</Product>
```

### How It Works

1. `WishlistProvider` wraps the content and provides `useWishlist()`
2. `ProductRemoveFromWishlistTrigger` uses `useWishlist()` to remove the product
3. Changes are auto-synced to the server

## Empty Handling

Wishlist automatically hides when there are no items:

- No empty state message displayed
- Section is completely hidden if empty
- Consistent with standard wishlist behavior (show/hide)

## Loading & Error States

### Skeleton Components

- `WishlistSkeleton` - Main skeleton with 4 item placeholders
- `WishlistItemSkeleton` - Single item skeleton

### Error Handling

- Network errors: Stored in `wishlist.error()`
- Failed to load: Shows skeleton
- Save failed: Error stored, can retry

## Performance Considerations

- Auto-save on item changes (debounced)
- Uses TanStack Query for caching (via createResource)
- Product images lazy loaded

## Migration from Old Components

Old `WishlistProvider` from `~/lib/stores` is deprecated.

```tsx
// OLD (deprecated)
<WishlistProvider>
  {children}
</WishlistProvider>

// NEW
<WishlistRoot>
  {children}
</WishlistRoot>
```
