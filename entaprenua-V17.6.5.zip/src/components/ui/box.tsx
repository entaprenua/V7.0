import type { Component, ComponentProps } from "solid-js"
import { splitProps } from "solid-js"

export const Box: Component<ComponentProps<"div">> = (props) => {
    
    return (
      <div {...props } />
   )
}
 

