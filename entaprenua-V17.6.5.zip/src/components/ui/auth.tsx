import {
  Show, splitProps, Switch, Match, createContext, useContext,
  type JSX, createMemo, For, createSignal, createEffect, on, onCleanup,
} from "solid-js"
import { AuthUIProvider, useAuthUI, PasswordResetProvider, usePasswordReset, EmailVerificationProvider, useEmailVerification, SessionProvider, useSession } from "./auth-context"
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from "./card"
import { Button } from "./button"
import { Flex } from "./flex"
import { Text } from "./text"
import { TextField, TextFieldInput, TextFieldLabel, TextFieldErrorMessage, TextFieldDescription } from "./text-field"
import { Checkbox } from "./checkbox"
import { Progress } from "./progress"
import { Skeleton } from "./skeleton"
import { Separator } from "./separator"
import { cn } from "~/lib/utils"
import { authApi } from "~/lib/api/auth"
import {
  validateEmailFormat, getPasswordStrength, validatePasswordMatch,
  validateUsername, getStrengthColor, getStrengthLabel,
  type EmailValidationResult, type PasswordValidationResult, type EmailServerValidationResult,
} from "~/lib/utils/validation"
import { useAuth } from "~/lib/guards/auth"
import type { IdentityProvider } from "~/lib/types"

const IDENTITY_PROVIDERS: Record<IdentityProvider, { name: string; icon: string; color: string }> = {
  GOOGLE: { name: "Google", icon: "G", color: "bg-white border-gray-300 text-gray-700 hover:bg-gray-50" },
  FACEBOOK: { name: "Facebook", icon: "f", color: "bg-blue-600 text-white hover:bg-blue-700" },
  GITHUB: { name: "GitHub", icon: "GH", color: "bg-gray-900 text-white hover:bg-gray-800" },
  APPLE: { name: "Apple", icon: "", color: "bg-black text-white hover:bg-gray-900" },
  LOCAL: { name: "Email", icon: "@", color: "bg-muted text-foreground" },
}

type EmailFieldProps = {
  value: string
  onInput: (value: string) => void
  label?: string
  placeholder?: string
  class?: string
  disabled?: boolean
  showServerValidation?: boolean
  onServerValidation?: (result: EmailServerValidationResult) => void
}

const EmailField = (props: EmailFieldProps) => {
  const [local, others] = splitProps(props, [
    "value", "onInput", "label", "placeholder", "class", "disabled", 
    "showServerValidation", "onServerValidation"
  ])
  
  const [formatResult, setFormatResult] = createSignal<EmailValidationResult>({ isValid: false })
  const [serverResult, setServerResult] = createSignal<EmailServerValidationResult | null>(null)
  const [isValidating, setIsValidating] = createSignal(false)
  const [debounceTimer, setDebounceTimer] = createSignal<number | null>(null)
  const [isApplyingSuggestion, setIsApplyingSuggestion] = createSignal(false)

  let currentEmail = ""
  let isMounted = true

  onCleanup(() => {
    isMounted = false
    if (debounceTimer()) {
      clearTimeout(debounceTimer()!)
    }
  })

  createEffect(on(() => local.value, (email) => {
    currentEmail = email
    const result = validateEmailFormat(email)
    setFormatResult(result)

    if (debounceTimer()) {
      clearTimeout(debounceTimer()!)
      setDebounceTimer(null)
    }

    if (local.showServerValidation && result.isValid && email.length > 5 && !isApplyingSuggestion()) {
      setIsValidating(true)
      const timer = setTimeout(async () => {
        if (!isMounted || currentEmail !== email) return
        try {
          const response = await authApi.validateEmail(email)
          if (response.success && response.data && isMounted && currentEmail === email) {
            setServerResult(response.data)
            local.onServerValidation?.(response.data)
          }
        } catch (e) {
          console.error("Server validation failed:", e)
        } finally {
          if (isMounted && currentEmail === email) {
            setIsValidating(false)
          }
        }
      }, 500)
      setDebounceTimer(timer as unknown as number)
    } else {
      setServerResult(null)
      setIsValidating(false)
    }
  }, { defer: false }))

  const showSuggestion = () => formatResult().suggestion && local.value !== formatResult().suggestion

  const handleSuggestionClick = () => {
    const suggestion = formatResult().suggestion
    if (suggestion) {
      setIsApplyingSuggestion(true)
      local.onInput(suggestion)
      setTimeout(() => setIsApplyingSuggestion(false), 0)
    }
  }

  return (
    <TextField>
      <TextFieldLabel>{local.label ?? "Email"}</TextFieldLabel>
      <TextFieldInput
        type="email"
        value={local.value}
        onInput={(e) => local.onInput(e.currentTarget.value)}
        placeholder={local.placeholder ?? "you@example.com"}
        class={local.class}
        disabled={local.disabled}
      />
      <Show when={!formatResult().isValid && local.value}>
        <TextFieldErrorMessage>{formatResult().error}</TextFieldErrorMessage>
      </Show>
      <Show when={showSuggestion()}>
        <TextFieldDescription class="text-blue-600 cursor-pointer hover:underline">
          Did you mean <span onClick={() => local.onInput(formatResult().suggestion!)}>{formatResult().suggestion}</span>?
        </TextFieldDescription>
      </Show>
      <Show when={isValidating()}>
        <Text class="text-xs text-muted-foreground">Validating...</Text>
      </Show>
      <Show when={serverResult() && !isValidating()}>
        <EmailValidationStatus result={serverResult()!} />
      </Show>
    </TextField>
  )
}

type EmailValidationStatusProps = {
  result: EmailServerValidationResult
  class?: string
}

const EmailValidationStatus = (props: EmailValidationStatusProps) => {
  const isGood = () => 
    props.result.isValidFormat && 
    props.result.isDeliverable && 
    !props.result.isDisposable

  const warnings = () => {
    const warns: string[] = []
    if (props.result.isDisposable) warns.push("Disposable email")
    if (!props.result.isDeliverable) warns.push("May not be deliverable")
    if (!props.result.isMxFound) warns.push("No MX record found")
    return warns
  }

  return (
    <Flex flexDirection="col" class={cn("gap-1 text-xs", props.class)}>
      <Show when={isGood()}>
        <Text class="text-green-600">Email verified</Text>
      </Show>
      <Show when={warnings().length > 0}>
        <Text class="text-orange-600">{warnings().join(" | ")}</Text>
      </Show>
      <Show when={props.result.qualityScore > 0}>
        <Flex class="items-center gap-2">
          <Text class="text-muted-foreground">Quality:</Text>
          <Progress value={props.result.qualityScore * 100} class="h-1 w-20" />
        </Flex>
      </Show>
    </Flex>
  )
}

type PasswordFieldProps = {
  value: string
  onInput: (value: string) => void
  label?: string
  placeholder?: string
  class?: string
  disabled?: boolean
  showStrength?: boolean
}

const PasswordField = (props: PasswordFieldProps) => {
  const [local, others] = splitProps(props, [
    "value", "onInput", "label", "placeholder", "class", "disabled", "showStrength"
  ])
  
  const strength = createMemo(() => getPasswordStrength(local.value))

  return (
    <TextField>
      <TextFieldLabel>{local.label ?? "Password"}</TextFieldLabel>
      <TextFieldInput
        type="password"
        value={local.value}
        onInput={(e) => local.onInput(e.currentTarget.value)}
        placeholder={local.placeholder ?? "Enter your password"}
        class={local.class}
        disabled={local.disabled}
      />
      <Show when={local.showStrength && local.value}>
        <Flex class="items-center gap-2 mt-1">
          <Progress 
            value={strength().score * 20} 
            class={cn("h-1 flex-1", getStrengthColor(strength().strength))} 
          />
          <Text class="text-xs text-muted-foreground">{getStrengthLabel(strength().strength)}</Text>
        </Flex>
        <Show when={strength().suggestions.length > 0}>
          <Text class="text-xs text-muted-foreground mt-1">
            {strength().suggestions.slice(0, 2).join(". ")}
          </Text>
        </Show>
      </Show>
      <Show when={strength().errors.length > 0 && local.value}>
        <TextFieldErrorMessage>{strength().errors[0]}</TextFieldErrorMessage>
      </Show>
    </TextField>
  )
}

type ConfirmPasswordFieldProps = {
  password: string
  value: string
  onInput: (value: string) => void
  label?: string
  placeholder?: string
  class?: string
  disabled?: boolean
}

const ConfirmPasswordField = (props: ConfirmPasswordFieldProps) => {
  const [local, others] = splitProps(props, [
    "password", "value", "onInput", "label", "placeholder", "class", "disabled"
  ])
  
  const matchResult = createMemo(() => validatePasswordMatch(local.password, local.value))

  return (
    <TextField>
      <TextFieldLabel>{local.label ?? "Confirm Password"}</TextFieldLabel>
      <TextFieldInput
        type="password"
        value={local.value}
        onInput={(e) => local.onInput(e.currentTarget.value)}
        placeholder={local.placeholder ?? "Confirm your password"}
        class={local.class}
        disabled={local.disabled}
      />
      <Show when={!matchResult().isValid && local.value}>
        <TextFieldErrorMessage>{matchResult().error}</TextFieldErrorMessage>
      </Show>
      <Show when={matchResult().isValid && local.value}>
        <TextFieldDescription class="text-green-600">Passwords match</TextFieldDescription>
      </Show>
    </TextField>
  )
}

type UsernameFieldProps = {
  value: string
  onInput: (value: string) => void
  label?: string
  placeholder?: string
  class?: string
  disabled?: boolean
}

const UsernameField = (props: UsernameFieldProps) => {
  const [local, others] = splitProps(props, [
    "value", "onInput", "label", "placeholder", "class", "disabled"
  ])
  
  const validationResult = createMemo(() => validateUsername(local.value))
  const [isChecking, setIsChecking] = createSignal(false)
  const [exists, setExists] = createSignal<boolean | null>(null)
  const [debounceTimer, setDebounceTimer] = createSignal<number | null>(null)

  let currentUsername = ""
  let isMounted = true

  onCleanup(() => {
    isMounted = false
    if (debounceTimer()) {
      clearTimeout(debounceTimer()!)
    }
  })

  createEffect(on(() => local.value, (username) => {
    currentUsername = username
    
    if (debounceTimer()) {
      clearTimeout(debounceTimer()!)
      setDebounceTimer(null)
    }

    if (validationResult().isValid && username.length >= 3) {
      setIsChecking(true)
      const timer = setTimeout(async () => {
        if (!isMounted || currentUsername !== username) return
        try {
          const response = await authApi.checkUsernameExists(username)
          if (isMounted && currentUsername === username) {
            setExists(response.data?.exists ?? false)
          }
        } catch (e) {
          if (isMounted && currentUsername === username) {
            setExists(null)
          }
        } finally {
          if (isMounted && currentUsername === username) {
            setIsChecking(false)
          }
        }
      }, 300)
      setDebounceTimer(timer as unknown as number)
    } else {
      setExists(null)
      setIsChecking(false)
    }
  }, { defer: false }))

  return (
    <TextField>
      <TextFieldLabel>{local.label ?? "Username"}</TextFieldLabel>
      <TextFieldInput
        type="text"
        value={local.value}
        onInput={(e) => local.onInput(e.currentTarget.value)}
        placeholder={local.placeholder ?? "johndoe"}
        class={local.class}
        disabled={local.disabled}
      />
      <Show when={!validationResult().isValid && local.value}>
        <TextFieldErrorMessage>{validationResult().error}</TextFieldErrorMessage>
      </Show>
      <Show when={isChecking()}>
        <TextFieldDescription>Checking availability...</TextFieldDescription>
      </Show>
      <Show when={exists() === true}>
        <TextFieldErrorMessage>Username is already taken</TextFieldErrorMessage>
      </Show>
      <Show when={exists() === false}>
        <TextFieldDescription class="text-green-600">Username is available</TextFieldDescription>
      </Show>
    </TextField>
  )
}

type LoginFormProps = {
  class?: string
  onSuccess?: (response: any) => void
  onError?: (error: string) => void
  redirectTo?: string
}

const LoginForm = (props: LoginFormProps) => {
  const [local, others] = splitProps(props, ["class", "onSuccess", "onError"])
  const [email, setEmail] = createSignal("")
  const [password, setPassword] = createSignal("")
  const [rememberMe, setRememberMe] = createSignal(false)
  const [isLoading, setIsLoading] = createSignal(false)
  const [error, setError] = createSignal<string | null>(null)

  const handleSubmit = async (e: Event) => {
    e.preventDefault()
    setIsLoading(true)
    setError(null)
    
    try {
      const response = await authApi.login({
        email: email(),
        password: password(),
        rememberMe: rememberMe(),
      })
      local.onSuccess?.(response)
    } catch (e: any) {
      const errorMsg = e?.message ?? "Login failed"
      setError(errorMsg)
      local.onError?.(errorMsg)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Card class={local.class}>
      <CardHeader>
        <CardTitle>Sign In</CardTitle>
        <CardDescription>Enter your credentials to access your account</CardDescription>
      </CardHeader>
      <form onSubmit={handleSubmit}>
        <CardContent class="space-y-4">
          <EmailField 
            value={email()} 
            onInput={setEmail}
            showServerValidation={false}
          />
          <PasswordField 
            value={password()} 
            onInput={setPassword}
            showStrength={false}
          />
          <Flex justifyContent="space-between" alignItems="center">
            <Flex class="items-center gap-2">
              <Checkbox 
                checked={rememberMe()}
                onChange={setRememberMe}
              />
              <Text class="text-sm">Remember me</Text>
            </Flex>
            <a href="/forgot-password" class="text-sm text-primary hover:underline">
              Forgot password?
            </a>
          </Flex>
          <Show when={error()}>
            <Text class="text-destructive text-sm">{error()}</Text>
          </Show>
        </CardContent>
        <CardFooter class="flex-col gap-4">
          <Button type="submit" class="w-full" disabled={isLoading()}>
            {isLoading() ? "Signing in..." : "Sign In"}
          </Button>
          <IdentityProviderButtons />
        </CardFooter>
      </form>
    </Card>
  )
}

type RegisterFormProps = {
  class?: string
  onSuccess?: (response: any) => void
  onError?: (error: string) => void
  redirectTo?: string
}

const RegisterForm = (props: RegisterFormProps) => {
  const [local, others] = splitProps(props, ["class", "onSuccess", "onError"])
  const [email, setEmail] = createSignal("")
  const [username, setUsername] = createSignal("")
  const [password, setPassword] = createSignal("")
  const [confirmPassword, setConfirmPassword] = createSignal("")
  const [acceptTerms, setAcceptTerms] = createSignal(false)
  const [isLoading, setIsLoading] = createSignal(false)
  const [error, setError] = createSignal<string | null>(null)
  const [emailValidationResult, setEmailValidationResult] = createSignal<EmailServerValidationResult | null>(null)

  const isFormValid = createMemo(() => {
    const passwordStrength = getPasswordStrength(password())
    return (
      validateEmailFormat(email()).isValid &&
      validateUsername(username()).isValid &&
      passwordStrength.isValid &&
      validatePasswordMatch(password(), confirmPassword()).isValid &&
      acceptTerms() &&
      !emailValidationResult()?.isDisposable
    )
  })

  const handleSubmit = async (e: Event) => {
    e.preventDefault()
    if (!isFormValid()) return
    
    setIsLoading(true)
    setError(null)
    
    try {
      const response = await authApi.register({
        email: email(),
        password: password(),
        confirmPassword: confirmPassword(),
        username: username(),
      })
      local.onSuccess?.(response)
    } catch (e: any) {
      const errorMsg = e?.message ?? "Registration failed"
      setError(errorMsg)
      local.onError?.(errorMsg)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Card class={local.class}>
      <CardHeader>
        <CardTitle>Create Account</CardTitle>
        <CardDescription>Enter your details to get started</CardDescription>
      </CardHeader>
      <form onSubmit={handleSubmit}>
        <CardContent class="space-y-4">
          <EmailField 
            value={email()} 
            onInput={setEmail}
            showServerValidation={true}
            onServerValidation={setEmailValidationResult}
          />
          <UsernameField 
            value={username()} 
            onInput={setUsername}
          />
          <PasswordField 
            value={password()} 
            onInput={setPassword}
            showStrength={true}
          />
          <ConfirmPasswordField
            password={password()}
            value={confirmPassword()}
            onInput={setConfirmPassword}
          />
          <Flex class="items-start gap-2">
            <Checkbox 
              checked={acceptTerms()}
              onChange={setAcceptTerms}
            />
            <Text class="text-sm">
              I agree to the <a href="/terms" class="text-primary hover:underline">Terms of Service</a> and{" "}
              <a href="/privacy" class="text-primary hover:underline">Privacy Policy</a>
            </Text>
          </Flex>
          <Show when={error()}>
            <Text class="text-destructive text-sm">{error()}</Text>
          </Show>
        </CardContent>
        <CardFooter class="flex-col gap-4">
          <Button type="submit" class="w-full" disabled={isLoading() || !isFormValid()}>
            {isLoading() ? "Creating account..." : "Create Account"}
          </Button>
          <IdentityProviderButtons />
        </CardFooter>
      </form>
    </Card>
  )
}

type IdentityProviderButtonsProps = {
  providers?: IdentityProvider[]
  class?: string
  onProviderClick?: (provider: IdentityProvider) => void
}

const IdentityProviderButtons = (props: IdentityProviderButtonsProps) => {
  const [local, others] = splitProps(props, ["providers", "class", "onProviderClick"])
  const [isLoading, setIsLoading] = createSignal<string | null>(null)
  const [error, setError] = createSignal<string | null>(null)
  
  const providers = () => local.providers ?? ["GOOGLE", "GITHUB", "APPLE"] as IdentityProvider[]

  const handleProviderClick = async (provider: IdentityProvider) => {
    if (provider === "LOCAL") return
    
    setIsLoading(provider)
    setError(null)
    
    try {
      const response = await authApi.getOAuthUrl(provider)
      if (response.data?.url) {
        window.location.href = response.data.url
      } else {
        setError("Unable to connect to OAuth provider. Please try again.")
      }
    } catch (e) {
      console.error("OAuth error:", e)
      setError(`Failed to connect to ${provider}. Please try again.`)
    } finally {
      setIsLoading(null)
    }
    local.onProviderClick?.(provider)
  }

  return (
    <Flex flexDirection="col" class={cn("gap-2 w-full", local.class)}>
      <Show when={error()}>
        <div class="p-2 text-sm text-destructive bg-destructive/10 rounded">
          {error()}
        </div>
      </Show>
      <Flex class="items-center gap-2">
        <Separator class="flex-1" />
        <Text class="text-xs text-muted-foreground">or continue with</Text>
        <Separator class="flex-1" />
      </Flex>
      <Flex class="gap-2">
        <For each={providers()}>
          {(provider) => {
            const config = IDENTITY_PROVIDERS[provider]
            const loading = () => isLoading() === provider
            return (
              <Button
                type="button"
                variant="outline"
                class={cn("flex-1", config.color)}
                onClick={() => handleProviderClick(provider)}
                disabled={loading()}
              >
                <Show when={loading()}>
                  <span class="mr-2 animate-spin">⟳</span>
                </Show>
                <Show when={!loading() && config.icon}>
                  <span class="mr-2 font-bold">{config.icon}</span>
                </Show>
                {config.name}
              </Button>
            )
          }}
        </For>
      </Flex>
    </Flex>
  )
}

type PasswordResetFormProps = {
  class?: string
  onSuccess?: () => void
  onError?: (error: string) => void
}

const PasswordResetForm = (props: PasswordResetFormProps) => {
  const [local, others] = splitProps(props, ["class", "onSuccess", "onError"])
  const [email, setEmail] = createSignal("")
  const [isLoading, setIsLoading] = createSignal(false)
  const [success, setSuccess] = createSignal(false)
  const [error, setError] = createSignal<string | null>(null)

  const handleSubmit = async (e: Event) => {
    e.preventDefault()
    setIsLoading(true)
    setError(null)
    
    try {
      await authApi.requestPasswordReset({ email: email() })
      setSuccess(true)
      local.onSuccess?.()
    } catch (e: any) {
      const errorMsg = e?.message ?? "Password reset failed"
      setError(errorMsg)
      local.onError?.(errorMsg)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <PasswordResetProvider>
      <Card class={local.class}>
        <CardHeader>
          <CardTitle>Reset Password</CardTitle>
          <CardDescription>
            {success() 
              ? "Check your email for reset instructions"
              : "Enter your email to receive reset instructions"
            }
          </CardDescription>
        </CardHeader>
        <Show when={!success()}>
          <form onSubmit={handleSubmit}>
            <CardContent class="space-y-4">
              <EmailField 
                value={email()} 
                onInput={setEmail}
                showServerValidation={false}
              />
              <Show when={error()}>
                <Text class="text-destructive text-sm">{error()}</Text>
              </Show>
            </CardContent>
            <CardFooter>
              <Button type="submit" class="w-full" disabled={isLoading()}>
                {isLoading() ? "Sending..." : "Send Reset Link"}
              </Button>
            </CardFooter>
          </form>
        </Show>
        <Show when={success()}>
          <CardContent>
            <Text class="text-center text-muted-foreground">
              If an account exists with that email, you will receive password reset instructions.
            </Text>
          </CardContent>
        </Show>
      </Card>
    </PasswordResetProvider>
  )
}

export type {
  EmailFieldProps,
  PasswordFieldProps,
  ConfirmPasswordFieldProps,
  UsernameFieldProps,
  LoginFormProps,
  RegisterFormProps,
  PasswordResetFormProps,
  IdentityProviderButtonsProps,
  EmailValidationStatusProps,
}

export {
  EmailField,
  PasswordField,
  ConfirmPasswordField,
  UsernameField,
  EmailValidationStatus,
  LoginForm,
  RegisterForm,
  PasswordResetForm,
  IdentityProviderButtons,
  AuthUIProvider,
  PasswordResetProvider,
  EmailVerificationProvider,
  SessionProvider,
  useAuthUI,
  usePasswordReset,
  useEmailVerification,
  useSession,
  IDENTITY_PROVIDERS,
}
