import { Show, For, createSignal, type JSX } from "solid-js"
import { splitProps, createEffect } from "solid-js"
import { CategoryProvider } from "./category-context"
import { CategoryImage, CategoryName, CategoryLevel } from "./category-sections"
import { categoriesApi } from "~/lib/api/categories"
import { useCurrentStoreId } from "~/lib/stores/store-context"
import { cn } from "~/lib/utils"
import type { Category } from "~/lib/types"

type CategoryMegaMenuViewProps = {
  storeId?: string
  data?: Category[]
  orientation?: "horizontal" | "vertical"
  class?: string
  children?: JSX.Element
}

export function CategoryMegaMenuView(props: CategoryMegaMenuViewProps) {
  const [local, others] = splitProps(props, ["storeId", "data", "orientation", "class", "children"])
  const contextStoreId = useCurrentStoreId()
  const resolvedStoreId = () => local.storeId ?? contextStoreId()
  const orientation = local.orientation ?? "horizontal"

  const [treeData, setTreeData] = createSignal<Category[]>([])
  const [loading, setLoading] = createSignal(true)
  const [error, setError] = createSignal<string | null>(null)
  const [activeMenu, setActiveMenu] = createSignal<string | null>(null)

  createEffect(() => {
    const store = resolvedStoreId()
    if (!store) return

    if (local.data) {
      setTreeData(local.data)
      setLoading(false)
      return
    }

    setLoading(true)
    setError(null)
    categoriesApi.getTree(store)
      .then((response) => {
        setTreeData(response.content)
        setLoading(false)
      })
      .catch((err) => {
        setError(err.message || "Failed to load categories")
        setLoading(false)
      })
  })

  const isHorizontal = () => orientation === "horizontal"

  return (
    <div class={cn("relative", local.class)}>
      <Show when={loading()}>
        <MegaMenuLoadingSkeleton horizontal={isHorizontal()} />
      </Show>
      <Show when={error()}>
        <div class="text-destructive text-sm p-4">{error()}</div>
      </Show>
      <Show when={!loading() && !error()}>
        <Show
          when={isHorizontal()}
          fallback={
            <nav class={cn("flex flex-col gap-1", local.class)}>
              <For each={treeData()}>
                {(item) => (
                  <MegaMenuVerticalNode 
                    item={item}
                    depth={0}
                    activeMenu={activeMenu}
                    setActiveMenu={setActiveMenu}
                  >
                    {local.children}
                  </MegaMenuVerticalNode>
                )}
              </For>
            </nav>
          }
        >
          <nav class={cn("flex items-center gap-1", local.class)}>
            <For each={treeData()}>
              {(item) => (
                <MegaMenuHorizontalItem 
                  item={item}
                  isActive={activeMenu() === item.id}
                  onHover={() => setActiveMenu(item.id ?? null)}
                  onLeave={() => setActiveMenu(null)}
                >
                  {local.children}
                </MegaMenuHorizontalItem>
              )}
            </For>
          </nav>
        </Show>
      </Show>
    </div>
  )
}

type MegaMenuHorizontalItemProps = {
  item: Category
  isActive: boolean
  onHover: () => void
  onLeave: () => void
  children?: JSX.Element
}

function MegaMenuHorizontalItem(props: MegaMenuHorizontalItemProps) {
  const hasChildren = () => (props.item.subcategories?.length ?? 0) > 0

  return (
    <CategoryProvider data={props.item}>
      <div 
        class="relative"
        onMouseEnter={props.onHover}
        onMouseLeave={props.onLeave}
      >
        <Show
          when={props.children}
          fallback={
            <div class={cn(
              "flex items-center gap-2 px-4 py-2 rounded-md cursor-pointer transition-colors",
              props.isActive ? "bg-accent" : "hover:bg-accent/50"
            )}>
              <CategoryImage class="size-6 rounded" />
              <span class="text-sm font-medium"><CategoryName /></span>
              <Show when={hasChildren()}>
                <span class="text-xs text-muted-foreground">▾</span>
              </Show>
            </div>
          }
        >
          <div class={cn(
            "flex items-center gap-2 px-4 py-2 rounded-md cursor-pointer transition-colors",
            props.isActive ? "bg-accent" : "hover:bg-accent/50"
          )}>
            {props.children}
          </div>
        </Show>
        
        <Show when={hasChildren() && props.isActive}>
          <MegaMenuDropdown 
            item={props.item}
            onClose={() => props.onLeave()}
          />
        </Show>
      </div>
    </CategoryProvider>
  )
}

type MegaMenuDropdownProps = {
  item: Category
  onClose: () => void
  children?: JSX.Element
}

function MegaMenuDropdown(props: MegaMenuDropdownProps) {
  return (
    <div 
      class="absolute top-full left-0 mt-1 min-w-[240px] bg-background border rounded-lg shadow-lg p-2 z-50"
      onMouseLeave={props.onClose}
    >
      <ul class="space-y-1">
        <For each={props.item.subcategories ?? []}>
          {(child) => (
            <MegaMenuDropdownItem item={child} children={props.children} />
          )}
        </For>
      </ul>
    </div>
  )
}

type MegaMenuDropdownItemProps = {
  item: Category
  children?: JSX.Element
}

function MegaMenuDropdownItem(props: MegaMenuDropdownItemProps) {
  const hasChildren = () => (props.item.subcategories?.length ?? 0) > 0
  const [showSubmenu, setShowSubmenu] = createSignal(false)

  return (
    <CategoryProvider data={props.item}>
      <li 
        class="relative"
        onMouseEnter={() => setShowSubmenu(true)}
        onMouseLeave={() => setShowSubmenu(false)}
      >
        <Show
          when={props.children}
          fallback={
            <div class={cn(
              "flex items-center gap-2 px-3 py-2 rounded-md cursor-pointer transition-colors",
              showSubmenu() ? "bg-accent" : "hover:bg-accent/50"
            )}>
              <CategoryImage class="size-6 rounded" />
              <span class="text-sm flex-1"><CategoryName /></span>
              <Show when={hasChildren()}>
                <span class="text-xs text-muted-foreground">▶</span>
              </Show>
            </div>
          }
        >
          <div class={cn(
            "flex items-center gap-2 px-3 py-2 rounded-md cursor-pointer transition-colors",
            showSubmenu() ? "bg-accent" : "hover:bg-accent/50"
          )}>
            {props.children}
          </div>
        </Show>
        
        <Show when={hasChildren() && showSubmenu()}>
          <div class="absolute left-full top-0 ml-1 min-w-[200px] bg-background border rounded-lg shadow-lg p-2">
            <ul class="space-y-1">
              <For each={props.item.subcategories ?? []}>
                {(subchild) => (
                  <MegaMenuDropdownItem item={subchild} children={props.children} />
                )}
              </For>
            </ul>
          </div>
        </Show>
      </li>
    </CategoryProvider>
  )
}

type MegaMenuVerticalNodeProps = {
  item: Category
  depth?: number
  activeMenu: () => string | null
  setActiveMenu: (id: string | null) => void
  children?: JSX.Element
}

function MegaMenuVerticalNode(props: MegaMenuVerticalNodeProps) {
  const [local] = splitProps(props, ["item", "depth", "activeMenu", "setActiveMenu", "children"])
  const depth = () => local.depth ?? 0
  const hasChildren = () => (local.item.subcategories?.length ?? 0) > 0
  const isActive = () => local.activeMenu() === local.item.id

  return (
    <CategoryProvider data={local.item} depth={depth()}>
      <li class="relative">
        <div 
          class={cn(
            "flex items-center gap-2 px-3 py-2 rounded-md cursor-pointer transition-colors",
            isActive() ? "bg-accent" : "hover:bg-accent/50"
          )}
          onClick={() => local.setActiveMenu(isActive() ? null : local.item.id ?? null)}
        >
          <CategoryImage class="size-5 rounded" />
          <span class="text-sm flex-1"><CategoryName /></span>
          <Show when={hasChildren()}>
            <span class="text-xs text-muted-foreground">{isActive() ? "▴" : "▾"}</span>
          </Show>
        </div>
        
        <Show when={hasChildren() && isActive()}>
          <ul class="mt-1 ml-2 border-l border-border pl-2 space-y-1">
            <For each={local.item.subcategories ?? []}>
              {(child) => (
                <MegaMenuVerticalNode 
                  item={child}
                  depth={depth() + 1}
                  activeMenu={local.activeMenu}
                  setActiveMenu={local.setActiveMenu}
                >
                  {local.children}
                </MegaMenuVerticalNode>
              )}
            </For>
          </ul>
        </Show>
      </li>
    </CategoryProvider>
  )
}

function MegaMenuLoadingSkeleton(props: { horizontal: boolean }) {
  return (
    <div class={cn("flex gap-2 p-2", !props.horizontal && "flex-col")}>
      <For each={props.horizontal ? [1, 2, 3, 4, 5] : [1, 2, 3]}>
        {() => (
          <div class={cn(
            "h-9 animate-pulse bg-muted rounded-md",
            props.horizontal ? "w-24" : "w-full h-8"
          )} />
        )}
      </For>
    </div>
  )
}
