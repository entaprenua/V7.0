import { Show, For, createSignal, type JSX } from "solid-js"
import { splitProps, createEffect } from "solid-js"
import { CategoryProvider } from "./category-context"
import { CategoryImage, CategoryName, CategoryLevel } from "./category-sections"
import { categoriesApi } from "~/lib/api/categories"
import { useCurrentStoreId } from "~/lib/stores/store-context"
import { cn } from "~/lib/utils"
import { 
  SidebarMenu, 
  SidebarMenuItem, 
  SidebarMenuButton,
  SidebarMenuSub,
  SidebarGroup,
  SidebarGroupLabel,
  SidebarGroupContent,
  SidebarMenuSkeleton,
} from "~/components/ui/sidebar"
import type { Category } from "~/lib/types"

type CategorySidebarViewProps = {
  storeId?: string
  data?: Category[]
  expanded?: boolean
  showCounts?: boolean
  class?: string
  children?: JSX.Element
}

export function CategorySidebarView(props: CategorySidebarViewProps) {
  const [local] = splitProps(props, ["storeId", "data", "expanded", "showCounts", "class", "children"])
  const contextStoreId = useCurrentStoreId()
  const resolvedStoreId = () => local.storeId ?? contextStoreId()
  const initialExpanded = local.expanded ?? true

  const [treeData, setTreeData] = createSignal<Category[]>([])
  const [loading, setLoading] = createSignal(true)
  const [error, setError] = createSignal<string | null>(null)

  createEffect(() => {
    const store = resolvedStoreId()
    if (!store) return

    if (local.data) {
      setTreeData(local.data)
      setLoading(false)
      return
    }

    setLoading(true)
    setError(null)
    categoriesApi.getTree(store)
      .then((response) => {
        setTreeData(response.content)
        setLoading(false)
      })
      .catch((err) => {
        setError(err.message || "Failed to load categories")
        setLoading(false)
      })
  })

  return (
    <SidebarGroup>
      <SidebarGroupLabel class="text-xs uppercase tracking-wider text-muted-foreground">
        Categories
      </SidebarGroupLabel>
      <SidebarGroupContent>
        <Show when={loading()}>
          <SidebarLoadingSkeleton />
        </Show>
        <Show when={error()}>
          <div class="text-destructive text-sm px-3 py-2">{error()}</div>
        </Show>
        <Show when={!loading() && !error()}>
          <SidebarMenu>
            <For each={treeData()}>
              {(item) => (
                <SidebarNode 
                  item={item} 
                  depth={0}
                  initialExpanded={initialExpanded}
                >
                  {local.children}
                </SidebarNode>
              )}
            </For>
          </SidebarMenu>
        </Show>
      </SidebarGroupContent>
    </SidebarGroup>
  )
}

type SidebarNodeProps = {
  item: Category
  depth?: number
  initialExpanded: boolean
  children?: JSX.Element
}

function SidebarNode(props: SidebarNodeProps) {
  const [local] = splitProps(props, ["item", "depth", "initialExpanded", "children"])
  const depth = () => local.depth ?? 0
  const hasChildren = () => (local.item.subcategories?.length ?? 0) > 0
  const [isExpanded, setIsExpanded] = createSignal(local.initialExpanded)

  const toggle = () => {
    if (hasChildren()) {
      setIsExpanded(!isExpanded())
    }
  }

  return (
    <CategoryProvider data={local.item} depth={depth()}>
      <SidebarMenuItem>
        <Show
          when={hasChildren()}
          fallback={
            <SidebarMenuButton class="w-full">
              <Show
                when={local.children}
                fallback={
                  <DefaultSidebarItem />
                }
              >
                {local.children}
              </Show>
            </SidebarMenuButton>
          }
        >
          <SidebarMenuButton 
            class="w-full"
            onClick={toggle}
            data-active={isExpanded()}
          >
            <Show
              when={local.children}
              fallback={
                <DefaultSidebarItem withExpand />
              }
            >
              {local.children}
            </Show>
            <ChevronRightIcon 
              class={cn(
                "ml-auto h-4 w-4 transition-transform shrink-0",
                isExpanded() && "rotate-90"
              )} 
            />
          </SidebarMenuButton>
          
          <Show when={hasChildren() && isExpanded()}>
            <SidebarMenuSub>
              <For each={local.item.subcategories ?? []}>
                {(child) => (
                  <SidebarNode 
                    item={child} 
                    depth={depth() + 1}
                    initialExpanded={local.initialExpanded}
                  >
                    {local.children}
                  </SidebarNode>
                )}
              </For>
            </SidebarMenuSub>
          </Show>
        </Show>
      </SidebarMenuItem>
    </CategoryProvider>
  )
}

function DefaultSidebarItem(props: { withExpand?: boolean }) {
  return (
    <div class="flex items-center gap-2 w-full">
      <CategoryImage class="size-5 rounded shrink-0" />
      <span class="truncate flex-1"><CategoryName /></span>
      <CategoryLevel class="text-xs text-muted-foreground shrink-0" />
    </div>
  )
}

function SidebarLoadingSkeleton() {
  return (
    <SidebarMenu>
      <For each={[1, 2, 3, 4, 5]}>
        {() => (
          <SidebarMenuItem>
            <SidebarMenuSkeleton />
          </SidebarMenuItem>
        )}
      </For>
    </SidebarMenu>
  )
}

function ChevronRightIcon(props: { class?: string }) {
  return (
    <svg 
      xmlns="http://www.w3.org/2000/svg" 
      viewBox="0 0 24 24" 
      fill="none" 
      stroke="currentColor" 
      stroke-width="2" 
      stroke-linecap="round" 
      stroke-linejoin="round"
      class={props.class}
    >
      <path d="m9 18 6-6-6-6" />
    </svg>
  )
}
