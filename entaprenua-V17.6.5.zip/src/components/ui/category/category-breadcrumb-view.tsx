import { Show, For, type JSX } from "solid-js"
import { createEffect, createSignal, splitProps } from "solid-js"
import { CategoryProvider } from "./category-context"
import { CategoryName } from "./category-sections"
import { categoriesApi } from "~/lib/api/categories"
import { useCurrentStoreId } from "~/lib/stores/store-context"
import { cn } from "~/lib/utils"
import type { Category } from "~/lib/types"

type CategoryBreadcrumbViewProps = {
  storeId?: string
  categoryId?: string
  separator?: string | JSX.Element
  class?: string
  children?: (item: Category) => JSX.Element
}

export function CategoryBreadcrumbView(props: CategoryBreadcrumbViewProps) {
  const [local] = splitProps(props, ["storeId", "categoryId", "separator", "class", "children"])
  const contextStoreId = useCurrentStoreId()
  const resolvedStoreId = () => local.storeId ?? contextStoreId()

  const [pathCategories, setPathCategories] = createSignal<Category[]>([])
  const [loading, setLoading] = createSignal(false)
  const [error, setError] = createSignal<string | null>(null)

  createEffect(() => {
    const store = resolvedStoreId()
    const categoryId = local.categoryId
    
    if (!store || !categoryId) {
      setPathCategories([])
      return
    }

    setLoading(true)
    setError(null)
    
    categoriesApi.getById(store, categoryId)
      .then((category) => {
        if (category.path) {
          const pathParts = category.path.split('.')
          const categoryPromises = pathParts.map((_, index: number) => {
            const level = index + 1
            return categoriesApi.getAll(store, 0, 100, { level })
              .then(response => response.content.find(c => {
                const cPathParts = c.path?.split('.') ?? []
                return cPathParts.length === level && c.path === pathParts.slice(0, level + 1).join('.')
              }))
          })
          return Promise.all(categoryPromises)
        }
        return []
      })
      .then((path) => {
        setPathCategories(path.filter(Boolean) as Category[])
        setLoading(false)
      })
      .catch((err) => {
        setError(err.message || "Failed to load breadcrumb")
        setLoading(false)
      })
  })

  const separator = () => local.separator ?? "/"

  return (
    <nav class={cn("flex items-center gap-2 text-sm", local.class)}>
      <Show when={loading()}>
        <BreadcrumbLoadingSkeleton />
      </Show>
      <Show when={error()}>
        <span class="text-destructive text-sm">{error()}</span>
      </Show>
      <Show when={!loading() && !error()}>
        <Show
          when={pathCategories().length > 0}
          fallback={<span class="text-muted-foreground">No category selected</span>}
        >
          <For each={pathCategories()}>
            {(item, index) => (
              <>
                <Show when={index() > 0}>
                  <span class="text-muted-foreground">
                    {typeof separator() === 'string' ? separator() : separator()}
                  </span>
                </Show>
                <CategoryProvider data={item}>
                  <span class="hover:underline cursor-pointer">
                    <Show
                      when={local.children}
                      fallback={<CategoryName />}
                    >
                      {local.children!(item)}
                    </Show>
                  </span>
                </CategoryProvider>
              </>
            )}
          </For>
          <Show when={local.categoryId && pathCategories().length > 0}>
            <Show when={pathCategories()[pathCategories().length - 1]?.id !== local.categoryId}>
              <span class="text-muted-foreground">
                {typeof separator() === 'string' ? separator() : separator()}
              </span>
              <span class="font-medium">Current</span>
            </Show>
          </Show>
        </Show>
      </Show>
    </nav>
  )
}

function BreadcrumbLoadingSkeleton() {
  return (
    <div class="flex items-center gap-2">
      <div class="h-4 w-20 animate-pulse bg-muted rounded" />
      <div class="h-4 w-4 animate-pulse bg-muted rounded" />
      <div class="h-4 w-24 animate-pulse bg-muted rounded" />
      <div class="h-4 w-4 animate-pulse bg-muted rounded" />
      <div class="h-4 w-16 animate-pulse bg-muted rounded" />
    </div>
  )
}
