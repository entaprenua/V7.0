# Category Components Architecture

## Overview

Atomic, composable category components with pre-built tree view variants. Uses single API call (`tree=true`) with client-side tree building to avoid infinite loops.

## Design Principles

1. **Codeless** - Components auto-read from context, no manual data passing
2. **Composable** - Section primitives that users combine freely
3. **Pre-built Variants** - Ready-to-use tree views (no recursive nesting code)
4. **Atomic** - Raw value components, user provides styling

## Data Flow

```
GET /stores/:id/categories?tree=true
        ↓
Full tree with subcategories[] populated
        ↓
TreeView components render recursively
        ↓
Click expand → toggle visibility (no re-fetch)
```

## API Endpoints

| Endpoint | Purpose |
|----------|---------|
| `GET /stores/:id/categories?root=true` | Root categories only |
| `GET /stores/:id/categories?tree=true` | Full nested tree |
| `GET /stores/:id/categories?level=N` | Categories by level |

## Tree View Variants

### 1. CategoryTreeView
Expandable tree with chevron icons. For admin panels, category management.

```tsx
<CategoryTreeView storeId>
  {(item) => (
    <Category>
      <CategoryImage class="size-6 rounded" />
      <CategoryName />
    </Category>
  )}
</CategoryTreeView>
```

### 2. CategorySidebarView
Vertical collapsible tree. For left-side navigation, filters.

```tsx
<CategorySidebarView storeId expanded={true}>
  {(item) => (
    <Category>
      <CategoryName />
      <CategoryLevelBadge />
    </Category>
  )}
</CategorySidebarView>
```

### 3. CategoryFilterTreeView
Checkbox-based multi-select tree. For faceted search filters.

```tsx
<CategoryFilterTreeView storeId>
  {(item, checked, onCheck) => (
    <label class="flex items-center gap-2">
      <input type="checkbox" checked={checked()} onChange={onCheck} />
      <CategoryName />
      <span class="text-muted-foreground">(12)</span>
    </label>
  )}
</CategoryFilterTreeView>
```

### 4. CategoryMegaMenuView
Horizontal dropdown menu with images. For main navigation.

```tsx
<CategoryMegaMenuView storeId orientation="horizontal">
  {(item) => (
    <Category>
      <CategoryImage class="size-12 rounded-lg" />
      <CategoryName />
      <Text variant="body2" class="text-muted-foreground">Description</Text>
    </Category>
  )}
</CategoryMegaMenuView>
```

### 5. CategoryBreadcrumbView
Non-interactive path display. For navigation context.

```tsx
<CategoryBreadcrumbView storeId categoryId="current-category-id" />
```

## Components

### CategoryList (Flat Lists)

For grid, horizontal, and simple lists.

```typescript
type CategoryListProps = {
  storeId?: string
  level?: number
  rootOnly?: boolean
  layout?: "vertical-grid" | "horizontal-grid" | "row"
  columns?: number
  gap?: number
  children?: JSX.Element
}
```

### CategoryTreeView

```typescript
type CategoryTreeViewProps = {
  storeId?: string
  data?: CategoryTreeNode[]       // Optional if storeId provided
  expanded?: boolean              // Initial state (default: true)
  class?: string
  children?: (item: CategoryTreeNode) => JSX.Element
}
```

### CategorySidebarView

```typescript
type CategorySidebarViewProps = {
  storeId?: string
  data?: CategoryTreeNode[]
  expanded?: boolean              // All nodes expanded by default
  showCounts?: boolean            // Show product counts
  class?: string
  children?: (item: CategoryTreeNode) => JSX.Element
}
```

### CategoryFilterTreeView

```typescript
type CategoryFilterTreeViewProps = {
  storeId?: string
  data?: CategoryTreeNode[]
  selectedIds?: string[]         // Controlled selection
  onSelectionChange?: (ids: string[]) => void
  class?: string
  children?: (item: CategoryTreeNode, checked: Accessor<boolean>, onCheck: (id: string, checked: boolean) => void) => JSX.Element
}
```

### CategoryMegaMenuView

```typescript
type CategoryMegaMenuViewProps = {
  storeId?: string
  data?: CategoryTreeNode[]
  orientation?: "horizontal" | "vertical"
  class?: string
  children?: (item: CategoryTreeNode) => JSX.Element
}
```

### CategoryBreadcrumbView

```typescript
type CategoryBreadcrumbViewProps = {
  storeId?: string
  categoryId?: string             // Current category for path
  separator?: string | JSX.Element
  class?: string
}
```

## Codeless Default Rendering

When no children provided, each view shows a sensible default:

| View | Default Shows |
|------|--------------|
| TreeView | Image + Name + Chevron |
| SidebarView | Name + Count |
| FilterTreeView | Checkbox + Name + Count |
| MegaMenuView | Image + Name |
| BreadcrumbView | Path segments with separators |

```tsx
// Fully codeless - uses defaults
<CategoryTreeView storeId />

// With minimal customization
<CategoryTreeView storeId>
  <CategoryTreeView.Item>
    <CategoryImage />
    <CategoryName />
  </CategoryTreeView.Item>
</CategoryTreeView>
```

## Atomic Section Primitives

All primitives read from `useCategory()`.

```typescript
<CategoryName class?: string />
<CategoryImage class?: string; alt?: string />
<CategorySlug class?: string />
<CategoryLevel class?: string />
<CategoryLevelBadge class?: string />
<CategoryDepth class?: string />
<CategoryPath class?: string />
<CategoryParentId class?: string />
<CategoryChildren />              // Renders subcategories with same template
<CategoryExpandButton />          // Chevron with click handler
```

## CategoryContext

```typescript
type CategoryContextValue = {
  data: Accessor<Category | null>
  id: Accessor<string | null>
  name: Accessor<string | null>
  slug: Accessor<string | null>
  image: Accessor<string | null>
  level: Accessor<number | null>
  depth: Accessor<number | null>
  parentId: Accessor<string | null>
  path: Accessor<string | null>
  subcategories: Accessor<Category[]>
  isExpanded: Accessor<boolean>
  toggleExpanded: () => void
  isChecked: Accessor<boolean>
  setChecked: (checked: boolean) => void
}

export const useCategory = (): CategoryContextValue => { ... }
```

## Usage Examples

### Grid Display

```tsx
<CategoryList storeId layout="vertical-grid" columns={4} gap={6}>
  <CategoryListView>
    <Category class="border rounded-xl overflow-hidden">
      <CategoryImage class="w-full h-32 object-cover" />
      <Flex class="p-4">
        <CategoryName class="font-semibold" />
      </Flex>
    </Category>
  </CategoryListView>
</CategoryList>
```

### Admin Tree (Expandable)

```tsx
<CategoryTreeView storeId>
  {(item) => (
    <Paper class="flex items-center gap-3 p-2 rounded hover:bg-muted">
      <CategoryImage class="size-8 rounded" />
      <CategoryName class="flex-1" />
      <CategoryLevelBadge class="ml-auto" />
      <CategoryExpandButton />
    </Paper>
  )}
</CategoryTreeView>
```

### Sidebar Filter

```tsx
<CategoryFilterTreeView storeId onSelectionChange={setSelected}>
  {(item, checked, onCheck) => (
    <Flex class="items-center gap-2 py-1">
      <Checkbox 
        checked={checked()} 
        onChange={(c) => onCheck(item.id, c)} 
      />
      <CategoryName />
      <Text variant="caption" class="ml-auto text-muted-foreground">
        (12)
      </Text>
    </Flex>
  )}
</CategoryFilterTreeView>
```

### Mega Menu Navigation

```tsx
<CategoryMegaMenuView orientation="horizontal">
  {(item) => (
    <Link href={`/category/${item.slug}`}>
      <CategoryImage class="size-16 rounded-lg" />
      <CategoryName class="text-center" />
    </Link>
  )}
</CategoryMegaMenuView>
```

### Breadcrumb

```tsx
<CategoryBreadcrumbView 
  storeId 
  categoryId={currentCategoryId}
  separator="/"
/>
```

## File Structure

```
src/components/ui/category/
├── index.ts                      # Barrel exports
├── category-context.tsx          # Context + useCategory() hook
├── category-root.tsx             # Category component
├── category-list.tsx             # CategoryList + CategoryListView
├── category-tree-view.tsx        # CategoryTreeView
├── category-sidebar-view.tsx     # CategorySidebarView
├── category-filter-view.tsx      # CategoryFilterTreeView
├── category-mega-menu.tsx        # CategoryMegaMenuView
├── category-breadcrumb-view.tsx  # CategoryBreadcrumbView
├── category-sections.tsx         # Atomic primitives
└── STRUCTURE.md                  # This file
```

## Implementation Order

| Phase | Components | Priority |
|-------|-----------|----------|
| 1 | CategoryList (flat) | ✅ Done |
| 2 | API `getTree()` | TODO |
| 3 | CategoryTreeView | TODO |
| 4 | CategorySidebarView | TODO |
| 5 | CategoryFilterTreeView | TODO |
| 6 | CategoryMegaMenuView | TODO |
| 7 | CategoryBreadcrumbView | TODO |

## Known Issues

### Nested CategoryList Infinite Loop (RESOLVED)

**Solution:** Pre-built tree views with single API fetch (`tree=true`).

Instead of recursive API calls, we fetch the full tree once and render client-side.

```tsx
// OLD (broken)
<CategoryList>
  <CategoryList>
    <CategoryList>  // Infinite loop!
    </CategoryList>
  </CategoryList>
</CategoryList>

// NEW (works)
<CategoryTreeView storeId>
  // Handles nested rendering internally
</CategoryTreeView>
```
