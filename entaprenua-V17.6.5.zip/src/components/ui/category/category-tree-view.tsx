import { Show, For, createSignal, type JSX } from "solid-js"
import { splitProps, createEffect } from "solid-js"
import { CategoryProvider, useCategory } from "./category-context"
import { CategoryImage, CategoryName, CategoryLevel } from "./category-sections"
import { categoriesApi } from "~/lib/api/categories"
import { useCurrentStoreId } from "~/lib/stores/store-context"
import { cn } from "~/lib/utils"
import type { Category } from "~/lib/types"

type CategoryTreeViewProps = {
  storeId?: string
  data?: Category[]
  expanded?: boolean
  class?: string
  children?: JSX.Element
}

export function CategoryTreeView(props: CategoryTreeViewProps) {
  const [local, others] = splitProps(props, ["storeId", "data", "expanded", "class", "children"])
  const contextStoreId = useCurrentStoreId()
  const resolvedStoreId = () => local.storeId ?? contextStoreId()
  const initialExpanded = local.expanded ?? true

  const [treeData, setTreeData] = createSignal<Category[]>([])
  const [loading, setLoading] = createSignal(true)
  const [error, setError] = createSignal<string | null>(null)

  createEffect(() => {
    const store = resolvedStoreId()
    if (!store) return

    if (local.data) {
      setTreeData(local.data)
      setLoading(false)
      return
    }

    setLoading(true)
    setError(null)
    categoriesApi.getTree(store)
      .then((response) => {
        setTreeData(response.content)
        setLoading(false)
      })
      .catch((err) => {
        setError(err.message || "Failed to load categories")
        setLoading(false)
      })
  })

  return (
    <div class={cn("relative", local.class)}>
      <Show when={loading()}>
        <TreeLoadingSkeleton />
      </Show>
      <Show when={error()}>
        <div class="text-destructive text-sm p-4">{error()}</div>
      </Show>
      <Show when={!loading() && !error()}>
        <ul class="space-y-1">
          <For each={treeData()}>
            {(item) => (
              <TreeNode 
                item={item} 
                depth={0}
                initialExpanded={initialExpanded}
              >
                {local.children}
              </TreeNode>
            )}
          </For>
        </ul>
      </Show>
    </div>
  )
}

type TreeNodeProps = {
  item: Category
  depth?: number
  initialExpanded: boolean
  children?: JSX.Element
}

function TreeNode(props: TreeNodeProps) {
  const [local] = splitProps(props, ["item", "depth", "initialExpanded", "children"])
  const depth = () => local.depth ?? 0
  const hasChildren = () => (local.item.subcategories?.length ?? 0) > 0
  const [isExpanded, setIsExpanded] = createSignal(local.initialExpanded)

  const indentClass = () => {
    const d = depth()
    if (d === 0) return ""
    if (d === 1) return "ml-4"
    return `ml-${Math.min(d * 4, 12)}`
  }

  const toggle = () => {
    if (hasChildren()) {
      setIsExpanded(!isExpanded())
    }
  }

  return (
    <CategoryProvider data={local.item} depth={depth()}>
      <li class={indentClass()}>
        <div 
          class="flex items-center gap-1 group"
          onClick={toggle}
        >
          <Show when={hasChildren()}>
            <button 
              class={cn(
                "size-5 flex items-center justify-center text-muted-foreground hover:text-foreground transition-all duration-200",
                isExpanded() && "rotate-90"
              )}
            >
              <ChevronRightIcon class="size-3" />
            </button>
          </Show>
          <Show when={!hasChildren()}>
            <span class="size-5" />
          </Show>
          <div class="flex-1">
            <Show
              when={local.children}
              fallback={<DefaultTreeItem />}
            >
              {local.children}
            </Show>
          </div>
        </div>
        <Show when={hasChildren() && isExpanded()}>
          <ul class="mt-1 space-y-1">
            <For each={local.item.subcategories ?? []}>
              {(child) => (
                <TreeNode 
                  item={child} 
                  depth={depth() + 1}
                  initialExpanded={local.initialExpanded}
                >
                  {local.children}
                </TreeNode>
              )}
            </For>
          </ul>
        </Show>
      </li>
    </CategoryProvider>
  )
}

function DefaultTreeItem(): JSX.Element {
  return (
    <div class="flex items-center gap-2 p-2 rounded hover:bg-muted cursor-pointer transition-colors">
      <CategoryImage class="size-6 rounded object-cover" />
      <CategoryName class="text-sm font-medium" />
      <CategoryLevel class="ml-auto text-xs text-muted-foreground bg-muted px-2 py-0.5 rounded" />
    </div>
  )
}

function TreeLoadingSkeleton() {
  return (
    <div class="space-y-2 p-2">
      <For each={[1, 2, 3, 4, 5]}>
        {() => (
          <div class="flex items-center gap-2">
            <div class="size-5 animate-pulse bg-muted rounded" />
            <div class="flex-1 h-8 animate-pulse bg-muted rounded" />
          </div>
        )}
      </For>
    </div>
  )
}

function ChevronRightIcon(props: { class?: string }) {
  return (
    <svg 
      xmlns="http://www.w3.org/2000/svg" 
      viewBox="0 0 24 24" 
      fill="none" 
      stroke="currentColor" 
      stroke-width="2" 
      stroke-linecap="round" 
      stroke-linejoin="round"
      class={props.class}
    >
      <path d="m9 18 6-6-6-6" />
    </svg>
  )
}
