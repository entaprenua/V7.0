import { Show, For, createSignal, type JSX, createMemo } from "solid-js"
import { splitProps, createEffect } from "solid-js"
import { CategoryProvider } from "./category-context"
import { CategoryImage, CategoryName } from "./category-sections"
import { categoriesApi } from "~/lib/api/categories"
import { useCurrentStoreId } from "~/lib/stores/store-context"
import { cn } from "~/lib/utils"
import type { Category } from "~/lib/types"

type CategoryFilterTreeViewProps = {
  storeId?: string
  data?: Category[]
  selectedIds?: string[]
  onSelectionChange?: (ids: string[]) => void
  class?: string
  children?: (item: Category, checked: () => boolean, onCheck: (id: string, checked: boolean) => void) => JSX.Element
}

export function CategoryFilterTreeView(props: CategoryFilterTreeViewProps) {
  const [local, others] = splitProps(props, ["storeId", "data", "selectedIds", "onSelectionChange", "class", "children"])
  const contextStoreId = useCurrentStoreId()
  const resolvedStoreId = () => local.storeId ?? contextStoreId()

  const [treeData, setTreeData] = createSignal<Category[]>([])
  const [loading, setLoading] = createSignal(true)
  const [error, setError] = createSignal<string | null>(null)
  const [selected, setSelected] = createSignal<Set<string>>(new Set(local.selectedIds ?? []))

  createEffect(() => {
    const store = resolvedStoreId()
    if (!store) return

    if (local.data) {
      setTreeData(local.data)
      setLoading(false)
      return
    }

    setLoading(true)
    setError(null)
    categoriesApi.getTree(store)
      .then((response) => {
        setTreeData(response.content)
        setLoading(false)
      })
      .catch((err) => {
        setError(err.message || "Failed to load categories")
        setLoading(false)
      })
  })

  const isChecked = (id: string) => selected().has(id)

  const handleCheck = (id: string, checked: boolean) => {
    const newSelected = new Set(selected())
    if (checked) {
      newSelected.add(id)
    } else {
      newSelected.delete(id)
    }
    setSelected(newSelected)
    local.onSelectionChange?.(Array.from(newSelected))
  }

  return (
    <div class={cn("w-full", local.class)}>
      <Show when={loading()}>
        <FilterLoadingSkeleton />
      </Show>
      <Show when={error()}>
        <div class="text-destructive text-sm p-4">{error()}</div>
      </Show>
      <Show when={!loading() && !error()}>
        <ul class="space-y-1">
          <For each={treeData()}>
            {(item) => (
              <FilterNode 
                item={item} 
                depth={0}
                checked={isChecked}
                onCheck={handleCheck}
                children={local.children}
              />
            )}
          </For>
        </ul>
      </Show>
    </div>
  )
}

type FilterNodeProps = {
  item: Category
  depth?: number
  checked: (id: string) => boolean
  onCheck: (id: string, checked: boolean) => void
  children?: (item: Category, checked: () => boolean, onCheck: (id: string, checked: boolean) => void) => JSX.Element
}

function FilterNode(props: FilterNodeProps) {
  const [local] = splitProps(props, ["item", "depth", "checked", "onCheck", "children"])
  const depth = () => local.depth ?? 0
  const hasChildren = () => (local.item.subcategories?.length ?? 0) > 0
  const [isExpanded, setIsExpanded] = createSignal(true)

  const isNodeChecked = () => local.checked(local.item.id ?? "")
  const allChildrenChecked = createMemo(() => {
    const children = local.item.subcategories ?? []
    if (children.length === 0) return isNodeChecked()
    return children.every(c => local.checked(c.id ?? ""))
  })
  const someChildrenChecked = createMemo(() => {
    const children = local.item.subcategories ?? []
    if (children.length === 0) return false
    const checkedCount = children.filter(c => local.checked(c.id ?? "")).length
    return checkedCount > 0 && checkedCount < children.length
  })

  const indentClass = () => {
    const d = depth()
    if (d === 0) return ""
    return `pl-${Math.min(d * 4 + 5, 12)}`
  }

  const toggleExpand = () => {
    if (hasChildren()) {
      setIsExpanded(!isExpanded())
    }
  }

  const handleCheckChange = (checked: boolean) => {
    local.onCheck(local.item.id ?? "", checked)
  }

  const handleParentCheckChange = (checked: boolean) => {
    local.onCheck(local.item.id ?? "", checked)
  }

  return (
    <CategoryProvider data={local.item} depth={depth()}>
      <li class={indentClass()}>
        <div class="flex items-center gap-2 py-2">
          <Show when={hasChildren()}>
            <button 
              onClick={toggleExpand}
              class="text-muted-foreground hover:text-foreground text-xs transition-transform"
              classList={{ "rotate-90": isExpanded() }}
            >
              ▶
            </button>
          </Show>
          <Show when={!hasChildren()}>
            <span class="w-3" />
          </Show>
          
          <Show
            when={local.children}
            fallback={
              <DefaultFilterItem 
                item={local.item}
                checked={isNodeChecked}
                allChecked={allChildrenChecked}
                someChecked={someChildrenChecked}
                onCheck={handleParentCheckChange}
              />
            }
          >
            {local.children!(local.item, isNodeChecked, local.onCheck)}
          </Show>
        </div>
        
        <Show when={hasChildren() && isExpanded()}>
          <ul class="space-y-1">
            <For each={local.item.subcategories ?? []}>
              {(child) => (
                <FilterNode 
                  item={child} 
                  depth={depth() + 1}
                  checked={local.checked}
                  onCheck={local.onCheck}
                  children={local.children}
                />
              )}
            </For>
          </ul>
        </Show>
      </li>
    </CategoryProvider>
  )
}

type DefaultFilterItemProps = {
  item: Category
  checked: () => boolean
  allChecked: () => boolean
  someChecked: () => boolean
  onCheck: (checked: boolean) => void
}

function DefaultFilterItem(props: DefaultFilterItemProps) {
  return (
    <label class="flex items-center gap-3 py-1 px-2 rounded hover:bg-muted cursor-pointer flex-1">
      <input
        type="checkbox"
        checked={props.checked()}
        ref={el => {
          if (el) el.indeterminate = props.someChecked() && !props.allChecked()
        }}
        onChange={(e) => props.onCheck(e.currentTarget.checked)}
        class="rounded border-input"
      />
      <CategoryImage class="size-4 rounded object-cover" />
      <span class="text-sm flex-1 truncate">{props.item.name}</span>
    </label>
  )
}

function FilterLoadingSkeleton() {
  return (
    <div class="space-y-2 p-2">
      <For each={[1, 2, 3, 4, 5]}>
        {() => (
          <div class="flex items-center gap-3 py-2 px-2">
            <div class="size-4 animate-pulse bg-muted rounded" />
            <div class="h-4 w-full animate-pulse bg-muted rounded" />
          </div>
        )}
      </For>
    </div>
  )
}
