import { ColorArea } from "@kobalte/core/color-area";



export { ColorArea }
export const ColorAreaBackground = ColorArea.Background
export const ColorAreaThumb = ColorArea.Thumb
export const ColorAreaHiddenInputX = ColorArea.HiddenInputX
export const ColorAreaHiddenInputY = ColorArea.HiddenInputY
export const ColorAreaLabel = ColorArea.Label;



