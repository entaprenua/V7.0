import { createContext, useContext, type JSX } from "solid-js"
import { createStore, produce } from "solid-js/store"
import type { Payment, PaymentMethod, PaymentStatus, Refund } from "~/lib/types"

type PaymentContextValue = {
  payment: Payment | null
  methods: PaymentMethod[]
  defaultMethod: PaymentMethod | null
  isProcessing: boolean
  error: string | null
  setPayment: (payment: Payment | null) => void
  setMethods: (methods: PaymentMethod[]) => void
  addMethod: (method: PaymentMethod) => void
  removeMethod: (methodId: string) => void
  setDefaultMethod: (methodId: string) => void
  setIsProcessing: (value: boolean) => void
  setError: (error: string | null) => void
  clear: () => void
}

const PaymentContext = createContext<PaymentContextValue | undefined>()

export const usePayment = (): PaymentContextValue | undefined => 
  useContext(PaymentContext)

type PaymentProviderProps = {
  initialPayment?: Payment | null
  initialMethods?: PaymentMethod[]
  children?: JSX.Element
}

export const PaymentProvider = (props: PaymentProviderProps) => {
  const [state, setState] = createStore<{
    payment: Payment | null
    methods: PaymentMethod[]
    isProcessing: boolean
    error: string | null
  }>({
    payment: props.initialPayment ?? null,
    methods: props.initialMethods ?? [],
    isProcessing: false,
    error: null,
  })

  const defaultMethod = () => 
    state.methods.find(m => m.isDefault && m.isActive) ?? state.methods[0] ?? null

  const value: PaymentContextValue = {
    get payment() { return state.payment },
    get methods() { return state.methods },
    get defaultMethod() { return defaultMethod() },
    get isProcessing() { return state.isProcessing },
    get error() { return state.error },
    setPayment: (payment) => setState("payment", payment),
    setMethods: (methods) => setState("methods", methods),
    addMethod: (method) => {
      setState(produce((s) => {
        const existingIndex = s.methods.findIndex(m => m.id === method.id)
        if (existingIndex >= 0) {
          s.methods[existingIndex] = method
        } else {
          s.methods.push(method)
        }
      }))
    },
    removeMethod: (methodId) => {
      setState(produce((s) => {
        s.methods = s.methods.filter(m => m.id !== methodId)
      }))
    },
    setDefaultMethod: (methodId) => {
      setState(produce((s) => {
        s.methods = s.methods.map(m => ({
          ...m,
          isDefault: m.id === methodId,
        }))
      }))
    },
    setIsProcessing: (value) => setState("isProcessing", value),
    setError: (error) => setState("error", error),
    clear: () => {
      setState({
        payment: null,
        methods: [],
        isProcessing: false,
        error: null,
      })
    },
  }

  return (
    <PaymentContext.Provider value={value}>
      {props.children}
    </PaymentContext.Provider>
  )
}

export type CheckoutStateValue = {
  cartId: string | null
  orderId: string | null
  total: number
  currency: string
  status: 'idle' | 'processing' | 'payment_required' | 'completed' | 'failed' | 'cancelled'
  clientSecret: string | null
  paymentId: string | null
  error: string | null
}

type CheckoutContextValue = {
  state: CheckoutStateValue
  setCartId: (cartId: string | null) => void
  setOrderId: (orderId: string | null) => void
  setTotal: (total: number) => void
  setCurrency: (currency: string) => void
  setStatus: (status: CheckoutStateValue['status']) => void
  setClientSecret: (secret: string | null) => void
  setPaymentId: (paymentId: string | null) => void
  setError: (error: string | null) => void
  reset: () => void
}

const CheckoutContext = createContext<CheckoutContextValue | undefined>()

export const useCheckout = (): CheckoutContextValue | undefined =>
  useContext(CheckoutContext)

type CheckoutProviderProps = {
  children?: JSX.Element
}

export const CheckoutProvider = (props: CheckoutProviderProps) => {
  const [state, setState] = createStore<CheckoutStateValue>({
    cartId: null,
    orderId: null,
    total: 0,
    currency: 'USD',
    status: 'idle',
    clientSecret: null,
    paymentId: null,
    error: null,
  })

  const value: CheckoutContextValue = {
    get state() { return state },
    setCartId: (cartId) => setState("cartId", cartId),
    setOrderId: (orderId) => setState("orderId", orderId),
    setTotal: (total) => setState("total", total),
    setCurrency: (currency) => setState("currency", currency),
    setStatus: (status) => setState("status", status),
    setClientSecret: (secret) => setState("clientSecret", secret),
    setPaymentId: (paymentId) => setState("paymentId", paymentId),
    setError: (error) => setState("error", error),
    reset: () => setState({
      cartId: null,
      orderId: null,
      total: 0,
      currency: 'USD',
      status: 'idle',
      clientSecret: null,
      paymentId: null,
      error: null,
    }),
  }

  return (
    <CheckoutContext.Provider value={value}>
      {props.children}
    </CheckoutContext.Provider>
  )
}

export type RefundStateValue = {
  paymentId: string | null
  amount: number
  reason: string | null
  status: 'idle' | 'processing' | 'completed' | 'failed'
  refundId: string | null
  error: string | null
}

type RefundContextValue = {
  state: RefundStateValue
  setPaymentId: (paymentId: string | null) => void
  setAmount: (amount: number) => void
  setReason: (reason: string | null) => void
  setStatus: (status: RefundStateValue['status']) => void
  setRefundId: (refundId: string | null) => void
  setError: (error: string | null) => void
  reset: () => void
}

const RefundContext = createContext<RefundContextValue | undefined>()

export const useRefund = (): RefundContextValue | undefined =>
  useContext(RefundContext)

type RefundProviderProps = {
  children?: JSX.Element
}

export const RefundProvider = (props: RefundProviderProps) => {
  const [state, setState] = createStore<RefundStateValue>({
    paymentId: null,
    amount: 0,
    reason: null,
    status: 'idle',
    refundId: null,
    error: null,
  })

  const value: RefundContextValue = {
    get state() { return state },
    setPaymentId: (paymentId) => setState("paymentId", paymentId),
    setAmount: (amount) => setState("amount", amount),
    setReason: (reason) => setState("reason", reason),
    setStatus: (status) => setState("status", status),
    setRefundId: (refundId) => setState("refundId", refundId),
    setError: (error) => setState("error", error),
    reset: () => setState({
      paymentId: null,
      amount: 0,
      reason: null,
      status: 'idle',
      refundId: null,
      error: null,
    }),
  }

  return (
    <RefundContext.Provider value={value}>
      {props.children}
    </RefundContext.Provider>
  )
}
