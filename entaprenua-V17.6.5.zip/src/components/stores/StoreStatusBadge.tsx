import { Badge } from "~/components/ui/badge"
import type { Store } from "~/lib/types"

interface StoreStatusBadgeProps {
  store: Store
}

export function StoreStatusBadge(props: StoreStatusBadgeProps) {
  const store = () => props.store

  if (store().isInMaintenanceMode) {
    return <Badge variant="warning">Maintenance</Badge>
  }

  if (store().isActive) {
    return <Badge class="bg-green-500">Active</Badge>
  }

  if (store().isTemplate) {
    return <Badge variant="outline">Template</Badge>
  }

  return <Badge variant="secondary">Draft</Badge>
}

export function StoreVisibilityBadge(props: { visibility?: string | null }) {
  const visibility = () => props.visibility

  if (visibility() === "public") {
    return <Badge class="bg-blue-500">Public</Badge>
  }

  if (visibility() === "unlisted") {
    return <Badge variant="warning">Unlisted</Badge>
  }

  return <Badge variant="secondary">Private</Badge>
}
