import { createSignal, Show, For } from "solid-js"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "~/components/ui/card"
import { Button } from "~/components/ui/button"
import { Flex, Badge, Text } from "~/components/ui"
import type { Store } from "~/lib/types"
import SettingsIcon from "lucide-solid/icons/settings"
import Trash2Icon from "lucide-solid/icons/trash-2"
import MoreVerticalIcon from "lucide-solid/icons/more-vertical"
import ExternalLinkIcon from "lucide-solid/icons/external-link"
import CopyIcon from "lucide-solid/icons/copy"

interface StoreCardProps {
  store: Store
  onDelete: (id: string) => void
  onManage: (id: string) => void
  onBuild: (id: string) => void
  onDuplicate: (id: string) => void
  onVisit: (store: Store) => void
}

export function StoreCard(props: StoreCardProps) {
  const store = () => props.store
  const [showMenu, setShowMenu] = createSignal(false)

  const statusBadge = () => {
    if (store().isInMaintenanceMode) {
      return <Badge variant="warning">Maintenance</Badge>
    }
    return store().isActive 
      ? <Badge class="bg-green-500">Active</Badge> 
      : <Badge variant="secondary">Inactive</Badge>
  }

  return (
    <Card class="overflow-hidden hover:shadow-md transition-shadow group">
      <div class="aspect-video bg-gradient-to-br from-muted to-muted/50 relative">
        <div class="absolute inset-0 flex items-center justify-center">
          <span class="text-4xl text-muted-foreground/30">🏪</span>
        </div>
        {statusBadge()}
      </div>
      <CardHeader class="p-4 pb-2">
        <Flex class="items-start justify-between gap-2">
          <div class="flex-1 min-w-0">
            <CardTitle class="text-lg truncate">{store().name}</CardTitle>
            <Text variant="caption" class="text-muted-foreground">
              {store().domain || store().subdomain || "No domain"}
            </Text>
          </div>
          <div class="relative">
            <Button variant="ghost" size="icon" class="size-8" onClick={() => setShowMenu(!showMenu())}>
              <MoreVerticalIcon class="size-4" />
            </Button>
            <Show when={showMenu()}>
              <div class="absolute right-0 top-full mt-1 w-44 bg-background border rounded-md shadow-lg z-50 py-1">
                <button
                  class="w-full px-3 py-2 text-left text-sm hover:bg-accent flex items-center gap-2"
                  onClick={() => { props.onManage(store().id); setShowMenu(false) }}
                >
                  <SettingsIcon class="size-4" /> Manage
                </button>
                <button
                  class="w-full px-3 py-2 text-left text-sm hover:bg-accent flex items-center gap-2"
                  onClick={() => { props.onBuild(store().id); setShowMenu(false) }}
                >
                  <CopyIcon class="size-4" /> Build
                </button>
                <button
                  class="w-full px-3 py-2 text-left text-sm hover:bg-accent flex items-center gap-2"
                  onClick={() => { props.onDuplicate(store().id); setShowMenu(false) }}
                >
                  <CopyIcon class="size-4" /> Duplicate
                </button>
                <Show when={store().domain || store().subdomain}>
                  <button
                    class="w-full px-3 py-2 text-left text-sm hover:bg-accent flex items-center gap-2"
                    onClick={() => { props.onVisit(store()); setShowMenu(false) }}
                  >
                    <ExternalLinkIcon class="size-4" /> Visit
                  </button>
                </Show>
                <div class="border-t my-1" />
                <button
                  class="w-full px-3 py-2 text-left text-sm hover:bg-accent flex items-center gap-2 text-destructive"
                  onClick={() => { props.onDelete(store().id); setShowMenu(false) }}
                >
                  <Trash2Icon class="size-4" /> Delete
                </button>
              </div>
            </Show>
          </div>
        </Flex>
      </CardHeader>
      <CardContent class="p-4 pt-0">
        <Text variant="body2" class="text-muted-foreground line-clamp-2">
          {store().description || "No description"}
        </Text>
        <Flex class="mt-2 gap-2">
          <Show when={store().isTemplate}><Badge variant="outline">Template</Badge></Show>
          <Badge variant="secondary" class="text-xs">{store().visibility || 'private'}</Badge>
        </Flex>
      </CardContent>
      <CardFooter class="p-4 pt-0 flex gap-2">
        <Button variant="outline" size="sm" class="flex-1 gap-2" onClick={() => props.onManage(store().id)}>
          <SettingsIcon class="size-4" /> Manage
        </Button>
        <Button variant="ghost" size="sm" onClick={() => props.onBuild(store().id)}>
          <CopyIcon class="size-4" />
        </Button>
      </CardFooter>
    </Card>
  )
}

export function StoreCardSkeleton() {
  return (
    <Card class="overflow-hidden">
      <div class="aspect-video bg-muted animate-pulse" />
      <CardContent class="p-4">
        <div class="h-5 w-3/4 bg-muted rounded mb-2" />
        <div class="h-4 w-1/2 bg-muted rounded mb-2" />
        <div class="h-4 w-full bg-muted rounded" />
      </CardContent>
      <CardFooter class="p-4 pt-0 flex gap-2">
        <div class="h-8 flex-1 bg-muted rounded-md" />
        <div class="h-8 w-8 bg-muted rounded-md" />
      </CardFooter>
    </Card>
  )
}
