import { Grid, Text, Heading, Skeleton } from "~/components/ui"
import type { StoreStats } from "~/lib/api/stores"

interface StoreStatsDisplayProps {
  stats?: StoreStats | null
  isLoading?: boolean
}

export function StoreStatsDisplay(props: StoreStatsDisplayProps) {
  const stats = () => props.stats

  if (props.isLoading) {
    return (
      <Grid cols={2} colsSm={3} class="gap-4">
        <div class="p-4 rounded-lg bg-muted animate-pulse">
          <Skeleton class="h-4 w-16 mb-2" />
          <Skeleton class="h-8 w-12" />
        </div>
        <div class="p-4 rounded-lg bg-muted animate-pulse">
          <Skeleton class="h-4 w-16 mb-2" />
          <Skeleton class="h-8 w-12" />
        </div>
        <div class="p-4 rounded-lg bg-muted animate-pulse">
          <Skeleton class="h-4 w-16 mb-2" />
          <Skeleton class="h-8 w-12" />
        </div>
        <div class="p-4 rounded-lg bg-muted animate-pulse">
          <Skeleton class="h-4 w-16 mb-2" />
          <Skeleton class="h-8 w-12" />
        </div>
      </Grid>
    )
  }

  if (!stats()) {
    return null
  }

  const statItems = [
    { label: "Products", value: stats()?.totalProducts || 0 },
    { label: "Orders", value: stats()?.totalOrders || 0 },
    { label: "Customers", value: stats()?.totalCustomers || 0 },
    { label: "Pages", value: stats()?.totalPages || 0 },
  ]

  return (
    <Grid cols={2} colsSm={4} class="gap-4">
      {statItems.map((item) => (
        <div class="p-4 rounded-lg bg-muted/50 text-center">
          <Text variant="caption" class="text-muted-foreground">{item.label}</Text>
          <Heading level={3}>{item.value.toLocaleString()}</Heading>
        </div>
      ))}
    </Grid>
  )
}

export function StoreRevenueDisplay(props: { revenue?: number }) {
  const revenue = () => props.revenue || 0

  return (
    <div class="p-4 rounded-lg bg-green-50 border border-green-200">
      <Text variant="caption" class="text-green-700">Total Revenue</Text>
      <Heading level={2} class="text-green-700">
        ${revenue().toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
      </Heading>
    </div>
  )
}
