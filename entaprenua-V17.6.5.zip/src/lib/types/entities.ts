export type UserRole = 'USER' | 'ADMIN' | 'STORE_OWNER' | 'STORE_MANAGER' | 'MODERATOR'

export type AccountStatus = 'ACTIVE' | 'LOCKED' | 'SUSPENDED' | 'PENDING_VERIFICATION'

export type IdentityProvider = 'LOCAL' | 'GOOGLE' | 'FACEBOOK' | 'GITHUB' | 'APPLE'

export interface User {
  id: string
  email: string
  username: string | null
  provider: IdentityProvider  // 'LOCAL' | 'GOOGLE' | 'FACEBOOK' | 'GITHUB' | 'APPLE'
  providerId: string | null
  avatarUrl: string | null
  emailVerified: boolean
  role?: UserRole  // Optional - for backward compatibility
  version: number
}

export interface Permission {
  id: string
  name: string
  description: string | null
  resource: string
  action: string
}

export interface Role {
  id: string
  name: string
  description: string | null
  permissions: Permission[]
}

export interface UserSession {
  id: string
  userId: string
  token: string
  refreshToken: string
  ipAddress: string | null
  userAgent: string | null
  deviceType: string | null
  browser: string | null
  os: string | null
  expiresAt: string
  createdAt: string
  lastAccessedAt: string
}

export interface PasswordResetToken {
  id: string
  userId: string
  token: string
  expiresAt: string
  usedAt: string | null
  createdAt: string
}

export interface EmailVerificationToken {
  id: string
  userId: string
  token: string
  expiresAt: string
  verifiedAt: string | null
  createdAt: string
}

export interface SecurityAuditEvent {
  id: string
  userId: string | null
  eventType: SecurityEventType
  ipAddress: string | null
  userAgent: string | null
  details: string | null
  createdAt: string
}

export type SecurityEventType = 
  | 'LOGIN_SUCCESS'
  | 'LOGIN_FAILED'
  | 'LOGOUT'
  | 'PASSWORD_CHANGED'
  | 'PASSWORD_RESET_REQUESTED'
  | 'PASSWORD_RESET_COMPLETED'
  | 'EMAIL_VERIFIED'
  | 'ACCOUNT_LOCKED'
  | 'ACCOUNT_UNLOCKED'
  | 'SUSPICIOUS_ACTIVITY'
  | 'TOKEN_REFRESHED'
  | 'SESSION_EXPIRED'

export interface Store {
  id: string;
  userId: string;
  parentId: string | null;
  name: string;
  description: string | null;
  domain: string | null;
  subdomain: string | null;
  isActive: boolean;
  isTemplate: boolean;
  isInMaintenanceMode?: boolean;
  version: number;
  insertedAt: string;
  updatedAt: string;
  // Template-specific fields
  logo?: string | null;
  favicon?: string | null;
  domainName?: string | null;
  price?: string | null;
  visibility?: string | null;
  docUrl?: string | null;
  pages?: StorePage[] | null;
}

export interface StoreCreateRequest {
  name: string;
  description?: string;
  templateId?: string;
  domain?: string;
  subdomain?: string;
  visibility?: 'public' | 'private' | 'unlisted';
}

export interface StoreUpdateRequest {
  name?: string;
  description?: string;
  domain?: string;
  subdomain?: string;
  logo?: string;
  favicon?: string;
  visibility?: 'public' | 'private' | 'unlisted';
  isInMaintenanceMode?: boolean;
}

export interface StoreStats {
  totalProducts: number;
  totalOrders: number;
  totalRevenue: number;
  totalCustomers: number;
  totalPages: number;
}

export interface Element {
  name: string;
  id: string;
  tailwind?: string;
  children?: Element[];
  [key: string]: any; //attributes(eg, tailwind, etc);
}

export interface StorePage {
  id: string;
  storeId: string;
  slug: string; 
  name: string;
  element: Element;
  version: number;
  insertedAt: string;
  updatedAt: string;
}


export interface Product {
  id: string;
  storeId: string;
  name: string;
  slug: string | null;
  description: string | null;
  price: string | null;
  compareToPrice: string | null;
  image: string | null;
  visibility: string | null;
  metadata: Record<string, string> | null;
  media: Record<string, string> | null;
  sku: string | null;
  stockQuantity: number;
  reservedQuantity: number;
  trackInventory: boolean;
  allowBackorder: boolean;
  lowStockThreshold: number;
  outOfStockThreshold: number;
  isDeleted: boolean;
  version: number;
  insertedAt: string;
  updatedAt: string;
}

export interface Category {
  id: string;
  storeId: string;
  name: string;
  slug: string | null;
  image: string | null;
  level: number | null;
  visibility: string | null;
  parentId: string | null;
  path: string | null;
  isDeleted: boolean;
  subcategories: Category[] | null;
  isMappedToParent?: boolean;
  insertedAt: string;
  updatedAt: string;
}

export interface Address {
  firstName: string
  lastName: string
  company?: string
  addressLine1: string
  addressLine2?: string
  city: string
  state?: string
  postalCode: string
  country: string
  phone?: string
}

export type OrderStatus = 'pending' | 'confirmed' | 'processing' | 'on_hold' | 'shipped' | 'delivered' | 'cancelled' | 'refunded' | 'returned' | 'payment_failed'

export interface Cart {
  id: string;
  storeId: string;
  customerId: string;
  currency: string;
  subtotal: string;
  total: string;
  notes: string | null;
  isLocked: boolean;
  version: number;
  insertedAt: string;
  updatedAt: string;
  lastModifiedBy: string | null;
  items?: CartItem[];
}

export interface CartItem {
  id: string;
  cartId: string;
  productId: string;
  price: string | number;
  quantity: number;
  subtotal: string | number;
  insertedAt: string;
  updatedAt: string;
  version: number;
}

export interface Order {
  id: string;
  storeId: string;
  customerId: string;
  orderNumber: string;
  status: OrderStatus;
  currency: string;
  subtotal: string;
  tax: string;
  shippingCost: string;
  discount: string;
  total: string;
  billingAddress: Address | null;
  shippingAddress: Address | null;
  notes: string | null;
  trackingNumber: string | null;
  paid: boolean;
  paidAt: string | null;
  shippedAt: string | null;
  deliveredAt: string | null;
  cancelledAt: string | null;
  refundedAt: string | null;
  version: number;
  insertedAt: string;
  updatedAt: string;
  lastModifiedBy: string | null;
  isDeleted?: boolean;
  items?: OrderItem[];
}

export interface OrderItem {
  id: string;
  orderId: string;
  productId: string;
  productName: string;
  price: string | number;
  quantity: number;
  subtotal: string | number;
  insertedAt: string;
  updatedAt: string;
  version: number;
}

export interface Wishlist {
  id: string;
  storeId: string;
  customerId: string;
  version: number;
  insertedAt: string;
  updatedAt: string;
  items?: WishlistItem[];
}

export interface WishlistItem {
  id: string;
  wishlistId: string;
  productId: string;
  insertedAt: string;
  updatedAt: string;
  version: number;
}

export interface ProductMetadata {
  id: string;
  productId: string;
  name: string;
  value: string;
  insertedAt: string;
}

export interface MediaVariants {
  thumbnail: string | null;
  medium: string | null;
  large: string | null;
}

export interface Media {
  id: string;
  url: string;
  type: string;
  mimeType: string | null;
  sizeBytes: number | null;
  width: number | null;
  height: number | null;
  alt: string | null;
  variants: MediaVariants | null;
  isPrimary: boolean;
  displayOrder: number;
  insertedAt: string;
  updatedAt: string;
}

export interface ProductDto {
  id: string;
  storeId: string;
  name: string;
  slug: string | null;
  description: string | null;
  price: string | null;
  compareToPrice: string | null;
  image: string | null;
  visibility: string | null;
  media: Media[] | null;
  metadata: Record<string, string> | null;
  sku: string | null;
  stockQuantity: number;
  reservedQuantity: number;
  trackInventory: boolean;
  allowBackorder: boolean;
  lowStockThreshold: number;
  outOfStockThreshold: number;
  isDeleted: boolean;
  version: number;
  insertedAt: string;
  updatedAt: string;
}

export type PaymentStatus = 
  | 'PENDING' 
  | 'PROCESSING' 
  | 'SUCCEEDED' 
  | 'FAILED' 
  | 'CANCELLED' 
  | 'REFUNDED' 
  | 'PARTIALLY_REFUNDED'

export type RefundReason = 
  | 'DUPLICATE' 
  | 'FRAUDULENT' 
  | 'REQUESTED_BY_CUSTOMER' 
  | 'EXPIRED_UNCAPTURED_CHARGE'

export type RefundStatus = 
  | 'PENDING' 
  | 'PROCESSING' 
  | 'SUCCEEDED' 
  | 'FAILED' 
  | 'CANCELLED'

export type PaymentMethodType = 
  | 'CARD' 
  | 'BANK_ACCOUNT' 
  | 'APPLE_PAY' 
  | 'GOOGLE_PAY' 
  | 'LINK'

export type BalanceTransactionType = 
  | 'CREDIT' 
  | 'DEBIT' 
  | 'REFUND' 
  | 'PURCHASE' 
  | 'GIFT' 
  | 'PROMOTIONAL'

export interface Payment {
  id: string
  orderId: string
  storeId: string
  userId: string
  stripePaymentIntentId: string | null
  stripeChargeId: string | null
  stripeCustomerId: string | null
  stripePaymentMethodId: string | null
  amount: number
  currency: string
  status: PaymentStatus
  applicationFee: number
  stripeFee: number
  netAmount: number | null
  amountRefunded: number
  refundReason: string | null
  refundedAt: string | null
  failureCode: string | null
  failureMessage: string | null
  paymentMethodType: string | null
  cardBrand: string | null
  cardLast4: string | null
  description: string | null
  metadata: Record<string, any> | null
  receiptEmail: string | null
  receiptNumber: string | null
  receiptUrl: string | null
  processedAt: string | null
  cancelledAt: string | null
  version: number
  insertedAt: string
  updatedAt: string
}

export interface Refund {
  id: string
  paymentId: string
  orderId: string
  storeId: string
  userId: string
  stripeRefundId: string | null
  amount: number
  currency: string
  reason: RefundReason | null
  status: RefundStatus
  failureReason: string | null
  description: string | null
  metadata: Record<string, any> | null
  processedAt: string | null
  version: number
  insertedAt: string
  updatedAt: string
}

export interface PaymentMethod {
  id: string
  userId: string
  storeId: string
  stripePaymentMethodId: string
  type: PaymentMethodType
  cardBrand: string | null
  cardLast4: string | null
  cardExpMonth: number | null
  cardExpYear: number | null
  bankName: string | null
  bankLast4: string | null
  isDefault: boolean
  isActive: boolean
  nickname: string | null
  billingName: string | null
  billingEmail: string | null
  billingPhone: string | null
  billingAddressLine1: string | null
  billingAddressLine2: string | null
  billingCity: string | null
  billingState: string | null
  billingPostalCode: string | null
  billingCountry: string | null
  version: number
  insertedAt: string
  updatedAt: string
}

export interface PaymentEvent {
  id: string
  stripeEventId: string
  eventType: string
  paymentId: string | null
  refundId: string | null
  orderId: string | null
  payload: Record<string, any>
  processed: boolean
  processingError: string | null
  processingAttempts: number
  receivedAt: string
  processedAt: string | null
}

export interface CustomerBalance {
  id: string
  userId: string
  storeId: string
  balance: number
  currency: string
  creditType: string
  version: number
  insertedAt: string
  updatedAt: string
}

export interface BalanceTransaction {
  id: string
  balanceId: string
  userId: string
  storeId: string
  amount: number
  balanceBefore: number
  balanceAfter: number
  transactionType: BalanceTransactionType
  referenceType: string | null
  referenceId: string | null
  description: string | null
  metadata: Record<string, any> | null
  version: number
  insertedAt: string
  updatedAt: string
}

export interface PaymentSettings {
  id: string
  storeId: string
  stripeAccountId: string | null
  stripeEnabled: boolean
  acceptCards: boolean
  acceptApplePay: boolean
  acceptGooglePay: boolean
  acceptBankTransfers: boolean
  captureMethod: string
  passProcessingFee: boolean
  processingFeePercentage: number
  requireCvv: boolean
  requireBillingAddress: boolean
  webhookSecret: string | null
  metadata: Record<string, any> | null
  version: number
  insertedAt: string
  updatedAt: string
}

export interface CreatePaymentRequest {
  orderId: string
  userId: string
  storeId: string
  amount: number
  currency?: string
  description?: string
  receiptEmail?: string
  metadata?: Record<string, string>
}

export interface CreatePaymentResponse {
  success: boolean
  paymentId: string | null
  clientSecret: string | null
  stripePaymentIntentId: string | null
  error?: string
}

export interface RefundPaymentRequest {
  paymentId: string
  amount?: number
  reason?: RefundReason
  description?: string
}

export interface RefundPaymentResponse {
  success: boolean
  refundId: string | null
  stripeRefundId: string | null
  amount: number
  status: RefundStatus
  error?: string
}

export type HeroDisplayType = 'carousel' | 'grid' | 'stack' | 'fade' | 'slide'
export type HeroBackgroundType = 'image' | 'video' | 'color' | 'gradient'
export type HeroContentPosition = 'top-left' | 'top-center' | 'top-right' | 'center-left' | 'center' | 'center-right' | 'bottom-left' | 'bottom-center' | 'bottom-right'
export type HeroTextAlignment = 'left' | 'center' | 'right'

export interface Hero {
  id: string
  storeId: string
  name: string
  displayType: string
  autoplay: boolean
  autoplayInterval: number
  showIndicators: boolean
  showNavigation: boolean
  aspectRatio: string
  maxHeight: number | null
  gap: number
  isActive: boolean
  startsAt: string | null
  endsAt: string | null
  metadata: Record<string, string> | null
  items: HeroItem[] | null
  version: number
  insertedAt: string
  updatedAt: string
}

export interface HeroItem {
  id: string
  heroId: string
  sortOrder: number
  
  backgroundType: string
  backgroundImageUrl: string | null
  backgroundImageAlt: string | null
  backgroundVideoUrl: string | null
  backgroundColor: string | null
  backgroundGradient: string | null
  overlayColor: string | null
  overlayOpacity: number | string
  
  title: string | null
  titleColor: string | null
  subtitle: string | null
  subtitleColor: string | null
  description: string | null
  descriptionColor: string | null
  
  contentPosition: string
  textAlignment: string
  
  ctaText: string | null
  ctaUrl: string | null
  ctaStyle: string
  ctaTarget: string
  
  ctaSecondaryText: string | null
  ctaSecondaryUrl: string | null
  ctaSecondaryStyle: string
  ctaSecondaryTarget: string
  
  mobileBackgroundImageUrl: string | null
  mobileContentPosition: string | null
  hideOnMobile: boolean
  hideOnDesktop: boolean
  
  startsAt: string | null
  endsAt: string | null
  
  isActive: boolean
  metadata: Record<string, string> | null
  version: number
  insertedAt: string
  updatedAt: string
}

export interface CreateHeroRequest {
  storeId: string
  name: string
  displayType?: string
  autoplay?: boolean
  autoplayInterval?: number
  showIndicators?: boolean
  showNavigation?: boolean
  aspectRatio?: string
  maxHeight?: number
  gap?: number
  isActive?: boolean
  startsAt?: string
  endsAt?: string
  metadata?: Record<string, string>
}

export interface UpdateHeroRequest extends Partial<CreateHeroRequest> {
  id: string
}

export interface CreateHeroItemRequest {
  heroId: string
  sortOrder?: number
  backgroundType?: string
  backgroundImageUrl?: string
  backgroundImageAlt?: string
  backgroundVideoUrl?: string
  backgroundColor?: string
  backgroundGradient?: string
  overlayColor?: string
  overlayOpacity?: number | string
  title?: string
  titleColor?: string
  subtitle?: string
  subtitleColor?: string
  description?: string
  descriptionColor?: string
  contentPosition?: string
  textAlignment?: string
  ctaText?: string
  ctaUrl?: string
  ctaStyle?: string
  ctaTarget?: string
  ctaSecondaryText?: string
  ctaSecondaryUrl?: string
  ctaSecondaryStyle?: string
  ctaSecondaryTarget?: string
  mobileBackgroundImageUrl?: string
  mobileContentPosition?: string
  hideOnMobile?: boolean
  hideOnDesktop?: boolean
  startsAt?: string
  endsAt?: string
  isActive?: boolean
  metadata?: Record<string, string>
}

export interface UpdateHeroItemRequest extends Partial<CreateHeroItemRequest> {
  id: string
}
