const ADMIN = "/admin"

export const routes = {
  // Auth
  home: "/",
  logIn: "/log-in",
  signUp: "/sign-up",
  forgotPassword: "/forgot-password",
  
  // Builder (path-based routing)
  builder: "/builder",
  builderStore: (id: string) => `/builder/${id}`,
  builderTemplate: (id: string) => `/builder/template/${id}`,
  
  // Stores Management
  stores: "/stores",
  newStore: "/stores/new",
  newStoreUpload: "/stores/new/upload",
  storeDetails: (id: string) => `/stores/${id}`,
  storeEdit: (id: string) => `/stores/${id}/edit`,
  storeSettings: (id: string) => `/stores/${id}/settings`,
  storeBuild: (id: string) => `/stores/${id}/build`,
  storeUpload: (id: string) => `/stores/${id}/upload`,
  storePages: (id: string) => `/stores/${id}/pages`,
  storeDuplicate: (id: string) => `/stores/${id}/duplicate`,
  storeClone: (id: string) => `/stores/${id}/clone`,
  
  // Admin Panel
  admin: ADMIN,
  adminProducts: `${ADMIN}/products`,
  adminProduct: (id: string) => `${ADMIN}/products/${id}`,
  adminNewProduct: `${ADMIN}/products/new`,
  adminCategories: `${ADMIN}/categories`,
  adminCategory: (id: string) => `${ADMIN}/categories/${id}`,
  adminNewCategory: `${ADMIN}/categories/new`,
  adminOrders: `${ADMIN}/orders`,
  adminOrder: (id: string) => `${ADMIN}/orders/${id}`,
  adminMedia: `${ADMIN}/media`,
  adminSettings: `${ADMIN}/settings`,
  
  // Templates (User-owned - templates they bought or created to sell)
  templates: "/templates",
  templateDetails: (id: string) => `/templates/${id}`,
  templateClone: (id: string) => `/templates/${id}/clone`,
  templatePreview: (id: string) => `/templates/${id}/preview`,
  templateEdit: (id: string) => `/templates/${id}/edit`,

  // Resources
  documentation: "/docs",
  support: "/support",
}
