export const styles = {
   
  avatar: "min-h-20 w-20",
  badge: "min-h-10 rounded-full min-w-10 text-", //color of text
  box:  "min-h-30 min-w-50  h-auto",
  button: "min-h-10 min-w-30 h-auto",
  caption: "min-h-8 w-full",
  card: "min-h-70 w-full h-auto",
  cardContent: "min-h-30 w-full h-auto",
  content: "min-h-30 w-full",
  description: "min-h-8 w-full h-auto",
  divider: "min-h-2", 
  drawerContent: "min-h-30 min-w-30 w-auto",
  footer: "min-h-8 w-full",
  header: "min-h-20 w-full",
  input: "h-20 w-full",
  item: "h-20 w-full",
  label: "min-h-8 w-full",
  link: "min-h-8 min-w-20 h-uto w-auto",
  media: "h-50 w-50",
  modal: "min-h-20", 
  paper: "min-h-50 w-50", 
  sheetContent: "min-w-30 min-h-30 w-auto",
  table: "min-h-50 min-w-80full",
  tableBody: "h-30 w-full",
  tableCell: "min-h-10 min-w-20",
  tableRow: "min-h-12 gap-2 w-full",
  text: "p-0 h-auto h-4",
  title: "min-h-8 w-auto",
  trigger: "min-h-10 min-w-30 w-auto", 
}





















