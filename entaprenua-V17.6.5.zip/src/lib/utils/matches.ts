function matchesPattern(str, pattern) {
  const regexPattern = pattern
    .replace(/{(\w+)}/g, '([^/]+)')  // {id} → ([^/]+)
    .replace(/\//g, '\\/');           // escape slashes
  
  return new RegExp(`^${regexPattern}$`).test(str);
}
