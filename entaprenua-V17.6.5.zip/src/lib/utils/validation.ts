export type EmailValidationResult = {
  isValid: boolean
  error?: string
  suggestion?: string
}

export type PasswordStrength = 'weak' | 'fair' | 'good' | 'strong'

export type PasswordValidationResult = {
  isValid: boolean
  strength: PasswordStrength
  score: number
  errors: string[]
  suggestions: string[]
}

export type EmailServerValidationResult = {
  email: string
  isValidFormat: boolean
  isDeliverable: boolean
  isSmtpValid: boolean
  isMxFound: boolean
  isDisposable: boolean
  isFree: boolean
  qualityScore: number
  suggestion?: string
}

const EMAIL_REGEX = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/

const COMMON_TYPOS: Record<string, string> = {
  'gmial.com': 'gmail.com',
  'gmal.com': 'gmail.com',
  'gamil.com': 'gmail.com',
  'gmail.co': 'gmail.com',
  'gmail.cm': 'gmail.com',
  'gmial.co': 'gmail.com',
  'hotmal.com': 'hotmail.com',
  'hotmai.com': 'hotmail.com',
  'hotmil.com': 'hotmail.com',
  'outlok.com': 'outlook.com',
  'outloo.com': 'outlook.com',
  'yaho.com': 'yahoo.com',
  'yaoo.com': 'yahoo.com',
  'protonmal.com': 'protonmail.com',
  'protonmai.com': 'protonmail.com',
  'icloud.co': 'icloud.com',
  'iclou.com': 'icloud.com',
}

const DISPOSABLE_DOMAINS = new Set([
  '10minutemail.com', 'tempmail.com', 'guerrillamail.com',
  'mailinator.com', 'throwaway.email', 'temp-mail.org',
  'fakeinbox.com', 'maildrop.cc', 'sharklasers.com',
])

export const validateEmailFormat = (email: string): EmailValidationResult => {
  if (!email || email.trim() === '') {
    return { isValid: false, error: 'Email is required' }
  }

  const trimmedEmail = email.trim().toLowerCase()

  if (trimmedEmail.length > 254) {
    return { isValid: false, error: 'Email is too long' }
  }

  if (!EMAIL_REGEX.test(trimmedEmail)) {
    return { isValid: false, error: 'Invalid email format' }
  }

  const [localPart, domain] = trimmedEmail.split('@')

  if (localPart.length > 64) {
    return { isValid: false, error: 'Email local part is too long' }
  }

  if (localPart.startsWith('.') || localPart.endsWith('.')) {
    return { isValid: false, error: 'Email local part cannot start or end with a dot' }
  }

  if (localPart.includes('..')) {
    return { isValid: false, error: 'Email local part cannot contain consecutive dots' }
  }

  const correctedDomain = COMMON_TYPOS[domain]
  if (correctedDomain) {
    return {
      isValid: true,
      suggestion: `${localPart}@${correctedDomain}`,
    }
  }

  if (DISPOSABLE_DOMAINS.has(domain)) {
    return {
      isValid: true,
      error: 'Disposable email addresses are not recommended',
    }
  }

  return { isValid: true }
}

export const getPasswordStrength = (password: string): PasswordValidationResult => {
  const errors: string[] = []
  const suggestions: string[] = []
  let score = 0

  if (!password) {
    return {
      isValid: false,
      strength: 'weak',
      score: 0,
      errors: ['Password is required'],
      suggestions: ['Enter a password'],
    }
  }

  if (password.length < 8) {
    errors.push('Password must be at least 8 characters')
  } else if (password.length >= 12) {
    score += 2
  } else {
    score += 1
  }

  if (password.length >= 16) {
    score += 1
  }

  if (/[a-z]/.test(password)) {
    score += 1
  } else {
    suggestions.push('Add lowercase letters')
  }

  if (/[A-Z]/.test(password)) {
    score += 1
  } else {
    suggestions.push('Add uppercase letters')
  }

  if (/[0-9]/.test(password)) {
    score += 1
  } else {
    suggestions.push('Add numbers')
  }

  if (/[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/.test(password)) {
    score += 1
  } else {
    suggestions.push('Add special characters')
  }

  const commonPatterns = [
    'password', '123456', 'qwerty', 'abc123', 'letmein',
    'admin', 'welcome', 'monkey', 'dragon', 'master',
  ]
  const lowerPassword = password.toLowerCase()
  if (commonPatterns.some(p => lowerPassword.includes(p))) {
    score -= 2
    errors.push('Password contains common patterns')
  }

  if (/(.)\1{2,}/.test(password)) {
    score -= 1
    suggestions.push('Avoid repeated characters')
  }

  score = Math.max(0, Math.min(5, score))

  const strengthMap: Record<number, PasswordStrength> = {
    0: 'weak',
    1: 'weak',
    2: 'fair',
    3: 'good',
    4: 'strong',
    5: 'strong',
  }

  return {
    isValid: password.length >= 8 && errors.length === 0,
    strength: strengthMap[score],
    score,
    errors,
    suggestions,
  }
}

export const validatePasswordMatch = (
  password: string,
  confirmPassword: string
): { isValid: boolean; error?: string } => {
  if (!confirmPassword) {
    return { isValid: false, error: 'Please confirm your password' }
  }

  if (password !== confirmPassword) {
    return { isValid: false, error: 'Passwords do not match' }
  }

  return { isValid: true }
}

export const validateUsername = (username: string): { isValid: boolean; error?: string } => {
  if (!username || username.trim() === '') {
    return { isValid: false, error: 'Username is required' }
  }

  const trimmed = username.trim()

  if (trimmed.length < 3) {
    return { isValid: false, error: 'Username must be at least 3 characters' }
  }

  if (trimmed.length > 30) {
    return { isValid: false, error: 'Username must be at most 30 characters' }
  }

  if (!/^[a-zA-Z0-9_]+$/.test(trimmed)) {
    return { isValid: false, error: 'Username can only contain letters, numbers, and underscores' }
  }

  if (trimmed.startsWith('_') || trimmed.endsWith('_')) {
    return { isValid: false, error: 'Username cannot start or end with an underscore' }
  }

  if (/_{2,}/.test(trimmed)) {
    return { isValid: false, error: 'Username cannot contain consecutive underscores' }
  }

  return { isValid: true }
}

export const getStrengthColor = (strength: PasswordStrength): string => {
  const colors: Record<PasswordStrength, string> = {
    weak: 'bg-red-500',
    fair: 'bg-orange-500',
    good: 'bg-yellow-500',
    strong: 'bg-green-500',
  }
  return colors[strength]
}

export const getStrengthLabel = (strength: PasswordStrength): string => {
  const labels: Record<PasswordStrength, string> = {
    weak: 'Weak',
    fair: 'Fair',
    good: 'Good',
    strong: 'Strong',
  }
  return labels[strength]
}
