/* NOT IMPORTABLE, wiil always fallback to error */
import { lazy } from "solid-js"

export const lazyComponent = (value:any /*Promise<T>*/) => lazy(async() => {
   try {
      return await value//import(route);      
    }catch(error){
       console.log("Error")                        
       return  { default: () => <> Error </> }                 
    }  
})
