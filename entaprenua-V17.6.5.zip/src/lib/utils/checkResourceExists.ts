import { 
  createMemo, createEffect, on, createSignal, type Accessor, type OnEffectFunction
} from "solid-js"

export const checkResourceExists = (
  queryMethod: () => boolean | undefined,
  onChange?: (exists: boolean) => void
) => {
   const [_exists, setExists]  = createSignal(false) 
   createEffect(on(queryMethod, (exists: boolean | undefined) => {
      if(exists === true || exists === false) setExists(exists);
      onChange?.(_exists()); 
   }))
   
   return createMemo(_exists)
}

