export const removeUnit = (value: string | number): number => {
  let newValue: string = "";
  for (let ch of String(value)){
    if(!isNaN(Number(ch))){
      newValue = newValue + ch;
    }
    else break;
  }
  const result = Number(newValue) 
  if(!isNaN(result)) return result
  return 0 
};


		 
	    

    

