import type { Product } from "~/lib/types"

/**
 * Represents the stock status of a product for UI display.
 */
export type ProductStockStatus = {
  label: string
  variant: "secondary" | "error" | "warning" | "success"
}

/**
 * Determines a product's stock status based on inventory tracking and quantity.
 * Used for displaying status badges in product lists (desktop table and mobile cells).
 * 
 * @param product - The product to check
 * @returns Status object with display label and badge variant
 * 
 * @example
 * const status = getProductStockStatus(product)
 * // Returns { label: "In stock", variant: "success" }
 */
export function getProductStockStatus(product: Product): ProductStockStatus {
  if (!product.trackInventory) {
    return { label: "Not tracked", variant: "secondary" }
  }
  
  if (product.stockQuantity <= 0) {
    return { label: "Out of stock", variant: "error" }
  }
  
  if (product.stockQuantity <= product.lowStockThreshold) {
    return { label: "Low stock", variant: "warning" }
  }
  
  return { label: "In stock", variant: "success" }
}
