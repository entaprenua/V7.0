export const removeWhiteSpaces = (strValue: string): string => {
  let newValue = ""
  for (let ch of strValue){
    if(ch != " ")
      newValue = newValue + ch
  }
  return newValue;
}
