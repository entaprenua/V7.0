export { makePersisted } from "@solid-primitives/storage"
