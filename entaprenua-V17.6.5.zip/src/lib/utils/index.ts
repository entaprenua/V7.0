import type { ClassValue } from "clsx"
import { clsx } from "clsx"
import { twMerge } from "tailwind-merge"
import { v4 as createUniqueId } from "uuid"
import { useColorMode } from "@kobalte/core"
import { createBreakpoints } from "@solid-primitives/media"

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

type RefInput = {
  ref?: (e: HTMLElement | undefined) => void
} | (() => ((e: HTMLElement | undefined) => void) | void) | undefined

function createRef<T extends HTMLElement = HTMLElement>(input?: RefInput) {
  const cb: any = (e: T) => {
    cb.ref = cb.current = e
    if (typeof input === "function") {
      const inputResult = input()
      if (typeof inputResult === "function") {
        inputResult(e)
      }
    } else if (input && typeof input.ref === "function") {
      input.ref(e)
    }
  }
  return cb
}

const capitalize = (str: string, letterIndex = 0): string => {
  return str[letterIndex].toUpperCase() + str.slice(1)
}

const getFileType = (file: File): "image" | "audio" | "video" | undefined => {
  if (file.type.includes("image/")) return "image"
  else if (file.type.includes("audio/")) return "audio"
  else if (file.type.includes("video/")) return "video"
  return undefined
}

const formatCurrency = (amount: string | number, currency = "USD"): string => {
  const num = typeof amount === "string" ? parseFloat(amount) : amount
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency,
  }).format(num)
}

const formatDate = (date: string | Date, options?: Intl.DateTimeFormatOptions): string => {
  const d = typeof date === "string" ? new Date(date) : date
  return d.toLocaleDateString("en-US", {
    year: "numeric",
    month: "short",
    day: "numeric",
    ...options,
  })
}

const formatDateTime = (date: string | Date): string => {
  const d = typeof date === "string" ? new Date(date) : date
  return d.toLocaleString("en-US", {
    year: "numeric",
    month: "short",
    day: "numeric",
    hour: "numeric",
    minute: "2-digit",
  })
}

const formatNumber = (num: number): string => {
  return new Intl.NumberFormat("en-US").format(num)
}

const formatPercent = (num: number): string => {
  return new Intl.NumberFormat("en-US", {
    style: "percent",
    minimumFractionDigits: 0,
    maximumFractionDigits: 1,
  }).format(num)
}

export {
  createUniqueId,
  cn,
  useColorMode,
  createBreakpoints,
  createRef,
  capitalize,
  getFileType,
  formatCurrency,
  formatDate,
  formatDateTime,
  formatNumber,
  formatPercent,
}
export const baseAbsolutePath = ""
export const TOP_APPBAR_HEIGHT = 30 //tailwind's h-30
export const Z_INDEX ="z-30000000000"
export * from "./routingConfig"
export { routes } from "./routes"
export { removeUnit } from './removeUnit';
export { removeWhiteSpaces } from "./removeWhiteSpaces";
export { checkResourceExists }from "./checkResourceExists"
export * from "./lazyComponent"
export { styles } from "./styles"
export { makePersisted } from "./makePersisted"
export * from "./htmlEvents"

