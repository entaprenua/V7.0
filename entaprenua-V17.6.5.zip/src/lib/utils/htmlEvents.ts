/* Ref: https://www.w3schools.com/tags/ref_eventattributes.asp */
export const htmlEvents = [
  /* Form events"*/ 
  "on-blur",
  "on-change",
  //"onContextMenu" //only on firefox,
  "on-focus",
  "on-input",
  "on-invalid",
  "on-reset",
  "on-search",
  "on-select",
  "on-submit",

  /* Keyboard events */
  "on-key-down",
  "on-key-press",
  "on-key-up",


  /* mouseEvents" */
  "on-click",
  "on-dbl-click",
  "on-mouse-down",
  "on-mouse-move",
  "on-mouse-out",
  "on-mouse-over",
  "on-mouse-up",
  "on-wheel",

  /* drag events" */
  /*
  "onDrag",
  "onDragEnd",
  "onDragEnter",
  "onDragLeave",
  "onDragOver",
  "onDragStart",
  "onDrop",
  "onScroll",
   */
  /* clipboard events */
  "on-copy",
  "on-cut",
  "on-paste",

  /* Media events */
  "on-abort",
  "on-can-play",
  "on-can-play-through",
  "on-cue-change",
  "on-duration-change",
  "on-emptied",
  "on-ended",
  "on-error",
  "on-loaded-data",
  "on-loaded-metadata",
  "on-load-start",
  "on-pause",
  "on-play",
  "on-playing",
  "on-progress",
  "on-rate-change",
  "on-seeked",
  "on-seeking",
  "on-stalled",
  "on-suspended",
  "on-time-update",
  "on-volume-change",
  "on-waiting",
   /* Miscellaneous events */ 
   //"onToggle",
   
   /* Window events" */
   /*"onAfterPrint",
   "onBeforePrint",
   "onBeforeUpload",
   "onBeforeUnload",
   "onError",
   "onHashChange",
   "onLoad",
   "onMessage",
   "onOffline",
   "onOnline",
   "onPageHide",
   "onPageShow",
   "onPopState",
   "onResize",
   "onStorage",
   "onUnload", 
   */
]






















































  
