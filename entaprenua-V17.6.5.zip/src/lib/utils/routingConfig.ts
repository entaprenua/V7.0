import { createEffect } from "solid-js"
import { routes } from "./routes"
import { useLocation } from "@solidjs/router"
export const baseUrl: string = "http://localhost:8080" 
	//"https://xxxx:pppp"
//export const baseUrl: string = "http://192.168.43.143:8080";

export const routePath = (path="") => {
  const location = useLocation() 
  /* FIXME: not expanding for basePath = location.pathname, or routes.<path> */

  const basePath = ""
  
  if (path?.[0] == "/")
	return `/${basePath}${path}`
  else return `/${basePath}/${path}`
}
