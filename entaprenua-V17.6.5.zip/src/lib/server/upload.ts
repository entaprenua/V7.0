import { db } from '~/lib/db';
import { stores, storePages } from '~/lib/db/schema';
import { eq } from 'drizzle-orm';
import parse from './parser';

const MAX_FILE_SIZE = 500 * 1024; // 500KB per file
const SUPPORTED_EXTENSIONS = ['.tsx', '.jsx'];

interface PageElement {
  id: string;
  name: string;
  rawJsx?: string;
  attributes?: Record<string, unknown>;
  children?: unknown[];
}

export interface UploadResult {
  success: boolean;
  storeId?: string;
  pagesCreated?: number;
  error?: string;
}

export async function importStore(
  name: string,
  userId: string,
  files: Record<string, string>
): Promise<UploadResult> {
  try {
    const pages = parseRoutesFiles(files);
    
    const storeId = crypto.randomUUID();

    // Create store
    await db.insert(stores).values({
      id: storeId,
      userId,
      name,
      parentId: storeId,
      visibility: 'public',
      isTemplate: false,
    });

    // Create pages
    const pageValues = pages.map(page => ({
      id: crypto.randomUUID(),
      storeId,
      name: page.name,
      slug: page.slug,
      element: page.element,
      version: 1,
    }));

    await db.insert(storePages).values(pageValues);

    return {
      success: true,
      storeId,
      pagesCreated: pages.length,
    };
  } catch (error: any) {
    console.error('[Upload] Import failed:', error);
    return { success: false, error: error.message };
  }
}

function parseRoutesFiles(files: Record<string, string>): Array<{ name: string; slug: string; element: unknown }> {
  const pages: Array<{ name: string; slug: string; element: unknown }> = [];

  for (const [filePath, content] of Object.entries(files)) {
    // Skip non-route files
    if (!filePath.includes('/routes/')) continue;
    
    // Check file extension
    const ext = getFileExtension(filePath);
    if (!SUPPORTED_EXTENSIONS.includes(ext)) {
      console.warn(`[Upload] Skipping unsupported file: ${filePath}`);
      continue;
    }
    
    // Check file size
    if (content.length > MAX_FILE_SIZE) {
      console.warn(`[Upload] Skipping oversized file (${filePath}): ${content.length} bytes`);
      continue;
    }

    // Check if it's a page file (page.tsx, index.tsx)
    const isPageFile = filePath.endsWith('/page.tsx') || 
                       filePath.endsWith('/page.jsx') ||
                       filePath.endsWith('/index.tsx') ||
                       filePath.endsWith('/index.jsx');
    
    if (!isPageFile) continue;

    // Extract route from path
    const routeInfo = extractRouteInfo(filePath);
    
    if (routeInfo.name) {
      const parsedContent = parsePageContent(content, routeInfo.componentName);
      
      pages.push({
        name: routeInfo.name,
        slug: routeInfo.slug,
        element: parsedContent,
      });
    }
  }

  // Create default home page if no pages found
  if (pages.length === 0) {
    console.log('[Upload] No route files found, creating default home page');
    pages.push({
      name: 'home',
      slug: '',
      element: createDefaultPage(),
    });
  }

  return pages;
}

function extractRouteInfo(filePath: string): { name: string; slug: string; componentName: string } {
  // Remove src/routes/ prefix
  const pathWithoutRoutes = filePath.replace(/^src\/routes\//, '');
  
  // Handle different patterns:
  // src/routes/index.tsx -> home
  // src/routes/about/page.tsx -> about-page
  // src/routes/about/team/index.tsx -> about-team-page
  
  const parts = pathWithoutRoutes.split('/');
  const fileName = parts[parts.length - 1];
  const dirParts = parts.slice(0, -1); // All but last part
  
  let name = '';
  let slug = '';
  let componentName = '';
  
  const isIndex = fileName === 'index.tsx' || fileName === 'index.jsx';
  const isPage = fileName === 'page.tsx' || fileName === 'page.jsx';
  
  if (dirParts.length === 0 && isIndex) {
    // src/routes/index.tsx -> home
    name = 'home';
    slug = '';
    componentName = 'home';
  } else if (isPage) {
    // src/routes/about/page.tsx -> about-page
    slug = dirParts.join('/');
    name = slug.replace(/\//g, '-') + '-page';
    componentName = name;
  } else if (isIndex && dirParts.length > 0) {
    // src/routes/about/team/index.tsx -> about-team-page
    slug = dirParts.join('/');
    name = slug.replace(/\//g, '-') + '-page';
    componentName = name;
  }
  
  return { name, slug, componentName };
}

function parsePageContent(content: string, fallbackName: string): PageElement {
  try {
    const result = parse(content);
    
    if (result.success && result.data) {
      return {
        id: crypto.randomUUID(),
        name: result.data.name,
        attributes: result.data.attributes,
        children: result.data.children,
      };
    }
    
    // Parse failed - return fallback with original name
    console.warn(`[Upload] Parse failed for ${fallbackName}:`, result.errors || result.warnings);
    return createFallbackPage(fallbackName, content);
    
  } catch (error: any) {
    console.error(`[Upload] Parse error for ${fallbackName}:`, error.message);
    return createFallbackPage(fallbackName, content);
  }
}

function createFallbackPage(name: string, rawJsx: string): PageElement {
  return {
    id: crypto.randomUUID(),
    name: name.toLowerCase(),
    rawJsx: rawJsx.substring(0, 1000), // Store first 1000 chars for debugging
    children: [],
  };
}

function createDefaultPage(): PageElement {
  return {
    id: crypto.randomUUID(),
    name: 'box',
    children: [],
  };
}

function getFileExtension(filePath: string): string {
  const lastDot = filePath.lastIndexOf('.');
  if (lastDot === -1) return '';
  return filePath.substring(lastDot);
}

// ============================================================================
// Import Codebase to Existing Store (ZIP)
// ============================================================================

export interface ImportCodebaseResult {
  success: boolean;
  pagesCreated?: number;
  error?: string;
}

export async function importCodebaseToStore(
  storeId: string,
  zipBuffer: ArrayBuffer
): Promise<ImportCodebaseResult> {
  try {
    // Extract ZIP and get files
    const files = await extractZipFiles(zipBuffer);
    
    // Filter for route files
    const routeFiles = filterRouteFiles(files);
    
    if (routeFiles.length === 0) {
      return { 
        success: false, 
        error: 'No route files found. Please ensure your ZIP contains src/routes/ directory.' 
      };
    }
    
    // Parse each file
    const pages = parseRouteFiles(routeFiles);
    
    // Save pages to existing store (merge behavior)
    const pageValues = pages.map(page => ({
      id: crypto.randomUUID(),
      storeId,
      name: page.name,
      slug: page.slug,
      element: page.element,
      version: 1,
    }));

    await db.insert(storePages).values(pageValues);

    return {
      success: true,
      pagesCreated: pages.length,
    };
  } catch (error: any) {
    console.error('[ImportCodebase] Failed:', error);
    return { success: false, error: error.message };
  }
}

async function extractZipFiles(buffer: ArrayBuffer): Promise<Record<string, string>> {
  const files: Record<string, string> = {};
  
  try {
    const AdmZip = (await import('adm-zip')).default;
    const zip = new AdmZip(Buffer.from(buffer));
    const zipEntries = zip.getEntries();
    
    for (const entry of zipEntries) {
      if (!entry.isDirectory) {
        const content = zip.readAsText(entry.entryName);
        files[entry.entryName] = content;
      }
    }
    
    console.log('[Upload] Extracted', Object.keys(files).length, 'files from ZIP');
  } catch (error: any) {
    console.error('[Upload] ZIP extraction error:', error.message);
    throw new Error('Failed to extract ZIP file: ' + error.message);
  }
  
  return files;
}

function filterRouteFiles(files: Record<string, string>): Array<{ path: string; content: string }> {
  const routeFiles: Array<{ path: string; content: string }> = [];
  
  for (const [path, content] of Object.entries(files)) {
    // Look for files in src/routes/
    if (!path.includes('/routes/')) continue;
    
    const ext = getFileExtension(path);
    if (!SUPPORTED_EXTENSIONS.includes(ext)) continue;
    
    // Skip non-page files
    if (!path.endsWith('/page.tsx') && 
        !path.endsWith('/page.jsx') &&
        !path.endsWith('/index.tsx') &&
        !path.endsWith('/index.jsx')) continue;
    
    routeFiles.push({ path, content });
  }
  
  return routeFiles;
}

function parseRouteFiles(files: Array<{ path: string; content: string }>): Array<{ name: string; slug: string; element: unknown }> {
  const pages: Array<{ name: string; slug: string; element: unknown }> = [];
  
  for (const file of files) {
    const routeInfo = extractRouteInfoFromPath(file.path);
    
    if (routeInfo.name) {
      const parsedContent = parsePageContent(file.content, routeInfo.componentName);
      
      pages.push({
        name: routeInfo.name,
        slug: routeInfo.slug,
        element: parsedContent,
      });
    }
  }
  
  // Add default page if none found
  if (pages.length === 0) {
    pages.push({
      name: 'home',
      slug: '',
      element: createDefaultPage(),
    });
  }
  
  return pages;
}

function extractRouteInfoFromPath(filePath: string): { name: string; slug: string; componentName: string } {
  const pathWithoutRoutes = filePath.replace(/^.*\/routes\//, '');
  
  const parts = pathWithoutRoutes.split('/');
  const fileName = parts[parts.length - 1];
  const dirParts = parts.slice(0, -1);
  
  let name = '';
  let slug = '';
  let componentName = '';
  
  const isIndex = fileName === 'index.tsx' || fileName === 'index.jsx';
  const isPage = fileName === 'page.tsx' || fileName === 'page.jsx';
  
  if (dirParts.length === 0 && isIndex) {
    name = 'home';
    slug = '';
    componentName = 'home';
  } else if (isPage) {
    slug = dirParts.join('/');
    name = slug.replace(/\//g, '-') + '-page';
    componentName = name;
  } else if (isIndex && dirParts.length > 0) {
    slug = dirParts.join('/');
    name = slug.replace(/\//g, '-') + '-page';
    componentName = name;
  }
  
  return { name, slug, componentName };
}

// ============================================================================
// Parse Single TSX File Content
// ============================================================================

export interface ParseFileResult {
  success: boolean;
  element?: PageElement;
  error?: string;
}

export function parseTsxFile(content: string): ParseFileResult {
  try {
    const result = parse(content);
    
    if (result.success && result.data) {
      const { name, ...rest } = result.data;
      return {
        success: true,
        element: {
          id: result.data.id || crypto.randomUUID(),
          name: result.data.name,
          ...rest,
        },
      };
    }
    
    // Parse failed - return fallback
    return {
      success: false,
      element: {
        id: crypto.randomUUID(),
        name: 'box',
        children: [],
      },
      error: result.warnings?.[0]?.message || 'Failed to parse file',
    };
  } catch (error: any) {
    return {
      success: false,
      element: {
        id: crypto.randomUUID(),
        name: 'box',
        children: [],
      },
      error: error.message,
    };
  }
}
