import jwt from 'jsonwebtoken';
import { db } from '../db';
import { tokenBlacklist } from '../db/schema';
import { eq } from 'drizzle-orm';

const JWT_SECRET = process.env.JWT_SECRET || 'change-this-to-a-secure-secret-in-production-min-256-bits';

export interface AuthUser {
  id: string;
  email?: string;
  username?: string;
  role?: string;
}

export async function isTokenBlacklisted(token: string): Promise<boolean> {
  try {
    const [result] = await db
      .select()
      .from(tokenBlacklist)
      .where(eq(tokenBlacklist.token, token))
      .limit(1);
    return !!result;
  } catch {
    // If table doesn't exist or error, skip blacklist check
    return false;
  }
}

export async function validateToken(token: string): Promise<AuthUser | null> {
  try {
    // Check token blacklist
    if (await isTokenBlacklisted(token)) {
      return null;
    }
    
    const decoded = jwt.verify(token, JWT_SECRET) as AuthUser & { sub?: string };
    
    return {
      id: decoded.sub || decoded.id,
      email: decoded.email,
      username: decoded.username,
      role: decoded.role,
    };
  } catch {
    return null;
  }
}

export function extractToken(request: Request): string | null {
  // Try cookie first
  const cookie = request.headers.get('cookie');
  if (cookie) {
    const match = cookie.match(/access_token=([^;]+)/);
    if (match) return match[1];
  }

  // Try Authorization header
  const auth = request.headers.get('Authorization');
  if (auth?.startsWith('Bearer ')) {
    return auth.slice(7);
  }

  return null;
}

export async function authMiddleware(request: Request): Promise<AuthUser> {
  const token = extractToken(request);
  
  if (!token) {
    throw new Error('Unauthorized - No token provided');
  }

  const user = await validateToken(token);
  
  if (!user) {
    throw new Error('Unauthorized - Invalid token');
  }

  return user;
}

// Helper to get optional auth (for public routes)
export async function getOptionalAuth(request: Request): Promise<AuthUser | null> {
  const token = extractToken(request);
  if (!token) return null;
  return validateToken(token);
}
