import * as ts from 'typescript';
import { ALLOWED_COMPONENTS, COMPONENT_NAME_MAP } from '~/builder/utils/component-registry';

// ============================================================================
// Types and Interfaces
// ============================================================================

interface JsxNode {
  name: string;
  children: JsxNode[];
  [key: string]: any; // Flattened attributes
}

interface ParseContext {
  sourceFile: ts.SourceFile;
  typeChecker: ts.TypeChecker;
  errors: ParseError[];
  warnings: ParseWarning[];
  options: ParseOptions;
}

interface ParseOptions {
  strictMode: boolean;
  maxDepth: number;
  maxChildren: number;
  allowedComponents: Set<string>;
  validateImports: boolean;
}

interface ParseError {
  message: string;
  location: string;
  line: number;
  column: number;
}

interface ParseWarning {
  message: string;
  location: string;
}

interface ParseResult {
  success: boolean;
  data?: JsxNode;
  errors: ParseError[];
  warnings: ParseWarning[];
  metadata: {
    parseTimeMs: number;
    nodeCount: number;
    maxDepthReached: number;
    sourceCodeLength: number;
  };
}

// ============================================================================
// Error Classes
// ============================================================================

class ParserError extends Error {
  constructor(
    message: string,
    public readonly location: string,
    public readonly line: number = 0,
    public readonly column: number = 0
  ) {
    super(message);
    this.name = 'ParserError';
  }
}

class UnsupportedComponentError extends ParserError {
  constructor(componentName: string, location: string, line: number, column: number) {
    super(`Unsupported component: ${componentName}`, location, line, column);
    this.name = 'UnsupportedComponentError';
  }
}

class ParseDepthExceededError extends ParserError {
  constructor(maxDepth: number, location: string) {
    super(`Maximum parse depth (${maxDepth}) exceeded`, location);
    this.name = 'ParseDepthExceededError';
  }
}

// ============================================================================
// Parser Configuration
// ============================================================================

const DEFAULT_OPTIONS: ParseOptions = {
  strictMode: false,
  maxDepth: 100,
  maxChildren: 1000,
  allowedComponents: ALLOWED_COMPONENTS,
  validateImports: false, // Skip import validation for performance
};

// ============================================================================
// Utility Functions
// ============================================================================

function normalizeTagName(name: string): string {
  if (!name) return '';
  // First try exact match in registry
  if (ALLOWED_COMPONENTS.has(name)) {
    return name;
  }
  // Then try case-insensitive match using the map
  const lowerName = name.toLowerCase();
  const registryName = COMPONENT_NAME_MAP.get(lowerName);
  return registryName || lowerName;
}

function getLineAndColumn(sourceFile: ts.SourceFile, pos: number): { line: number; column: number } {
  const { line, character } = sourceFile.getLineAndCharacterOfPosition(pos);
  return { line: line + 1, column: character + 1 };
}

function formatLocation(node: ts.Node, sourceFile: ts.SourceFile): string {
  const { line, column } = getLineAndColumn(sourceFile, node.getStart());
  return `${sourceFile.fileName || 'source'}:${line}:${column}`;
}

// ============================================================================
// Import Processing (Optional - for strict mode)
// ============================================================================

function processImports(
  node: ts.ImportDeclaration,
  context: ParseContext
): void {
  if (!context.options.validateImports) return;

  const moduleSpecifier = (node.moduleSpecifier as ts.StringLiteral)?.text || '';
  
  // Check for side-effect imports
  if (!node.importClause && moduleSpecifier) {
    const location = formatLocation(node, context.sourceFile);
    context.warnings.push({
      message: `Side-effect import detected: ${moduleSpecifier}`,
      location,
    });
    return;
  }

  // Validate component imports
  if (node.importClause?.namedBindings && ts.isNamedImports(node.importClause.namedBindings)) {
    node.importClause.namedBindings.elements.forEach(specifier => {
      const name = specifier.name.text;
      const normalizedName = normalizeTagName(name);
      
      if (!context.options.allowedComponents.has(normalizedName)) {
        const location = formatLocation(specifier, context.sourceFile);
        context.warnings.push({
          message: `Import of non-standard component: ${name}`,
          location,
        });
      }
    });
  }
}

// ============================================================================
// Attribute Processing
// ============================================================================

function processJsxAttributes(
  node: ts.JsxOpeningElement | ts.JsxSelfClosingElement,
  context: ParseContext
): Record<string, any> {
  const attributes: Record<string, any> = {};

  node.attributes.properties.forEach(attr => {
    if (ts.isJsxAttribute(attr)) {
      const name = attr.name.getText(context.sourceFile);
      
      if (attr.initializer) {
        if (ts.isStringLiteral(attr.initializer)) {
          attributes[name] = attr.initializer.text;
        } else if (ts.isJsxExpression(attr.initializer)) {
          // Handle expression values
          const expression = attr.initializer.expression;
          if (expression) {
            if (ts.isStringLiteral(expression)) {
              attributes[name] = expression.text;
            } else if (ts.isNumericLiteral(expression)) {
              attributes[name] = parseFloat(expression.text);
            } else if (expression.kind === ts.SyntaxKind.TrueKeyword) {
              attributes[name] = true;
            } else if (expression.kind === ts.SyntaxKind.FalseKeyword) {
              attributes[name] = false;
            } else if (ts.isArrayLiteralExpression(expression)) {
              attributes[name] = expression.elements.map(e => e.getText(context.sourceFile));
            } else if (ts.isObjectLiteralExpression(expression)) {
              const obj: Record<string, any> = {};
              expression.properties.forEach(prop => {
                if (ts.isPropertyAssignment(prop) && ts.isIdentifier(prop.name)) {
                  obj[prop.name.text] = prop.initializer.getText(context.sourceFile);
                }
              });
              attributes[name] = obj;
            } else {
              // Store as string representation for complex expressions
              attributes[name] = expression.getText(context.sourceFile);
            }
          }
        }
      } else {
        // Boolean attribute without value (e.g., <Button disabled />)
        attributes[name] = true;
      }
    }
  });

  return attributes;
}

// ============================================================================
// Component Name Resolution
// ============================================================================

function resolveComponentName(
  tagName: string,
  context: ParseContext
): { name: string; isSupported: boolean } {
  const normalizedName = normalizeTagName(tagName);
  
  // Check if component is in registry
  if (!context.options.allowedComponents.has(normalizedName)) {
    // Return user's original name so renderer can show "unknown"
    return { name: tagName, isSupported: false };
  }
  
  return { name: normalizedName, isSupported: true };
}

// ============================================================================
// Main Parser
// ============================================================================

function processJsxNode(
  node: ts.Node,
  context: ParseContext,
  depth: number = 0
): JsxNode | null {
  // Check depth limit
  if (depth > context.options.maxDepth) {
    const location = formatLocation(node, context.sourceFile);
    throw new ParseDepthExceededError(context.options.maxDepth, location);
  }

  // Handle import declarations
  if (ts.isImportDeclaration(node)) {
    processImports(node, context);
    return null;
  }

  // Handle JSX Fragment
  if (ts.isJsxFragment(node)) {
    const comp: JsxNode = {
      name: 'box',
      children: [],
    };

    // Process children
    for (const child of node.children) {
      const processedChild = processJsxNode(child, context, depth + 1);
      if (processedChild?.name) {
        comp.children.push(processedChild);
      }
    }

    return comp;
  }

  // Handle JSX Element
  if (ts.isJsxElement(node)) {
    const tagName = node.openingElement.tagName.getText(context.sourceFile);
    const { name, isSupported } = resolveComponentName(tagName, context);
    
    if (!isSupported) {
      const { line, column } = getLineAndColumn(context.sourceFile, node.getStart());
      const location = formatLocation(node, context.sourceFile);
      
      if (context.options.strictMode) {
        throw new UnsupportedComponentError(tagName, location, line, column);
      } else {
        context.warnings.push({
          message: `Unsupported component: ${tagName}`,
          location,
        });
      }
    }

    const attributes = processJsxAttributes(node.openingElement, context);
    
    // Flatten attributes into the node
    const comp: JsxNode = {
      name,
      children: [],
      ...attributes,
    };

    // Handle SVG specially
    if (tagName === 'svg' || tagName === 'Svg') {
      let childrenStr = '';
      for (const child of node.children) {
        childrenStr += child.getText(context.sourceFile);
      }
      comp['xmlPart'] = childrenStr;
    } else {
      // Process children
      for (const child of node.children) {
        const processedChild = processJsxNode(child, context, depth + 1);
        if (processedChild?.name) {
          comp.children.push(processedChild);
          
          // Check max children limit
          if (comp.children.length > context.options.maxChildren) {
            const location = formatLocation(node, context.sourceFile);
            throw new ParserError(
              `Maximum children count (${context.options.maxChildren}) exceeded`,
              location
            );
          }
        }
      }
    }

    // Add ID if not present
    if (!comp.id) {
      comp.id = crypto.randomUUID();
    }

    return comp;
  }

  // Handle Self-Closing JSX Element
  if (ts.isJsxSelfClosingElement(node)) {
    const tagName = node.tagName.getText(context.sourceFile);
    const { name, isSupported } = resolveComponentName(tagName, context);
    
    if (!isSupported) {
      const location = formatLocation(node, context.sourceFile);
      
      if (context.options.strictMode) {
        const { line, column } = getLineAndColumn(context.sourceFile, node.getStart());
        throw new UnsupportedComponentError(tagName, location, line, column);
      } else {
        context.warnings.push({
          message: `Unsupported component: ${tagName}`,
          location,
        });
      }
    }

    const attributes = processJsxAttributes(node, context);
    
    // Flatten attributes into the node
    const comp: JsxNode = {
      name,
      children: [],
      ...attributes,
    };

    // Add ID if not present
    if (!comp.id) {
      comp.id = crypto.randomUUID();
    }

    return comp;
  }

  // Handle JSX Expression
  if (ts.isJsxExpression(node)) {
    const text = node.getText(context.sourceFile);
    
    // Handle children prop
    if (text === '{children}' || text === '{props.children}') {
      return {
        name: 'children-prop',
        children: [],
      };
    }

    // Try to find nested JSX in expression
    let nestedJsx: JsxNode | null = null;
    ts.forEachChild(node, (child) => {
      if (!nestedJsx) {
        nestedJsx = processJsxNode(child, context, depth + 1);
      }
    });

    if (nestedJsx) {
      return nestedJsx;
    }

    return null;
  }

  // Handle JSX Text
  if (ts.isJsxText(node)) {
    const text = node.text.trim();
    if (text) {
      return {
        name: 'text',
        variant: 'body',
        text: text,
        id: crypto.randomUUID(),
        children: [],
      };
    }
    return null;
  }

  // Recursively search for JSX in other node types
  let result: JsxNode | null = null;
  ts.forEachChild(node, (child) => {
    if (!result) {
      result = processJsxNode(child, context, depth + 1);
    }
  });

  return result;
}

// ============================================================================
// Main Export Function
// ============================================================================

export default function parse(sourceCode: string, options?: Partial<ParseOptions>): ParseResult {
  const startTime = Date.now();
  const mergedOptions: ParseOptions = { ...DEFAULT_OPTIONS, ...options };

  // Validate input
  if (!sourceCode || typeof sourceCode !== 'string') {
    return {
      success: false,
      errors: [{
        message: 'Source code must be a non-empty string',
        location: 'input',
        line: 0,
        column: 0,
      }],
      warnings: [],
      metadata: {
        parseTimeMs: Date.now() - startTime,
        nodeCount: 0,
        maxDepthReached: 0,
        sourceCodeLength: 0,
      },
    };
  }

  try {
    // Create TypeScript source file
    const sourceFile = ts.createSourceFile(
      'input.tsx',
      sourceCode,
      ts.ScriptTarget.Latest,
      true,
      ts.ScriptKind.TSX
    );

    // Create type checker (minimal program for type info)
    const options: ts.CompilerOptions = {
      allowJs: true,
      noEmit: true,
      jsx: ts.JsxEmit.React,
    };
    
    const host: ts.CompilerHost = {
      getSourceFile: (fileName) => fileName === 'input.tsx' ? sourceFile : undefined,
      getDefaultLibFileName: () => 'lib.d.ts',
      writeFile: () => { /* noop */ },
      getCurrentDirectory: () => '',
      getDirectories: () => [] as string[],
      fileExists: (fileName) => fileName === 'input.tsx',
      readFile: (fileName) => fileName === 'input.tsx' ? sourceCode : undefined,
      getCanonicalFileName: (fileName) => fileName,
      useCaseSensitiveFileNames: () => true,
      getNewLine: () => '\n',
      resolveModuleNames: () => [],
    };
    
    const program = ts.createProgram(['input.tsx'], options, host);
    
    const typeChecker = program.getTypeChecker();

    // Initialize parse context
    const context: ParseContext = {
      sourceFile,
      typeChecker,
      errors: [],
      warnings: [],
      options: mergedOptions,
    };

    // Find and process root JSX node
    let result: JsxNode | null = null;
    let maxDepthReached = 0;

    function findJsxRoot(node: ts.Node, depth: number): void {
      if (result) return;
      if (depth > maxDepthReached) maxDepthReached = depth;

      if (ts.isJsxElement(node) || 
          ts.isJsxSelfClosingElement(node) || 
          ts.isJsxFragment(node) ||
          ts.isImportDeclaration(node)) {
        result = processJsxNode(node, context, 0);
        return;
      }

      ts.forEachChild(node, (child) => findJsxRoot(child, depth + 1));
    }

    findJsxRoot(sourceFile, 0);

    const parseTime = Date.now() - startTime;

    // Count total nodes
    let nodeCount = 0;
    function countNodes(node: JsxNode): void {
      nodeCount++;
      node.children.forEach(countNodes);
    }
    if (result) {
      countNodes(result);
    }

    return {
      success: result !== null,
      data: result || undefined,
      errors: context.errors,
      warnings: context.warnings,
      metadata: {
        parseTimeMs: parseTime,
        nodeCount,
        maxDepthReached,
        sourceCodeLength: sourceCode.length,
      },
    };

  } catch (error) {
    const parseTime = Date.now() - startTime;
    
    return {
      success: false,
      errors: [{
        message: error instanceof Error ? error.message : 'Unknown parsing error',
        location: 'parser',
        line: 0,
        column: 0,
      }],
      warnings: [],
      metadata: {
        parseTimeMs: parseTime,
        nodeCount: 0,
        maxDepthReached: 0,
        sourceCodeLength: sourceCode.length,
      },
    };
  }
}

// Export types and utilities for consumers
export type {
  JsxNode,
  ParseOptions,
  ParseResult,
  ParseError,
  ParseWarning,
};

export {
  ParserError,
  UnsupportedComponentError,
  ParseDepthExceededError,
  ALLOWED_COMPONENTS,
  normalizeTagName,
};
