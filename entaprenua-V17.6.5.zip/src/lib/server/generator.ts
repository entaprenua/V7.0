import { db } from '../index';
import { stores, storePages } from '../schema';
import { eq } from 'drizzle-orm';

interface Component {
  id: string;
  name: string;
  tailwind?: string;
  children?: Component[];
  [key: string]: unknown;
}

interface PageElement {
  id: string;
  name: string;
  children?: Component[];
}

export interface GenerateResult {
  success: boolean;
  files?: Record<string, string>;
  error?: string;
}

export async function generateStore(storeId: string): Promise<GenerateResult> {
  try {
    const [store] = await db.select().from(stores).where(eq(stores.id, storeId));
    if (!store) {
      return { success: false, error: 'Store not found' };
    }

    const pages = await db.select().from(storePages).where(eq(storePages.storeId, storeId));
    
    if (pages.length === 0) {
      return { success: false, error: 'No pages found' };
    }

    const files: Record<string, string> = {};

    // Generate SolidStart pages
    for (const page of pages) {
      if (page.name === 'root') {
        files['src/root-layout-content.tsx'] = generateRootLayout(page.element as PageElement | null);
      } else {
        const slug = page.slug || page.name.replace('-page', '');
        const path = slug ? `src/routes/${slug}/page.tsx` : 'src/routes/index.tsx';
        files[path] = generatePage(page.name, page.element as PageElement | null);
      }
    }

    return { success: true, files };
  } catch (error: any) {
    return { success: false, error: error.message };
  }
}

function generateRootLayout(content: PageElement | null): string {
  return `// Root layout content - auto-generated
import { ParentComponent } from 'solid-js';

const RootLayoutContent: ParentComponent = (props) => {
  return (
    <div class="min-h-screen">
      {props.children}
    </div>
  );
};

export default RootLayoutContent;
`;
}

function generatePage(pageName: string, content: PageElement | null): string {
  const componentName = toComponentName(pageName);
  
  return `// ${pageName} page - auto-generated
import { ParentComponent } from 'solid-js';

const ${componentName}Page: ParentComponent = (props) => {
  return (
    <main>
      <h1>${formatTitle(pageName)}</h1>
      ${content ? `/* Content: ${JSON.stringify(content, null, 2)} */` : ''}
    </main>
  );
};

export default ${componentName}Page;
`;
}

function toComponentName(name: string): string {
  return name
    .split(/[-_]/)
    .map(word => word.charAt(0).toUpperCase() + word.slice(1))
    .join('');
}

function formatTitle(name: string): string {
  return name
    .replace(/-/g, ' ')
    .replace(/_/g, ' ')
    .split(/ /)
    .map(word => word.charAt(0).toUpperCase() + word.slice(1))
    .join(' ');
}
