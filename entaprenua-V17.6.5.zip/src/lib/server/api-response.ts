export interface ApiResponse<T = unknown> {
  success: boolean;
  message: string;
  data: T | null;
  error: ApiError | null;
  timestamp: number;
  path: string | null;
}

export interface ApiError {
  code: string;
  message: string;
  details: Record<string, string> | null;
  fieldErrors: any[] | null;
}

export function apiSuccess<T>(data: T, message = 'Success'): ApiResponse<T> {
  return {
    success: true,
    message,
    data,
    error: null,
    timestamp: Date.now(),
    path: null,
  };
}

export function apiError(message: string, code = 'ERROR'): ApiResponse<null> {
  return {
    success: false,
    message,
    data: null,
    error: {
      code,
      message,
      details: null,
      fieldErrors: null,
    },
    timestamp: Date.now(),
    path: null,
  };
}
