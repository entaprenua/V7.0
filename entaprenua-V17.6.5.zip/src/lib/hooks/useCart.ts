import { cartsApi } from "~/lib/api/carts"
import { getOrCreateGuestId, clearGuestId } from "./useCartGuestId"
import type { Cart, CartItem } from "~/lib/types"

export type ProductInput = {
  id: string
  name?: string
  price?: string | number | null
  image?: string
  quantity?: number
}

export interface CartFetchOptions {
  storeId: string
  userId?: string
  guestId?: string
}

export async function fetchCart(options: CartFetchOptions): Promise<Cart | null> {
  const { storeId } = options
  if (!storeId) return null
  try {
    return await cartsApi.getActive(storeId)
  } catch {
    return null
  }
}

export async function addToCart(options: CartFetchOptions & {
  productId: string
  quantity?: number
}): Promise<CartItem> {
  const cart = await cartsApi.getActive(options.storeId)
  return cartsApi.addItem(cart.id, options.productId, options.quantity ?? 1)
}

export async function updateCartItem(options: CartFetchOptions & {
  itemId: string
  quantity: number
}): Promise<CartItem> {
  const cart = await cartsApi.getActive(options.storeId)
  return cartsApi.updateItem(cart.id, options.itemId, options.quantity)
}

export async function removeFromCart(options: CartFetchOptions & {
  itemId: string
}): Promise<void> {
  const cart = await cartsApi.getActive(options.storeId)
  return cartsApi.removeItem(cart.id, options.itemId)
}

export async function clearCart(options: CartFetchOptions): Promise<void> {
  const cart = await cartsApi.getActive(options.storeId)
  return cartsApi.clear(cart.id)
}

export async function mergeGuestCart(options: CartFetchOptions): Promise<Cart> {
  const cart = await cartsApi.getActive(options.storeId)
  clearGuestId()
  return cart
}

export function getCurrentCartParams(): { guestId: string } {
  return { guestId: getOrCreateGuestId() }
}
