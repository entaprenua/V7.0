import { pgTable, uuid, varchar, jsonb, integer, timestamp, boolean, text, numeric } from 'drizzle-orm/pg-core';

// ============================================================================
// STORES
// ============================================================================
export const stores = pgTable('stores', {
  id: uuid('id').defaultRandom().primaryKey(),
  parentId: uuid('parent_id'),
  userId: uuid('user_id').notNull(),
  name: varchar('name', { length: 255 }).notNull(),
  slug: varchar('slug', { length: 255 }).unique(),
  domainName: varchar('domain_name', { length: 255 }),
  logo: text('logo'),
  favicon: text('favicon'),
  isInMaintenanceMode: boolean('is_in_maintenance_mode').default(false),
  isTemplate: boolean('is_template').default(false),
  isPremium: boolean('is_premium').default(false),
  price: numeric('price', { precision: 10, scale: 2 }),
  visibility: varchar('visibility', { length: 20 }).default('public'),
  description: text('description'),
  docUrl: text('doc_url'),
  version: integer('version').default(1),
  isDeleted: boolean('is_deleted').default(false),
  insertedAt: timestamp('inserted_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
});

// ============================================================================
// STORE PAGES
// ============================================================================
export const storePages = pgTable('store_pages', {
  id: uuid('id').defaultRandom().primaryKey(),
  storeId: uuid('store_id').notNull().references(() => stores.id, { onDelete: 'cascade' }),
  name: varchar('name', { length: 100 }).notNull(),
  slug: varchar('slug', { length: 255 }),
  element: jsonb('element'),
  version: integer('version').default(1),
  insertedAt: timestamp('inserted_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
});

// ============================================================================
// USERS (Shared from Spring Boot)
// ============================================================================
export const users = pgTable('users', {
  id: uuid('id').defaultRandom().primaryKey(),
  email: varchar('email', { length: 255 }).notNull(),
  username: varchar('username', { length: 100 }),
  password: varchar('password', { length: 255 }),
  provider: varchar('provider', { length: 20 }).default('LOCAL'),
  providerId: varchar('provider_id', { length: 255 }),
  avatarUrl: varchar('avatar_url', { length: 500 }),
  emailVerified: boolean('email_verified').default(false),
  role: varchar('role', { length: 20 }).default('USER'),
  isDeleted: boolean('is_deleted').default(false),
  insertedAt: timestamp('inserted_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
});

// ============================================================================
// USER SESSIONS (Shared from Spring Boot)
// ============================================================================
export const userSessions = pgTable('user_sessions', {
  id: uuid('id').defaultRandom().primaryKey(),
  userId: uuid('user_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  token: varchar('token', { length: 500 }).notNull(),
  refreshToken: varchar('refresh_token', { length: 500 }),
  ipAddress: varchar('ip_address', { length: 45 }),
  userAgent: text('user_agent'),
  deviceType: varchar('device_type', { length: 50 }),
  browser: varchar('browser', { length: 50 }),
  os: varchar('os', { length: 50 }),
  expiresAt: timestamp('expires_at').notNull(),
  insertedAt: timestamp('inserted_at').defaultNow(),
  lastAccessedAt: timestamp('last_accessed_at').defaultNow(),
});

// ============================================================================
// TOKEN BLACKLIST (Shared from Spring Boot)
// ============================================================================
export const tokenBlacklist = pgTable('token_blacklist', {
  id: uuid('id').defaultRandom().primaryKey(),
  token: varchar('token', { length: 500 }).notNull(),
  expiresAt: timestamp('expires_at').notNull(),
  insertedAt: timestamp('inserted_at').defaultNow(),
});

// ============================================================================
// STORE PURCHASES (Shared from Spring Boot)
// ============================================================================
export const storePurchases = pgTable('store_purchases', {
  id: uuid('id').defaultRandom().primaryKey(),
  userId: uuid('user_id').notNull(),
  storeId: uuid('store_id').notNull(),
  pricePaid: varchar('price_paid', { length: 50 }),
  currency: varchar('currency', { length: 10 }).default('USD'),
  stripeSessionId: varchar('stripe_session_id', { length: 255 }),
  stripePaymentIntentId: varchar('stripe_payment_intent_id', { length: 255 }),
  status: varchar('status', { length: 20 }).default('PENDING'),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
});

// ============================================================================
// TYPE EXPORTS
// ============================================================================
export type Store = typeof stores.$inferSelect;
export type NewStore = typeof stores.$inferInsert;
export type StorePage = typeof storePages.$inferSelect;
export type NewStorePage = typeof storePages.$inferInsert;
export type User = typeof users.$inferSelect;
export type NewUser = typeof users.$inferInsert;
export type UserSession = typeof userSessions.$inferSelect;
export type NewUserSession = typeof userSessions.$inferInsert;
export type TokenBlacklist = typeof tokenBlacklist.$inferSelect;
export type NewTokenBlacklist = typeof tokenBlacklist.$inferInsert;
export type StorePurchase = typeof storePurchases.$inferSelect;
export type NewStorePurchase = typeof storePurchases.$inferInsert;
