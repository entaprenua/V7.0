import { eq, and, desc, sql } from 'drizzle-orm';
import { db } from '../index';
import { stores, storePages, storePurchases, type Store, type StorePage, type StorePurchase } from '../schema';
import { db as dbConnection } from '../index';

export interface RouteInfo {
  pageName: string;
  slug: string;
}

export interface SaveStoreWithPagesData {
  id: string;
  userId: string;
  name: string;
  description?: string | null;
  domainName?: string | null;
  logo?: string | null;
  favicon?: string | null;
  visibility?: string | null;
  isInMaintenanceMode?: boolean;
  pages: Array<{
    name: string;
    slug?: string;
    element: any;
  }>;
}

export interface SaveStoreWithPagesResult {
  store: Store;
}

export async function saveStoreWithPages(
  data: SaveStoreWithPagesData
): Promise<SaveStoreWithPagesResult> {
  const database = dbConnection;

  const pageValues = data.pages.map((page) => ({
    id: crypto.randomUUID(),
    name: page.name,
    slug: page.slug ?? page.name.toLowerCase().replace(/\s+/g, '-').replace(/-+$/, ''),
    element: page.element,
  }));

  const results = await database.transaction(async (tx) => {
    await tx.execute(sql`
      WITH store_upsert AS (
        INSERT INTO stores (id, user_id, name, description, domain_name, logo, favicon, visibility, is_in_maintenance_mode, version)
        VALUES (
          ${data.id},
          ${data.userId},
          ${data.name},
          ${data.description ?? null},
          ${data.domainName ?? null},
          ${data.logo ?? null},
          ${data.favicon ?? null},
          ${data.visibility ?? 'public'},
          ${data.isInMaintenanceMode ?? false},
          1
        )
        ON CONFLICT (id) DO UPDATE SET
          name = EXCLUDED.name,
          description = EXCLUDED.description,
          domain_name = EXCLUDED.domain_name,
          logo = EXCLUDED.logo,
          favicon = EXCLUDED.favicon,
          visibility = EXCLUDED.visibility,
          is_in_maintenance_mode = EXCLUDED.is_in_maintenance_mode,
          version = stores.version + 1,
          updated_at = NOW()
        RETURNING id
      ),
      page_data AS (
        SELECT * FROM jsonb_to_recordset(${JSON.stringify(pageValues)}::jsonb) AS t(id uuid, name varchar, slug varchar, element jsonb)
      ),
      page_upsert AS (
        INSERT INTO store_pages (id, store_id, name, slug, element, version)
        SELECT p.id, ${data.id}, p.name, p.slug, 
          CASE 
            WHEN jsonb_typeof(p.element) = 'object' THEN p.element
            ELSE jsonb_build_object('data', p.element)
          END, 
          1
        FROM page_data p
        ON CONFLICT (store_id, name) DO UPDATE SET
          element = EXCLUDED.element,
          slug = EXCLUDED.slug,
          version = store_pages.version + 1,
          updated_at = NOW()
      )
      SELECT 
        s.id, s.user_id, s.parent_id, s.name, s.description, s.domain_name, s.logo, s.favicon,
        s.is_in_maintenance_mode, s.is_template, s.visibility, s.price, s.doc_url, s.version,
        s.is_deleted, s.inserted_at, s.updated_at
      FROM stores s WHERE s.id = ${data.id};
    `);

    const [store] = await tx
      .select()
      .from(stores)
      .where(eq(stores.id, data.id));

    return { store: store as Store };
  });
  return results;
}

export const storeRepository = {
  async findById(id: string): Promise<Store | undefined> {
    const [store] = await db.select().from(stores).where(eq(stores.id, id));
    return store;
  },

  async findBySlug(slug: string): Promise<Store | undefined> {
    const [store] = await db.select().from(stores).where(eq(stores.slug, slug));
    return store;
  },

  async findByUserId(userId: string): Promise<Store[]> {
    return db
      .select()
      .from(stores)
      .where(eq(stores.userId, userId))
      .orderBy(desc(stores.insertedAt));
  },

  async existsByOwnerIdAndName(
    ownerId: string,
    name: string,
    excludeStoreId?: string
  ): Promise<boolean> {
    const conditions = [
      eq(stores.userId, ownerId),
      eq(stores.name, name),
      eq(stores.isDeleted, false)
    ];

    if (excludeStoreId) {
      conditions.push(eq(stores.id, excludeStoreId));
    }

    const [result] = await db
      .select()
      .from(stores)
      .where(and(...conditions))
      .limit(1);

    return !!result;
  },

  async findRoutes(storeId: string): Promise<RouteInfo[]> {
    const pages = await db
      .select({
        pageName: storePages.name,
        slug: storePages.slug,
      })
      .from(storePages)
      .where(eq(storePages.storeId, storeId));

    return pages.map(p => ({
      pageName: p.pageName,
      slug: p.slug ?? ''
    }));
  },

  async findAllPages(storeId: string): Promise<StorePage[]> {
    return db
      .select()
      .from(storePages)
      .where(eq(storePages.storeId, storeId));
  },

  async findPage(storeId: string, pageName: string): Promise<StorePage | undefined> {
    const [page] = await db
      .select()
      .from(storePages)
      .where(
        and(
          eq(storePages.storeId, storeId),
          eq(storePages.name, pageName)
        )
      );
    return page;
  },

  /**
   * Find page by slug.
   * NOTE: For root/home page, use slug="home" instead of "/" - URL routing doesn't support "/" as a parameter.
   */
  async findPageBySlug(storeId: string, slug: string): Promise<StorePage | undefined> {
    const [page] = await db
      .select()
      .from(storePages)
      .where(
        and(
          eq(storePages.storeId, storeId),
          eq(storePages.slug, slug)
        )
      );
    return page;
  },

  async savePage(
    page: Partial<StorePage> & { storeId: string; name: string }
  ): Promise<StorePage> {
    const slug = page.slug ?? page.name.toLowerCase().replace(/\s+/g, '-').replace(/-+$/, '');
    
    const [result] = await db
      .insert(storePages)
      .values({
        id: page.id ?? crypto.randomUUID(),
        storeId: page.storeId,
        name: page.name,
        slug: slug,
        element: page.element,
        version: (page.version ?? 0) + 1,
      })
      .onConflictDoUpdate({
        target: [storePages.storeId, storePages.slug],
        set: {
          element: page.element,
          version: (page.version ?? 0) + 1,
          updatedAt: new Date(),
        },
      })
      .returning();
    return result;
  },

  async deletePage(storeId: string, pageName: string): Promise<void> {
    await db
      .delete(storePages)
      .where(
        and(
          eq(storePages.storeId, storeId),
          eq(storePages.name, pageName)
        )
      );
  },

  async create(data: {
    userId: string;
    name: string;
    domainName?: string;
    isTemplate?: boolean;
    visibility?: string;
  }): Promise<Store> {
    const [store] = await db
      .insert(stores)
      .values({
        id: crypto.randomUUID(),
        userId: data.userId,
        name: data.name,
        domainName: data.domainName,
        isTemplate: data.isTemplate ?? false,
        visibility: data.visibility ?? 'public',
      })
      .returning();
    return store;
  },

  async save(store: Partial<Store> & { id: string; userId: string; name: string }): Promise<Store> {
    const [result] = await db
      .insert(stores)
      .values({
        id: store.id,
        parentId: store.parentId,
        userId: store.userId,
        name: store.name,
        domainName: store.domainName,
        logo: store.logo,
        favicon: store.favicon,
        isInMaintenanceMode: store.isInMaintenanceMode,
        isTemplate: store.isTemplate,
        visibility: store.visibility,
        description: store.description,
        price: store.price,
        docUrl: store.docUrl,
        version: (store.version ?? 0) + 1,
      })
      .onConflictDoUpdate({
        target: stores.id,
        set: {
          parentId: store.parentId,
          userId: store.userId,
          name: store.name,
          domainName: store.domainName,
          logo: store.logo,
          favicon: store.favicon,
          isInMaintenanceMode: store.isInMaintenanceMode,
          isTemplate: store.isTemplate,
          visibility: store.visibility,
          description: store.description,
          price: store.price,
          docUrl: store.docUrl,
          version: (store.version ?? 0) + 1,
          updatedAt: new Date(),
        },
      })
      .returning();
    return result;
  },

  async update(
    id: string,
    data: Partial<Pick<Store, 'name' | 'description' | 'logo' | 'favicon' | 'domainName' | 'visibility' | 'isInMaintenanceMode'>>
  ): Promise<Store> {
    const [updated] = await db
      .update(stores)
      .set({
        ...data,
        version: 1,
        updatedAt: new Date(),
      })
      .where(eq(stores.id, id))
      .returning();
    return updated;
  },

  async delete(id: string): Promise<void> {
    await db
      .update(stores)
      .set({ isDeleted: true, updatedAt: new Date() })
      .where(eq(stores.id, id));
  },

  async clone(
    sourceStoreId: string,
    newStoreId: string,
    newName: string,
    userId: string
  ): Promise<Store> {
    // Clone store - insert select
    const insertResult = await db.execute(sql`
      INSERT INTO stores (id, parent_id, user_id, name, domain_name, is_in_maintenance_mode,
          logo, favicon, is_template, visibility, description, version)
      SELECT ${newStoreId}, parent_id, ${userId}, ${newName}, domain_name,
          COALESCE(is_in_maintenance_mode, false), logo, favicon, false, 'public', description, 1
      FROM stores WHERE id = ${sourceStoreId}
    `);
    
    if (insertResult.rowCount === 0) {
      throw new Error('Source store not found');
    }

    // Get cloned store
    const [clonedStore] = await db
      .select()
      .from(stores)
      .where(eq(stores.id, newStoreId))
      .limit(1);

    // Clone pages - insert select
    await db.execute(sql`
      INSERT INTO store_pages (id, store_id, name, slug, element, version)
      SELECT gen_random_uuid(), ${newStoreId}, name, slug, element, 1
      FROM store_pages WHERE store_id = ${sourceStoreId}
    `);

    return clonedStore;
  },

  async findTemplates(): Promise<Store[]> {
    return db
      .select()
      .from(stores)
      .where(eq(stores.isTemplate, true));
  },

  async findPurchaseById(id: string): Promise<StorePurchase | undefined> {
    const [purchase] = await db
      .select()
      .from(storePurchases)
      .where(eq(storePurchases.id, id));
    return purchase;
  },

  async findPurchaseByUserAndStore(userId: string, storeId: string): Promise<StorePurchase | undefined> {
    const [purchase] = await db
      .select()
      .from(storePurchases)
      .where(
        and(
          eq(storePurchases.userId, userId),
          eq(storePurchases.storeId, storeId)
        )
      );
    return purchase;
  },

  async hasPurchased(userId: string, storeId: string): Promise<boolean> {
    const purchase = await this.findPurchaseByUserAndStore(userId, storeId);
    return purchase?.status === 'COMPLETED';
  },

  async updatePurchaseStatus(id: string, status: string, paymentIntentId?: string): Promise<StorePurchase | undefined> {
    const [updated] = await db
      .update(storePurchases)
      .set({
        status,
        stripePaymentIntentId: paymentIntentId ?? null,
        updatedAt: new Date(),
      })
      .where(eq(storePurchases.id, id))
      .returning();
    return updated;
  },
};
