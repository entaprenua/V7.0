import { createContext, useContext, type ParentComponent } from "solid-js"
import { createSignal } from "solid-js"
import { createItemList, productToEntry, toCartItems, type ProductInput } from "../item-list"
import type { ItemListEntry, ItemListSnapshot } from "../item-list"
import type { Cart, CartItem } from "~/lib/types"

type CartStore = ReturnType<typeof createItemList> & {
  sync: (cart: Cart) => void
  addProduct: (product: ProductInput, quantity?: number) => void
  toCartItems: () => CartItem[]
}

const CartContext = createContext<CartStore>()

export const useCart = (): CartStore => {
  const ctx = useContext(CartContext)
  if (!ctx) throw new Error("useCart must be used within CartProvider")
  return ctx
}

export const CartProvider: ParentComponent<{ initialCart?: Cart }> = (props) => {
  const list = createItemList(undefined, { defaultQuantity: 1, defaultSelected: true })
  const [cartData, setCartData] = createSignal<Cart | undefined>(props.initialCart)

  const sync = (cart: Cart): void => {
    setCartData(cart)
    const snapshot: ItemListSnapshot = {
      id: cart.id,
      storeId: cart.storeId,
      customerId: cart.customerId,
      currency: cart.currency,
      subtotal: cart.subtotal,
      total: cart.total,
      notes: cart.notes,
      items: cart.items?.map((item): ItemListEntry => ({
        id: item.id,
        productId: item.productId,
        quantity: item.quantity,
        price: item.price,
        name: "",
        image: undefined,
        selected: true,
        subtotal: item.subtotal,
        cartId: item.cartId,
      })),
    }
    list.setSnapshot(snapshot)
  }

  const addProduct = (product: ProductInput, quantity = 1): void => {
    const entry = productToEntry(product, { quantity, selected: true })
    if (entry) list.add(entry)
  }

  const toCartItemsFn = (): CartItem[] => {
    const cartId = cartData()?.id ?? ""
    return toCartItems(list.items(), cartId)
  }

  const store: CartStore = {
    ...list,
    sync,
    addProduct,
    toCartItems: toCartItemsFn,
  }

  return <CartContext.Provider value={store}>{props.children}</CartContext.Provider>
}
