import { createContext, useContext, createSignal, type ParentComponent, type Accessor } from "solid-js"
import { createStore } from "solid-js/store"
import { useAuth } from "~/lib/guards/auth"
import { storesApi, productsApi, categoriesApi, ordersApi, mediaApi } from "~/lib/api"
import { useStoreContext } from "./store-context"
import type { Store, Product, Category, Order, Media } from "~/lib/types"

type AdminPanelState = {
  stores: Store[]
  currentStore: Store | null
  products: Product[]
  categories: Category[]
  orders: Order[]
  media: Media[]
  isLoading: boolean
  isLoadingStore: boolean
  error: string | null
}

type AdminPanelActions = {
  loadStores: () => Promise<void>
  switchStore: (storeId: string) => Promise<void>
  loadProducts: (page?: number) => Promise<void>
  loadCategories: () => Promise<void>
  loadOrders: (page?: number) => Promise<void>
  loadMedia: () => Promise<void>
  createProduct: (data: Partial<Product>) => Promise<Product | null>
  updateProduct: (id: string, data: Partial<Product>) => Promise<Product | null>
  deleteProduct: (id: string) => Promise<boolean>
  createCategory: (data: Partial<Category>) => Promise<Category | null>
  updateCategory: (id: string, data: Partial<Category>) => Promise<Category | null>
  deleteCategory: (id: string) => Promise<boolean>
  updateOrderStatus: (id: string, status: string) => Promise<Order | null>
  uploadMedia: (file: File) => Promise<Media | null>
  deleteMedia: (id: string) => Promise<boolean>
  updateStore: (data: Partial<Store>) => Promise<Store | null>
  clearError: () => void
}

type AdminPanelContextValue = Accessor<AdminPanelState> & AdminPanelActions

const AdminPanelContext = createContext<AdminPanelContextValue>()

export const useAdminPanel = (): AdminPanelContextValue => {
  const ctx = useContext(AdminPanelContext)
  if (!ctx) throw new Error("useAdminPanel must be used within AdminPanelProvider")
  return ctx
}

export const AdminPanelProvider: ParentComponent = (props) => {
  const auth = useAuth()
  let storeContext: ReturnType<typeof useStoreContext> | undefined
  
  try {
    storeContext = useStoreContext()
  } catch {
    // StoreContext not available (outside StoreProvider)
  }

  const [state, setState] = createStore<AdminPanelState>({
    stores: [],
    currentStore: null,
    products: [],
    categories: [],
    orders: [],
    media: [],
    isLoading: false,
    isLoadingStore: false,
    error: null,
  })

  const syncToGlobalContext = (store: Store | null) => {
    if (storeContext) {
      storeContext.setCurrentStore(store)
    }
  }

  const setError = (error: string | null) => setState("error", error)
  const setLoading = (loading: boolean) => setState("isLoading", loading)

  const loadStores = async () => {
    if (!auth.isAuthenticated()) return
    setLoading(true)
    setError(null)
    try {
      const response = await storesApi.getAll()
      const stores = response.content ?? []
      setState("stores", stores)

      const savedStoreId = localStorage.getItem("current-store-id")
      const currentStore = savedStoreId
        ? stores.find((s) => s.id === savedStoreId) ?? stores[0]
        : stores[0]

      if (currentStore) {
        setState("currentStore", currentStore)
        syncToGlobalContext(currentStore)
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load stores")
    } finally {
      setLoading(false)
    }
  }

  const switchStore = async (storeId: string) => {
    const store = state.stores.find((s) => s.id === storeId)
    if (!store || store.id === state.currentStore?.id) return

    setState("isLoadingStore", true)
    setState("currentStore", store)
    syncToGlobalContext(store)
    
    setState("products", [])
    setState("categories", [])
    setState("orders", [])
    setState("media", [])
    
    await Promise.all([
      loadProducts(),
      loadCategories(),
      loadOrders(),
      loadMedia(),
    ])
    
    setState("isLoadingStore", false)
  }

  const loadProducts = async (page = 0) => {
    if (!state.currentStore?.id) return
    setLoading(true)
    setError(null)
    try {
      const response = await productsApi.getAll(state.currentStore.id, page, 50)
      setState("products", response.content ?? [])
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load products")
    } finally {
      setLoading(false)
    }
  }

  const loadCategories = async () => {
    if (!state.currentStore?.id) return
    setLoading(true)
    setError(null)
    try {
      const response = await categoriesApi.getAll(state.currentStore.id)
      setState("categories", response.content ?? [])
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load categories")
    } finally {
      setLoading(false)
    }
  }

  const loadOrders = async (page = 0) => {
    if (!state.currentStore?.id) return
    setLoading(true)
    setError(null)
    try {
      const response = await ordersApi.getAll(state.currentStore.id, { page, size: 50 })
      setState("orders", response.content ?? [])
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load orders")
    } finally {
      setLoading(false)
    }
  }

  const loadMedia = async () => {
    if (!state.currentStore?.id) return
    setLoading(true)
    setError(null)
    try {
      const media = await mediaApi.getByStore(state.currentStore.id)
      setState("media", media)
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load media")
    } finally {
      setLoading(false)
    }
  }

  const createProduct = async (data: Partial<Product>): Promise<Product | null> => {
    if (!state.currentStore?.id) return null
    setLoading(true)
    setError(null)
    try {
      const product = await productsApi.create(state.currentStore.id, data)
      if (product) {
        setState("products", (p) => [product, ...p])
        return product
      }
      return null
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to create product")
      return null
    } finally {
      setLoading(false)
    }
  }

  /**
   * Update a product using upsert pattern.
   * Always calls productsApi.create() with id to support both create and update.
   * Optimistically updates local state on success.
   */
  const updateProduct = async (id: string, data: Partial<Product>): Promise<Product | null> => {
    if (!state.currentStore?.id) return null
    setLoading(true)
    setError(null)
    try {
      const product = await productsApi.create(state.currentStore.id, { id, ...data })
      if (product) {
        setState("products", (p) => p.map((pr) => pr.id === id ? product : pr))
        return product
      }
      return null
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to update product")
      return null
    } finally {
      setLoading(false)
    }
  }

  const deleteProduct = async (id: string): Promise<boolean> => {
    if (!state.currentStore?.id) return false
    setLoading(true)
    setError(null)
    try {
      await productsApi.delete(state.currentStore.id, id)
      setState("products", (p) => p.filter((pr) => pr.id !== id))
      return true
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to delete product")
      return false
    } finally {
      setLoading(false)
    }
  }

  const createCategory = async (data: Partial<Category>): Promise<Category | null> => {
    if (!state.currentStore?.id) return null
    setLoading(true)
    setError(null)
    try {
      const category = await categoriesApi.create(state.currentStore.id, data)
      if (category) {
        setState("categories", (c) => [...c, category])
        return category
      }
      return null
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to create category")
      return null
    } finally {
      setLoading(false)
    }
  }

  const updateCategory = async (id: string, data: Partial<Category>): Promise<Category | null> => {
    if (!state.currentStore?.id) return null
    setLoading(true)
    setError(null)
    try {
      const category = await categoriesApi.create(state.currentStore.id, { ...data, id })
      if (category) {
        setState("categories", (c) => c.map((cat) => cat.id === id ? category : cat))
        return category
      }
      return null
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to update category")
      return null
    } finally {
      setLoading(false)
    }
  }

  const deleteCategory = async (id: string): Promise<boolean> => {
    if (!state.currentStore?.id) return false
    setLoading(true)
    setError(null)
    try {
      await categoriesApi.delete(state.currentStore.id, id)
      setState("categories", (c) => c.filter((cat) => cat.id !== id))
      return true
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to delete category")
      return false
    } finally {
      setLoading(false)
    }
  }

  const updateOrderStatus = async (id: string, status: string): Promise<Order | null> => {
    if (!state.currentStore?.id) return null
    setLoading(true)
    setError(null)
    try {
      const order = await ordersApi.updateStatus(state.currentStore.id, id, status as any)
      if (order) {
        setState("orders", (o) => o.map((ord) => ord.id === id ? order : ord))
        return order
      }
      return null
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to update order status")
      return null
    } finally {
      setLoading(false)
    }
  }

  const uploadMedia = async (file: File): Promise<Media | null> => {
    if (!state.currentStore?.id) return null
    setLoading(true)
    setError(null)
    try {
      const response = await mediaApi.upload([file], state.currentStore.id)
      if (response.successful > 0) {
        await loadMedia()
        return state.media[0] || null
      }
      return null
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to upload media")
      return null
    } finally {
      setLoading(false)
    }
  }

  const deleteMedia = async (id: string): Promise<boolean> => {
    if (!state.currentStore?.id) return false
    setLoading(true)
    setError(null)
    try {
      await mediaApi.delete(id, state.currentStore.id)
      setState("media", (m) => m.filter((med) => med.id !== id))
      return true
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to delete media")
      return false
    } finally {
      setLoading(false)
    }
  }

  const updateStore = async (data: Partial<Store>): Promise<Store | null> => {
    if (!state.currentStore?.id) return null
    setLoading(true)
    setError(null)
    try {
      const updateData = {
        id: state.currentStore.id,
        name: data.name,
        description: data.description ?? undefined,
        domain: data.domain ?? undefined,
        subdomain: data.subdomain ?? undefined,
        logo: data.logo ?? undefined,
        favicon: data.favicon ?? undefined,
        visibility: (data.visibility as any) ?? undefined,
      }
      const store = await storesApi.updateStore(updateData)
      if (store) {
        setState("currentStore", store)
        setState("stores", (s) => s.map((st) => st.id === store.id ? store : st))
        return store
      }
      return null
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to update store")
      return null
    } finally {
      setLoading(false)
    }
  }

  const clearError = () => setError(null)

  const contextValue: AdminPanelContextValue = Object.assign(
    () => state,
    {
      loadStores,
      switchStore,
      loadProducts,
      loadCategories,
      loadOrders,
      loadMedia,
      createProduct,
      updateProduct,
      deleteProduct,
      createCategory,
      updateCategory,
      deleteCategory,
      updateOrderStatus,
      uploadMedia,
      deleteMedia,
      updateStore,
      clearError,
    }
  )

  return (
    <AdminPanelContext.Provider value={contextValue}>
      {props.children}
    </AdminPanelContext.Provider>
  )
}
