import { createContext, useContext, type ParentComponent } from "solid-js"
import { createSignal } from "solid-js"
import { createItemList, productToEntry, toOrderItems, type ProductInput } from "../item-list"
import type { ItemListEntry, ItemListSnapshot } from "../item-list"
import type { Order, OrderItem, Address } from "~/lib/types"

type OrderStore = ReturnType<typeof createItemList> & {
  order: () => Order | undefined
  sync: (order: Order) => void
  addProduct: (product: ProductInput, quantity?: number) => void
  setBillingAddress: (address: Address) => void
  setShippingAddress: (address: Address) => void
  toOrderItems: () => OrderItem[]
}

const OrderContext = createContext<OrderStore>()

export const useOrder = (): OrderStore => {
  const ctx = useContext(OrderContext)
  if (!ctx) throw new Error("useOrder must be used within OrderProvider")
  return ctx
}

export const OrderProvider: ParentComponent<{ initialOrder?: Order }> = (props) => {
  const list = createItemList(undefined, { defaultQuantity: 1, defaultSelected: true })
  const [orderData, setOrderData] = createSignal<Order | undefined>(props.initialOrder)
  const [billingAddress, setBillingAddress] = createSignal<Address | null>(null)
  const [shippingAddress, setShippingAddress] = createSignal<Address | null>(null)

  const sync = (order: Order): void => {
    setOrderData(order)
    if (order.billingAddress) setBillingAddress(order.billingAddress)
    if (order.shippingAddress) setShippingAddress(order.shippingAddress)
    const snapshot: ItemListSnapshot = {
      id: order.id,
      storeId: order.storeId,
      customerId: order.customerId,
      currency: order.currency,
      subtotal: order.subtotal,
      total: order.total,
      notes: order.notes,
      items: order.items?.map((item): ItemListEntry => ({
        id: item.id,
        productId: item.productId,
        quantity: item.quantity,
        price: item.price,
        name: item.productName,
        selected: true,
        subtotal: item.subtotal,
        orderId: item.orderId,
      })),
    }
    list.setSnapshot(snapshot)
  }

  const addProduct = (product: ProductInput, quantity = 1): void => {
    const entry = productToEntry(product, { quantity, selected: true })
    if (entry) list.add(entry)
  }

  const toOrderItemsFn = (): OrderItem[] => {
    const orderId = orderData()?.id ?? ""
    return toOrderItems(list.items(), orderId)
  }

  const store: OrderStore = {
    ...list,
    order: orderData,
    sync,
    addProduct,
    setBillingAddress,
    setShippingAddress,
    toOrderItems: toOrderItemsFn,
  }

  return <OrderContext.Provider value={store}>{props.children}</OrderContext.Provider>
}
