import { createContext, useContext, type ParentComponent } from "solid-js"
import { createSignal } from "solid-js"
import { createItemList, productToEntry, toWishlistItems, type ProductInput } from "../item-list"
import type { ItemListEntry, ItemListSnapshot } from "../item-list"
import type { Wishlist, WishlistItem } from "~/lib/types"

type WishlistStore = ReturnType<typeof createItemList> & {
  sync: (wishlist: Wishlist) => void
  addProduct: (product: ProductInput) => void
  toWishlistItems: () => WishlistItem[]
}

const WishlistContext = createContext<WishlistStore>()

export const useWishlist = (): WishlistStore => {
  const ctx = useContext(WishlistContext)
  if (!ctx) throw new Error("useWishlist must be used within WishlistProvider")
  return ctx
}

export const WishlistProvider: ParentComponent<{ initialWishlist?: Wishlist }> = (props) => {
  const list = createItemList(undefined, { defaultQuantity: 1, defaultSelected: true })
  const [wishlistData, setWishlistData] = createSignal<Wishlist | undefined>(props.initialWishlist)

  const sync = (wishlist: Wishlist): void => {
    setWishlistData(wishlist)
    const snapshot: ItemListSnapshot = {
      id: wishlist.id,
      storeId: wishlist.storeId,
      customerId: wishlist.customerId,
      items: wishlist.items?.map((item): ItemListEntry => ({
        id: item.id,
        productId: item.productId,
        quantity: 1,
        price: 0,
        name: "",
        selected: true,
        subtotal: 0,
        wishlistId: item.wishlistId,
      })),
    }
    list.setSnapshot(snapshot)
  }

  const addProduct = (product: ProductInput): void => {
    if (!product.id || list.hasProduct(product.id)) return
    const entry = productToEntry(product, { quantity: 1, selected: true })
    if (entry) list.add(entry)
  }

  const toWishlistItemsFn = (): WishlistItem[] => {
    const wishlistId = wishlistData()?.id ?? ""
    return toWishlistItems(list.items(), wishlistId)
  }

  const store: WishlistStore = {
    ...list,
    sync,
    addProduct,
    toWishlistItems: toWishlistItemsFn,
  }

  return <WishlistContext.Provider value={store}>{props.children}</WishlistContext.Provider>
}
