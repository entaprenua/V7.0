import { createContext, useContext, createSignal, type Accessor, type ParentComponent } from "solid-js"
import { makePersisted } from "~/lib/utils"
import type { Store } from "~/lib/types"

type StoreContextValue = {
  currentStore: Accessor<Store | null>
  currentStoreId: Accessor<string | null>
  setCurrentStore: (store: Store | null) => void
  isLoading: Accessor<boolean>
  setIsLoading: (loading: boolean) => void
}

const StoreContext = createContext<StoreContextValue>()

export const useStoreContext = (): StoreContextValue => {
  const ctx = useContext(StoreContext)
  if (!ctx) {
    throw new Error("useStoreContext must be used within StoreProvider")
  }
  return ctx
}

export const useCurrentStore = (): Accessor<Store | null> => {
  return useStoreContext().currentStore
}

export const useCurrentStoreId = (): Accessor<string | null> => {
  return useStoreContext().currentStoreId
}

export const StoreProvider: ParentComponent<{ store?: Store | null }> = (props) => {
  const [currentStore, setCurrentStore] = createSignal<Store | null>(props.store ?? null)
  const [isLoading, setIsLoading] = createSignal(false)

  const persistedStoreId = makePersisted(
    createSignal<string | null>(null),
    { name: "current-store-id" }
  )
  const [, setPersistedId] = persistedStoreId
  const [persistedId] = persistedStoreId

  const handleSetCurrentStore = (store: Store | null) => {
    setCurrentStore(store)
    setPersistedId(store?.id ?? null)
  }

  const value: StoreContextValue = {
    currentStore,
    currentStoreId: () => {
      const store = currentStore()
      return store?.id ?? persistedId() ?? null
    },
    setCurrentStore: handleSetCurrentStore,
    isLoading,
    setIsLoading,
  }

  return (
    <StoreContext.Provider value={value}>
      {props.children}
    </StoreContext.Provider>
  )
}

export { StoreContext }
export type { StoreContextValue }
