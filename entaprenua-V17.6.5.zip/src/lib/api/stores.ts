import { api, getCsrfToken } from './client';
import type { Store, StorePage, PagedResponse, ApiSuccess } from '../types';

export type StoreStatus = 'active' | 'inactive' | 'maintenance';
export type StoreVisibility = 'public' | 'private' | 'unlisted';


export interface StoreUpdateRequest {
  name?: string;
  description?: string;
  domain?: string;
  subdomain?: string;
  logo?: string;
  favicon?: string;
  visibility?: StoreVisibility;
  isInMaintenanceMode?: boolean;
}

export interface StoreSaveRequest {
  userId: string;
  name: string;
  description?: string;
  domainName?: string;
  logo?: string;
  favicon?: string;
  visibility?: StoreVisibility;
  isInMaintenanceMode?: boolean;
  pages: Array<{
    name: string;
    slug?: string;
    element?: any;
  }>;
}

export interface StoreStats {
  totalProducts: number;
  totalOrders: number;
  totalRevenue: number;
  totalCustomers: number;
  totalPages: number;
}

export interface StoreSearchParams {
  ownerId?: string;
  page?: number;
  size?: number;
  status?: StoreStatus;
  search?: string;
  sortBy?: 'name' | 'created' | 'updated';
  sortOrder?: 'asc' | 'desc';
  includeTemplates?: boolean;
}

export interface DomainValidationResult {
  available: boolean;
  message?: string;
}

const STORES = "/stores"

export const storesApi = {
  getAll: async (params: StoreSearchParams = {}): Promise<PagedResponse<Store>> => {
    const csrfToken = getCsrfToken();
    const queryParams = new URLSearchParams();
    
    if (params.ownerId) queryParams.set('ownerId', params.ownerId);
    if (params.page !== undefined) queryParams.set('page', String(params.page));
    if (params.size !== undefined) queryParams.set('size', String(params.size));
    if (params.status) queryParams.set('status', params.status);
    if (params.search) queryParams.set('q', params.search);
    if (params.sortBy) queryParams.set('sortBy', params.sortBy);
    if (params.sortOrder) queryParams.set('sortOrder', params.sortOrder);
    if (params.includeTemplates !== undefined) queryParams.set('includeTemplates', String(params.includeTemplates));

    const url = queryParams.toString() ? `${STORES}?${queryParams.toString()}` : STORES;
    return api.get<PagedResponse<Store>>(url, csrfToken || undefined);
  },

  getById: async (id: string): Promise<ApiSuccess<Store>> => {
    const csrfToken = getCsrfToken();
    return api.get<ApiSuccess<Store>>(`${STORES}/${id}`, csrfToken || undefined);
  },

  checkExists: async (id: string): Promise<{ exists: boolean }> => {
    const csrfToken = getCsrfToken();
    return api.get<{ exists: boolean }>(`${STORES}/${id}/exists`, csrfToken || undefined);
  },

  getTemplates: async (params: { 
    page?: number; 
    size?: number; 
    search?: string;
  } = {}): Promise<PagedResponse<Store>> => {
    const csrfToken = getCsrfToken();
    const queryParams = new URLSearchParams();
    
    if (params.page !== undefined) queryParams.set('page', String(params.page));
    if (params.size !== undefined) queryParams.set('size', String(params.size));
    if (params.search) queryParams.set('search', params.search);

    const url = queryParams.toString() ? `/templates?${queryParams.toString()}` : `/templates`;
    return api.get<PagedResponse<Store>>(url, csrfToken || undefined);
  },

  // Public API - templates are accessible without authentication
  getTemplateById: async (id: string): Promise<ApiSuccess<Store>> => {
    const csrfToken = getCsrfToken();
    return api.get<ApiSuccess<Store>>(`/templates/${id}`, csrfToken || undefined);
  },

  purchaseTemplate: async (
    templateId: string,
    successUrl?: string,
    cancelUrl?: string
  ): Promise<{ checkoutUrl: string; purchaseId: string }> => {
    const csrfToken = getCsrfToken();
    const defaultSuccessUrl = `${window.location.origin}/templates/${templateId}?purchased=true`;
    const defaultCancelUrl = `${window.location.origin}/templates/${templateId}`;
    
    return api.post<{ checkoutUrl: string; purchaseId: string }>(
      `${STORES}/templates/${templateId}/purchase`,
      {
        storeId: templateId,
        successUrl: successUrl || defaultSuccessUrl,
        cancelUrl: cancelUrl || defaultCancelUrl,
      },
      csrfToken || undefined
    );
  },

  getTemplatePurchases: async (): Promise<any[]> => {
    const csrfToken = getCsrfToken();
    return api.get<any[]>(`${STORES}/purchases`, csrfToken || undefined);
  },

  checkTemplatePurchased: async (templateId: string): Promise<{ purchased: boolean }> => {
    const csrfToken = getCsrfToken();
    return api.get<{ purchased: boolean }>(
      `${STORES}/templates/${templateId}/purchased`,
      csrfToken || undefined
    );
  },

  // Fetched from SolidStart API (/api/stores/{storeId}/routes)
  getRoutes: async (storeId: string): Promise<{ pageName: string; slug: string }[]> => {
    const csrfToken = getCsrfToken();
    return api.solidStart.get<{ pageName: string; slug: string }[]>(
      `${STORES}/${storeId}/routes`,
      csrfToken || undefined
    );
  },

  // SolidStart API: Get store by ID (for builder)
  getStoreById: async (id: string): Promise<ApiSuccess<Store>> => {
    const csrfToken = getCsrfToken();
    return api.solidStart.get<ApiSuccess<Store>>(`${STORES}/${id}`, csrfToken || undefined);
  },

  // SolidStart API: Get store by slug (public)
  getStoreBySlug: async (slug: string): Promise<ApiSuccess<Store>> => {
    return api.solidStart.get<ApiSuccess<Store>>(`${STORES}/slug/${slug}`);
  },

  // SolidStart API: Get page by storeId and page slug
  getPageBySlug: async (storeId: string, pageSlug: string): Promise<ApiSuccess<StorePage>> => {
    return api.solidStart.get<ApiSuccess<StorePage>>(`${STORES}/${storeId}/pages/${pageSlug}`);
  },

  // SolidStart API: Update store
  updateStore: async (data: Partial<Store>): Promise<Store> => {
    const csrfToken = getCsrfToken();
    return api.solidStart.put<Store>(`${STORES}/${data.id!}`, data, csrfToken || undefined);
  },

  // SolidStart API: Delete store
  deleteStore: async (id: string): Promise<ApiSuccess<{ success: boolean }>> => {
    const csrfToken = getCsrfToken();
    return api.solidStart.delete<ApiSuccess<{ success: boolean }>>(`${STORES}/${id}`, csrfToken || undefined);
  },

  // SolidStart API: Clone store
  cloneStore: async (id: string, data: { name?: string; purchaseId?: string }): Promise<Store> => {
    const csrfToken = getCsrfToken();
    return api.solidStart.post<Store>(`${STORES}/${id}/clone`, data, csrfToken || undefined);
  },

  // SolidStart API: Check if store name exists
  checkNameExists: async (name: string): Promise<{ exists: boolean }> => {
    const csrfToken = getCsrfToken();
    return api.solidStart.get<{ exists: boolean }>(`/stores/check-name?name=${encodeURIComponent(name)}`, csrfToken || undefined);
  },

  // SolidStart API: Export store
  exportStore: async (id: string): Promise<any> => {
    const csrfToken = getCsrfToken();
    return api.solidStart.get<any>(`${STORES}/${id}/export`, csrfToken || undefined);
  },

  // SolidStart API: Import store
  importStore: async (data: FormData): Promise<any> => {
    const csrfToken = getCsrfToken();
    const response = await fetch(`${STORES}/import`, {
      method: 'POST',
      body: data,
      credentials: 'include',
      headers: csrfToken ? { 'X-CSRF-Token': csrfToken } : {},
    });
    if (!response.ok) {
      throw new Error('Failed to import store');
    }
    return response.json();
  },

  // SolidStart API: Get all pages for store
  getPages: async (storeId: string): Promise<ApiSuccess<StorePage[]>> => {
    const csrfToken = getCsrfToken();
    return api.solidStart.get<ApiSuccess<StorePage[]>>(`${STORES}/${storeId}/pages`, csrfToken || undefined);
  },

  // SolidStart API: Create page
  createPage: async (storeId: string, data: { name: string; slug?: string; element?: any }): Promise<ApiSuccess<StorePage>> => {
    const csrfToken = getCsrfToken();
    return api.solidStart.post<ApiSuccess<StorePage>>(`${STORES}/${storeId}/pages`, data, csrfToken || undefined);
  },

  // SolidStart API: Get page by name
  getPage: async (storeId: string, pageName: string): Promise<ApiSuccess<StorePage>> => {
    const csrfToken = getCsrfToken();
    return api.solidStart.get<ApiSuccess<StorePage>>(`${STORES}/${storeId}/pages/${pageName}`, csrfToken || undefined);
  },

  // SolidStart API: Update page
  updatePage: async (storeId: string, pageName: string, data: { slug?: string; element?: any }): Promise<ApiSuccess<StorePage>> => {
    const csrfToken = getCsrfToken();
    return api.solidStart.put<ApiSuccess<StorePage>>(`${STORES}/${storeId}/pages/${pageName}`, data, csrfToken || undefined);
  },

  // SolidStart API: Delete page
  deletePage: async (storeId: string, pageName: string): Promise<ApiSuccess<{ success: boolean }>> => {
    const csrfToken = getCsrfToken();
    return api.solidStart.delete<ApiSuccess<{ success: boolean }>>(`${STORES}/${storeId}/pages/${pageName}`, csrfToken || undefined);
  },

  // SolidStart API: Save store with pages (combined endpoint)
  saveStoreWithPages: async (storeId: string, data: Omit<StoreSaveRequest, 'userId'> & { userId?: string }): Promise<Store> => {
    const csrfToken = getCsrfToken();
    return api.solidStart.put<Store>(`${STORES}/${storeId}/save`, data, csrfToken || undefined);
  },

  // SolidStart API: Import codebase (ZIP) to existing store
  importCodebase: async (
    storeId: string, 
    formData: FormData,
    onProgress?: (progress: { stage: string; progress: number; message: string }) => void
  ): Promise<{ success: boolean; pagesCreated?: number; message?: string }> => {
    const csrfToken = getCsrfToken();
    const response = await api.solidStart.post<{ success: boolean; pagesCreated?: number; message?: string; error?: string }>(
      `${STORES}/${storeId}/import`,
      formData,
      csrfToken || undefined
    );
    
    if (response.success === false) {
      throw new Error(response.error || 'Import failed');
    }
    
    return response;
  },
};
