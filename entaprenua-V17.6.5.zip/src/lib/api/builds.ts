import { getCsrfToken } from './client';

export type Framework = 'solidstart' | 'nextjs';

export interface BuildResult {
  success: boolean;
  storeId: string;
  storeName: string;
  fileCount: number;
  framework: Framework;
  downloadedAt: string;
}

export interface UploadResult {
  success: boolean;
  storeId: string;
  name: string;
  pagesCount: number;
  framework: Framework;
}

export interface BuildProgress {
  stage: 'preparing' | 'generating' | 'compressing' | 'complete';
  progress: number;
  message: string;
}

const STORES_BASE = '/stores';

export const buildsApi = {
  exportStore: async (
    storeId: string,
    framework: Framework = 'solidstart',
    onProgress?: (progress: BuildProgress) => void
  ): Promise<Blob> => {
    onProgress?.({ stage: 'preparing', progress: 0, message: 'Preparing build...' });
    
    const csrfToken = getCsrfToken();
    const url = `${STORES_BASE}/${storeId}/export?framework=${framework}`;
    
    const headers: Record<string, string> = {};
    if (csrfToken) {
      headers['X-CSRF-TOKEN'] = csrfToken;
    }

    onProgress?.({ stage: 'generating', progress: 30, message: 'Generating store files...' });

    const response = await fetch(url, {
      method: 'GET',
      headers,
      credentials: 'include',
    });

    if (!response.ok) {
      const error = await response.json().catch(() => ({ error: 'Export failed' }));
      throw new Error(error.error || `Export failed with status ${response.status}`);
    }

    onProgress?.({ stage: 'compressing', progress: 70, message: 'Compressing files...' });

    const blob = await response.blob();
    
    onProgress?.({ stage: 'complete', progress: 100, message: 'Build complete!' });

    return blob;
  },

  downloadStore: async (storeId: string, storeName: string, framework: Framework = 'solidstart'): Promise<void> => {
    const blob = await buildsApi.exportStore(storeId, framework);
    
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${storeName.toLowerCase().replace(/\s+/g, '-')}.zip`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  },

  importStore: async (
    files: File[],
    storeName: string,
    onProgress?: (progress: BuildProgress) => void
  ): Promise<UploadResult> => {
    onProgress?.({ stage: 'preparing', progress: 0, message: 'Preparing upload...' });

    const csrfToken = getCsrfToken();
    const formData = new FormData();
    
    formData.append('name', storeName);

    files.forEach((file) => {
      formData.append('files', file);
    });

    onProgress?.({ stage: 'generating', progress: 30, message: 'Uploading files...' });

    const headers: Record<string, string> = {};
    if (csrfToken) {
      headers['X-CSRF-TOKEN'] = csrfToken;
    }

    const response = await fetch(`${STORES_BASE}/import`, {
      method: 'POST',
      headers,
      credentials: 'include',
      body: formData,
    });

    if (!response.ok) {
      const error = await response.json().catch(() => ({ error: 'Upload failed' }));
      throw new Error(error.error || `Upload failed with status ${response.status}`);
    }

    onProgress?.({ stage: 'compressing', progress: 70, message: 'Processing store...' });

    const result = await response.json();
    
    onProgress?.({ stage: 'complete', progress: 100, message: 'Upload complete!' });

    return {
      success: result.success,
      storeId: result.storeId,
      name: result.name,
      pagesCount: result.pagesCount,
      framework: result.framework.toLowerCase() as Framework,
    };
  },

  createStoreFromTemplate: async (
    templateId: string,
    storeName: string
  ): Promise<{ storeId: string }> => {
    const csrfToken = getCsrfToken();
    
    const response = await fetch(`${STORES_BASE}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...(csrfToken ? { 'X-CSRF-TOKEN': csrfToken } : {}),
      },
      credentials: 'include',
      body: JSON.stringify({ templateId, name: storeName }),
    });

    if (!response.ok) {
      const error = await response.json().catch(() => ({ error: 'Failed to create store' }));
      throw new Error(error.error || `Failed with status ${response.status}`);
    }

    const result = await response.json();
    return { storeId: result.data?.id };
  },
};
