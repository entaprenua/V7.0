import { api } from './client'
import type { 
  Hero, HeroItem, 
  CreateHeroRequest, UpdateHeroRequest,
  CreateHeroItemRequest, UpdateHeroItemRequest 
} from '../types'

const BASE = '/heroes'

export const heroesApi = {
  getByStoreId: async (storeId: string, includeItems = true, token?: string) => 
    api.get<Hero[]>(`/stores/${storeId}/heroes?includeItems=${includeItems}`, token),

  getActiveByStoreId: async (storeId: string, token?: string) =>
    api.get<Hero[]>(`/stores/${storeId}/heroes/active`, token),

  getById: async (storeId: string, heroId: string, includeItems = true, token?: string) =>
    api.get<Hero>(`/stores/${storeId}/heroes/${heroId}?includeItems=${includeItems}`, token),

  create: async (data: CreateHeroRequest, token: string) =>
    api.post<Hero>(`/stores/${data.storeId}/heroes`, data, token),

  update: async (storeId: string, heroId: string, data: UpdateHeroRequest, token: string) =>
    api.post<Hero>(`/stores/${storeId}/heroes/${heroId}`, data, token),

  delete: async (storeId: string, heroId: string, token: string) =>
    api.delete<void>(`/stores/${storeId}/heroes/${heroId}`, token),

  getItems: async (storeId: string, heroId: string, token?: string) =>
    api.get<HeroItem[]>(`/stores/${storeId}/heroes/${heroId}/items`, token),

  createItem: async (storeId: string, data: CreateHeroItemRequest, token: string) =>
    api.post<HeroItem>(`/stores/${storeId}/heroes/items`, data, token),

  updateItem: async (storeId: string, data: UpdateHeroItemRequest, token: string) =>
    api.post<HeroItem>(`/stores/${storeId}/heroes/items`, data, token),

  deleteItem: async (storeId: string, itemId: string, token: string) =>
    api.delete<void>(`/stores/${storeId}/heroes/items/${itemId}`, token),
}
