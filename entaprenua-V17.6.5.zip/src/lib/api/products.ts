import { api, getCsrfToken } from './client';
import type { Product, PagedResponse } from '../types';

const PRODUCTS_BASE = (storeId: string) => `/stores/${storeId}/products`;

export interface ProductFilters {
  search?: string
  status?: "in_stock" | "low_stock" | "out_of_stock" | "not_tracked"
  visibility?: "public" | "private" | "draft"
  categoryId?: string
  minPrice?: number
  maxPrice?: number
  sortBy?: "name" | "price" | "stockQuantity" | "visibility" | "createdAt"
  sortOrder?: "asc" | "desc"
}

const buildFilterParams = (filters?: ProductFilters): URLSearchParams => {
  const params = new URLSearchParams();
  if (filters?.search) params.append("search", filters.search);
  if (filters?.status) params.append("status", filters.status);
  if (filters?.visibility) params.append("visibility", filters.visibility);
  if (filters?.categoryId) params.append("categoryId", filters.categoryId);
  if (filters?.minPrice) params.append("minPrice", String(filters.minPrice));
  if (filters?.maxPrice) params.append("maxPrice", String(filters.maxPrice));
  if (filters?.sortBy) params.append("sortBy", filters.sortBy);
  if (filters?.sortOrder) params.append("sortOrder", filters.sortOrder);
  return params;
};

export const productsApi = {
  getAll: async (
    storeId: string, 
    page = 0, 
    size = 20, 
    filters?: ProductFilters
  ): Promise<PagedResponse<Product>> => {
    const csrfToken = getCsrfToken();
    const filterParams = buildFilterParams(filters);
    filterParams.set("page", String(page));
    filterParams.set("size", String(size));
    return api.get<PagedResponse<Product>>(`${PRODUCTS_BASE(storeId)}?${filterParams}`, csrfToken || undefined);
  },

  getById: async (storeId: string, id: string, includeMedia = false, includeMetadata = false): Promise<Product> => {
    const csrfToken = getCsrfToken();
    const params = new URLSearchParams();
    if (includeMedia) params.append('includeMedia', 'true');
    if (includeMetadata) params.append('includeMetadata', 'true');
    const query = params.toString() ? `?${params.toString()}` : '';
    return api.get<Product>(`${PRODUCTS_BASE(storeId)}/${id}${query}`, csrfToken || undefined);
  },

  getBySlug: async (storeId: string, slug: string, includeMedia = false, includeMetadata = false): Promise<Product> => {
    const csrfToken = getCsrfToken();
    const params = new URLSearchParams();
    if (includeMedia) params.append('includeMedia', 'true');
    if (includeMetadata) params.append('includeMetadata', 'true');
    const query = params.toString() ? `?${params.toString()}` : '';
    return api.get<Product>(`${PRODUCTS_BASE(storeId)}/by-slug/${encodeURIComponent(slug)}${query}`, csrfToken || undefined);
  },

  create: async (storeId: string, data: Partial<Product>): Promise<Product> => {
    const csrfToken = getCsrfToken();
    return api.post<Product>(PRODUCTS_BASE(storeId), data, csrfToken || undefined);
  },

  update: async (storeId: string, id: string, data: Partial<Product>): Promise<Product> => {
    const csrfToken = getCsrfToken();
    return api.put<Product>(`${PRODUCTS_BASE(storeId)}/${id}`, data, csrfToken || undefined);
  },

  delete: async (storeId: string, id: string): Promise<void> => {
    const csrfToken = getCsrfToken();
    return api.delete<void>(`${PRODUCTS_BASE(storeId)}/${id}`, csrfToken || undefined);
  },

  getByCategory: async (storeId: string, categoryId: string, page = 0, size = 20): Promise<PagedResponse<Product>> => {
    const csrfToken = getCsrfToken();
    return api.get<PagedResponse<Product>>(`${PRODUCTS_BASE(storeId)}/category/${categoryId}?page=${page}&size=${size}`, csrfToken || undefined);
  },

  search: async (
    storeId: string, 
    query: string, 
    page = 0, 
    size = 20,
    filters?: ProductFilters
  ): Promise<PagedResponse<Product>> => {
    const csrfToken = getCsrfToken();
    const filterParams = buildFilterParams(filters);
    filterParams.set("page", String(page));
    filterParams.set("size", String(size));
    filterParams.set("search", query);
    return api.get<PagedResponse<Product>>(`${PRODUCTS_BASE(storeId)}?${filterParams}`, csrfToken || undefined);
  },

  existsByName: async (storeId: string, name: string): Promise<{ exists: boolean; id?: string }> => {
    const csrfToken = getCsrfToken();
    const url = `${PRODUCTS_BASE(storeId)}/by-name?name=${encodeURIComponent(name)}`
    try {
      const response = await api.get<{ id: string }>(url, csrfToken || undefined)
      return { exists: true, id: response.id }
    } catch (e: any) {
      if (e.status === 404) {
        return { exists: false }
      }
      return { exists: false }
    }
  },
};
