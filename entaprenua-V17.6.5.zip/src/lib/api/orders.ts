import { api, getCsrfToken } from './client';
import type { Order, PagedResponse } from '../types';

export type OrderStatus = 'pending' | 'confirmed' | 'processing' | 'on_hold' | 'shipped' | 'delivered' | 'cancelled' | 'refunded' | 'returned' | 'payment_failed';

export interface OrderSearchParams {
  page?: number;
  size?: number;
  status?: OrderStatus;
  search?: string;
  sortBy?: 'created' | 'updated' | 'total';
  sortOrder?: 'asc' | 'desc';
}

const STORES_BASE = '/stores';

export const ordersApi = {
  getAll: async (
    storeId: string, 
    params: OrderSearchParams = {}
  ): Promise<PagedResponse<Order>> => {
    const csrfToken = getCsrfToken();
    const queryParams = new URLSearchParams();
    
    if (params.page !== undefined) queryParams.set('page', String(params.page));
    if (params.size !== undefined) queryParams.set('size', String(params.size));
    if (params.status) queryParams.set('status', params.status);
    if (params.search) queryParams.set('search', params.search);
    if (params.sortBy) queryParams.set('sortBy', params.sortBy);
    if (params.sortOrder) queryParams.set('sortOrder', params.sortOrder);

    const url = queryParams.toString() 
      ? `${STORES_BASE}/${storeId}/orders?${queryParams.toString()}` 
      : `${STORES_BASE}/${storeId}/orders`;
    return api.get<PagedResponse<Order>>(url, csrfToken || undefined);
  },

  getById: async (storeId: string, orderId: string): Promise<Order> => {
    const csrfToken = getCsrfToken();
    return api.get<Order>(`${STORES_BASE}/${storeId}/orders/${orderId}`, csrfToken || undefined);
  },

  updateStatus: async (storeId: string, orderId: string, status: OrderStatus): Promise<Order> => {
    const csrfToken = getCsrfToken();
    return api.put<Order>(`${STORES_BASE}/${storeId}/orders/${orderId}/status`, { status }, csrfToken || undefined);
  },

  cancel: async (storeId: string, orderId: string): Promise<Order> => {
    const csrfToken = getCsrfToken();
    return api.put<Order>(`${STORES_BASE}/${storeId}/orders/${orderId}/status`, { status: 'cancelled' }, csrfToken || undefined);
  },

  delete: async (storeId: string, orderId: string): Promise<void> => {
    const csrfToken = getCsrfToken();
    return api.delete<void>(`${STORES_BASE}/${storeId}/orders/${orderId}`, csrfToken || undefined);
  },
};

export const ORDER_STATUS_LABELS: Record<OrderStatus, string> = {
  pending: 'Pending',
  confirmed: 'Confirmed',
  processing: 'Processing',
  on_hold: 'On Hold',
  shipped: 'Shipped',
  delivered: 'Delivered',
  cancelled: 'Cancelled',
  refunded: 'Refunded',
  returned: 'Returned',
  payment_failed: 'Payment Failed',
};

export const ORDER_STATUS_COLORS: Record<OrderStatus, string> = {
  pending: 'warning',
  confirmed: 'default',
  processing: 'default',
  on_hold: 'warning',
  shipped: 'info',
  delivered: 'success',
  cancelled: 'secondary',
  refunded: 'secondary',
  returned: 'warning',
  payment_failed: 'destructive',
};
