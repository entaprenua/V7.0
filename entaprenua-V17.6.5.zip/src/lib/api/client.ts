const API_BASE = '/api/v1';
const SOLIDSTART_API_BASE = '/api';

type FetchOptions = {
  method?: 'GET' | 'POST' | 'PUT' | 'DELETE' | 'PATCH';
  body?: unknown;
  headers?: Record<string, string>;
  csrfToken?: string;
};

let cachedCsrfToken: string | null = null;
let tokenExpiresAt: number | null = null;
let refreshInProgress: Promise<boolean> | null = null;

export function setCsrfToken(token: string | null) {
  cachedCsrfToken = token;
}

export function getCsrfToken(): string | null {
  return cachedCsrfToken;
}

export function setTokenExpiry(expiresAt: number | null) {
  tokenExpiresAt = expiresAt;
}

export function getTokenExpiry(): number | null {
  return tokenExpiresAt;
}

function shouldIncludeCsrf(path: string, method: string): boolean {
  if (method === 'GET') return false;
  const exemptPaths = ['/auth/login', '/auth/register', '/auth/refresh'];
  return !exemptPaths.some(p => path.includes(p));
}

function isTokenExpiringSoon(): boolean {
  if (!tokenExpiresAt) return false;
  const bufferMs = 60000; // 1 minute buffer
  return Date.now() + bufferMs >= tokenExpiresAt;
}

async function silentRefresh(): Promise<boolean> {
  if (refreshInProgress) {
    return refreshInProgress;
  }
  
  refreshInProgress = (async () => {
    try {
      const response = await fetch(`${API_BASE}/auth/refresh`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
      });
      
      if (!response.ok) return false;
      
      const data = await response.json();
      if (data.success) {
        if (data.csrfToken) {
          cachedCsrfToken = data.csrfToken;
          sessionStorage.setItem('auth_csrf', data.csrfToken);
        }
        if (data.expiresAt) {
          tokenExpiresAt = data.expiresAt;
        }
        return true;
      }
      return false;
    } catch {
      return false;
    } finally {
      refreshInProgress = null;
    }
  })();
  
  return refreshInProgress;
}

async function request<T>(path: string, options: FetchOptions = {}): Promise<T> {
  return requestInternal<T>(path, options, API_BASE);
}

async function requestSolidStart<T>(path: string, options: FetchOptions = {}): Promise<T> {
  return requestInternal<T>(path, options, SOLIDSTART_API_BASE);
}

async function requestInternal<T>(path: string, options: FetchOptions, baseUrl: string): Promise<T> {
  const { method = 'GET', body, headers = {}, csrfToken } = options;

  if (isTokenExpiringSoon() && !path.includes('/auth/')) {
    await silentRefresh();
  }

  const requestHeaders: Record<string, string> = {
    'Content-Type': 'application/json',
    ...headers,
  };

  const effectiveCsrf = csrfToken || cachedCsrfToken;
  if (effectiveCsrf && shouldIncludeCsrf(path, method)) {
    requestHeaders['X-CSRF-Token'] = effectiveCsrf;
  }

  const config: RequestInit = {
    method,
    headers: requestHeaders,
    credentials: 'include',
  };

  if (body && method !== 'GET') {
    config.body = JSON.stringify(body);
  }

  const response = await fetch(`${baseUrl}${path}`, config);

  if (response.status === 401 && !path.includes('/auth/')) {
    const refreshed = await silentRefresh();
    if (refreshed) {
      const retryConfig: RequestInit = { ...config };
      const retryHeaders = new Headers(config.headers as Headers);
      if (cachedCsrfToken && shouldIncludeCsrf(path, method)) {
        retryHeaders.set('X-CSRF-Token', cachedCsrfToken);
      }
      retryConfig.headers = retryHeaders;
      
      const retryResponse = await fetch(`${baseUrl}${path}`, retryConfig);
      if (!retryResponse.ok) {
        const error = await retryResponse.json().catch(() => ({ message: 'Request failed' }));
        throw new ApiError(error.message || `HTTP ${retryResponse.status}`, retryResponse.status, error);
      }
      if (retryResponse.status === 204) return {} as T;
      return retryResponse.json();
    }
    
    const event = new CustomEvent('auth:unauthorized');
    window.dispatchEvent(event);
  }

  if (!response.ok) {
    const error = await response.json().catch(() => ({ message: 'Request failed' }));
    throw new ApiError(error.message || `HTTP ${response.status}`, response.status, error);
  }

  if (response.status === 204) {
    return {} as T;
  }

  const json = await response.json();
  
  // Check if response is wrapped in ApiResponse and unwrap data if present
  if (json && typeof json === 'object' && 'success' in json && 'data' in json) {
    const apiResponse = json as { success: boolean; data: unknown; message?: string; error?: unknown };
    if (apiResponse.success) {
      return apiResponse.data as T;
    } else {
      throw new ApiError(apiResponse.message || 'Request failed', response.status, apiResponse.error);
    }
  }
  
  return json as T;
}

export class ApiError extends Error {
  status: number;
  data: unknown;

  constructor(message: string, status: number, data?: unknown) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.data = data;
  }
}

export const api = {
  get: <T>(path: string, csrfToken?: string) => 
    request<T>(path, { csrfToken }),
  post: <T>(path: string, body: unknown, csrfToken?: string) => 
    request<T>(path, { method: 'POST', body, csrfToken }),
  put: <T>(path: string, body: unknown, csrfToken?: string) => 
    request<T>(path, { method: 'PUT', body, csrfToken }),
  patch: <T>(path: string, body: unknown, csrfToken?: string) => 
    request<T>(path, { method: 'PATCH', body, csrfToken }),
  delete: <T>(path: string, csrfToken?: string) => 
    request<T>(path, { method: 'DELETE', csrfToken }),
  solidStart: {
    get: <T>(path: string, csrfToken?: string) => 
      requestSolidStart<T>(path, { csrfToken }),
    post: <T>(path: string, body: unknown, csrfToken?: string) => 
      requestSolidStart<T>(path, { method: 'POST', body, csrfToken }),
    put: <T>(path: string, body: unknown, csrfToken?: string) => 
      requestSolidStart<T>(path, { method: 'PUT', body, csrfToken }),
    patch: <T>(path: string, body: unknown, csrfToken?: string) => 
      requestSolidStart<T>(path, { method: 'PATCH', body, csrfToken }),
    delete: <T>(path: string, csrfToken?: string) => 
      requestSolidStart<T>(path, { method: 'DELETE', csrfToken }),
  },
};
