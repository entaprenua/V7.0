import { api, getCsrfToken, setCsrfToken } from './client'
import type {
  User,
  LoginRequest, LoginResponse,
  RegisterRequest, RegisterResponse,
  PasswordResetRequestRequest, PasswordResetConfirmRequest,
  EmailVerificationRequest,
  ChangePasswordRequest,
  UpdateProfileRequest,
} from '../types'
import type { EmailServerValidationResult } from '../utils/validation'

const AUTH_BASE = '/auth'

export interface SessionInfo {
  id: string
  deviceType: string | null
  browser: string | null
  os: string | null
  ipAddress: string | null
  lastAccessedAt: string | null
  createdAt: string | null
  isActive: boolean
  isCurrent: boolean
}

export const authApi = {
  login: async (credentials: LoginRequest): Promise<LoginResponse> => {
    const response = await api.post<LoginResponse>(`${AUTH_BASE}/login`, credentials)
    
    if (response.csrfToken) {
      setCsrfToken(response.csrfToken)
    }
    
    return response
  },

  register: async (data: RegisterRequest): Promise<RegisterResponse> => {
    const response = await api.post<RegisterResponse>(`${AUTH_BASE}/register`, data)
    
    if (response.csrfToken) {
      setCsrfToken(response.csrfToken)
    }
    
    return response
  },

  logout: async (): Promise<void> => {
    const csrfToken = getCsrfToken()
    await api.post(`${AUTH_BASE}/logout`, {}, csrfToken || undefined)
    setCsrfToken(null)
  },

  me: async (): Promise<User> => {
    return api.get<User>(`${AUTH_BASE}/me`)
  },

  refresh: async (): Promise<LoginResponse> => {
    const response = await api.post<LoginResponse>(`${AUTH_BASE}/refresh`, {})
    
    if (response.csrfToken) {
      setCsrfToken(response.csrfToken)
    }
    
    return response
  },

  updateProfile: async (data: UpdateProfileRequest): Promise<User> => {
    const csrfToken = getCsrfToken()
    return api.put<User>(`${AUTH_BASE}/profile`, data, csrfToken || undefined)
  },

  changePassword: async (data: ChangePasswordRequest): Promise<void> => {
    const csrfToken = getCsrfToken()
    return api.post<void>(`${AUTH_BASE}/change-password`, data, csrfToken || undefined)
  },

  requestPasswordReset: async (data: PasswordResetRequestRequest): Promise<void> => {
    return api.post<void>(`${AUTH_BASE}/password-reset/request`, data)
  },

  confirmPasswordReset: async (data: PasswordResetConfirmRequest): Promise<void> => {
    return api.post<void>(`${AUTH_BASE}/password-reset/confirm`, data)
  },

  verifyEmail: async (data: EmailVerificationRequest): Promise<User> => {
    return api.post<User>(`${AUTH_BASE}/verify-email`, data)
  },

  resendVerification: async (email: string): Promise<void> => {
    return api.post<void>(`${AUTH_BASE}/resend-verification`, { email })
  },

  getSessions: async (): Promise<SessionInfo[]> => {
    const csrfToken = getCsrfToken()
    return api.get<SessionInfo[]>(`${AUTH_BASE}/sessions`, csrfToken || undefined)
  },

  revokeSession: async (sessionId: string): Promise<void> => {
    const csrfToken = getCsrfToken()
    return api.delete<void>(`${AUTH_BASE}/sessions/${sessionId}`, csrfToken || undefined)
  },

  revokeAllSessions: async (): Promise<void> => {
    const csrfToken = getCsrfToken()
    return api.post<void>(`${AUTH_BASE}/sessions/revoke-all`, {}, csrfToken || undefined)
  },

  validateEmail: async (email: string): Promise<EmailServerValidationResult> => {
    return api.get<EmailServerValidationResult>(
      `${AUTH_BASE}/validate-email?email=${encodeURIComponent(email)}`
    )
  },

  checkEmailExists: async (email: string): Promise<{ exists: boolean; provider?: string }> => {
    return api.get<{ exists: boolean; provider?: string }>(
      `${AUTH_BASE}/check-email?email=${encodeURIComponent(email)}`
    )
  },

  checkUsernameExists: async (username: string): Promise<{ exists: boolean }> => {
    return api.get<{ exists: boolean }>(
      `${AUTH_BASE}/check-username?username=${encodeURIComponent(username)}`
    )
  },

  getOAuthUrl: async (provider: string): Promise<{ url: string }> => {
    return api.get<{ url: string }>(
      `${AUTH_BASE}/oauth/${provider}/url`
    )
  },

  handleOAuthCallback: async (provider: string, code: string, state?: string): Promise<LoginResponse> => {
    const response = await api.post<LoginResponse>(
      `${AUTH_BASE}/oauth/${provider}/callback`,
      { code, state }
    )
    
    if (response.csrfToken) {
      setCsrfToken(response.csrfToken)
    }
    
    return response
  },
}

export const rolesApi = {
  getAll: async (): Promise<{ name: string; description: string | null }[]> => {
    const csrfToken = getCsrfToken()
    return api.get<{ name: string; description: string | null }[]>(
      `${AUTH_BASE}/roles`,
      csrfToken || undefined
    )
  },

  getUserPermissions: async (userId: string): Promise<string[]> => {
    const csrfToken = getCsrfToken()
    return api.get<string[]>(
      `${AUTH_BASE}/users/${userId}/permissions`,
      csrfToken || undefined
    )
  },

  hasPermission: async (permission: string): Promise<{ hasPermission: boolean }> => {
    const csrfToken = getCsrfToken()
    return api.get<{ hasPermission: boolean }>(
      `${AUTH_BASE}/check-permission?permission=${encodeURIComponent(permission)}`,
      csrfToken || undefined
    )
  },
}
