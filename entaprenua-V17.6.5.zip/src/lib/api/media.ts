import { api, getCsrfToken } from './client';
import type { MediaUploadResponse, StorageStats, Media } from '../types';

const MEDIA_BASE = '/media';

const getMediaBaseUrl = (): string => {
  return import.meta.env.VITE_API_URL || '';
};

export const mediaApi = {
  upload: async (files: File[], storeId: string): Promise<MediaUploadResponse> => {
    const formData = new FormData();
    files.forEach((file) => formData.append('files', file));

    const response = await fetch(`/api/v1/stores/${storeId}/media`, {
      method: 'POST',
      credentials: 'include',
      body: formData,
    });

    if (!response.ok) {
      const error = await response.json().catch(() => ({ message: 'Upload failed' }));
      throw new Error(error.message || `HTTP ${response.status}`);
    }

    return response.json();
  },

  getById: async (id: string, storeId: string): Promise<Media> => {
    const csrfToken = getCsrfToken();
    return api.get<Media>(`/api/v1/stores/${storeId}/media/${id}`, csrfToken || undefined);
  },

  getByStore: async (storeId: string): Promise<Media[]> => {
    const csrfToken = getCsrfToken();
    return api.get<Media[]>(`/api/v1/stores/${storeId}/media`, csrfToken || undefined);
  },

  delete: async (id: string, storeId: string): Promise<void> => {
    const csrfToken = getCsrfToken();
    return api.delete<void>(`/api/v1/stores/${storeId}/media/${id}`, csrfToken || undefined);
  },

  getStorageStats: async (storeId: string): Promise<StorageStats> => {
    const csrfToken = getCsrfToken();
    return api.get<StorageStats>(`/api/v1/stores/${storeId}/media/stats`, csrfToken || undefined);
  },

  getUrl: (path: string): string => {
    return `${getMediaBaseUrl()}/media/${path}`;
  },
};
