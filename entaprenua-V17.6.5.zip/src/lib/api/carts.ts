import { api } from './client';
import type { Cart, CartItem } from '../types';

const CARTS_BASE = '/carts';

export const cartsApi = {
  get: async (cartId: string, token?: string): Promise<Cart> => {
    return api.get<Cart>(`${CARTS_BASE}/${cartId}`, token);
  },

  getActive: async (storeId: string, token?: string): Promise<Cart> => {
    return api.get<Cart>(`${CARTS_BASE}/active?storeId=${storeId}`, token);
  },

  create: async (storeId: string, token?: string): Promise<Cart> => {
    return api.post<Cart>(CARTS_BASE, { storeId }, token);
  },

  addItem: async (cartId: string, productId: string, quantity: number, token?: string): Promise<CartItem> => {
    return api.post<CartItem>(`${CARTS_BASE}/${cartId}/items`, { productId, quantity }, token);
  },

  updateItem: async (cartId: string, itemId: string, quantity: number, token?: string): Promise<CartItem> => {
    return api.patch<CartItem>(`${CARTS_BASE}/${cartId}/items/${itemId}`, { quantity }, token);
  },

  removeItem: async (cartId: string, itemId: string, token?: string): Promise<void> => {
    return api.delete<void>(`${CARTS_BASE}/${cartId}/items/${itemId}`, token);
  },

  clear: async (cartId: string, token?: string): Promise<void> => {
    return api.delete<void>(`${CARTS_BASE}/${cartId}/items`, token);
  },

  delete: async (cartId: string, token?: string): Promise<void> => {
    return api.delete<void>(`${CARTS_BASE}/${cartId}`, token);
  },
};
