import { api } from './client'
import type {
  Payment, Refund, PaymentMethod, PaymentSettings, CustomerBalance,
  PagedResponse, CreatePaymentRequest, CreatePaymentResponse,
  RefundPaymentRequest, RefundPaymentResponse
} from '../types'

const PAYMENTS_BASE = '/payments'

export const paymentsApi = {
  createPaymentIntent: async (
    data: CreatePaymentRequest,
    token: string
  ): Promise<CreatePaymentResponse> => {
    return api.post<CreatePaymentResponse>(`${PAYMENTS_BASE}/create`, data, token)
  },

  getById: async (
    paymentId: string,
    token: string
  ): Promise<Payment> => {
    return api.get<Payment>(`${PAYMENTS_BASE}/${paymentId}`, token)
  },

  getByOrderId: async (
    orderId: string,
    token: string
  ): Promise<Payment[]> => {
    return api.get<Payment[]>(`${PAYMENTS_BASE}/order/${orderId}`, token)
  },

  getByStoreId: async (
    storeId: string,
    page = 0,
    size = 20,
    token: string
  ): Promise<PagedResponse<Payment>> => {
    return api.get<PagedResponse<Payment>>(
      `${PAYMENTS_BASE}?storeId=${storeId}&page=${page}&size=${size}`,
      token
    )
  },

  getByUserId: async (
    userId: string,
    page = 0,
    size = 20,
    token: string
  ): Promise<PagedResponse<Payment>> => {
    return api.get<PagedResponse<Payment>>(
      `${PAYMENTS_BASE}/user/${userId}?page=${page}&size=${size}`,
      token
    )
  },

  getStatus: async (
    paymentId: string,
    token: string
  ): Promise<{ status: string; processedAt: string | null }> => {
    return api.get<{ status: string; processedAt: string | null }>(
      `${PAYMENTS_BASE}/${paymentId}/status`,
      token
    )
  },

  refund: async (
    data: RefundPaymentRequest,
    token: string
  ): Promise<RefundPaymentResponse> => {
    return api.post<RefundPaymentResponse>(
      `${PAYMENTS_BASE}/${data.paymentId}/refund`,
      { amount: data.amount, reason: data.reason, description: data.description },
      token
    )
  },

  cancel: async (
    paymentId: string,
    token: string
  ): Promise<Payment> => {
    return api.post<Payment>(
      `${PAYMENTS_BASE}/${paymentId}/cancel`,
      {},
      token
    )
  },
}

export const paymentMethodsApi = {
  getAll: async (
    storeId: string,
    token: string
  ): Promise<PaymentMethod[]> => {
    return api.get<PaymentMethod[]>(
      `${PAYMENTS_BASE}/methods?storeId=${storeId}`,
      token
    )
  },

  getById: async (
    methodId: string,
    token: string
  ): Promise<PaymentMethod> => {
    return api.get<PaymentMethod>(
      `${PAYMENTS_BASE}/methods/${methodId}`,
      token
    )
  },

  create: async (
    data: {
      storeId: string
      stripePaymentMethodId: string
      type: string
      isDefault?: boolean
      nickname?: string
    },
    token: string
  ): Promise<PaymentMethod> => {
    return api.post<PaymentMethod>(
      `${PAYMENTS_BASE}/methods`,
      data,
      token
    )
  },

  update: async (
    methodId: string,
    data: Partial<PaymentMethod>,
    token: string
  ): Promise<PaymentMethod> => {
    return api.put<PaymentMethod>(
      `${PAYMENTS_BASE}/methods/${methodId}`,
      data,
      token
    )
  },

  setDefault: async (
    methodId: string,
    token: string
  ): Promise<PaymentMethod> => {
    return api.post<PaymentMethod>(
      `${PAYMENTS_BASE}/methods/${methodId}/default`,
      {},
      token
    )
  },

  delete: async (
    methodId: string,
    token: string
  ): Promise<void> => {
    return api.delete<void>(
      `${PAYMENTS_BASE}/methods/${methodId}`,
      token
    )
  },
}

export const refundsApi = {
  create: async (
    data: RefundPaymentRequest,
    token: string
  ): Promise<RefundPaymentResponse> => {
    return api.post<RefundPaymentResponse>(
      `${PAYMENTS_BASE}/${data.paymentId}/refund`,
      { amount: data.amount, reason: data.reason, description: data.description },
      token
    )
  },

  getByPaymentId: async (
    paymentId: string,
    token: string
  ): Promise<Refund[]> => {
    return api.get<Refund[]>(
      `${PAYMENTS_BASE}/${paymentId}/refunds`,
      token
    )
  },

  getById: async (
    refundId: string,
    token: string
  ): Promise<Refund> => {
    return api.get<Refund>(
      `${PAYMENTS_BASE}/refunds/${refundId}`,
      token
    )
  },

  getByStoreId: async (
    storeId: string,
    page = 0,
    size = 20,
    token: string
  ): Promise<PagedResponse<Refund>> => {
    return api.get<PagedResponse<Refund>>(
      `${PAYMENTS_BASE}/refunds?storeId=${storeId}&page=${page}&size=${size}`,
      token
    )
  },
}

export const paymentSettingsApi = {
  getByStoreId: async (
    storeId: string,
    token: string
  ): Promise<PaymentSettings> => {
    return api.get<PaymentSettings>(
      `${PAYMENTS_BASE}/settings/${storeId}`,
      token
    )
  },

  update: async (
    storeId: string,
    data: Partial<PaymentSettings>,
    token: string
  ): Promise<PaymentSettings> => {
    return api.put<PaymentSettings>(
      `${PAYMENTS_BASE}/settings/${storeId}`,
      data,
      token
    )
  },
}

export const customerBalanceApi = {
  getByStoreId: async (
    storeId: string,
    token: string
  ): Promise<CustomerBalance> => {
    return api.get<CustomerBalance>(
      `${PAYMENTS_BASE}/balance?storeId=${storeId}`,
      token
    )
  },
}
