import { Router } from "@solidjs/router";
import { FileRoutes } from "@solidjs/start/router";
import { Suspense } from "solid-js";
import { MetaProvider } from "@solidjs/meta";
import { QueryClient, QueryClientProvider } from "@tanstack/solid-query";
import { AuthProvider } from "~/lib/guards/auth";
import { StoreProvider } from "~/lib/stores";
import { BuilderProvider} from "./builder/builder-provider"
import Home from "./home"
import "./app.css";
import BuilderRoutes from "./builder/routes"

// Shared QueryClient instance - required so all components share the same cache.
// Without this, invalidating/refetching queries from one component won't affect others.
const queryClient = new QueryClient()

export default function App() {
  
  return (
    <MetaProvider>
      <QueryClientProvider client={queryClient}>
        <AuthProvider>
          <StoreProvider>
            <BuilderProvider>   
              <Router
                root={Home}
              >
                <FileRoutes />
                <BuilderRoutes />  
              </Router>
            </BuilderProvider> 
          </StoreProvider>
        </AuthProvider>
      </QueryClientProvider>
    </MetaProvider>
  );
}
