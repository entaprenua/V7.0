import { Box } from "~/components/ui/box"
import { Flex } from "~/components/ui/flex"
import { Spacer } from "~/components/ui/spacer"
import { Button } from "~/components/ui/button"
import { clientOnly } from "@solidjs/start"
import {createEffect, on, Show, Suspense, lazy } from "solid-js";
import { useParams, useNavigate, useLocation} from "@solidjs/router"
import { isServer } from "solid-js/web"
import { ColorModeProvider, ColorModeScript, cookieStorageManagerSSR } from "@kobalte/core"
import { getCookie } from "vinxi/http"

import { useBuilder } from "~"
import TopAppbar from "./top-appbar"
import { routes } from "~/lib/utils"
import BuilderHome from "./builder/home"

export default clientOnly(async () => ({default: Home }), {lazy: true})

function getServerCookies() {
  "use server"
  const colorMode = getCookie("kb-color-mode")
  return colorMode ? `kb-color-mode=${colorMode}` : ""
}


function Home(props){
  const builder = useBuilder()
  const navigate = useNavigate()
  const location = useLocation() 
  const storageManager = cookieStorageManagerSSR(isServer ? getServerCookies() : document.cookie)
 
  const params = useParams();
  const isInBuilder = () => location.pathname.includes("builder/") 
  createEffect(() => {
     console.log("isInBuilder:", isInBuilder())
  }) 
   return (
     <div class="h-full overflow-clip bg-background"> 
       <ColorModeScript 
           storageType={storageManager.type}
       />
       <ColorModeProvider 
         storageManager={storageManager}
       >
 	       <Show when={!isInBuilder()}
             fallback={<BuilderHome {...props} />}
         > 
          <Box class="h-[100vh] overflow-auto bg-gradient-to-b from-background to-secondary/10">
 		         <Suspense fallback={
 		           <div class="flex items-center justify-center h-[calc(100vh-5rem)]">
 		           <div class="animate-pulse text-muted-foreground">Loading...</div>
 		           </div>
 		        }> 
 		           {props.children} 
 		         </Suspense> 
 	        </Box> 
         </Show> 
      </ColorModeProvider>
    </div> 
   )
}
      
