import { ReactiveElement, ReactiveSet, ReactiveMap} from "~";
import { Element } from "~/lib/types"

/* Deep clone and conversion */
export const elementToObject = (el: ReactiveElement): Element => {
  try { 

     const obj: Element = {
       id: el.id,	
       name: el.name, 
	     children: [], 
	     tailwind: el.tailwind,
     };
     el.attributes.forEach((value, name) => {
	      if(value  instanceof ReactiveElement){
  	      obj[name] = elementToObject(value);
        }else {
	        if(value === false || value === true) {      
	           value = String(value)
	        }  
	        obj[name] = value 
       } 
     })
     let child = el.firstChild;
     while (child != null) {
       obj.children.push(elementToObject(child)); 
       const nextSibling = child.nextSibling;
       child = nextSibling;
     }
     return obj
  }catch(error) {
	console.error("Conversion of element to object failed with error: ", error)
	return undefined 
  }
}

export const objectToElement = (obj: Element) => {
  try {  
    const el: ReactiveElement = new ReactiveElement(obj.name);
    el.id = obj.id 
    el.tailwind = obj.tailwind
    Object.entries(obj).forEach(([name, value]: any) => {
      if(typeof(value) === "string") {
	       value = value.replace(/"/g, "") 
	    }
	    if(value?.name && value?.id) {
          /* We checked for name and value to assert that it is an element type*/  
	         el.attributes.set(name, objectToElement(value as Element))
        }else { 
	        if(value === "false" || value === "true")  { 
	         value = value=="false"? false: true 
	        } 
	        el.attributes.set(name, value);
        }
      })
    const children = obj.children
    const length =  children.length
    if(length == 0) {
	      el.children = new ReactiveMap()
    }
    else {
      let index = 0;
      const lastIndex = length - 1; 
      let child: Element | null = children[index]
      
      /* Set the previous of child by accessing
       * previous works in target el container
       * Set nextSibling of Previous sibling to ~ current child,
       * That means, set next of current child to null, (as we will set
       * it in the next iteration) 
       * - This prevents need to recurse when setting the siblings, which 
       *   would be children x 3 , as we would do 3 times for every itteration
        
      */
      children.forEach((child, index, children) => {
       const childEl = objectToElement(child); 
       if(childEl) { 
	       childEl.parent = el; 
	       /* if no child in the target container, that means no prev */ 
	      if(el.children.size > 0) {
	        /* Given the ids does not change */ 
	        const previousSibling = el.children.get(children[index - 1].id)!
	        previousSibling.nextSibling = childEl;
	        childEl.previousSibling = previousSibling; 
	        childEl.nextSibling = null /* will be changed in the next child */ 
	      }else childEl.previousSibling = null;
	       /* Save using set, not the tracking methods liek el.append,
	        * to save computation 
	       */
	       el.children.set(childEl.id, childEl);
      } 
     })
    } 
    return el;
  }catch(error) {
     console.error("Conversion failed with error: ", error);
     //return new ReactiveElement("box"); 
  }
}


    
