#!/bin/bash
# Setup script for storefront storage directory

set -e

echo "Setting up storefront storage directory..."

# Configuration
STORE_DIR="/var/lib/entaprenua/stores"
USER="nesh"
GROUP="nesh"

# Create directory if it doesn't exist
echo "Creating directory: $STORE_DIR"
sudo mkdir -p "$STORE_DIR"

# Set ownership
echo "Setting ownership to $USER:$GROUP"
sudo chown -R "$USER:$GROUP" "$STORE_DIR"

# Set permissions (read/write/execute for owner and group)
echo "Setting permissions to 770"
sudo chmod -R 770 "$STORE_DIR"

echo "Done!"
echo ""
echo "Directory details:"
ls -la "$STORE_DIR"
