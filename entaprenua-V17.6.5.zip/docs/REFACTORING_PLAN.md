# Store & Template Routes Refactoring Plan

## Overview
Refactor the client-side store and template management to be production-ready with proper validation, error handling, and UX.

---

## 1. Enhanced Stores API (`src/lib/api/stores.ts`)

**Add:**
- `duplicate(id)` - Clone an existing store
- `publish(id)` - Publish store to domain
- `unpublish(id)` - Take store offline
- `getStats(id)` - Get store analytics/stats
- Domain validation endpoint

---

## 2. New Store Types (`src/lib/types/entities.ts`)

**Add interfaces:**
```typescript
interface StoreCreateRequest {
  name: string
  description?: string
  templateId?: string  // If creating from template
  domain?: string
}

interface StoreUpdateRequest extends Partial<Store> {}

interface StoreStats {
  totalProducts: number
  totalOrders: number
  totalRevenue: number
  totalCustomers: number
}
```

---

## 3. Stores List Page (`src/routes/stores/index.tsx`)

**Refactor:**
- Add search & filter (by status, date)
- Add bulk actions (delete, activate)
- Add store cards with quick stats
- Proper loading/error states
- Confirmation dialogs for destructive actions
- Real-time status updates

---

## 4. New Store Wizard (`src/routes/stores/new.tsx`)

**Refactor to multi-step wizard:**
1. **Choose Type** - Blank store vs From Template
2. **Store Details** - Name, description, category
3. **Domain Setup** - Custom domain or subdomain
4. **Review & Create**

**Add:**
- Real-time name validation (availability check)
- Domain validation
- Progress indicator
- Save draft functionality

---

## 5. Store Detail/Edit Page (`src/routes/stores/[id]/index.tsx`) - NEW

**Add:**
- Store settings (name, description, logo)
- Domain management
- Store status (active/inactive/maintenance)
- Delete store with confirmation
- Store preview

---

## 6. Templates Marketplace (`src/routes/templates/index.tsx`)

**Enhance:**
- Pagination instead of loading all
- Category filters (from server)
- Price range filter
- Server-side search
- Template cards with ratings, usage count

---

## 7. Template Detail Page (`src/routes/templates/[id].tsx`)

**Enhance:**
- Full template data from API
- Screenshot gallery
- Feature list from template metadata
- "Use Template" creates store from template
- "Buy Template" initiates payment flow

---

## 8. Template Developer Routes

Keep but enhance:
- `src/routes/templates/developer/index.tsx` - My templates
- `src/routes/templates/developer/new.tsx` - Create template
- `src/routes/templates/developer/[id]/pricing.tsx` - Set pricing

---

## 9. Reusable Components (new)

```
src/components/stores/
├── StoreCard.tsx        # Store display card
├── StoreForm.tsx        # Create/edit form
├── StoreStats.tsx       # Stats display
├── StoreStatusBadge.tsx # Status indicator
├── DomainSetup.tsx      # Domain configuration

src/components/templates/
├── TemplateCard.tsx
├── TemplateFilters.tsx
├── TemplateGallery.tsx
```

---

## 10. Routes Update (`src/lib/utils/routes.ts`)

```typescript
routes.stores              // "/stores"
routes.newStore            // "/stores/new"
routes.storeDetails(id)    // "/stores/:id"
routes.storeSettings(id)   // "/stores/:id/settings"
routes.storeBuild(id)      // "/stores/:id/build" (generate ZIP)

routes.templates           // "/templates"
routes.template(id)        // "/templates/:id"
routes.templateDeveloper   // "/templates/developer"
routes.newTemplate         // "/templates/developer/new"
```

---

## Summary of Changes

| File | Action |
|------|--------|
| `src/lib/api/stores.ts` | Extend with new methods |
| `src/lib/types/entities.ts` | Add store request types |
| `src/routes/stores/index.tsx` | Rewrite with full CRUD |
| `src/routes/stores/new.tsx` | Rewrite as wizard |
| `src/routes/stores/[id].tsx` | NEW - store detail page |
| `src/routes/templates/index.tsx` | Enhance with filters |
| `src/routes/templates/[id].tsx` | Enhance with full data |
| `src/components/stores/*.tsx` | NEW - reusable components |
| `src/components/templates/*.tsx` | NEW - reusable components |
| `src/lib/utils/routes.ts` | Update routes |

---

## 11. Build/Export System (`src/lib/api/builds.ts`)

**New API for store export:**
```typescript
// Export store as ZIP (SolidStart or NextJS)
GET /api/v1/builds/{storeId}?framework=solidstart|nextjs
Response: application/octet-stream (ZIP file download)

// Upload existing store ZIP
POST /api/v1/upload/store
- multipart/form-data with store files
- Auto-detects framework (NextJS: app/, SolidStart: src/routes/)
- Returns storeId, pagesCount, framework
```

**Supported Frameworks:**
| Framework | Folder Structure | Export | Upload |
|-----------|-----------------|--------|--------|
| SolidStart | `src/routes/` | ✅ | ✅ |
| NextJS | `app/` | ✅ | ✅ |

**Client Features:**
- Download store as ZIP (SolidStart/NextJS)
- Upload ZIP to import existing store
- Progress tracking for large uploads

---

## 12. Store Build Page (`src/routes/stores/[id]/build.tsx`) - NEW

- Select framework (SolidStart/NextJS)
- Preview generated files count
- Download ZIP button
- Upload ZIP to import store
- Build history/status

---

## Notes

- The server supports building/generating stores as ZIP files (see `docs/CMS_BUILDS_MODULE.md`)
- Templates can be marketplace items (free or paid)
- Stores can be published to custom domains
- Framework detection for upload is based on folder structure
