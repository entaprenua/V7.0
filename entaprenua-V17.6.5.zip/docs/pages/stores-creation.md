# Store Creation Flow Documentation

## Overview

The store creation flow allows users to create new stores either by:
1. Starting from a marketplace template
2. Cloning from their existing stores

This document describes the complete flow and architecture.

---

## User Flow Diagram

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         STORE CREATION FLOW                                  │
└─────────────────────────────────────────────────────────────────────────────┘

   ┌──────────────┐     ┌─────────────────┐     ┌──────────────────────────┐
   │  /stores    │────▶│  /stores/new   │────▶│  Step 1: Choose Source   │
   │  (List)     │     │  (Wizard)       │     │                          │
   └──────────────┘     └─────────────────┘     │  ┌────────────────────┐ │
                                                 │  │ Browse Templates  │ │
   [+ Create New Store]                          │  │ ────────────────  │ │
         │                                       │  │ [Browse → /templ]│ │
         ▼                                       │  └────────────────────┘ │
   ┌──────────────┐                              │                          │
   │  /stores/new │     ┌─────────────────┐     │  ┌────────────────────┐ │
   │  (Wizard)    │◀────│ ?templateId=xxx│     │  │ Clone from Stores │ │
   └──────────────┘     │ (pre-selected) │     │  │ ────────────────  │ │
                        └─────────────────┘     │  │ [List of user's  │ │
                                               │  │    stores]       │ │
                                               │  └────────────────────┘ │
                                               └──────────────────────────┘
                                                         │
                                                         ▼
                                            ┌──────────────────────────┐
                                            │  Step 2: Store Details   │
                                            │  ─────────────────────   │
                                            │  • Store Name           │
                                            │  • Description          │
                                            │  • Starting source      │
                                            └──────────────────────────┘
                                                         │
                                                         ▼
                                            ┌──────────────────────────┐
                                            │  Step 3: Domain Setup   │
                                            │  ─────────────────────   │
                                            │  • Subdomain            │
                                            │  • Custom Domain        │
                                            └──────────────────────────┘
                                                         │
                                                         ▼
                                            ┌──────────────────────────┐
                                            │  Step 4: Review & Create│
                                            └──────────────────────────┘
                                                         │
                                                         ▼
                                            ┌──────────────────────────┐
                                            │  /stores/:id/build      │
                                            │  (Builder)              │
                                            └──────────────────────────┘
```

---

## Routes

| Route | File | Description |
|-------|------|-------------|
| `/stores` | `routes/stores/index.tsx` | List of user's stores |
| `/stores/new` | `routes/stores/new.tsx` | Store creation wizard |
| `/stores/new?templateId=xxx` | `routes/stores/new.tsx` | Pre-selected template |
| `/templates` | `routes/templates/index.tsx` | Template marketplace |
| `/templates/:id` | `routes/templates/[id].tsx` | Template detail page |

---

## Step-by-Step Flow

### Step 1: Choose Starting Point

**User Options:**

1. **Browse Templates**
   - Click "Browse Templates" button
   - Navigates to `/templates` marketplace
   - User browses and selects a template
   - Clicks "Use Template"
   - Redirects to `/stores/new?templateId={template_id}`
   - Template is pre-selected in the wizard

2. **Clone from Your Stores**
   - Shows list of user's existing stores
   - Uses `createResource` to fetch stores lazily
   - Select a store to clone
   - Continue to next step

**Code Location:** `src/routes/stores/new.tsx` - Step 1 UI

```tsx
// Fetch user's stores only when clone option is selected
const [myStores] = createResource(
  () => storeType() === "clone",
  async (shouldFetch) => {
    if (!shouldFetch) return []
    const response = await storesApi.getAll({ size: 50 })
    return response.content || []
  }
)
```

### Step 2: Store Details

- Enter store name (with availability validation)
- Enter description
- Display selected source (template or cloned store)

### Step 3: Domain Setup

- Choose subdomain (e.g., `mystore.entaprenua.com`)
- OR choose custom domain

### Step 4: Review & Create

- Review all selections
- Click "Create Store"
- Navigate to builder at `/stores/:id/build`

---

## Template Marketplace Flow

```
┌─────────────────────────────────────────────────────────────────┐
│                    TEMPLATE MARKETPLACE                          │
└─────────────────────────────────────────────────────────────────┘

   ┌──────────────┐
   │  /templates  │
   │  (Browse)    │
   └──────────────┘
         │
         ▼
   ┌──────────────┐     ┌─────────────────┐
   │  Filter by   │────▶│  Search         │
   │  Category    │     │  & Sort         │
   └──────────────┘     └─────────────────┘
         │
         ▼
   ┌──────────────┐
   │  Template    │
   │  Card        │
   └──────────────┘
         │
         ▼         ┌─────────────────┐
   ┌──────────────┐     │  Preview       │
   │  /templates/ │────▶│  Template     │
   │  :id         │     │  Details      │
   └──────────────┘     └─────────────────┘
         │
         ▼
   ┌──────────────┐
   │  "Use        │────▶  /stores/new?templateId=xxx
   │   Template"  │
   └──────────────┘
```

---

## Key Features

### 1. URL Parameter Support

The store creation page accepts a `templateId` query parameter:

```tsx
// From templates/[id].tsx
const handleUseTemplate = () => {
  navigate(`${routes.newStore}?templateId=${template()?.id}`)
}

// In stores/new.tsx
const [searchParams] = useSearchParams<{ templateId?: string }>()

onMount(() => {
  if (searchParams.templateId) {
    setSelectedTemplate(searchParams.templateId)
    setStoreType("template")
  }
})
```

### 2. Lazy Loading of User Stores

Stores are only fetched when the user chooses to clone:

```tsx
const [myStores] = createResource(
  () => storeType() === "clone",  // Only fetch when clone is selected
  async (shouldFetch) => {
    if (!shouldFetch) return []
    const response = await storesApi.getAll({ size: 50 })
    return response.content || []
  }
)
```

### 3. Name Availability Check

Real-time store name validation:

```tsx
const handleNameChange = (value: string) => {
  setName(value)
  setNameAvailable(null)
  
  // Debounce API call
  nameCheckTimeout = setTimeout(async () => {
    const result = await storesApi.validateName(value)
    setNameAvailable(result.data?.available)
  }, 500)
}
```

---

## State Management

### Store Creation Wizard State

```tsx
const [currentStep, setCurrentStep] = createSignal(1)
const [storeType, setStoreType] = createSignal<StoreType>("clone")
const [selectedTemplate, setSelectedTemplate] = createSignal<string | null>(null)
const [cloneFromStoreId, setCloneFromStoreId] = createSignal<string | null>(null)
const [name, setName] = createSignal("")
const [description, setDescription] = createSignal("")
const [domainType, setDomainType] = createSignal<"subdomain" | "custom">("subdomain")
const [subdomain, setSubdomain] = createSignal("")
const [customDomain, setCustomDomain] = createSignal("")
const [nameAvailable, setNameAvailable] = createSignal<boolean | null>(null)
```

### Step Validation

```tsx
const isStep1Valid = () => {
  if (storeType() === "clone") {
    return cloneFromStoreId() !== null
  }
  return selectedTemplate() !== null
}

const isStep2Valid = () => name().trim().length >= 3 && nameAvailable() !== false

const isStep3Valid = () => {
  if (domainType() === "subdomain") {
    return subdomain().trim().length >= 3
  }
  return customDomain().trim().length >= 3
}
```

---

## API Integration

### Creating a Store

```tsx
const handleSubmit = async () => {
  const storeData = {
    name: name(),
    description: description() || undefined,
    visibility: "private",
  }

  // Set template source
  if (storeType() === "clone" && cloneFromStoreId()) {
    storeData.templateId = cloneFromStoreId()
  } else if (storeType() === "template" && selectedTemplate()) {
    storeData.templateId = selectedTemplate()
  }

  // Set domain
  if (domainType() === "subdomain") {
    storeData.subdomain = subdomain().toLowerCase()
  } else {
    storeData.domain = customDomain().toLowerCase()
  }

  const result = await storesApi.create(storeData)
  
  if (result.success) {
    navigate(routes.storeBuild(result.data.id))
  }
}
```

### Relevant API Methods

```tsx
// storesApi
getAll(params)           // Fetch user's stores for cloning
validateName(name)       // Check name availability  
create(data)            // Create new store
createFromTemplate(id)  // Legacy - now redirects to create

// Template API
getTemplates(params)     // Fetch marketplace templates
getTemplateById(id)     // Get single template
```

---

## Unified Store Concept

In this implementation, **templates are just stores** with a special flag:

```tsx
interface Store {
  id: string
  name: string
  description?: string
  is_template?: boolean  // If true, this is a sellable template
  visibility?: 'public' | 'private' | 'unlisted'
  price?: number         // Template price (if for sale)
  // ... other fields
}
```

- **Regular Store**: `is_template = false`, `visibility = private`
- **Template in Marketplace**: `is_template = true`, `visibility = public`

This simplifies the architecture - there's no separate "template" entity, just stores that can be marked as sellable.

---

## Future Enhancements

1. **Sell as Template Option** - Add option in store settings to publish as template
2. **Template Pricing** - Set price when publishing as template
3. **Template Categories** - Organize marketplace by category
4. **Template Ratings** - User reviews on templates
5. **Template Updates** - Handle template updates for cloned stores
6. **Search Persistence** - Remember search params in URL

---

## Changelog

### v1.1.0 (2026-02-25)
- Unified store/template concept (no separate template creation)
- Added "Clone from Your Stores" in wizard
- Template marketplace redirects to store creation with pre-selected template
- Lazy loading of user stores in clone step
- URL parameter support for template pre-selection

### v1.0.0 (2026-02-21)
- Initial implementation
- Separate template developer flow
- Basic store creation wizard
