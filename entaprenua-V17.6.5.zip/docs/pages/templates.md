# Templates Page Documentation

## Overview

The Templates page (`src/routes/templates/index.tsx`) is the marketplace where users browse and purchase store templates. It displays a gallery of pre-built stores and starting-point templates available for use.

## Architecture

### Page Structure

```
TemplatesPage
├── HeroSection
│   ├── Badge (Template Marketplace)
│   ├── Heading (Choose Your Perfect Store Template)
│   ├── Description
│   └── Stats (Templates, Components, Stores, Rating)
├── FeatureGrid
│   ├── Drag & Drop Builder
│   ├── E-Commerce Ready
│   ├── One-Click Export
│   └── Mobile Responsive
├── FilterSection
│   ├── SearchInput
│   ├── SortSelect
│   └── CategoryButtons (All, E-Commerce, Portfolio, Blog, Business, Landing)
├── TemplateGrid
│   └── TemplateCard[] (with Preview, Price, Actions)
└── CTASection (Contact Sales)
```

### Data Flow

```
storesApi.getTemplates()
    ↓
templates[] (reactive signal)
    ↓
filteredTemplates() (computed - search, sort, category)
    ↓
TemplateCard[] (rendered)
```

## Components

### TemplateCard

Displays a single template with preview, details, and actions.

```tsx
type TemplateCardProps = {
  template: {
    id: string
    name: string
    description?: string
    price?: number | null
    logo?: string
  }
}
```

**Features:**
- Aspect ratio 4:3 preview image with hover zoom
- Price badge (Free or $XX.XX)
- Preview button → `/templates/[id]`
- "Use Free" / "Buy Now" action buttons
- Fallback icon for missing logo

### TemplateFilters

Search, sort, and category filtering controls.

```tsx
type TemplateFiltersProps = {
  selectedCategory: string
  onSelectCategory: (id: string) => void
  searchQuery: string
  onSearchChange: (query: string) => void
  sortBy: string
  onSortChange: (sort: string) => void
}
```

**Categories:**
| ID | Label |
|----|-------|
| all | All Templates |
| ecommerce | E-Commerce |
| portfolio | Portfolio |
| blog | Blog |
| business | Business |
| landing | Landing Page |

**Sort Options:**
- `newest` - Newest first
- `price-low` - Price: Low to High
- `price-high` - Price: High to Low
- `name` - Alphabetical

### Stats

Displays marketplace metrics.

```tsx
function Stats() {
  // 50+ Templates
  // 100+ Components
  // 10K+ Stores Created
  // 4.9 Average Rating
}
```

### FeatureGrid

Highlights template benefits.

```tsx
const features = [
  { icon: LayoutTemplateIcon, title: "Drag & Drop Builder", description: "..." },
  { icon: StoreIcon, title: "E-Commerce Ready", description: "..." },
  { icon: DownloadIcon, title: "One-Click Export", description: "..." },
  { icon: CheckIcon, title: "Mobile Responsive", description: "..." },
]
```

## API Integration

### Fetching Templates

```tsx
import { storesApi } from "~/lib/api"

const response = await storesApi.getTemplates()
// Returns: { content: Store[], totalElements, totalPages, ... }
```

### Template Preview Images

```tsx
const TEMPLATE_PREVIEWS: Record<string, string> = {
  default: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=800&h=600&fit=crop",
}
```

Uses a default placeholder for all templates. In production, each template would have its own preview URL stored in the database.

## Filtering Logic

```tsx
const filteredTemplates = () => {
  let result = templates()

  // 1. Search filter
  if (searchQuery()) {
    const query = searchQuery().toLowerCase()
    result = result.filter(
      (t) => t.name?.toLowerCase().includes(query) ||
             t.description?.toLowerCase().includes(query)
    )
  }

  // 2. Sort
  if (sortBy() === "price-low") {
    result = [...result].sort((a, b) => (a.price || 0) - (b.price || 0))
  } else if (sortBy() === "price-high") {
    result = [...result].sort((a, b) => (b.price || 0) - (a.price || 0))
  } else if (sortBy() === "name") {
    result = [...result].sort((a, b) => a.name.localeCompare(b.name))
  } else {
    // newest - default
    result = [...result].sort(
      (a, b) => new Date(b.insertedAt || 0).getTime() - new Date(a.insertedAt || 0).getTime()
    )
  }

  return result
}
```

## State Management

```tsx
const [templates, setTemplates] = createSignal<any[]>([])
const [isLoading, setIsLoading] = createSignal(true)
const [selectedCategory, setSelectedCategory] = createSignal("all")
const [searchQuery, setSearchQuery] = createSignal("")
const [sortBy, setSortBy] = createSignal("newest")
const [error, setError] = createSignal<string | null>(null)
```

## Routing

| Route | File | Description |
|-------|------|-------------|
| `/templates` | `templates/index.tsx` | Template marketplace listing |
| `/templates/:id` | `templates/[id].tsx` | Individual template preview |

## Dependencies

```tsx
// Core
import { createSignal, onMount, For, Show } from "solid-js"
import { A } from "@solidjs/router"

// UI Components
import { Card, CardContent, CardFooter } from "~/components/ui/card"
import { Button } from "~/components/ui/button"
import { Flex, Grid, Badge, Text, Heading } from "~/components/ui"

// API
import { storesApi } from "~/lib/api"

// Icons (lucide-solid)
import StarIcon from "lucide-solid/icons/star"
import SearchIcon from "lucide-solid/icons/search"
import EyeIcon from "lucide-solid/icons/eye"
import DownloadIcon from "lucide-solid/icons/download"
import ShoppingCartIcon from "lucide-solid/icons/shopping-cart"
import LayoutTemplateIcon from "lucide-solid/icons/layout-template"
import StoreIcon from "lucide-solid/icons/store"
import CheckIcon from "lucide-solid/icons/check"
```

## Usage Patterns

### Basic Template Grid

```tsx
<Grid cols={1} colsSm={2} colsLg={3} colsXl={4} class="gap-6">
  <For each={filteredTemplates()}>
    {(template) => <TemplateCard template={template} />}
  </For>
</Grid>
```

### With Loading State

```tsx
<Show when={isLoading()}>
  <Grid cols={1} colsSm={2} colsLg={3} colsXl={4} class="gap-6">
    <For each={[1, 2, 3, 4, 5, 6, 7, 8]}>
      {() => (
        <Card class="overflow-hidden">
          <div class="aspect-[4/3] bg-muted animate-pulse" />
          <CardContent class="p-4">
            <div class="h-4 bg-muted rounded w-3/4 mb-2 animate-pulse" />
            <div class="h-3 bg-muted rounded w-1/2 animate-pulse" />
          </CardContent>
        </Card>
      )}
    </For>
  </Grid>
</Show>
```

### Empty State

```tsx
<Show when={!isLoading() && filteredTemplates().length === 0}>
  <Flex class="flex-col items-center justify-center py-16 text-center">
    <LayoutTemplateIcon class="size-16 text-muted-foreground mb-4" />
    <Heading level={4} class="mb-2">No Templates Found</Heading>
    <Text class="text-muted-foreground mb-4">
      Try adjusting your search or filters
    </Text>
    <Button variant="outline" onClick={() => { 
      setSearchQuery(""); 
      setSelectedCategory("all") 
    }}>
      Clear Filters
    </Button>
  </Flex>
</Show>
```

## Responsive Breakpoints

| Breakpoint | Grid Columns | Layout |
|------------|--------------|--------|
| default | 1 | Single column |
| sm | 2 | 2 columns |
| lg | 3 | 3 columns |
| xl | 4 | 4 columns |

## Accessibility

- Semantic `<section>`, `<nav>`, `<header>`, `<footer>` elements
- Proper heading hierarchy (h1 → h2 → h3)
- Alt text for template preview images
- Keyboard navigable filter buttons
- ARIA labels where needed
- Focus states on interactive elements

## Error Handling

```tsx
<Show when={error()}>
  <div class="mt-8 p-4 rounded-lg bg-destructive/10 text-destructive text-center">
    {error()}
  </div>
</Show>
```

## Future Enhancements

1. **Category Filtering** - Implement actual category filtering (currently UI only)
2. **Template Previews** - Individual preview images per template
3. **Favorites** - Save favorite templates
4. **Ratings & Reviews** - User reviews on templates
5. **Search Suggestions** - Autocomplete in search
6. **Infinite Scroll** - Load more templates on scroll
7. **Filter Persistence** - Remember filter selections
8. **Template Comparison** - Compare multiple templates side-by-side

## Testing

### Unit Tests (Recommended)

```tsx
describe("TemplateFilters", () => {
  it("filters templates by search query", () => {
    render(() => (
      <TemplateFilters
        searchQuery="ecommerce"
        onSearchChange={setSearchQuery}
        selectedCategory="all"
        onSelectCategory={() => {}}
        sortBy="newest"
        onSortChange={() => {}}
      />
    ))
    // Test search filtering
  })

  it("sorts templates by price", () => {
    // Test price sorting
  })
})

describe("TemplateCard", () => {
  it("shows Free badge for free templates", () => {
    render(() => <TemplateCard template={{ name: "Test", price: 0 }} />)
    expect(screen.getByText("Free")).toBeInTheDocument()
  })

  it("shows price for paid templates", () => {
    render(() => <TemplateCard template={{ name: "Test", price: 49.99 }} />)
    expect(screen.getByText("$49.99")).toBeInTheDocument()
  })
})
```

### E2E Tests (Recommended)

```tsx
test("templates page loads and displays templates", async ({ page }) => {
  await page.goto("/templates")
  await expect(page.getByText("Choose Your Perfect Store Template")).toBeVisible()
  await expect(page.getByText("Templates")).toBeVisible()
})

test("search filters templates", async ({ page }) => {
  await page.goto("/templates")
  await page.fill('input[placeholder="Search templates..."]', "store")
  // Verify filtered results
})

test("template preview navigation", async ({ page }) => {
  await page.goto("/templates")
  await page.click('a[href="/templates/1"]')
  await expect(page).toHaveURL(/\/templates\/\w+/)
})
```

## Changelog

### v1.0.0 (2026-02-21)
- Initial implementation
- Template grid with cards
- Search and sort functionality
- Category filter buttons
- Loading and empty states
- Stats and feature sections
- Responsive grid layout

---

## Template Developer Section

For developers who want to create and sell templates, see [Template Developer Documentation](./templates-developer.md).

### Quick Links

| Route | Description |
|-------|-------------|
| `/templates/developer` | Manage your templates |
| `/templates/developer/new` | Create new template |
| `/templates/developer/:id/pricing` | Set template pricing |
