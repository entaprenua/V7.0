# Component Registry Refactoring Plan

## Overview

Refactor the component registry to use actual component props from `builder/components/*` and add camel-to-kebab conversion for DOM attributes.

## Current Issues

1. **Naming mismatch**: Registry uses kebab-case, but UI components expect camelCase props
2. **Missing conversion**: Attributes are stored but not passed to components as props
3. **Orphaned components**: Some components in registry don't exist in builder/components/
4. **Limited attribute types**: Only supports string, number, boolean, enum arrays

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                        USER EDIT                             │
│  Inspector shows "close-on-escape-key-down" (kebab)        │
└─────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│              Inspector.setAttribute()                        │
│  kebabToCamel("close-on-escape-key-down")                │
│  → setAttribute("closeOnEscapeKeyDown", "true")            │
└─────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│              ReactiveElement (camel)                        │
│  Stores: { "closeOnEscapeKeyDown": "true" }               │
└─────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│                   computeProps                              │
│  Returns attributes directly (no conversion needed)        │
└─────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│                   UI Component                              │
│  Receives camelCase props: closeOnEscapeKeyDown={true}   │
└─────────────────────────────────────────────────────────────┘
```

## Implementation Steps

### Step 1: Keep Registry as kebab-case (no changes needed)

The registry already uses kebab-case which matches HTML/DOM conventions.

```typescript
// Before (kebab)
dialog: {
  attributes: {
    "close-on-escape-key-down": "boolean",
    "force-mount": "boolean",
  }
}

// After (camel)
dialog: {
  attributes: {
    closeOnEscapeKeyDown: { type: "boolean", default: true },
    forceMount: { type: "boolean", default: false },
  }
}
```

### Step 2: Update Inspector to Convert kebab → camel

Update `ComponentAttributes.tsx` to convert kebab to camel when setting attributes:

```typescript
// Helper: kebab-case to camelCase
const kebabToCamel = (str: string) => 
  str.replace(/-([a-z])/g, (_, c) => c.toUpperCase());

const setAttributeValue = (attrName: string, value: string) => {
  // Convert kebab to camel for component props
  const camelKey = kebabToCamel(attrName)
  selected()?.setAttribute(camelKey, value);
}
```

Note: No changes needed in computeProps - components receive camelCase directly via spread.

### Step 4: Update Inspector Rendering

Update `ComponentAttributes.tsx` to:
1. Read camelCase attributes from registry
2. Display camelCase names in UI
3. Convert to kebab when setting attributes

### Step 5: Clean Up Orphaned Components

Remove from registry any components not exported in `builder/components/*`:

| Exists in builder/components | In Registry |
|----------------------------|-------------|
| Button | button ✅ |
| Input | input ❌ (missing) |
| Dialog | dialog ✅ |
| Text | text ✅ |
| Badge | badge ✅ |
| Card | card ❌ (missing) |
| Flex | flex ✅ |
| Grid | grid ✅ |
| Sidebar | sidebar ❌ |
| Popover | popover ❌ |
| NavigationMenu | navigation-menu ❌ |
| DropdownMenu | dropdown-menu ❌ |

## Components to Add to Registry

From `builder/components/*`:

| Category | Components |
|---------|------------|
| **input** | Button, Input |
| **layout** | Box, Flex, Grid |
| **data-display** | Text, Badge, Separator, Image, Avatar, AspectRatio, Video, Audio, Carousel, Search |
| **surface** | Card, Accordion, Collapsible |
| **feedback** | Alert, AlertDialog, Dialog, Callout, Tooltip, Skeleton |
| **navigation** | Sidebar, DropdownMenu, NavigationMenu, Popover |
| **utilities** | Switch |

## New Attribute Schema Example

```typescript
// Example: Dialog component
dialog: {
  attributes: {
    modal: { 
      type: "boolean", 
      default: true, 
      description: "Show backdrop overlay" 
    },
    open: { 
      type: "boolean", 
      default: false 
    },
    defaultOpen: { 
      type: "boolean", 
      default: false 
    },
    onOpenChange: { 
      type: "event", 
      description: "Callback when open state changes" 
    },
  },
  contextuals: {
    "dialogTrigger": {},
    "dialogContent": {
      contextuals: {
        "dialogHeader": {
          contextuals: {
            "dialogTitle": {},
            "dialogDescription": {},
          }
        },
        "dialogFooter": {},
        "dialogCloseButton": {},
      }
    },
  }
}
```

## Files Modified

| File | Changes |
|------|---------|
| `builder/inspector/ComponentAttributes.tsx` | ✅ Added kebabToCamel conversion for setAttribute/getAttribute |
| `builder/utils/component-registry.ts` | Keep kebab (no changes needed) |
| `builder/canvas/utils/computeProps.ts` | No changes needed |

## Benefits

1. **Type safety**: Registry matches actual component props
2. **Better DX**: Descriptions, defaults, validation
3. **Performance**: Conversion only happens in computeProps (once per render)
4. **Maintainability**: Single source of truth for component API
5. **Clean**: Only actual components in registry
