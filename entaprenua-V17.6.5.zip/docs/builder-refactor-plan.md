# Builder Refactoring Implementation Plan

## Current State Analysis

### Directory Structure
```
src/builder/
├── core/                    # Core builder logic
│   ├── ReactiveElement.ts   # Element model
│   ├── ReactiveRouter.ts    # Router model
│   ├── DragAndDrop.ts       # Drag and drop logic
│   ├── Selection.ts        # Selection management
│   ├── Clipboard.ts        # Clipboard operations
│   ├── Container.ts        # Container logic
│   ├── Record.ts           # Record/history
│   ├── cloneElement.ts     # Element cloning
│   └── primitives/         # Reactive primitives
│       ├── Node.ts
│       ├── ReactiveMap.ts
│       └── ReactiveSet.ts
├── body/                   # Rendering layer
│   ├── content/           # Component rendering
│   │   ├── input/         # Form inputs
│   │   ├── navigation/    # Navigation components
│   │   ├── data-display/  # Display components
│   │   ├── feedback/      # Feedback components
│   │   ├── surface/       # Surface components
│   │   ├── layout/        # Layout components
│   │   └── utils/         # Utility components
│   └── pages/             # Page rendering
├── utils/                 # Utilities
│   ├── ui/                # UI controls for properties panel
│   ├── component.ts       # Component config hook
│   ├── component-registry.ts  # Component definitions
│   ├── isInsertable.ts   # Insert validation
│   └── ...
├── panels/                # Side panels
├── menubar/              # Top menu bar
├── types/                # Type definitions
└── index.tsx            # Main exports
```

### Issues Identified

1. **Broken Imports**: Many files reference deleted/non-existent modules
2. **Duplicate Files**: `comp.ts` (duplicate of component.ts logic)
3. **Missing Components**: No `Divider`, `Row`, `TextButton` in UI lib
4. **Type Errors**: `~` alias not resolving in tooling
5. **Inconsistent Naming**: Mixed conventions

---

## Implementation Plan

### Phase 1: Fix Core Infrastructure

1. **Create comprehensive types** (`types/index.ts`)
   - Builder types
   - Element types
   - Config types

2. **Consolidate component registry**
   - Keep `component-registry.ts` as single source of truth
   - Export from single index

### Phase 2: Fix Utils

3. **Consolidate utils**
   - `component.ts` - keep as main hook
   - `isInsertable.ts` - simplify
   - Remove duplicates

4. **Fix utils/ui/**
   - Replace non-existent UI components (Row → Flex, HorizontalDivider → Separator, TextButton → Button)
   - Fix imports
   - Consolidate contexts

### Phase 3: Fix Core Modules

5. **Fix ReactiveElement.ts**
   - Fix imports
   - Clean up logic

6. **Fix DragAndDrop.ts**
   - Fix imports

### Phase 4: Fix Panels & Menubar

7. **Fix panels imports**
8. **Fix menubar imports**

### Phase 5: Clean Up

9. **Delete obsolete files**
   - `robotasks.md`
   - Any other orphans

10. **Update main exports** (`index.tsx`)

---

## Files to Delete
- `robotasks.md` - documentation file
- Check for any other orphans

## Files to Modify
All files with broken imports

## Success Criteria
- All imports resolve correctly
- No duplicate functionality
- Clear, consistent naming
- Production-ready code structure
