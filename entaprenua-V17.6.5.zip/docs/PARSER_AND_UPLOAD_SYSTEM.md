# Parser & Upload System Implementation

## Overview

This document describes the complete implementation of:
1. JSX Parser - validates and parses JSX components against the registry
2. Upload API - handles ZIP files and individual page files
3. Upload UI - dedicated pages for uploading codebases

---

## Part 1: Parser System

### Files Created/Modified

| File | Description |
|------|-------------|
| `src/lib/server/parser/index.ts` | JSX parser using TypeScript AST |
| `src/routes/api/parse/index.ts` | Parser API endpoint |
| `src/builder/utils/component-registry.ts` | Single source of truth for allowed components |

### Features

- **Case-insensitive matching**: `dialogTrigger`, `DialogTrigger`, `DIALOGTRIGGER` all resolve to `dialogTrigger`
- **Flattened attributes**: `{ name: "box", id: "..." }` instead of nested `{ name: "box", attributes: { id: "..." } }`
- **Unknown components**: Returns user's original name (not normalized) so renderer can show "Unknown: ComponentName"
- **HTML tags support**: h1-h6, p, span, div, etc. mapped to Text/Box components
- **Contextual components**: dialogTrigger, cardHeader, navbarBrand, etc.

### Parser API

**Endpoint:** `POST /api/parse`

```bash
curl -X POST http://localhost:3000/api/parse \
  -H "Content-Type: application/json" \
  -d '{"code":"<Box>Hello</Box>"}'
```

**Response:**
```typescript
// Success
{ success: true, data: { name: "box", id: "...", children: [...] }, warnings: [] }

// Unknown component (with warning)
{ success: true, data: { name: "CustomComponent", ... }, warnings: [{ message: "Unsupported component: CustomComponent" }] }
```

---

## Part 2: Upload Service

### Files Created/Modified

| File | Description |
|------|-------------|
| `src/lib/server/upload.ts` | Upload service with ZIP extraction and parsing |
| `src/routes/api/stores/import.ts` | Import new store + upload |
| `src/routes/api/stores/[id]/import/index.ts` | Import to existing store |
| `src/lib/api/stores.ts` | API client methods |

### Features

- **ZIP extraction**: Uses `adm-zip` to extract and process ZIP files
- **Route file detection**: Finds `.tsx/.jsx` files in `src/routes/`
- **Parser integration**: Uses the JSX parser to parse uploaded files
- **Fallback handling**: On parse failure, stores original content for debugging
- **Merge behavior**: Adds pages to existing store without deleting

### API Endpoints

#### POST /api/stores/import
Create new store and import codebase.

```bash
curl -X POST http://localhost:3000/api/stores/import \
  -F "name=My Store" \
  -F "description=My store description" \
  -F "file=@codebase.zip"
```

#### POST /api/stores/:id/import
Add pages to existing store.

```bash
curl -X POST http://localhost:3000/api/stores/store-123/import \
  -F "file=@page.tsx"
```

---

## Part 3: Upload UI

### Files Created/Modified

| File | Description |
|------|-------------|
| `src/routes/stores/[id]/upload/index.tsx` | Upload page for existing stores |
| `src/routes/stores/new/upload/index.tsx` | Upload page for new stores |
| `src/lib/utils/routes.ts` | Added `storeUpload` and `newStoreUpload` routes |

### Upload Flow

#### Existing Store (`/stores/:id/upload`)
1. Upload ZIP or .tsx/.jsx files
2. Preview files and edit page names/slugs
3. Click "Add Pages" to import

#### New Store (`/stores/new/upload`)
1. Upload ZIP or .tsx/.jsx files (Step 1)
2. Fill store details (Step 2)
3. Click "Create Store"

### Features

- **Drag and drop**: Drop files directly on the page
- **Multiple file types**: ZIP (codebase), .tsx, .jsx (page files)
- **File preview**: Shows selected files with editable name/slug
- **Status tracking**: Shows pending/uploading/done/error per file
- **Progress indicator**: Visual progress bar during upload

### Routes Added

```typescript
routes.storeUpload(id)        // /stores/:id/upload
routes.newStoreUpload        // /stores/new/upload
```

---

## Component Registry Integration

### Files Modified

| File | Changes |
|------|---------|
| `src/builder/utils/component-registry.ts` | Added HTML tags, `ALLOWED_COMPONENTS` Set, `COMPONENT_NAME_MAP` |

### Registry Structure

```typescript
componentRegistry = {
  // Top-level components
  box: { component: Box },
  button: { component: Button },
  dialog: { component: Dialog, contextuals: {...} },
  
  // Contextual/child components (nested)
  dialogTrigger: { component: DialogTrigger },
  dialogContent: { component: DialogContent },
  
  // HTML tags
  h1: { component: Text, variant: 'h1' },
  div: { component: Box },
}
```

### Derived Exports

```typescript
// All component names (for parser validation)
ALLOWED_COMPONENTS: Set<string>

// Case-insensitive lookup (for parser)
COMPONENT_NAME_MAP: Map<string, string>

// Component map (for renderer)
componentMap: Record<string, Component>
```

---

## Links from Store Pages

### Build Page (`/stores/:id/build`)
Quick Actions section now includes "Upload Code" button.

### Store Details Page (`/stores/:id`)
Quick Actions section now includes "Upload Code" button.

### New Store Page (`/stores/new`)
Step 1 now includes "Upload Your Code" option.

---

## Dependencies Added

| Package | Purpose |
|---------|---------|
| `adm-zip` | ZIP file extraction |

---

## Validation Checklist

- [x] Parser validates against registry
- [x] Parser handles case-insensitive component names
- [x] Parser returns flattened attributes
- [x] Parser handles unknown components gracefully
- [x] Upload accepts ZIP files
- [x] Upload accepts .tsx/.jsx files
- [x] Upload extracts ZIP contents
- [x] Upload parses TSX files using parser
- [x] Upload creates new store with pages
- [x] Upload adds pages to existing store
- [x] UI shows drag and drop
- [x] UI shows file preview with editable names
- [x] UI shows progress indicator
- [x] Links added to build page
- [x] Links added to store details page
- [x] Links added to new store page

---

## Future Improvements

### Phase 1: Basic
- [ ] Parallel parsing for multiple files
- [ ] File filtering (skip node_modules, .git)
- [ ] Larger file size limits

### Phase 2: Incremental Uploads
- [ ] File hash tracking for change detection
- [ ] Skip unchanged files on re-upload
- [ ] Database schema for file hashes

### Phase 3: Production
- [ ] Rate limiting
- [ ] Background job processing for large uploads
- [ ] Progress streaming to client
- [ ] Web Workers for parsing
