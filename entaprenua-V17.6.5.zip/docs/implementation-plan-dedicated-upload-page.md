# Dedicated Store Upload Page Implementation Plan

## Overview
Create a dedicated page for uploading codebases to existing stores with drag-and-drop support, ZIP extraction, and progress tracking.

---

## Files to Create/Modify

### 1. New Route: `src/routes/stores/[id]/upload/index.tsx`
Dedicated upload page with:
- Large drag-and-drop zone
- ZIP file support
- Progress indicator
- File list showing import status

### 2. Modify: `src/routes/api/stores/[id]/import.ts`
New endpoint for importing to existing store:
- Accept ZIP file
- Extract and process
- Return progress/status

### 3. Modify: `src/lib/server/upload.ts`
Add ZIP extraction support:
- Use ZIP library (fflate or jszip)
- Find all .tsx/.jsx in src/routes/
- Parse each file
- Save to existing store (merge behavior)

### 4. Modify: API Client
Add API method for store import:
- `storesApi.importCodebase(storeId, formData, onProgress)`

---

## UI/UX Design

### Page Layout
```
┌─────────────────────────────────────────────────┐
│ ← Back                    Upload Code           │
├─────────────────────────────────────────────────┤
│                                                 │
│  ┌─────────────────────────────────────────┐  │
│  │         Drag & Drop Zone                 │  │
│  │                                         │  │
│  │     📁 Drop ZIP file here               │  │
│  │     or click to browse                  │  │
│  │                                         │  │
│  │  Supported: SolidStart (src/routes/)    │  │
│  └─────────────────────────────────────────┘  │
│                                                 │
│  ┌─────────────────────────────────────────┐  │
│  │ Files to import:                         │  │
│  │ ✓ src/routes/index.tsx        [OK]      │  │
│  │ ✓ src/routes/about/page.tsx   [OK]      │  │
│  │ ✓ src/routes/shop/page.tsx   [OK]      │  │
│  └─────────────────────────────────────────┘  │
│                                                 │
│  ┌─────────────────────────────────────────┐  │
│  │ ████████████░░░░░░░░░░  45%            │  │
│  │ Parsing files...                        │  │
│  └─────────────────────────────────────────┘  │
│                                                 │
│  [Cancel]                      [Import]        │
│                                                 │
└─────────────────────────────────────────────────┘
```

### Components
- **Dropzone:** Large, obvious drag area using FileFieldDropzone
- **File List:** Show each file with status (pending/processing/done/error)
- **Progress Bar:** Overall progress with stage message

---

## API Design

### Endpoint: POST /api/stores/:id/import

**Request:**
```
Content-Type: multipart/form-data
Body:
  - file: ZIP file
```

**Response (streaming):**
```typescript
// Progress events
{ stage: "extracting", progress: 10, message: "Extracting ZIP..." }
{ stage: "scanning", progress: 20, message: "Scanning for files..." }
{ stage: "parsing", progress: 30, message: "Parsing 5 files..." }
{ stage: "saving", progress: 80, message: "Saving to database..." }
{ stage: "complete", progress: 100, message: "Import complete!", pagesCreated: 5 }
{ stage: "error", progress: 0, error: "Failed to parse file X" }
```

---

## Implementation Steps

### Step 1: Create Upload Page
- Create `src/routes/stores/[id]/upload/index.tsx`
- Add drag-and-drop UI
- Add file list display
- Add progress indicator

### Step 2: Create API Endpoint
- Create `src/routes/api/stores/[id]/import/index.ts`
- Accept ZIP file
- Stream progress back to client

### Step 3: Add ZIP Extraction
- Install ZIP library (fflate - smaller)
- Extract ZIP to temp
- Find .tsx/.jsx files

### Step 4: Update Upload Service
- Add ZIP handling in `upload.ts`
- Support merge behavior (add pages to existing store)

### Step 5: Update API Client
- Add `storesApi.importCodebase()` method

---

## Dependencies
- ZIP library: `fflate` (small, fast) or `jszip`

---

## Validation Checklist

- [ ] Upload page renders correctly
- [ ] Drag and drop works
- [ ] File picker works
- [ ] ZIP files are accepted
- [ ] Non-ZIP files are rejected
- [ ] Progress shows during upload
- [ ] Files list shows import status
- [ ] Success shows pages created count
- [ ] Error shows failure message
- [ ] Pages are saved to database
- [ ] Existing pages are preserved (merge)
