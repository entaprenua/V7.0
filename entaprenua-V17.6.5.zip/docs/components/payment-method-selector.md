# Payment Method Selector Documentation

## Overview

The `PaymentMethodSelector` component provides a comprehensive UI for selecting Stripe payment methods. It supports 19 different payment methods with automatic currency-based filtering.

## Installation

The component is part of the UI library:

```tsx
import {
  PaymentMethodSelector,
  PaymentMethodGrid,
  PaymentMethodPopular,
  PaymentMethodCategories,
  PaymentMethodSummary,
} from "~/components/ui"
```

## Basic Usage

```tsx
import { createSignal } from "solid-js"

function CheckoutPage() {
  const [selectedMethod, setSelectedMethod] = createSignal<string | null>(null)
  const [currency, setCurrency] = createSignal("USD")

  return (
    <PaymentMethodSelector
      currency={currency()}
      selectedMethod={selectedMethod()}
      onMethodSelect={setSelectedMethod}
    >
      <PaymentMethodPopular />
    </PaymentMethodSelector>
  )
}
```

## Components

### PaymentMethodSelector

Main context provider that manages selection state and currency filtering.

| Prop | Type | Default | Description |
|------|------|---------|-------------|
| `currency` | `string` | `"USD"` | Current currency (filters available methods) |
| `selectedMethod` | `StripePaymentMethodType \| null` | `null` | Currently selected method |
| `onMethodSelect` | `(method: StripePaymentMethodType) => void` | - | Callback when method is selected |
| `onCurrencyChange` | `(currency: string) => void` | - | Callback when currency changes |
| `allowedMethods` | `StripePaymentMethodType[]` | - | Restrict to specific methods |
| `showCategories` | `boolean` | `true` | Show category labels |
| `showPopular` | `boolean` | `true` | Show popular badge |
| `class` | `string` | - | Additional CSS classes |

### PaymentMethodGrid

Grid layout for displaying payment methods.

```tsx
<PaymentMethodGrid columns={2} />
```

| Prop | Type | Default | Description |
|------|------|---------|-------------|
| `columns` | `1 \| 2 \| 3 \| 4` | `2` | Number of columns |
| `class` | `string` | - | Additional CSS classes |

### PaymentMethodPopular

Shows only popular payment methods (Card, Apple Pay, Google Pay, M-Pesa, Klarna).

```tsx
<PaymentMethodPopular />
```

### PaymentMethodCategories

Groups methods by category (Cards, Wallets, Bank Transfers, BNPL, Regional).

```tsx
<PaymentMethodCategories />
```

### PaymentMethodSummary

Displays the currently selected payment method.

```tsx
<PaymentMethodSummary />
```

### PaymentMethodOption

Individual payment method button (used internally).

## Supported Payment Methods

### Cards
| ID | Name | Currencies | Regions |
|----|------|------------|---------|
| `card` | Credit/Debit Card | All | Global |

### Digital Wallets
| ID | Name | Currencies | Regions |
|----|------|------------|---------|
| `apple_pay` | Apple Pay | USD, EUR, GBP, etc. | Global |
| `google_pay` | Google Pay | USD, EUR, GBP, etc. | Global |
| `alipay` | Alipay | CNY, USD, EUR | China |
| `wechat_pay` | WeChat Pay | CNY, USD, EUR | China |
| `grabpay` | GrabPay | SGD, MYR, PHP, etc. | Southeast Asia |

### Bank Transfers
| ID | Name | Currencies | Regions |
|----|------|------------|---------|
| `ach_debit` | ACH Direct Debit | USD | United States |
| `sepa_debit` | SEPA Direct Debit | EUR | Europe |
| `ideal` | iDEAL | EUR | Netherlands |
| `bancontact` | Bancontact | EUR | Belgium |
| `sofort` | Sofort | EUR | Germany, Austria |
| `giropay` | giropay | EUR | Germany |
| `eps` | EPS | EUR | Austria |
| `p24` | Przelewy24 | PLN | Poland |

### Buy Now, Pay Later
| ID | Name | Currencies | Regions |
|----|------|------------|---------|
| `klarna` | Klarna | USD, EUR, GBP | Global |
| `afterpay_clearpay` | Afterpay/Clearpay | USD, AUD, GBP, CAD | US, AU, UK, CA |
| `affirm` | Affirm | USD, CAD | United States, Canada |

### Regional
| ID | Name | Currencies | Regions |
|----|------|------------|---------|
| `mpesa` | M-Pesa | KES | Kenya |

## Currency Filtering

Methods are automatically filtered based on the selected currency:

```tsx
// KES currency - shows M-Pesa
<PaymentMethodSelector currency="KES">
  <PaymentMethodGrid />
</PaymentMethodSelector>

// EUR currency - shows SEPA, iDEAL, Bancontact, etc.
<PaymentMethodSelector currency="EUR">
  <PaymentMethodGrid />
</PaymentMethodSelector>

// USD currency - shows ACH, Card, Apple Pay, etc.
<PaymentMethodSelector currency="USD">
  <PaymentMethodGrid />
</PaymentMethodSelector>
```

## Restricting Methods

Use `allowedMethods` to show only specific options:

```tsx
<PaymentMethodSelector
  currency="USD"
  allowedMethods={['card', 'apple_pay', 'google_pay']}
>
  <PaymentMethodGrid />
</PaymentMethodSelector>
```

## Integration with Checkout

```tsx
import { createSignal } from "solid-js"
import { PaymentMethodSelector, PaymentMethodPopular, PaymentMethodSummary } from "~/components/ui"

function CheckoutForm() {
  const [paymentMethod, setPaymentMethod] = createSignal<string | null>(null)
  const [currency] = createSignal("USD")
  const [amount] = createSignal(99.99)

  const handleSubmit = async () => {
    if (!paymentMethod()) {
      alert("Please select a payment method")
      return
    }
    
    // Create payment intent with selected method
    const response = await fetch("/api/payments/create", {
      method: "POST",
      body: JSON.stringify({
        amount: amount(),
        currency: currency(),
        payment_method_types: [paymentMethod()],
      }),
    })
    
    // Handle response...
  }

  return (
    <div class="space-y-6">
      <div>
        <h2>Payment Method</h2>
        <p>Total: ${amount().toFixed(2)} {currency()}</p>
      </div>

      <PaymentMethodSelector
        currency={currency()}
        selectedMethod={paymentMethod()}
        onMethodSelect={setPaymentMethod}
      >
        <PaymentMethodPopular />
        <PaymentMethodSummary />
      </PaymentMethodSelector>

      <button 
        onClick={handleSubmit}
        disabled={!paymentMethod()}
      >
        Pay Now
      </button>
    </div>
  )
}
```

## Custom Styling

All components accept a `class` prop:

```tsx
<PaymentMethodSelector class="max-w-2xl mx-auto">
  <PaymentMethodGrid 
    columns={3} 
    class="gap-4 p-4 bg-muted rounded-lg" 
  />
</PaymentMethodSelector>
```

## Accessing Context

Use the hook for custom implementations:

```tsx
import { usePaymentMethodSelector } from "~/components/ui"

function CustomPaymentUI() {
  const { selectedMethod, availableMethods, currency } = usePaymentMethodSelector()
  
  return (
    <div>
      <p>Selected: {selectedMethod()}</p>
      <p>Currency: {currency()}</p>
      <p>Available: {availableMethods().length} methods</p>
    </div>
  )
}
```

## TypeScript Types

```tsx
import type {
  StripePaymentMethodType,
  PaymentMethodInfo,
  PaymentMethodCategory,
} from "~/components/ui/payment-method-selector"

// Payment method IDs
type StripePaymentMethodType = 
  | 'card' | 'mpesa' | 'apple_pay' | 'google_pay'
  | 'ach_debit' | 'sepa_debit' | 'ideal' | 'bancontact'
  | 'sofort' | 'giropay' | 'eps' | 'p24'
  | 'alipay' | 'wechat_pay' | 'grabpay'
  | 'klarna' | 'afterpay_clearpay' | 'affirm'

// Method information
interface PaymentMethodInfo {
  id: StripePaymentMethodType
  name: string
  description: string
  icon: JSX.Element
  category: PaymentMethodCategory
  currencies: string[]
  regions: string[]
  popular?: boolean
}

// Categories
type PaymentMethodCategory = 
  | 'cards' 
  | 'wallets' 
  | 'bank_transfers' 
  | 'bnpl' 
  | 'regional'
```

## Backend Integration

Send the selected payment method type to your Stripe integration:

```typescript
// Backend: Create PaymentIntent with selected method
const paymentIntent = await stripe.paymentIntents.create({
  amount: 9999,
  currency: 'usd',
  payment_method_types: [selectedMethod], // e.g., 'card', 'mpesa', 'apple_pay'
  // ...
})
```

## Demo

See `/demos/payment` for a comprehensive demo with:
- Currency switching
- Popular methods
- Full grid display
- Category grouping
- Selection summary
