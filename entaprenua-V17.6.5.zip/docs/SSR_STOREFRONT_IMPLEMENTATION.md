# SSR Storefront Implementation Plan

## Overview

Multi-storefront SSR (Server-Side Rendering) architecture where:
- Each storefront runs as a separate Node.js process
- StoreId is hardcoded in each built storefront
- Spring Boot handles process management and routing
- Nginx acts as reverse proxy

---

## Completed Implementation

### 1. Spring Boot Backend

#### Files Created/Modified

| File | Purpose |
|------|---------|
| `runtime/src/main/kotlin/com/entaprenua/storefront/StorefrontConfig.kt` | Configuration |
| `runtime/src/main/kotlin/com/entaprenua/storefront/ProcessManagerService.kt` | Process spawning/management |
| `runtime/src/main/kotlin/com/entaprenua/storefront/StoreRegistry.kt` | Domain-port mapping |
| `runtime/src/main/kotlin/com/entaprenua/storefront/StorefrontProxyHandler.kt` | HTTP proxy to storefronts |
| `runtime/src/main/kotlin/com/entaprenua/store/impl/StoreServiceImpl.kt` | API handlers |
| `runtime/src/main/kotlin/com/entaprenua/store/services/StoreService.kt` | Service interface |
| `runtime/src/main/kotlin/com/entaprenua/repositories/StoreRepository.kt` | Database methods |
| `runtime/src/main/kotlin/com/entaprenua/entities/Store.kt` | Entity with storefront fields |
| `runtime/src/main/kotlin/com/entaprenua/config/ApiRouterConfig.kt` | API routes |

#### Database Migration

```sql
-- V21: Add SSR storefront columns to stores table
ALTER TABLE stores 
ADD COLUMN IF NOT EXISTS storefront_port INTEGER,
ADD COLUMN IF NOT EXISTS storefront_process_id INTEGER,
ADD COLUMN IF NOT EXISTS storefront_status VARCHAR(20) DEFAULT 'stopped',
ADD COLUMN IF NOT EXISTS storefront_registered_at TIMESTAMPTZ,
ADD COLUMN IF NOT EXISTS storefront_last_heartbeat TIMESTAMPTZ;
```

#### API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/v1/stores/{id}/start` | Start storefront |
| POST | `/api/v1/stores/{id}/stop` | Stop storefront |
| GET | `/api/v1/stores/{id}/status` | Get storefront status |
| POST | `/api/v1/stores/{id}/register` | Register storefront |
| DELETE | `/api/v1/stores/{id}/unregister` | Unregister storefront |

#### Configuration

```properties
app.storefront.base-path=/var/lib/entaprenua/stores
app.storefront.base-port=3000
app.storefront.max-stores=100
app.storefront.process-manager-enabled=true
```

#### Storefront Storage

- **Location:** `/var/lib/entaprenua/stores/{storeId}/`
- **Entry point:** `node index.mjs`
- **Default port:** 3000 (auto-incremented)

---

### 2. Testing Results

✅ Storefront starts successfully
✅ Storefront serves SSR HTML
✅ Database updates with storefront status
✅ Start/Stop/Status endpoints working

---

### 3. Local Access

```bash
# Add to /etc/hosts
127.0.0.1 m-shop.entaprenua.com

# Start storefront
curl -X POST http://localhost:8080/api/v1/stores/{storeId}/start \
  -H "Content-Type: application/json" \
  -d '{"domain": "m-shop.entaprenua.com"}'

# Access
http://m-shop.entaprenua.com:3000
```

---

## Production Plan

### 1. VPS Requirements

- Provider: **Hostinger** (to be purchased)
- Domain: To be registered
- DNS: Point to VPS IP

### 2. Directory Structure on VPS

```
/var/lib/entaprenua/
├── stores/
│   ├── {storeId-1}/
│   │   ├── index.mjs
│   │   ├── package.json
│   │   └── _build/
│   └── {storeId-2}/
│       └── ...
└── builds/                   # Source for builds
```

### 3. Nginx Configuration

File: `/etc/nginx/sites-available/entaprenua`

```nginx
upstream backend {
    server localhost:8080;
}

# Main domain
server {
    listen 80;
    listen 443 ssl http2;
    server_name entaprenua.com www.entaprenua.com;

    ssl_certificate /etc/letsencrypt/live/entaprenua.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/entaprenua.com/privkey.pem;

    location / {
        proxy_pass http://backend;
        proxy_set_header Host $host;
    }
}

# Storefront subdomains
server {
    listen 80;
    listen 443 ssl http2;
    server_name ~^(?<subdomain>.+)\.entaprenua\.com$;

    ssl_certificate /etc/letsencrypt/live/entaprenua.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/entaprenua.com/privkey.pem;

    location / {
        proxy_pass http://backend;
        proxy_set_header Host $host;
    }
}
```

### 4. SSL Setup

```bash
# Install Certbot
sudo apt install certbot python3-certbot-nginx

# Generate wildcard certificate
sudo certbot --nginx -d entaprenua.com -d *.entaprenua.com
```

### 5. Firewall

```bash
sudo ufw allow 80/tcp   # HTTP
sudo ufw allow 443/tcp   # HTTPS
sudo ufw allow 22/tcp    # SSH
sudo ufw enable
```

---

## SolidStart Publish & Deploy Pipeline

### Architecture

```
SolidStart App (Builder + E-commerce)
        │
        │ User clicks "Publish"
        ▼
    Build Process (on VPS)
        │
        ├── npm run build
        │
        ▼
    Copy to /var/lib/entaprenua/stores/{id}/
        │
        ▼
    Start Node.js Process
        │
        ▼
    Register with Spring Boot API
        │
        ▼
    Storefront Live!
```

### Implementation Requirements

1. **Publish Endpoint** - Add to SolidStart Builder API
2. **Build Process** - Run `npm run build` on VPS
3. **Deploy Script** - Copy build to store directory
4. **Register API** - Call Spring Boot to start storefront

---

## Open Questions

### Production Setup

1. **Build trigger:** Should builds happen automatically when user saves in Builder, or manually (click "Publish")?
   - Current plan: Manual "Publish" button

2. **Build location:** Should the Builder server build and upload, or should the VPS pull and build?
   - Current plan: Build on VPS

3. **Multiple storefronts:** Do you need to support different storefront templates (different designs), or one template for all stores?

4. **CI/CD:** Do you want to set up automatic deployments (GitHub Actions, etc.)?

### Publish Pipeline

1. **Build timeout:** How long should the publish request wait? (May need async/queue)

2. **Build failure handling:** Should users see build errors in UI? How to report failures?

3. **Existing stores:** For existing stores without built storefronts, should they auto-build on first publish?

---

## Files Created

| File | Purpose |
|------|---------|
| `docs/IMPLEMENTATION_SSR_STOREFRONT.md` | Implementation plan |
| `docs/nginx-storefronts.conf` | Production Nginx config |
| `docs/nginx-local-dev.conf` | Local dev Nginx config |
| `scripts/setup-storefront-dir.sh` | Setup script for storefront directory |
| `runtime/src/main/resources/db/migration/V21__Add_storefront_columns.sql` | Database migration |

---

## Notes

- Node installed at: `/usr/local/node-v22.21.0-linux-x64/bin/node`
- Symlinked to: `/usr/bin/node`
- Default store path: `/var/lib/entaprenua/stores/{storeId}/`
- Entry point: `node index.mjs`

---

*Last Updated: 2026-03-16*
