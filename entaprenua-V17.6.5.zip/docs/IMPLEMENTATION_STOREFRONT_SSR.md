# Storefront SSR Implementation TODO

## Status: In Progress

---

## Phase 1: Middleware & Domain Lookup

- [ ] Create middleware for subdomain/domain detection
- [ ] Extract domain from request headers (Host header)
- [ ] Determine if subdomain or custom domain
- [ ] Handle reserved subdomains (admin, www, api, etc.)
- [ ] Lookup store by domain from Spring Boot API
- [ ] Add x-store-id header to request

---

## Phase 2: Store Context (Modify Existing)

- [x] StoreContext provider already exists (src/lib/stores/store-context.tsx)
- [ ] Modify StoreProvider to read x-store-id from request headers

---

## Phase 3: Nginx Configuration

- [ ] Configure wildcard subdomain routing (*.entaprenua.com)
- [ ] Configure custom domain virtual hosts
- [ ] Set up SSL with Let's Encrypt
