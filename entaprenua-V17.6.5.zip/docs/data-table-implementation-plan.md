# Enterprise Data Table Implementation Plan

## Overview

Refactor admin products page to use server-side filtering, sorting, and pagination with a production-ready enterprise data table.

## Current State

- Client-side filtering and sorting
- Partial pagination state (no UI)
- Uses custom table components

## Target State

- Server-side filtering, sorting, pagination
- Responsive design (mobile, tablet, desktop)
- Clean, reusable `DataTableServer` component

---

## Components Available

- `Pagination` - kobalte-based pagination (Items, Previous, Next)
- `Select` - for filter dropdowns
- `DropdownMenu` - for row actions
- `Input` - for search
- `Table` - existing table components
- `Checkbox` - for row selection

---

## Implementation Plan

### Phase 1: API Layer Updates

**File:** `src/lib/api/products.ts`

Add filter and sort parameters to product API methods:

```typescript
interface ProductFilters {
  search?: string
  status?: "in_stock" | "low_stock" | "out_of_stock" | "not_tracked"
  visibility?: "public" | "private" | "draft"
  sortBy?: "name" | "price" | "stockQuantity" | "visibility" | "createdAt"
  sortOrder?: "asc" | "desc"
}

getAll(storeId, page, size, filters): PagedResponse<Product>
search(storeId, query, page, size, filters): PagedResponse<Product>
```

### Phase 2: Create DataTableServer Component

**File:** `src/components/ui/data-table-server.tsx`

#### Props Interface

```typescript
interface DataTableServerProps<T> {
  columns: ColumnDef<T>[]
  fetchData: (params: QueryParams) => Promise<{ data: T[], total: number }>
  queryKey?: any[]
  filters?: FilterConfig[]
  defaultPageSize?: number
  onRowSelect?: (rows: T[]) => void
  renderRowActions?: (row: T) => JSX
}
```

#### Internal State

- `page` (0-indexed)
- `pageSize`
- `sorting` { field, direction }
- `filters` { field, value }
- `totalItems`
- `totalPages`
- `selectedRows`

#### Features

- Debounced search (300ms)
- Server-side pagination with total count
- Sortable columns (click header)
- Filterable (status, visibility dropdowns)
- Row selection (checkbox)
- Row actions (dropdown menu)
- Loading states (skeleton/spinner)
- Empty states
- Error handling with retry

### Phase 3: Responsive Design

#### Desktop (≥1024px)
- Full table view with all columns
- Horizontal scroll for overflow

#### Tablet (768px - 1023px)
- Horizontal scroll
- Collapsible optional columns

#### Mobile (<768px)
- Card-based layout instead of table
- Each row as a card with key-value pairs
- Sticky action buttons

### Phase 4: Products Page Integration

**File:** `src/routes/admin/products/index.tsx`

1. Remove client-side filtering/sorting code
2. Use `DataTableServer` component
3. Define columns with sort/filter support
4. Wire up API calls
5. Add pagination UI

### Phase 5: Polish

- Add page size selector (10, 20, 50, 100)
- Add "Showing X-Y of Z" text
- Add keyboard shortcuts (optional)
- URL state persistence (optional future enhancement)

---

## UI Layout

### Desktop
```
┌─────────────────────────────────────────────────────────────┐
│  [Search........] [Status▼] [Visibility▼] [Reset]           │
├─────────────────────────────────────────────────────────────┤
│  ☑ │ Image │ Name ▼ │ Price ▼ │ Stock ▼ │ Status │ Actions│
├─────────────────────────────────────────────────────────────┤
│  ☐ │  🖼   │ Foo    │ $10.00  │  50     │ In     │ ⋮     │
│  ☐ │  🖼   │ Bar    │ $20.00  │  0      │ Out    │ ⋮     │
├─────────────────────────────────────────────────────────────┤
│  Showing 1-20 of 234  [<Prev] [1] [2] [3]... [Next>]     │
└─────────────────────────────────────────────────────────────┘
```

### Mobile
```
┌────────────────────────────────────┐
│ [Search...] [Filters]             │
├────────────────────────────────────┤
│ ┌────────────────────────────────┐ │
│ │ ☑ 🖼 Foo        $10.00  In ✓ │ │
│ │    Stock: 50                  │ │
│ └────────────────────────────────┘ │
│ ┌────────────────────────────────┐ │
│ │ ☐ 🖼 Bar        $20.00  Out ✗│ │
│ └────────────────────────────────┘ │
├────────────────────────────────────┤
│ [< Prev] Page 1 of 12 [Next >]    │
└────────────────────────────────────┘
```

---

## Filter Options

| Filter | Type | Options |
|--------|------|---------|
| Search | Text | - |
| Status | Select | All, In Stock, Low Stock, Out of Stock, Not Tracked |
| Visibility | Select | All, Public, Private, Draft |

---

## Implementation Order

1. Update `productsApi.ts` - add filter params
2. Create `DataTableServer` component
3. Add responsive styles (cards on mobile)
4. Integrate with products page
5. Add debounced search
6. Add page size selector

---

## Future Enhancements (Not in Scope)

- Column visibility toggle
- Column resizing
- Fixed/sticky header
- Persistent state in URL
- Saved filter presets
- Export (CSV/Excel)
- Virtual scrolling
- Keyboard navigation
- Row expansion
- Bulk actions menu
- Stale-while-revalidate
- Request deduplication
- Optimistic updates
