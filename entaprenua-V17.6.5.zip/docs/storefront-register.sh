#!/bin/bash
# Storefront Registration Script
# This script registers the storefront with the Spring Boot process manager

# Read environment variables
STORE_PORT=${PORT:-3000}
STORE_ID=${STORE_ID}
STORE_DOMAIN=${STORE_DOMAIN}
API_BASE_URL=${API_BASE_URL:-http://localhost:8080}

if [ -z "$STORE_ID" ] || [ -z "$STORE_DOMAIN" ]; then
    echo "ERROR: STORE_ID and STORE_DOMAIN environment variables must be set"
    exit 1
fi

# Register the store
register_store() {
    echo "Registering store $STORE_ID at $STORE_DOMAIN on port $STORE_PORT..."
    
    response=$(curl -s -X POST "$API_BASE_URL/api/v1/stores/register" \
        -H "Content-Type: application/json" \
        -d "{\"storeId\": \"$STORE_ID\", \"domain\": \"$STORE_DOMAIN\", \"port\": $STORE_PORT}")
    
    if [ $? -eq 0 ]; then
        echo "Store registered successfully: $response"
    else
        echo "Failed to register store: $response"
    fi
}

# Unregister the store
unregister_store() {
    echo "Unregistering store $STORE_ID..."
    
    response=$(curl -s -X DELETE "$API_BASE_URL/api/v1/stores/$STORE_ID/unregister" \
        -H "Content-Type: application/json")
    
    if [ $? -eq 0 ]; then
        echo "Store unregistered successfully: $response"
    else
        echo "Failed to unregister store: $response"
    fi
}

# Handle signals
trap 'unregister_store; exit 0' SIGINT SIGTERM

# Register on startup
register_store

# Wait for the process to finish
wait
