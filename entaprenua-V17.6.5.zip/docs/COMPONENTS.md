# UI Components Documentation

**Version**: 1.0  
**Date**: 2026-02-21  
**Framework**: SolidStart + Kobalte + TailwindCSS

---

## Payment Components

### Overview

The payment module provides a comprehensive set of components for handling payments, refunds, and payment method management.

### File Structure

```
src/components/ui/
├── payment.tsx           # Main component exports
├── payment-context.tsx   # Context providers
└── index.tsx             # Re-exports
```

---

### Core Components

#### PaymentRoot

Root container that provides payment context and data fetching.

```tsx
<PaymentRoot 
  paymentId="abc-123"           // Fetch by ID
  orderId="order-456"           // OR fetch by order
  data={paymentObject}          // OR pass directly
  queryKey={["payment", id]}    // Custom query key
>
  <PaymentAmount />
  <PaymentStatusBadge />
</PaymentRoot>
```

**Props:**
| Prop | Type | Description |
|------|------|-------------|
| paymentId | string | Payment ID to fetch |
| orderId | string | Order ID to fetch payments for |
| data | Payment | Pre-loaded payment data |
| queryKey | unknown[] | Custom React Query key |
| errorFallback | JSX | Error state fallback |
| loadingFallback | JSX | Loading state fallback |

---

#### PaymentAmount

Displays formatted payment amount with currency.

```tsx
<PaymentAmount />
// Output: "$99.99"

<PaymentAmount label="Total: " />
// Output: "Total: $99.99"
```

---

#### PaymentStatusBadge

Displays payment status with color-coded badge.

```tsx
<PaymentStatusBadge />
// Output: <Badge>Succeeded</Badge> (green)
```

**Status Colors:**
| Status | Color |
|--------|-------|
| PENDING | Yellow |
| PROCESSING | Blue |
| SUCCEEDED | Green |
| FAILED | Red |
| CANCELLED | Gray |
| REFUNDED | Purple |

---

#### PaymentCardInfo

Displays card brand and last 4 digits.

```tsx
<PaymentCardInfo />
// Output: [VISA] ****4242
```

---

#### PaymentDate

Displays formatted payment date.

```tsx
<PaymentDate />
// Output: "Feb 21, 2026, 3:45 PM"
```

---

#### PaymentRefundTrigger

Button that opens refund dialog.

```tsx
<PaymentRefundTrigger 
  onSuccess={(result) => console.log(result)}
  onError={(err) => console.error(err)}
>
  Request Refund
</PaymentRefundTrigger>
```

---

#### PaymentCancelTrigger

Button to cancel pending payments.

```tsx
<PaymentCancelTrigger 
  onSuccess={(payment) => console.log(payment)}
>
  Cancel Payment
</PaymentCancelTrigger>
```

---

#### PaymentList

Displays paginated list of payments.

```tsx
<PaymentList 
  storeId="store-123"
  // OR
  userId="user-456"
  renderItem={(payment) => (
    <PaymentRoot data={payment}>
      <Card>...</Card>
    </PaymentRoot>
  )}
/>
```

---

#### PaymentMethodCard

Displays a single payment method.

```tsx
<PaymentMethodCard
  method={paymentMethod}
  isSelected={selectedId === method.id}
  onSelect={(method) => setSelectedId(method.id)}
/>
```

---

#### PaymentMethodList

Displays all user payment methods.

```tsx
<PaymentMethodList
  storeId="store-123"
  selectedId={selectedMethodId}
  onSelect={(method) => setSelectedMethodId(method.id)}
/>
```

---

#### CheckoutForm

Complete checkout form with payment method selection.

```tsx
<CheckoutForm
  storeId="store-123"
  cartId="cart-456"
  total={99.99}
  currency="USD"
  onSuccess={({ orderId, paymentId }) => {
    navigate(`/order/${orderId}`)
  }}
  onError={(err) => setError(err.message)}
/>
```

---

### Context Providers

#### PaymentProvider

Provides payment state management.

```tsx
<PaymentProvider initialPayment={payment}>
  {children}
</PaymentProvider>
```

**Hook:** `usePayment()`
```typescript
const { 
  payment, 
  methods, 
  defaultMethod, 
  isProcessing, 
  error,
  setPayment,
  addMethod,
  removeMethod,
  setDefaultMethod,
} = usePayment()
```

---

#### CheckoutProvider

Manages checkout flow state.

```tsx
<CheckoutProvider>
  {children}
</CheckoutProvider>
```

**Hook:** `useCheckout()`
```typescript
const { 
  state,        // { cartId, orderId, total, status, clientSecret, ... }
  setStatus,
  setError,
  reset,
} = useCheckout()
```

---

#### RefundProvider

Manages refund state.

```tsx
<RefundProvider>
  {children}
</RefundProvider>
```

**Hook:** `useRefund()`

---

### Skeleton Components

```tsx
<PaymentSkeleton />
<PaymentListSkeleton />
```

---

## Auth Components

### Overview

Comprehensive authentication components with client-side validation, server-side email verification, and OAuth support.

### File Structure

```
src/components/ui/
├── auth.tsx              # Main component exports
├── auth-context.tsx      # Context providers
└── index.tsx             # Re-exports

src/lib/utils/
└── validation.ts         # Client-side validation utilities
```

---

### Core Components

#### LoginForm

Complete login form with validation.

```tsx
<LoginForm
  onSuccess={(response) => {
    // Handle successful login
    navigate('/dashboard')
  }}
  onError={(error) => {
    // Handle login error
    showToast(error)
  }}
/>
```

---

#### RegisterForm

Registration form with full validation.

```tsx
<RegisterForm
  onSuccess={(response) => {
    if (response.requiresEmailVerification) {
      navigate('/verify-email')
    } else {
      navigate('/dashboard')
    }
  }}
  onError={(error) => showToast(error)}
/>
```

---

#### PasswordResetForm

Password reset request form.

```tsx
<PasswordResetForm
  onSuccess={() => showToast('Check your email')}
  onError={(err) => showToast(err)}
/>
```

---

### Field Components

#### EmailField

Email input with client + server validation.

```tsx
<EmailField
  value={email()}
  onInput={setEmail}
  label="Email Address"
  placeholder="you@example.com"
  showServerValidation={true}
  onServerValidation={(result) => {
    // result: EmailServerValidationResult
    console.log(result.qualityScore)
    console.log(result.isDisposable)
  }}
/>
```

**Features:**
- Real-time format validation
- Typo suggestions (gmial → gmail)
- Server-side deliverability check
- Disposable email detection
- Quality score display

---

#### PasswordField

Password input with strength indicator.

```tsx
<PasswordField
  value={password()}
  onInput={setPassword}
  label="Password"
  showStrength={true}
/>
```

**Features:**
- Real-time strength calculation
- Visual strength bar (weak/fair/good/strong)
- Suggestion messages
- Common pattern detection

---

#### ConfirmPasswordField

Password confirmation with match validation.

```tsx
<ConfirmPasswordField
  password={password()}
  value={confirmPassword()}
  onInput={setConfirmPassword}
/>
```

---

#### UsernameField

Username input with availability check.

```tsx
<UsernameField
  value={username()}
  onInput={setUsername}
/>
```

**Features:**
- Format validation (3-30 chars, alphanumeric + underscore)
- Real-time availability check via API
- Visual feedback for taken usernames

---

#### IdentityProviderButtons

OAuth provider buttons.

```tsx
<IdentityProviderButtons
  providers={['GOOGLE', 'GITHUB', 'APPLE']}
  onProviderClick={(provider) => console.log(provider)}
/>
```

---

### Validation Utilities

Located in `src/lib/utils/validation.ts`

#### validateEmailFormat

```typescript
const result = validateEmailFormat(email)
// {
//   isValid: boolean,
//   error?: string,
//   suggestion?: string  // "Did you mean ...@gmail.com?"
// }
```

#### getPasswordStrength

```typescript
const result = getPasswordStrength(password)
// {
//   isValid: boolean,
//   strength: 'weak' | 'fair' | 'good' | 'strong',
//   score: 0-5,
//   errors: string[],
//   suggestions: string[]
// }
```

#### validatePasswordMatch

```typescript
const result = validatePasswordMatch(password, confirmPassword)
// { isValid: boolean, error?: string }
```

#### validateUsername

```typescript
const result = validateUsername(username)
// { isValid: boolean, error?: string }
```

#### Helper Functions

```typescript
getStrengthColor(strength)  // Returns Tailwind class
getStrengthLabel(strength)  // Returns display label
```

---

### Context Providers

#### AuthUIProvider

```tsx
<AuthUIProvider initialUser={user} initialToken={token}>
  {children}
</AuthUIProvider>
```

**Hook:** `useAuthUI()`
```typescript
const {
  user,
  token,
  isAuthenticated,
  isLoading,
  error,
  permissions,
  setUser,
  hasRole,
  hasPermission,
  clear,
} = useAuthUI()
```

---

#### PasswordResetProvider

```tsx
<PasswordResetProvider>
  {children}
</PasswordResetProvider>
```

**Hook:** `usePasswordReset()`

---

#### EmailVerificationProvider

```tsx
<EmailVerificationProvider>
  {children}
</EmailVerificationProvider>
```

**Hook:** `useEmailVerification()`

---

#### SessionProvider

```tsx
<SessionProvider>
  {children}
</SessionProvider>
```

**Hook:** `useSession()`

---

### Types

```typescript
// Email validation
export type EmailValidationResult = {
  isValid: boolean
  error?: string
  suggestion?: string
}

export type EmailServerValidationResult = {
  email: string
  isValidFormat: boolean
  isDeliverable: boolean
  isSmtpValid: boolean
  isMxFound: boolean
  isDisposable: boolean
  isFree: boolean
  qualityScore: number
  suggestion?: string
}

// Password validation
export type PasswordStrength = 'weak' | 'fair' | 'good' | 'strong'

export type PasswordValidationResult = {
  isValid: boolean
  strength: PasswordStrength
  score: number
  errors: string[]
  suggestions: string[]
}
```

---

## API Integration

### paymentsApi

```typescript
import { paymentsApi } from '~/lib/api/payments'

// Create payment intent
const response = await paymentsApi.createPaymentIntent({
  orderId: '...',
  userId: '...',
  storeId: '...',
  amount: 9999,
  currency: 'USD',
}, token)

// Get payment
const payment = await paymentsApi.getById(paymentId, token)

// Refund
const refund = await paymentsApi.refund({
  paymentId: '...',
  amount: 5000,
  reason: 'REQUESTED_BY_CUSTOMER',
}, token)
```

### authApi

```typescript
import { authApi } from '~/lib/api/auth'

// Login
const response = await authApi.login({
  email: 'user@example.com',
  password: 'password',
  rememberMe: true,
})

// Register
const response = await authApi.register({
  email: 'user@example.com',
  password: 'password',
  confirmPassword: 'password',
  username: 'johndoe',
  acceptTerms: true,
})

// Validate email (server-side)
const validation = await authApi.validateEmail('user@example.com')

// Check availability
const { exists } = await authApi.checkEmailExists('user@example.com')

// OAuth
const { url } = await authApi.getOAuthUrl('GOOGLE')
window.location.href = url
```

---

## Usage Patterns

### Complete Checkout Flow

```tsx
import { CheckoutForm, PaymentRoot, PaymentStatusBadge } from '~/components/ui'

function CheckoutPage() {
  const cart = useCart()
  
  return (
    <CheckoutForm
      storeId={storeId}
      cartId={cart.id}
      total={cart.subtotal}
      onSuccess={({ orderId, paymentId }) => {
        navigate(`/order/${orderId}/confirmation`)
      }}
    />
  )
}

function OrderConfirmationPage() {
  return (
    <PaymentRoot paymentId={paymentId}>
      <Card>
        <CardHeader>
          <CardTitle>Payment <PaymentStatusBadge /></CardTitle>
        </CardHeader>
        <CardContent>
          <PaymentAmount label="Amount: " />
          <PaymentCardInfo />
          <PaymentDate />
          <PaymentReceiptUrl>View Receipt</PaymentReceiptUrl>
        </CardContent>
      </Card>
    </PaymentRoot>
  )
}
```

### Complete Auth Flow

```tsx
import { LoginForm, RegisterForm, EmailField } from '~/components/ui'

function LoginPage() {
  return (
    <LoginForm
      onSuccess={(response) => navigate('/dashboard')}
      onError={(err) => toast.error(err)}
    />
  )
}

function RegisterPage() {
  return (
    <RegisterForm
      onSuccess={(response) => {
        if (response.requiresEmailVerification) {
          navigate('/verify-email-sent')
        } else {
          navigate('/dashboard')
        }
      }}
    />
  )
}
```

### Custom Email Validation

```tsx
import { EmailField, validateEmailFormat } from '~/components/ui'
import { authApi } from '~/lib/api/auth'

function CustomForm() {
  const [email, setEmail] = createSignal('')
  const [serverResult, setServerResult] = createSignal(null)
  
  // Client validation - immediate
  const clientResult = createMemo(() => validateEmailFormat(email()))
  
  // Server validation - debounced in EmailField
  return (
    <EmailField
      value={email()}
      onInput={setEmail}
      showServerValidation={true}
      onServerValidation={(result) => {
        setServerResult(result)
        if (result.isDisposable) {
          warnUser('Disposable emails not recommended')
        }
      }}
    />
  )
}
```

---

## Product Components

### Overview

Product components provide a compound pattern for displaying and interacting with products in an e-commerce context. They integrate with Cart, Wishlist, and Order stores.

### File Structure

```
src/components/ui/
├── product.tsx           # Main component exports
├── product-context.tsx   # Context provider
└── index.tsx             # Re-exports

src/lib/stores/
├── cart.tsx              # Cart store provider
├── wishlist.tsx          # Wishlist store provider
├── order.tsx             # Order store provider
└── index.ts              # Re-exports
```

---

### Core Components

#### Product

Root container that provides product context.

```tsx
<Product 
  data={product}              // Product data object
  queryFn={() => fetchProduct(id)}  // OR fetch via query
  queryKey={["product", id]}  // Query key
>
  <ProductName />
  <ProductPrice />
  <ProductAddToCartTrigger>Add to Cart</ProductAddToCartTrigger>
</Product>
```

**Props:**
| Prop | Type | Description |
|------|------|-------------|
| data | any | Pre-loaded product data |
| queryFn | () => Promise | Fetch function for lazy loading |
| queryKey | unknown[] | Query cache key |
| errorFallback | JSX | Error state fallback |
| loadingFallback | JSX | Loading state fallback |

---

#### ProductName

Displays product name.

```tsx
<ProductName />
<ProductName label="Custom Label" />
```

---

#### ProductPrice

Displays product price.

```tsx
<ProductPrice />
<ProductPrice label="Price: $" />
```

---

#### ProductAddToCartTrigger

Button that adds product to cart.

```tsx
<ProductAddToCartTrigger class="w-full">
  Add to Cart
</ProductAddToCartTrigger>
```

**Behavior:**
- Only renders if product is NOT in cart
- Calls `cart.addProduct()` internally
- Uses product's quantity from context (default: 1)

---

#### ProductRemoveFromCartTrigger

Button that removes product from cart.

```tsx
<ProductRemoveFromCartTrigger>
  Remove
</ProductRemoveFromCartTrigger>
```

**Behavior:**
- Only renders if product IS in cart
- Finds cart item by product ID
- Calls `cart.remove()` internally

---

#### ProductToggleWishlistTrigger

Button that toggles wishlist status.

```tsx
<ProductToggleWishlistTrigger>
  {inWishlist() ? "Remove from Wishlist" : "Add to Wishlist"}
</ProductToggleWishlistTrigger>
```

**Behavior:**
- Adds to wishlist if not present
- Removes from wishlist if already present

---

#### ProductQuantityActions

Quantity controls (decrement, input, increment).

```tsx
<ProductQuantityActions class="w-32" />
```

**Behavior:**
- Decrement: Reduces quantity by 1, removes if quantity becomes 0
- Input: Direct quantity input
- Increment: Increases quantity by 1

---

### Context Provider

#### ProductProvider

Provides product state management.

```tsx
<ProductProvider data={product}>
  {children}
</ProductProvider>
```

**Hook:** `useProduct()`
```typescript
const {
  data,           // Product data
  isInCart,       // () => boolean
  isInWishlist,   // () => boolean
  update,         // (updates) => void
} = useProduct()
```

**Important:** Product quantity is synced FROM the cart, not TO it. The cart is the source of truth.

---

### Store Providers

#### CartProvider

Manages shopping cart state.

```tsx
<CartProvider initialCart={cart}>
  {children}
</CartProvider>
```

**Hook:** `useCart()`
```typescript
const cart = useCart()

// State
cart.items()           // ItemListEntry[]
cart.count()           // number
cart.subtotal()        // number
cart.isEmpty()         // boolean

// Actions
cart.addProduct(product, quantity)   // Add product
cart.remove(id)                       // Remove by item ID
cart.setQuantity(id, quantity)        // Update quantity
cart.clear()                          // Clear all items
cart.hasProduct(productId)            // Check if product in cart
cart.findByProductId(productId)       // Find item by product ID
cart.sync(backendCart)                // Sync with backend data
cart.toCartItems()                    // Convert to CartItem[]
```

---

#### WishlistProvider

Manages wishlist state.

```tsx
<WishlistProvider initialWishlist={wishlist}>
  {children}
</WishlistProvider>
```

**Hook:** `useWishlist()`
```typescript
const wishlist = useWishlist()

// State & Actions (same pattern as cart)
wishlist.items()
wishlist.count()
wishlist.addProduct(product)
wishlist.remove(id)
wishlist.hasProduct(productId)
wishlist.findByProductId(productId)
wishlist.sync(backendWishlist)
wishlist.toWishlistItems()
```

---

#### OrderProvider

Manages order state.

```tsx
<OrderProvider initialOrder={order}>
  {children}
</OrderProvider>
```

**Hook:** `useOrder()`
```typescript
const order = useOrder()

// State & Actions
order.items()
order.count()
order.subtotal()
order.addProduct(product, quantity)
order.remove(id)
order.clear()
order.sync(backendOrder)
order.toOrderItems()
order.order()                        // Get full order object
order.setBillingAddress(address)
order.setShippingAddress(address)
```

---

### Usage Patterns

#### Complete Product Card

```tsx
import { Product, ProductName, ProductPrice, ProductAddToCartTrigger, ProductToggleWishlistTrigger } from '~/components/ui'

function ProductCard({ product }) {
  return (
    <Card>
      <Product data={product}>
        <img src={product.image} alt={product.name} />
        <ProductName class="text-lg font-bold" />
        <ProductPrice class="text-primary" />
        <Flex class="gap-2">
          <ProductAddToCartTrigger class="flex-1">
            Add to Cart
          </ProductAddToCartTrigger>
          <ProductToggleWishlistTrigger class="flex-1">
            Wishlist
          </ProductToggleWishlistTrigger>
        </Flex>
      </Product>
    </Card>
  )
}
```

#### Store Demo Page

```tsx
import { CartProvider, WishlistProvider, OrderProvider } from '~/lib/stores'

function StorePage() {
  return (
    <CartProvider>
      <WishlistProvider>
        <OrderProvider>
          <ProductGrid />
          <CartSection />
          <WishlistSection />
          <CheckoutSection />
        </OrderProvider>
      </WishlistProvider>
    </CartProvider>
  )
}
```

---

### Architecture Notes

#### Data Flow

```
props.data → ProductProvider → product store
                                      ↓
                              cart.findByProductId()
                                      ↓
                              quantity sync (one-way: cart → product)
```

The product context syncs quantity FROM the cart (source of truth), not the reverse. This prevents circular dependencies.

#### Store Implementation

All stores use a shared `createItemList` utility (`src/lib/item-list.ts`) which provides:
- Generic item management (add, remove, update, setQuantity)
- Memoized computations (count, subtotal, isEmpty)
- Snapshot sync for backend data
- Product ID lookups

---

## Store Templates

### Overview

Store templates are pre-built store archetypes available in the marketplace. They come in two forms:

| Type | Description |
|------|-------------|
| **Ready-made stores** | Complete, pre-built stores - purchase and use as-is |
| **Templates** | Starting point stores - customize before launching |

Templates combine Product, Cart, Category, Hero, and Payment components into complete storefront layouts.

### Ready-made Stores

Ready-made stores are fully functional e-commerce stores that users can purchase and use immediately. They include:

- Pre-populated product catalogs
- Configured categories and navigation
- Set up hero sections and banners
- Integrated payment settings
- Complete checkout flows

Users buy a ready-made store and receive a fully operational store they can start selling from right away.

### Templates

Templates are starting point stores that users customize before launching. They provide:

- Pre-designed layouts and component arrangements
- Sample product placeholders
- Configurable hero sections
- Flexible category structures
- Customizable payment integration

Users can modify products, branding, colors, and content to create their unique store.

### Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                      SHOP TEMPLATE LAYER                         │
│                                                                  │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐             │
│  │ HeroSection │  │ProductGrid  │  │CategoryNav  │             │
│  └─────────────┘  └─────────────┘  └─────────────┘             │
│                                                                  │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐             │
│  │ ProductCard │  │  CartDrawer │  │CheckoutFlow │             │
│  └─────────────┘  └─────────────┘  └─────────────┘             │
└─────────────────────────────────────────────────────────────────┘
                            │
┌─────────────────────────────────────────────────────────────────┐
│                      COMPONENT LAYER                             │
│                                                                  │
│  Product    Cart    Wishlist    Order    Category    Hero       │
│  ───────    ────    ────────    ─────    ────────    ────     │
│                                                                  │
│  QueryBoundary + Context Providers + Store Integrations          │
└─────────────────────────────────────────────────────────────────┘
                            │
┌─────────────────────────────────────────────────────────────────┐
│                      API / DATA LAYER                            │
│                                                                  │
│  productsApi    cartsApi    ordersApi    categoriesApi           │
│  heroesApi      paymentsApi mediaApi                            │
└─────────────────────────────────────────────────────────────────┘
```

### Database Schema

The shop templates work with these core tables:

```
stores
├── id (UUID)
├── user_id (UUID)
├── name
├── domain_name
├── logo, favicon
├── is_template (BOOLEAN)
└── is_in_maintenance_mode

products
├── id (UUID)
├── store_id (UUID)
├── name (CITEXT)
├── price (DECIMAL)
├── compare_to_price (DECIMAL)
├── image (VARCHAR)
├── visibility
└── version (optimistic locking)

categories
├── id (UUID)
├── store_id (UUID)
├── name (CITEXT)
├── image (VARCHAR)
├── level (1, 2, 3)
└── visibility

category_hierarchy
├── parent_category_id (UUID)
└── child_category_id (UUID)

carts
├── id (UUID)
├── store_id (UUID)
├── customer_id (UUID)
├── currency
├── subtotal, total
├── is_locked
└── version

cart_items
├── cart_id (UUID)
├── product_id (UUID)
├── price, quantity, subtotal
└── version

orders
├── id (UUID)
├── store_id (UUID)
├── customer_id (UUID)
├── order_number (unique)
├── status (pending, paid, shipped, etc.)
├── subtotal, tax, shipping_cost, discount, total
├── billing_address, shipping_address (JSONB)
├── paid_at, shipped_at, delivered_at
└── version

heroes
├── id (UUID)
├── store_id (UUID)
├── name
├── display_type (carousel, grid, stack, fade, slide)
├── autoplay, autoplay_interval
├── show_indicators, show_navigation
├── aspect_ratio, max_height, gap
├── is_active
├── starts_at, ends_at (scheduling)
└── version

hero_items
├── hero_id (UUID)
├── sort_order
├── background_type (image, video, color, gradient)
├── background_image_url, background_video_url
├── background_color, background_gradient
├── overlay_color, overlay_opacity
├── title, subtitle, description
├── content_position (top-left, center, bottom-right, etc.)
├── text_alignment
├── cta_text, cta_url, cta_style
├── cta_secondary_* (secondary CTA)
├── mobile_background_image_url (mobile override)
├── starts_at, ends_at (item-level scheduling)
└── version

media
├── id (UUID)
├── store_id (UUID)
├── url
├── type (image, video, audio, document)
├── mime_type, size_bytes
├── width, height
├── thumbnail_url, medium_url, large_url (variants)
├── is_primary, display_order
└── version

payments
├── id (UUID)
├── order_id (UUID)
├── store_id, user_id
├── stripe_payment_intent_id
├── amount (cents), currency
├── status (PENDING, PROCESSING, SUCCEEDED, FAILED, etc.)
├── application_fee, stripe_fee, net_amount
├── amount_refunded
├── card_brand, card_last4
├── receipt_url
└── version
```

### Component Patterns

#### Hero Section

```tsx
import { HeroRoot, HeroItems, HeroItem } from '~/components/ui'

<HeroRoot storeId={storeId}>
  <HeroItems layout="row">
    {(item) => (
      <HeroItem 
        item={item}
        aspectRatio="16/9"
        maxHeight={600}
      />
    )}
  </HeroItems>
</HeroRoot>
```

**With Embla Carousel:**

```tsx
import { HeroRoot, HeroItems, HeroItem } from '~/components/ui'
import { Carousel, CarouselContent, CarouselItem, CarouselPrevious, CarouselNext, CarouselDots } from '~/components/ui'

<HeroRoot heroId={heroId}>
  <Carousel autoplay showDots>
    <CarouselContent>
      <HeroItems layout="row">
        {(item) => (
          <CarouselItem>
            <HeroItem item={item} aspectRatio="16/9" />
          </CarouselItem>
        )}
      </HeroItems>
    </CarouselContent>
    <CarouselPrevious />
    <CarouselNext />
    <CarouselDots />
  </Carousel>
</HeroRoot>
```

#### Product Grid

```tsx
import { CollectionView } from '~/components/ui'
import { productsApi } from '~/lib/api/products'

function ProductGrid({ storeId, categoryId }) {
  return (
    <Query
      queryFn={() => productsApi.getByStoreId(storeId, { categoryId })}
      queryKey={['products', storeId, categoryId]}
    >
      <QueryBoundary>
        <CollectionView
          layout="grid"
          columns={4}
          columnsMedium={3}
          columnsSmall={2}
          gap={4}
        >
          {(product) => <ProductCard product={product} />}
        </CollectionView>
      </QueryBoundary>
    </Query>
  )
}
```

#### Product Card

```tsx
import { Product, ProductName, ProductPrice, ProductMedia, ProductAddToCartTrigger, ProductToggleWishlistTrigger } from '~/components/ui'
import { Card } from '~/components/ui'

function ProductCard({ product }) {
  return (
    <Card class="overflow-hidden">
      <Product data={product}>
        <ProductMedia class="aspect-square" />
        <div class="p-4">
          <ProductName class="font-semibold" />
          <ProductPrice class="text-lg text-primary" />
          <div class="mt-4 flex gap-2">
            <ProductAddToCartTrigger class="flex-1">
              Add to Cart
            </ProductAddToCartTrigger>
            <ProductToggleWishlistTrigger>
              ♡
            </ProductToggleWishlistTrigger>
          </div>
        </div>
      </Product>
    </Card>
  )
}
```

#### Category Navigation

```tsx
import { CategoryMenu, CategoryRoot } from '~/components/ui'
import { categoriesApi } from '~/lib/api/categories'

function StoreNavigation({ storeId }) {
  return (
    <Query
      queryFn={() => categoriesApi.getByStoreId(storeId)}
      queryKey={['categories', storeId]}
    >
      <QueryBoundary>
        <CategoryRoot>
          <CategoryMenu orientation="horizontal" />
        </CategoryRoot>
      </QueryBoundary>
    </Query>
  )
}
```

#### Shopping Cart

```tsx
import { CartProvider, Cart, CartItems, CartSummary, CartSubtotal, CartCheckoutTrigger } from '~/components/ui'
import { Button } from '~/components/ui'

function CartPage() {
  return (
    <CartProvider>
      <div class="grid grid-cols-3 gap-8">
        <div class="col-span-2">
          <CartItems renderItem={(item) => (
            <CartItemCard item={item} />
          )} />
          <CartEmpty>
            <p>Your cart is empty</p>
            <Button onClick={() => navigate('/shop')}>Continue Shopping</Button>
          </CartEmpty>
        </div>
        <div>
          <CartSummary class="p-4 border rounded-lg">
            <h3>Order Summary</h3>
            <div class="flex justify-between mt-4">
              <span>Subtotal</span>
              <CartSubtotal />
            </div>
            <CartCheckoutTrigger class="w-full mt-4">
              Proceed to Checkout
            </CartCheckoutTrigger>
          </CartSummary>
        </div>
      </div>
    </CartProvider>
  )
}
```

#### Checkout Flow

```tsx
import { CheckoutProvider, useCheckout } from '~/components/ui'
import { CheckoutForm, PaymentRoot, PaymentStatusBadge } from '~/components/ui'
import { Button } from '~/components/ui'

function CheckoutPage({ storeId, cartId, total }) {
  return (
    <CheckoutProvider>
      <div class="max-w-2xl mx-auto">
        <h1>Checkout</h1>
        <CheckoutForm
          storeId={storeId}
          cartId={cartId}
          total={total}
          onSuccess={({ orderId, paymentId }) => {
            navigate(`/order/${orderId}/confirmation`)
          }}
          onError={(err) => toast.error(err.message)}
        />
      </div>
    </CheckoutProvider>
  )
}

function OrderConfirmationPage({ orderId }) {
  return (
    <PaymentRoot orderId={orderId}>
      <Card>
        <CardHeader>
          <CardTitle>Order Confirmation</CardTitle>
        </CardHeader>
        <CardContent>
          <PaymentStatusBadge />
          <PaymentAmount class="text-2xl mt-4" />
        </CardContent>
        <CardFooter>
          <PaymentReceiptUrl>View Receipt</PaymentReceiptUrl>
        </CardFooter>
      </Card>
    </PaymentRoot>
  )
}
```

### Store Providers

All shop templates require wrapping with store providers:

```tsx
import { CartProvider, WishlistProvider, OrderProvider } from '~/lib/stores'

function StoreLayout({ children }) {
  return (
    <CartProvider>
      <WishlistProvider>
        <OrderProvider>
          {children}
        </OrderProvider>
      </WishlistProvider>
    </CartProvider>
  )
}

function App() {
  return (
    <StoreLayout>
      <Header />
      <HeroSection />
      <ProductGrid />
      <CartDrawer />
    </StoreLayout>
  )
}
```

### API Integration

```typescript
import { productsApi } from '~/lib/api/products'
import { categoriesApi } from '~/lib/api/categories'
import { cartsApi } from '~/lib/api/carts'
import { heroesApi } from '~/lib/api/heroes'
import { paymentsApi } from '~/lib/api/payments'

// Fetch products
const products = await productsApi.getByStoreId(storeId)
const product = await productsApi.getById(productId)

// Fetch categories
const categories = await categoriesApi.getByStoreId(storeId)
const categoryTree = await categoriesApi.getTree(storeId)

// Cart operations
const cart = await cartsApi.getByStoreAndUser(storeId, userId)
await cartsApi.addItem(cartId, { productId, quantity })
await cartsApi.updateItem(cartId, itemId, { quantity })
await cartsApi.removeItem(cartId, itemId)

// Hero sections
const heroes = await heroesApi.getActiveByStoreId(storeId)
const hero = await heroesApi.getById(heroId)

// Payments
const payment = await paymentsApi.createPaymentIntent(request, token)
await paymentsApi.refund({ paymentId, amount }, token)
```

### Icon Usage

```tsx
import { ShoppingCartIcon, SearchIcon, UserIcon, MenuIcon } from '~/icons'

// In components
<ShoppingCartIcon class="w-5 h-5" />
<SearchIcon class="w-5 h-5" />
<UserIcon class="w-5 h-5" />
<MenuIcon class="w-5 h-5" />
```

Available icons: ArrowLeft, ArrowRight, Bell, Check, ChevronDown, ChevronLeft, ChevronRight, ChevronUp, Copy, Cross, Cut, Eye, EyeOff, Image, Images, Home, Globe, Laptop, Link, Mail, Menu, Minus, Moon, MoreHoriz, MoreVert, Palette, Phone, Plus, Redo, RotateCw, Save, ShieldUser, PanelBottom, PanelLeft, PanelRight, PanelTop, Pencil, Clipboard, Reload, Search, Settings, ShoppingCart, Sun, Undo, User, Trash2

### Page Templates

#### Home Page

```tsx
function StoreHomePage({ storeId }) {
  return (
    <StoreLayout>
      <Appbar storeId={storeId} />
      <HeroRoot storeId={storeId} />
      <section class="py-12">
        <h2 class="text-2xl font-bold mb-8">Featured Products</h2>
        <ProductGrid storeId={storeId} />
      </section>
      <section class="py-12 bg-muted">
        <h2 class="text-2xl font-bold mb-8">Categories</h2>
        <CategoryGrid storeId={storeId} />
      </section>
      <Footer />
    </StoreLayout>
  )
}
```

#### Product Detail Page

```tsx
function ProductDetailPage({ productId }) {
  return (
    <StoreLayout>
      <div class="grid grid-cols-2 gap-8 py-8">
        <ProductMediaGallery productId={productId} />
        <div>
          <Product data={product}>
            <ProductName class="text-3xl font-bold" />
            <ProductPrice class="text-2xl text-primary mt-2" />
            <ProductDescription class="mt-4" />
            <ProductQuantityActions class="mt-6" />
            <ProductAddToCartTrigger class="w-full mt-4">
              Add to Cart
            </ProductAddToCartTrigger>
            <ProductToggleWishlistTrigger class="mt-2">
              Add to Wishlist
            </ProductToggleWishlistTrigger>
          </Product>
        </div>
      </div>
    </StoreLayout>
  )
}
```

#### Category Page

```tsx
function CategoryPage({ storeId, categoryId }) {
  return (
    <StoreLayout>
      <div class="py-8">
        <CategoryBreadcrumb categoryId={categoryId} />
        <h1 class="text-3xl font-bold mt-4">
          <CategoryName />
        </h1>
        <ProductGrid storeId={storeId} categoryId={categoryId} />
      </div>
    </StoreLayout>
  )
}
```

---

## Changelog

### 2026-02-22
- Fixed `defer: true` bug in ProductProvider that prevented data initialization
- Removed circular dependency between cart quantity and product quantity syncs
- Removed redundant sync effects in CartProvider, WishlistProvider, OrderProvider
- Cleaned up unused imports (createEffect, on)
