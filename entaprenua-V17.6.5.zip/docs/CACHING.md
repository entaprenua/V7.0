# Caching Strategy

This document describes the caching approach used in the application, particularly for the products admin area.

## Overview

The application uses [TanStack Query](https://tanstack.com/query/latest) for server state management. This document explains the caching patterns used and how to maintain consistency across the application.

## Shared QueryClient

### Problem

Previously, each `Query` component created its own `QueryClient` instance. This meant that calling `invalidateQueries` or `refetchQueries` from one component would not affect queries in other components, since they were managing separate caches.

### Solution

A single `QueryClient` is now created at the application root in `src/app.tsx`:

```tsx
const queryClient = new QueryClient()

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      {/* ... */}
    </QueryClientProvider>
  )
}
```

This ensures all components share the same cache, so cache invalidation in one place affects all queries throughout the app.

## Cache Update Patterns

### After Save Operations

When saving data (e.g., product edits), we use a two-pronged approach for immediate UI consistency:

1. **Admin Panel Store Update** - Updates the local store used by components
2. **Direct Cache Update** - Uses `setQueriesData` to immediately update cached data

```tsx
const handleSave = async () => {
  const result = await save()
  if (result) {
    // 1. Update admin panel store
    admin.updateProduct(initialProduct.id, result)
    
    // 2. Update query cache directly
    const storeId = admin().currentStore?.id
    if (storeId) {
      queryClient.setQueriesData(
        { queryKey: ["products", storeId], exact: false },
        (old) => {
          if (!old) return old
          // Handle both array and paged response formats
          if (Array.isArray(old)) {
            return old.map(p => p.id === result.id ? { ...p, ...result } : p)
          }
          if (old?.content) {
            return { 
              ...old, 
              content: old.content.map(p => p.id === result.id ? { ...p, ...result } : p) 
            }
          }
          return old
        }
      )
    }
  }
}
```

### Query Key Patterns

- **Products list**: `["products", storeId]` - with pagination/sorting/filters appended
- **Single product**: `["product", productId]`

When updating, use `exact: false` to match all variants (different pages, filters, etc.):

```tsx
queryClient.setQueriesData(
  { queryKey: ["products", storeId], exact: false },
  // ...
)
```

## Common Issues & Fixes

### API Response Handling

Some APIs return data directly rather than wrapped in a response object. Always check the actual API response structure:

```tsx
// Wrong - assumes response.data exists
const result = response.data

// Correct - check for direct return
const result = response.id ? response : null
```

### Array Guards

When processing cached data, guard against non-array values:

```tsx
if (Array.isArray(initialMedia)) {
  initialMedia.forEach(...)
}
```

### Preserving Fields

When updating cached data, spread both the existing item and the new data to preserve fields that might not be in the API response:

```tsx
old.map(p => p.id === result.id ? { ...p, ...result } : p)
```

## Files Modified

- `src/app.tsx` - Added shared QueryClientProvider
- `src/routes/admin/products/ProductForm.tsx` - Cache updates after save
- `src/routes/admin/products/product-quick-edit.tsx` - Cache updates after save
- `src/routes/admin/products/product-editor-context.tsx` - API response handling
