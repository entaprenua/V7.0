# Implementation Plan: Multi-Storefront SSR Architecture

---

## Architecture Overview

```
┌─────────────────────────────────────────┐
│           Nginx (Reverse Proxy)           │
│         Handles routing, SSL, caching    │
└──────────────────┬──────────────────────┘
                   │
                   ▼
┌─────────────────────────────────────────┐
│      Spring Boot (Process Manager)       │
│  - Registry (domain → port)            │
│  - Spawn/monitor store processes        │
│  - Health checks                        │
└──────────────────┬──────────────────────┘
                   │
        ┌──────────┼──────────┐
        ▼          ▼          ▼
   Store 1     Store 2    Store 3
  (SolidStart) (SolidStart) (SolidStart)
```

---

## Implementation Phases

### Phase 1: Nginx Configuration

**Purpose**: Route all storefront requests to Spring Boot process manager

| Task | Description |
|------|-------------|
| 1.1 | Configure wildcard subdomain routing (`*.entaprenua.com`) |
| 1.2 | Configure custom domain virtual hosts |
| 1.3 | Set up SSL with Let's Encrypt |
| 1.4 | Proxy all requests to Spring Boot (port 8080) |

### Phase 2: Process Manager Service (Spring Boot)

**Purpose**: Manage lifecycle of storefront processes

| Task | Description |
|------|-------------|
| 2.1 | Create `ProcessManagerService` class |
| 2.2 | Implement `startStore(storeId, storePath)` - spawns Node process |
| 2.3 | Implement `stopStore(storeId)` - kills process |
| 2.4 | Implement `getStoreStatus(storeId)` - check if running |
| 2.5 | Implement port allocation |

### Phase 3: Registry Service (Spring Boot)

**Purpose**: Track domain → port mapping

| Task | Description |
|------|-------------|
| 3.1 | Create `StoreRegistry` class |
| 3.2 | Add `register(domain, storeId, port)` method |
| 3.3 | Add `unregister(domain)` method |
| 3.4 | Add `getPort(domain)` method |
| 3.5 | Add persistence to database |

### Phase 4: HTTP Proxy (Spring Boot)

**Purpose**: Proxy requests to correct storefront process

| Task | Description |
|------|-------------|
| 4.1 | Create `StorefrontProxyHandler` |
| 4.2 | Extract domain from request headers |
| 4.3 | Lookup port from registry |
| 4.4 | Proxy to correct store process |
| 4.5 | Handle errors (store not found, process down) |

### Phase 5: API Endpoints

**Purpose**: Manage storefront processes

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/v1/stores/{id}/start` | Start store process |
| POST | `/api/v1/stores/{id}/stop` | Stop store process |
| GET | `/api/v1/stores/{id}/status` | Check if running |
| POST | `/api/v1/stores/register` | Store registers its port |

### Phase 6: Store Integration

**Purpose**: Each storefront registers on startup

| Task | Description |
|------|-------------|
| 6.1 | Each store reads port from environment |
| 6.2 | Store calls `/api/v1/stores/register` on startup |
| 6.3 | Store calls `/api/v1/stores/unregister` on shutdown |

### Phase 7: Cleanup

**Purpose**: Remove Spring Boot static storefront serving

| Task | Description |
|------|-------------|
| 7.1 | Remove `StorefrontServer.kt` |
| 7.2 | Remove `StorefrontRouterConfig.kt` |
| 7.3 | Remove related static file serving code |
| 7.4 | Update documentation |

---

## File Structure (Spring Boot)

```
src/main/kotlin/com/entaprenua/
├── storefront/
│   ├── StorefrontProxyHandler.kt     # HTTP proxy to store processes
│   ├── ProcessManagerService.kt     # Spawn/monitor processes
│   ├── StoreRegistry.kt             # Domain → port mapping
│   └── PortAllocator.kt            # Port allocation
│
└── routes/
    └── api/
        └── stores/
            ├── StartStoreHandler.kt   # POST /start
            ├── StopStoreHandler.kt    # POST /stop
            ├── StatusHandler.kt       # GET /status
            └── RegisterHandler.kt     # POST /register
```

---

## API Endpoints

### Process Management

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/v1/stores/{storeId}/start` | Start store process |
| POST | `/api/v1/stores/{storeId}/stop` | Stop store process |
| GET | `/api/v1/stores/{storeId}/status` | Get store status |
| GET | `/api/v1/stores/domain/{domain}` | Get store by domain |

### Store Registration

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/v1/stores/register` | Store registers with port |
| DELETE | `/api/v1/stores/{storeId}/unregister` | Store unregisters |

---

## Request Flow

### 1. Store Starts
```
Store Node process starts
    │
    ▼
Reads port from environment (e.g., 3001)
    │
    ▼
POST /api/v1/stores/register { domain, storeId, port: 3001 }
    │
    ▼
Registry stores: domain → port
```

### 2. Request Flow
```
User visits: mystore.entaprenua.com
    │
    ▼
Nginx receives request
    │
    ▼
Nginx proxies to Spring Boot (localhost:8080)
    │
    ▼
Extract domain: "mystore.entaprenua.com"
    │
    ▼
Registry looks up: domain → port 3001
    │
    ▼
Proxy to: localhost:3001
    │
    ▼
Store 1 returns SSR response
```

---

## Configuration

### Store Startup Environment
```bash
# In each store's start script
STORE_PORT=3001
STORE_DOMAIN=mystore.entaprenua.com
STORE_ID=550e8400-e29b-41d4-a716-446655440000
```

### Spring Boot Config
```yaml
# application.yaml
storefront:
  base-port: 3000
  max-stores: 100
  health-check-interval: 30s
  start-timeout: 60s
```

---

## Advantages

| Benefit | Explanation |
|---------|-------------|
| Industry Standard | Java/Spring Boot for infrastructure |
| Scalable | Add more stores by spawning processes |
| Isolated | One store crash doesn't affect others |
| Performant | Nginx handles SSL/caching |
| Stable | Spring Boot process management is mature |

---

## Related Documentation

- `STOREFRONT.md` - Storefront architecture overview
- `DISK_BUILD_SYSTEM.md` - Build system
