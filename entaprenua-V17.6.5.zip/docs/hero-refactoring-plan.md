# Hero Component Refactoring Plan

## Goal
Refactor `components/ui/hero.tsx` to follow the same pattern as Product and Cart components.

## Current State

| File | Lines | Issues |
|------|-------|--------|
| `hero.tsx` | 204 | All-in-one, complex |
| `hero-context.tsx` | Separate | Basic context only |

## Server API (Already Exists)

```
GET /stores/:storeId/heroes              # List heroes
GET /stores/:storeId/heroes/active       # Active heroes  
GET /heroes/:id                          # By ID
```

## Proposed Structure

```
components/ui/hero/
├── hero-root.tsx       # Main component with auto-fetch
├── hero-context.tsx    # Context (enhance existing)
├── hero-sections.tsx   # UI sections
└── index.ts            # Barrel exports
```

## Implementation Details

### 1. hero-root.tsx
- Auto-infer storeId from StoreContext
- Support data from: props → context → URL params
- Use `useParams` for heroId fallback
- Pattern from ProductRoot

### 2. hero-sections.tsx
Split sections like Product does:

| Component | Description |
|-----------|-------------|
| `HeroItem` | Full hero slide wrapper |
| `HeroItems` | List using Collection+CollectionView |
| `HeroItemBackground` | Background image/color/gradient |
| `HeroItemTitle` | Title text |
| `HeroItemSubtitle` | Subtitle text |
| `HeroItemDescription` | Description text |
| `HeroItemCTA` | Primary CTA button |
| `HeroItemCTASecondary` | Secondary CTA button |

### 3. hero-context.tsx
- Auto-detect if inside Collection vs standalone
- Helper functions for CTA URLs

### 4. Use Collection Pattern
- `HeroItems` wraps `Collection` + `CollectionView`
- Each `HeroItem` uses data from Collection context

## Usage Examples

```tsx
// Standalone - fetch by heroId
<HeroRoot heroId="123">
  <HeroItems layout="carousel">
    <HeroItem>
      <HeroItemTitle />
      <HeroItemCTA />
    </HeroItem>
  </HeroItems>
</HeroRoot>

// Standalone - fetch active for store  
<HeroRoot storeId="store-123">
  <HeroItems>
    <HeroItem />
  </HeroItems>
</HeroRoot>

// Inline data
<HeroRoot data={heroData}>
  <HeroItems>...</HeroItems>
</HeroRoot>
```

## Data Flow

```
┌─────────────────────────────────────────────────────────────┐
│                    HeroRoot                                    │
├─────────────────────────────────────────────────────────────┤
│  1. Has props.data? → use it                                │
│  2. Has context (Collection)? → use it                     │
│  3. Has heroId prop? → fetch by ID                          │
│  4. Has storeId prop/context? → fetch active hero            │
│  5. Has URL params? → fetch by ID                            │
└─────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│                    HeroProvider                               │
│  - Stores hero data in context                               │
│  - Provides helpers: getHero(), isActive()                   │
└─────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│                    HeroItems                                  │
│  - Uses Collection + CollectionView                          │
│  - Renders children for each hero item                      │
└─────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│                    HeroItem (sections)                        │
│  - HeroItemBackground                                        │
│  - HeroItemTitle                                            │
│  - HeroItemSubtitle                                         │
│  - HeroItemDescription                                       │
│  - HeroItemCTA                                              │
│  - HeroItemCTASecondary                                     │
└─────────────────────────────────────────────────────────────┘
```

## Migration

### Before (current)
```tsx
<HeroRoot heroId="123" class="my-hero">
  <HeroItems layout="carousel">
    {(item) => (
      <HeroItem item={item}>
        <h1>{item.title}</h1>
        <a href={item.ctaUrl}>{item.ctaText}</a>
      </HeroItem>
    )}
  </HeroItems>
</HeroRoot>
```

### After (new pattern)
```tsx
<HeroRoot heroId="123">
  <HeroItems layout="carousel">
    <HeroItem>
      <HeroItemTitle />
      <HeroItemCTA />
    </HeroItem>
  </HeroItems>
</HeroRoot>
```

Or even simpler for full content:
```tsx
<HeroRoot heroId="123">
  <HeroItems layout="carousel">
    <HeroItem />
  </HeroItems>
</HeroRoot>
```
