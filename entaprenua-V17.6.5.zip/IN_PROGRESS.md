Goal
Build an enterprise-grade admin UI for products and categories with:
- Products: List, create, edit (inline, drawer, full page), media management, metadata
- Categories: List with children counts, create, edit with children management
- Follow modern UX patterns (optimistic updates for stock, auto-refetch for categories)
Instructions
- User wants similar UI pattern for categories as products
- Categories should NOT use tree structure - they're a flat list with children/parents relationship via category_hierarchy table (many-to-many)
- Edit/new pages should manage children directly (not parents)
- Use auto-refetch for categories (not optimistic updates)
- Only stock quantity uses optimistic updates
- Immediate UI updates after add/delete
Discoveries
Category Data Model (Key Finding)
- level = Category Type (1=Primary, 2=Secondary, 3=Tertiary) - NOT hierarchy depth
- Many-to-Many - A category can have MULTIPLE parents via category_hierarchy junction table
- DAG structure (Directed Acyclic Graph), not a tree
- Server API returns flat list; need to call getById?withChildren=true for children
