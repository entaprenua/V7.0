# Entaprenua - Visual E-Commerce Platform

A powerful visual e-commerce platform built with SolidJS, featuring a drag-and-drop page builder, template system, and enterprise-grade backend.

## Features

### Frontend
- **Visual Page Builder**: Drag-and-drop interface for building storefronts
- **80+ UI Components**: Rich component library with e-commerce, layout, form components
- **Template System**: Clone community templates or create your own
- **Admin Dashboard**: Manage products, categories, orders, and media
- **Multi-Store Support**: Handle multiple stores from one account
- **Cookie-Based Auth**: HttpOnly cookies with CSRF protection

### Backend Integration
- **RESTful API**: 40+ endpoints
- **Authentication**: HttpOnly cookie-based JWT with refresh tokens
- **Payments**: Stripe integration
- **Media**: Asset management with variants

## Getting Started

### Prerequisites

- Node.js >= 22
- Backend server running at `http://localhost:8080`

### Installation

```bash
npm install
```

### Development

```bash
npm run dev
```

Open http://localhost:5173 in your browser.

### Building

```bash
npm run build
npm start
```

## Routes

| Route | Description |
|-------|-------------|
| `/` | Home page |
| `/log-in` | Login |
| `/sign-up` | Registration |
| `/stores` | Manage stores |
| `/stores/new` | Create new store |
| `/admin` | Admin dashboard |
| `/admin/products` | Product management |
| `/admin/categories` | Category management |
| `/admin/orders` | Order management |
| `/admin/media` | Media library |
| `/admin/settings` | Store settings |
| `/templates` | Browse templates |
| `/docs` | Documentation |

## Tech Stack

| Technology | Purpose |
|------------|---------|
| SolidJS | UI Framework |
| SolidStart | Meta-framework |
| Tailwind CSS | Styling |
| Kobalte UI | Component Primitives |
| TanStack Query | Data Fetching |
| Lucide | Icons |

## Documentation

- [docs/README.md](./docs/README.md) - Detailed documentation
- [docs/pages/home.md](./docs/pages/home.md) - Home page guide

## Related

- [Server Documentation](../../server/entaprenua/docs/)
- [Cloudflare Setup](../../server/entaprenua/docs/CLOUDFLARE_SETUP.md)
