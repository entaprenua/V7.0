- solid-styled-components -> https://github.com/solidjs/solid-styled-components 
- @ypescript-eslint/parser
- @eslint/js
- eslint-solid-plugin
- tailwind* @tailwind
- @solidjs-primitives/* 
- @tailswindcss/forms
- @kobalte
- @corvu/* 
- @ark/* 
- @tanstack/solid-virtual

- postcss && postcss-js for build cms tailwind-to-css converter utility



