I(AI) am supposed to consume the following as prompts: 

2 Ask user if i should study the backend server for this codebase; if yes,
  i should navigate to ../../server/entaprenua/ study the ./docs/*, and the    codebase.
1. Consume prompts in ./../../robotasks.md and act accordingly
 
