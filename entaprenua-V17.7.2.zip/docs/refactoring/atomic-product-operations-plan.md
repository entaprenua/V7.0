# Product Metadata/Media Atomic Operations Refactoring Plan

## Goal
Refactor Product save operations to use atomic add/remove patterns, matching Category's implementation.

## Status: ✅ COMPLETED (2026-03-21)

---

## Implementation Summary

### Backend Changes

#### 1. ProductDto.kt
- Added `ProductInput` with atomic operation fields
- Added `MetadataInput` (key, value)
- Added `MediaInput` (id?, url)

#### 2. ProductSaveServiceImpl.kt
- Changed from "deleted" marker pattern to atomic operations
- `addMetadata` - list of {key, value} to add
- `removeMetadata` - list of keys to remove
- `addMedia` - list of {id?, url} to add
- `removeMedia` - list of IDs to remove

### Frontend Changes

#### 1. products.ts API
- Added `ProductInput` type with atomic operation fields
- Added `MetadataInput` and `MediaInput` interfaces
- Updated `create` and `update` methods to use `ProductInput`

#### 2. product-editor-context.tsx
- Replaced `buildMetadataMap()` with `buildMetadataOperations()`
- Replaced `buildMediaMap()` with `buildMediaOperations()`
- Now sends `addMetadata`, `removeMetadata`, `addMedia`, `removeMedia`

---

## Files Modified

### Backend (Kotlin)
- `runtime/src/main/kotlin/com/entaprenua/store/dtos/ProductDto.kt` ✅
- `runtime/src/main/kotlin/com/entaprenua/store/impl/ProductSaveServiceImpl.kt` ✅

### Frontend (TypeScript)
- `src/lib/api/products.ts` ✅
- `src/routes/admin/products/product-editor-context.tsx` ✅

---

## Pattern Comparison

### Before (Fragile)
```kotlin
if (value == "deleted") {
    toBeDeletedMetadata.add(name)
}
```

### After (Clean)
```kotlin
for (meta in incoming.addMetadata) {
    metadataToAdd.add(ProductMetadata(...))
}
for (key in incoming.removeMetadata) {
    metadataKeysToRemove.add(key)
}
```

---

## Test Scenarios

1. ✅ Create product with metadata/media
2. ✅ Update product - add new metadata
3. ✅ Update product - remove metadata
4. ✅ Update product - add new media
5. ✅ Update product - remove media
6. ✅ Mixed operations
