import {
  ProductList,
  ProductListView,
  Product,
  ProductImage,
  ProductName,
  ProductPrice,
  ProductComparePrice,
  ProductStockBadge,
  ProductAddToCartTrigger,
  ProductToggleWishlistTrigger,
  ProductPagination,
  ProductPaginationInfo,
  Pagination,
  PaginationItems,
  PaginationItem,
  PaginationEllipsis,
  PaginationPrevious,
  PaginationNext,
} from "~/components/ui/product"
import {
  CartProvider,
  CartIcon,
} from "~/components/ui/cart"
import { Flex } from "~/components/ui/flex"
import { Text } from "~/components/ui/text"
import { Paper } from "~/components/ui/paper"
import { Link } from "~/components/ui/link"

export default function StoreHome() {
  return (
    <CartProvider>
      <div class="min-h-screen bg-background">
        <header class="sticky top-0 z-50 bg-white border-b shadow-sm">
          <Flex class="max-w-7xl mx-auto px-6 py-4 items-center justify-between">
            <Link href="demos/store" class="text-2xl font-bold text-primary">
              TechStore
            </Link>

            <Flex class="items-center gap-4">
              <CartIcon />
            </Flex>
          </Flex>
        </header>

        <div class="bg-primary text-primary-foreground py-16">
          <div class="max-w-7xl mx-auto px-6">
            <Text variant="h1" class="font-bold text-white text-4xl mb-4">
              Premium Tech Products
            </Text>
            <Text variant="body1" class="text-white/80 text-lg max-w-2xl">
              Discover our curated collection of high-quality tech accessories.
            </Text>
          </div>
        </div>

        <div class="max-w-7xl mx-auto px-6 py-12">
          <Text variant="h2" class="font-bold mb-8">All Products</Text>

          <ProductList layout="vertical-grid" columns={4} gap={6} pageSize={12}>
            <ProductListView>
              <Product href={`/demos/store/product`}>
                <Paper class="border rounded-xl overflow-hidden hover:shadow-xl transition-all duration-300 h-full flex flex-col">
                  <div class="relative">
                    <ProductImage class="w-full h-56 object-cover" />
                    <div class="absolute top-3 right-3">
                      <ProductToggleWishlistTrigger class="bg-white/90 hover:bg-white rounded-full p-2 shadow-md" />
                    </div>
                    <div class="absolute top-3 left-3">
                      <ProductStockBadge />
                    </div>
                  </div>
                  <Flex class="flex-1 flex-col p-4 gap-2">
                    <ProductName class="font-semibold text-base line-clamp-2" />
                    <Flex class="items-center gap-2">
                      <ProductPrice class="text-lg font-bold" />
                      <ProductComparePrice class="text-sm" />
                    </Flex>
                    <ProductAddToCartTrigger class="w-full mt-auto pt-2" />
                  </Flex>
                </Paper>
              </Product>
            </ProductListView>
            <Flex class="mt-8 justify-center">
              <ProductPagination
                itemComponent={<PaginationItem class="rounded-full" />}
              >
                <PaginationPrevious > Previous </PaginationPrevious>
                <PaginationItems />
                <PaginationNext> Next </PaginationNext>
              </ProductPagination>
            </Flex>
          </ProductList>
        </div>
      </div>
    </CartProvider>
  )
}
