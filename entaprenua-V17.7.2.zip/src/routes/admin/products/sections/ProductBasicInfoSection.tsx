import { Show, createSignal } from "solid-js"
import { useProductEditor } from "../product-editor-context"
import { TextField, TextFieldInput, TextFieldLabel, TextFieldErrorMessage, TextFieldDescription } from "~/components/ui/text-field"
import { Flex } from "~/components/ui/flex"
import { Text } from "~/components/ui/text"
import { Button } from "~/components/ui/button"
import { Box } from "~/components/ui/box"

function generateSlug(text: string): string {
  return text
    .toLowerCase()
    .trim()
    .replace(/[^\w\s-]/g, "")
    .replace(/\s+/g, "-")
    .replace(/-+/g, "-")
    .slice(0, 100)
}

export function ProductBasicInfoSection() {
  const { formData, updateField, nameExistsWarning, errors } = useProductEditor()
  const [isFocused, setIsFocused] = createSignal(false)

  const handleNameBlur = () => {
    setIsFocused(false)
    if (!formData.slug && formData.name) {
      updateField("slug", generateSlug(formData.name))
    }
  }

  const handleRegenerateSlug = () => {
    if (formData.name) {
      updateField("slug", generateSlug(formData.name))
    }
  }

  const urlPreview = () => {
    const slug = formData.slug || (formData.name ? generateSlug(formData.name) : "your-product")
    return `/products/${slug}`
  }

  return (
    <>
      <TextField>
        <TextFieldLabel>Product Name *</TextFieldLabel>
        <TextFieldInput
          value={formData.name}
          onInput={(e) => updateField("name", e.currentTarget.value)}
          onBlur={handleNameBlur}
          placeholder="Enter product name"
          class={errors.name ? "border-destructive" : undefined}
        />
        <Show when={errors.name}>
          <TextFieldErrorMessage>{errors.name}</TextFieldErrorMessage>
        </Show>
        <Show when={nameExistsWarning()}>
          <Text class="text-sm text-amber-600 mt-1">{nameExistsWarning()}</Text>
        </Show>
      </TextField>

      <Box class="relative">
        <TextField>
          <TextFieldLabel>URL Slug</TextFieldLabel>
          <Flex class="items-center gap-2">
            <TextFieldInput
              value={formData.slug}
              onInput={(e) => updateField("slug", e.currentTarget.value)}
              placeholder="auto-generated-from-name"
              class="flex-1"
            />
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={handleRegenerateSlug}
              disabled={!formData.name}
              title="Generate from name"
            >
              ↻
            </Button>
          </Flex>
          <TextFieldDescription>
            <Flex class="items-center gap-1">
              <Text class="text-muted-foreground">{urlPreview()}</Text>
            </Flex>
          </TextFieldDescription>
        </TextField>
      </Box>

      <TextField>
        <TextFieldLabel>Description</TextFieldLabel>
        <TextFieldInput
          value={formData.description}
          onInput={(e) => updateField("description", e.currentTarget.value)}
          placeholder="Enter product description"
        />
      </TextField>

      <TextField>
        <TextFieldLabel>SKU</TextFieldLabel>
        <TextFieldInput
          value={formData.sku}
          onInput={(e) => updateField("sku", e.currentTarget.value)}
          placeholder="Enter product SKU"
        />
      </TextField>

      <Flex class="flex-col sm:flex-row gap-4">
        <TextField class="flex-1">
          <TextFieldLabel>Price</TextFieldLabel>
          <TextFieldInput
            type="number"
            step="0.01"
            min="0"
            value={formData.price}
            onInput={(e) => updateField("price", e.currentTarget.value)}
            placeholder="0.00"
            class={errors.price ? "border-destructive" : undefined}
          />
          <Show when={errors.price}>
            <TextFieldErrorMessage>{errors.price}</TextFieldErrorMessage>
          </Show>
        </TextField>

        <TextField class="flex-1">
          <TextFieldLabel>Compare at Price</TextFieldLabel>
          <TextFieldInput
            type="number"
            step="0.01"
            min="0"
            value={formData.compareToPrice}
            onInput={(e) => updateField("compareToPrice", e.currentTarget.value)}
            placeholder="0.00"
          />
        </TextField>
      </Flex>
    </>
  )
}
