import type { JSX } from "solid-js"
import type { SearchRootProps } from "@kobalte/core/search"
import { Search } from "@kobalte/core/search"
import { useProductSearch } from "./product-search-context"
import { Product } from "./product-root"
import type { Product as ProductType } from "~/lib/types"

export * from "@kobalte/core/search"

export type ProductSearchProps = {
  placeholder?: string
  class?: string
  itemComponent?: (props: { item: ProductType }) => JSX.Element
  children?: JSX.Element
}

export function ProductSearch(props: ProductSearchProps) {
  const context = useProductSearch()

  return (
    <Search<ProductType>
      options={context.results()}
      onInputChange={context.handleSearch}
      optionValue="id"
      optionLabel="name"
      itemComponent={(itemProps) => (
        <Search.Item item={itemProps.item}>
          <Search.ItemLabel>
            <Product data={itemProps.item.rawValue}>
              {props.itemComponent}
            </Product>
          </Search.ItemLabel>
        </Search.Item>
      )}
    >
      {props.children}
    </Search>
  )
}
