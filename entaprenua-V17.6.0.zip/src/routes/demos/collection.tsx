import {
  Collection,
  CollectionView,
  CollectionItem,
  useCollectionItem,
} from "~/components/ui/collection"
import { Flex } from "~/components/ui/flex"
import { Text } from "~/components/ui/text"
import { Paper } from "~/components/ui/paper"

const MOCK_USERS = [
  { id: 1, name: "John Doe", email: "john@example.com", role: "Admin" },
  { id: 2, name: "Jane Smith", email: "jane@example.com", role: "User" },
  { id: 3, name: "Bob Johnson", email: "bob@example.com", role: "User" },
  { id: 4, name: "Alice Brown", email: "alice@example.com", role: "Editor" },
  { id: 5, name: "Charlie Wilson", email: "charlie@example.com", role: "User" },
  { id: 6, name: "Diana Miller", email: "diana@example.com", role: "Admin" },
]

const mockFetchUsers = async () => {
  await new Promise((resolve) => setTimeout(resolve, 1000))
  return MOCK_USERS
}

function UserCard() {
  const item = useCollectionItem()
  
  return (
    <Paper class="p-4 border rounded-lg hover:shadow-md transition-shadow">
      <Flex class="flex-col gap-2">
        <Text class="font-semibold">{item?.item.name}</Text>
        <Text variant="body2" class="text-muted-foreground">{item?.item.email}</Text>
        <Text variant="caption">{item?.item.role}</Text>
      </Flex>
    </Paper>
  )
}

export default function CollectionDemo() {
  return (
    <div class="min-h-screen bg-background p-8">
      <div class="max-w-7xl mx-auto">
        <Text variant="h1" class="font-bold mb-2">Collection Demo</Text>
        <Text variant="body1" class="text-muted-foreground mb-8">
          Demonstrating Collection and CollectionView components with mock data
        </Text>

        <Text variant="h2" class="font-semibold mb-4">Grid Layout (3 columns)</Text>
        <Collection queryFn={mockFetchUsers} queryKey={["users"]} layout="vertical-grid" columns={3} gap={4}>
          <CollectionView class="mb-12">
            <UserCard />
          </CollectionView>
        </Collection>

        <Text variant="h2" class="font-semibold mb-4">Grid Layout (2 columns)</Text>
        <Collection queryFn={mockFetchUsers} queryKey={["users-2"]} layout="vertical-grid" columns={2} gap={6}>
          <CollectionView>
            <UserCard />
          </CollectionView>
        </Collection>

        <Text variant="h2" class="font-semibold mb-4">Row Layout</Text>
        <Collection queryFn={mockFetchUsers} queryKey={["users-3"]} layout="row" gap={4}>
          <CollectionView>
            <UserCard />
          </CollectionView>
        </Collection>

        <Text variant="h2" class="font-semibold mb-4">Column Layout</Text>
        <Collection queryFn={mockFetchUsers} queryKey={["users-4"]} layout="column" gap={4}>
          <CollectionView>
            <UserCard />
          </CollectionView>
        </Collection>

        <Text variant="h2" class="font-semibold mb-4">Using Function Children</Text>
        <Collection queryFn={mockFetchUsers} queryKey={["users-5"]} layout="vertical-grid" columns={4} gap={4}>
          <CollectionView>
            {(user: any) => (
              <Paper class="p-4 border rounded-lg">
                <Flex class="flex-col gap-1">
                  <Text class="font-bold">{user.name}</Text>
                  <Text variant="caption" class="text-muted-foreground">
                    {user.email}
                  </Text>
                  <Text variant="caption">
                    {user.role}
                  </Text>
                </Flex>
              </Paper>
            )}
          </CollectionView>
        </Collection>
      </div>
    </div>
  )
}
