# Category Components Architecture

## Overview

Atomic, composable category components following the codeless pattern used by Product and Hero components. Users compose UI by nesting components without manual data passing.

## Design Principles

1. **Codeless** - Components auto-read from context, no manual data passing
2. **Composable** - Section primitives that users combine freely
3. **Auto-Nesting** - Nested `CategoryList` automatically infers parent from context
4. **Atomic** - Raw value components, user provides styling

## Core Pattern

```tsx
<CategoryList storeId="123">
  <CategoryListView>
    <Category>
      <CategoryName />
      <CategoryImage />
      
      <CategoryList>
        <CategoryListView>
          <Category>
            <CategoryName />
            
            <CategoryList>
              <CategoryListView>
                <Category>
                  <CategoryName />
                </Category>
              </CategoryListView>
            </CategoryList>
          </Category>
        </CategoryListView>
      </CategoryList>
    </Category>
  </CategoryListView>
</CategoryList>
```

### How Auto-Nesting Works

1. `CategoryList` at top level fetches root categories (no parentId)
2. Each iteration provides `CollectionItemContext` with current category
3. Nested `CategoryList` inside a category iteration auto-detects parent via `useCollectionItem()`
4. Nested `CategoryList` fetches children of that parent category
5. Pattern repeats recursively

## Components

### CategoryList

Fetches categories with automatic nesting support.

```typescript
type CategoryListProps = {
  storeId?: string
  parentId?: string           // Explicit parent (optional)
  page?: number
  pageSize?: number
  queryKey?: unknown[]
  enabled?: boolean
  errorFallback?: JSX.Element
  loadingFallback?: JSX.Element
  layout?: CollectionLayoutMode
  columns?: CollectionColumnCount
  gap?: CollectionGapSize
  children?: JSX.Element
}
```

**Behavior:**
- If `parentId` provided → fetches children of that parent
- If no `parentId` and nested in iteration → auto-infers parentId from CollectionItemContext
- If no `parentId` and top level → fetches root categories

### CategoryListView

Renders list layout.

```typescript
type CategoryListViewProps = {
  class?: string
  children?: JSX.Element
}
```

### Category

Wraps content, auto-reads from `CollectionItemContext`.

```typescript
type CategoryProps = {
  storeId?: string
  categorySlug?: string       // By slug lookup
  data?: CategoryProps       // Explicit data (optional)
  class?: string
  children?: JSX.Element
}
```

### CategoryContext

Provides access to category data for section components.

```typescript
type CategoryContextValue = {
  data: Accessor<CategoryProps | null>
  id: Accessor<string | null>
  name: Accessor<string | null>
  slug: Accessor<string | null>
  image: Accessor<string | null>
  level: Accessor<number | null>
  parentId: Accessor<string | null>
  path: Accessor<string | null>        // LTree path string
  depth: Accessor<number | null>        // Extracted from path
  isRoot: Accessor<boolean>
}

export const useCategory = (): CategoryContextValue => { ... }
```

## Atomic Section Primitives

All components read from `useCategory()`. User composes styling.

```typescript
<CategoryName class?: string />
<CategoryImage class?: string; alt?: string />
<CategorySlug class?: string />
<CategoryLevel class?: string />
<CategoryDepth class?: string />
<CategoryPath class?: string />
<CategoryParentId class?: string />
```

## Usage Examples

### Simple Grid

```tsx
<CategoryList storeId="123" layout="vertical-grid" columns={4}>
  <CategoryListView>
    <Category class="p-4 border rounded-lg">
      <CategoryImage class="w-full h-32 object-cover rounded" />
      <CategoryName class="font-semibold mt-2" />
    </Category>
  </CategoryListView>
</CategoryList>
```

### Codeless Tree

```tsx
<CategoryList storeId="123">
  <CategoryListView>
    <Category class="border-b py-2">
      <CategoryName class="font-medium" />
      
      <CategoryList>
        <CategoryListView>
          <Category class="ml-4 py-1">
            <CategoryName />
            
            <CategoryList>
              <CategoryListView>
                <Category class="ml-4 py-1">
                  <CategoryName />
                </Category>
              </CategoryListView>
            </CategoryList>
          </Category>
        </CategoryListView>
      </CategoryList>
    </Category>
  </CategoryListView>
</CategoryList>
```

### With Link Wrapping

```tsx
<CategoryListView>
  <Category>
    <CategoryImage />
    <CategoryName />
  </Category>
</CategoryListView>
```

## File Structure

```
src/components/ui/category/
├── index.ts                    # Barrel exports
├── category-context.tsx        # Context + useCategory() hook
├── category-root.tsx           # Category component
├── category-list.tsx          # CategoryList + CategoryListView
├── category-sections.tsx       # Atomic primitives
├── STRUCTURE.md               # This file
└── REFACTOR_PLAN.md          # Design decisions
```

## API Alignment

| Endpoint | CategoryList Usage |
|----------|-------------------|
| `GET /stores/:id/categories?root=true` | Root categories (no parentId) |
| `GET /stores/:id/categories/:parentId/subcategories` | Children of parent (with parentId) |
| `GET /stores/:id/categories/by-slug/:slug` | Single category by slug |

## Known Issues

### Nested CategoryList Causes Infinite Loop

**Status:** Open

**Description:**
When `CategoryList` is nested inside another `CategoryList` (for recursive tree rendering), it causes an infinite re-render loop.

**Root Cause:**
`CategoryList` uses `useCollectionItem()` to detect if it's nested in a category iteration and automatically fetch children. However, `useCollectionItem()` reads from `CollectionItemContextInstance` which may not propagate correctly through nested `For` loop iterations in SolidJS.

**Expected Behavior:**
```tsx
<CategoryList storeId="123">
  <CategoryListView>
    <Category>
      <CategoryName />
      <CategoryList>  {/* Should auto-fetch children of parent */}
        <CategoryListView>
          <Category>
            <CategoryName />
          </Category>
        </CategoryListView>
      </CategoryList>
    </Category>
  </CategoryListView>
</CategoryList>
```

**Actual Behavior:**
Nested `CategoryList` causes infinite re-renders.

**Proposed Solutions (not yet implemented):**

1. **ParentCategoryContext + SubcategoryList**
   - Create a dedicated `ParentCategoryContext` that only `Category` sets
   - Create `SubcategoryList` that reads from `ParentCategoryContext`
   - Cleaner separation of concerns

2. **Explicit parentId prop**
   - Remove auto-detection
   - Require explicit `parentId` prop for nested lists
   - Less "codeless" but more predictable

3. **Context Provider Fix**
   - Investigate why `CollectionItemContext` doesn't propagate through nested `For` loops
   - May require changes to how `CollectionView` provides context

---

## Migration Notes

### Old → New

```tsx
// OLD
<Category storeId="123" categoryId="456">
  <CategoryImage />
  <CategoryName />
</Category>

// NEW
<CategoryList storeId="123">
  <CategoryListView>
    <Category>
      <CategoryImage />
      <CategoryName />
    </Category>
  </CategoryListView>
</CategoryList>
```

### Removed Components

The following were removed (too opinionated):
- `CategoryLevelBadge` - user wraps `CategoryLevel` with styling
- `CategoryBreadcrumb` - user composes with `CategoryPath`
- `CategoryTreeView` - use nested `CategoryList` pattern
- `CategoryMenu` - use nested `CategoryList` with custom styling
- `CategorySkeleton` - user builds their own loading states
