import { For, Show, createResource, type JSX } from "solid-js"
import { categoriesApi } from "~/lib/api/categories"
import { useCurrentStoreId } from "~/lib/stores/store-context"
import { Paper } from "~/components/ui/paper"
import { Flex } from "~/components/ui/flex"
import { Text } from "~/components/ui/text"
import { Link } from "~/components/ui/link"

interface NestedCategoryItemProps {
  category: { id: string; name: string; slug?: string | null; level?: number | null; imageUrl?: string | null }
  depth?: number
}

function NestedCategoryItem(props: NestedCategoryItemProps) {
  const storeId = useCurrentStoreId()
  
  const [children] = createResource(
    () => props.category.id,
    async (parentId) => {
      const store = storeId()
      if (!store) return []
      const response = await categoriesApi.getByParent(store, parentId, 0, 50)
      return response.content
    }
  )

  const depth = () => props.depth ?? 0
  const indent = () => depth() * 24

  return (
    <div class="border-b last:border-b-0">
      <Flex 
        class="items-center gap-3 py-3 px-3 hover:bg-muted/50 transition-colors"
        style={{ "padding-left": `${indent() + 12}px` }}
      >
        <div 
          class="bg-muted w-8 h-8 rounded flex items-center justify-center text-xs font-medium"
        >
          {props.category.level ?? 0}
        </div>
        <Show when={props.category.imageUrl}>
          <img 
            src={props.category.imageUrl!} 
            alt={props.category.name}
            class="w-10 h-10 rounded object-cover"
          />
        </Show>
        <div class="flex-1">
          <span class="font-medium">{props.category.name}</span>
          <Text variant="caption" class="text-muted-foreground text-xs">
            {props.category.slug}
          </Text>
        </div>
      </Flex>

      <Show when={children()?.length}>
        <div class="border-l-2 border-muted ml-4">
          <For each={children()}>
            {(child) => (
              <NestedCategoryItem 
                category={child} 
                depth={depth() + 1}
              />
            )}
          </For>
        </div>
      </Show>
    </div>
  )
}

function ExplicitNestedDemo() {
  const storeId = useCurrentStoreId()

  const [rootCategories] = createResource(
    storeId,
    async (store) => {
      if (!store) return []
      const response = await categoriesApi.getRoot(store)
      return response.content
    }
  )

  return (
    <Paper class="p-6 border rounded-xl">
      <Text variant="h3" class="font-semibold mb-2">Explicit Nested Tree (Manual parentId passing)</Text>
      <Text variant="body2" class="text-muted-foreground mb-4">
        Each level explicitly fetches children by passing parentId to the API. No context magic.
      </Text>
      <Show when={rootCategories.loading}>
        <div class="animate-pulse space-y-2">
          <For each={[1, 2, 3]}>{() => <div class="h-12 bg-muted rounded" />}</For>
        </div>
      </Show>
      <Show when={rootCategories.error}>
        <Text variant="body2" class="text-destructive">
          Error: {String(rootCategories.error)}
        </Text>
      </Show>
      <Show when={rootCategories()}>
        <Show when={rootCategories()!.length === 0}>
          <Text variant="body2" class="text-muted-foreground py-8 text-center">
            No root categories found
          </Text>
        </Show>
        <div class="border rounded-lg overflow-hidden">
          <For each={rootCategories()}>
            {(category) => (
              <NestedCategoryItem category={category} depth={0} />
            )}
          </For>
        </div>
      </Show>
    </Paper>
  )
}

function FlatListDemo() {
  const storeId = useCurrentStoreId()

  const [allCategories] = createResource(
    storeId,
    async (store) => {
      if (!store) return []
      const response = await categoriesApi.getAll(store, 0, 100)
      return response.content
    }
  )

  return (
    <Paper class="p-6 border rounded-xl">
      <Text variant="h3" class="font-semibold mb-2">Flat List with Level Indicator</Text>
      <Text variant="body2" class="text-muted-foreground mb-4">
        All categories fetched at once, displayed with level-based indentation
      </Text>
      <Show when={allCategories.loading}>
        <div class="animate-pulse space-y-2">
          <For each={[1, 2, 3, 4, 5]}>{() => <div class="h-12 bg-muted rounded" />}</For>
        </div>
      </Show>
      <Show when={allCategories.error}>
        <Text variant="body2" class="text-destructive">
          Error: {String(allCategories.error)}
        </Text>
      </Show>
      <Show when={allCategories()}>
        <div class="space-y-1">
          <For each={allCategories()}>
            {(category) => (
              <Flex 
                class="items-center gap-3 p-2 hover:bg-muted/50 rounded transition-colors"
                style={{ "padding-left": `${(category.level ?? 0) * 24 + 8}px` }}
              >
                <div class="bg-muted w-6 h-6 rounded flex items-center justify-center text-xs font-medium">
                  {category.level ?? 0}
                </div>
                <Text variant="body2" class="flex-1">{category.name}</Text>
                <Text variant="caption" class="text-muted-foreground">{category.slug}</Text>
              </Flex>
            )}
          </For>
        </div>
      </Show>
    </Paper>
  )
}

export default function CategoryNestedTest() {
  return (
    <div class="min-h-screen bg-background">
      <header class="sticky top-0 z-50 bg-white border-b shadow-sm">
        <Flex class="max-w-7xl mx-auto px-6 py-4 items-center justify-between">
          <Link href="demos/store" class="text-2xl font-bold text-primary">
            TechStore
          </Link>
          <Flex class="items-center gap-4">
            <Link href="demos/store" class="text-sm font-medium">
              Products
            </Link>
            <Link href="demos/store/category" class="text-sm font-medium">
              Categories
            </Link>
            <Link href="demos/store/category-nested-test" class="text-sm font-medium text-primary">
              Nested Test
            </Link>
          </Flex>
        </Flex>
      </header>

      <div class="bg-secondary text-secondary-foreground py-16">
        <div class="max-w-7xl mx-auto px-6">
          <Text variant="h1" class="font-bold text-white text-4xl mb-4">
            Nested Category Test
          </Text>
          <Text variant="body1" class="text-white/80 text-lg max-w-2xl">
            Testing nested category rendering with explicit data passing (no context magic)
          </Text>
        </div>
      </div>

      <div class="max-w-5xl mx-auto px-6 py-12 space-y-8">
        <ExplicitNestedDemo />
        <FlatListDemo />
      </div>

      <div class="max-w-5xl mx-auto px-6 py-12 border-t">
        <Text variant="h3" class="font-semibold mb-4">Test Approach</Text>
        <Paper class="p-6 border rounded-xl">
          <Text variant="body2" class="mb-4">
            This test avoids the "codeless" context propagation that causes infinite loops.
            Instead, each component explicitly receives and passes data.
          </Text>
          <pre class="text-sm text-muted-foreground bg-muted p-4 rounded-lg overflow-x-auto">
{`// Explicit pattern (this test):
<NestedCategoryItem category={category}>
  <For each={children}>
    <NestedCategoryItem category={child} depth={depth + 1} />
  </For>
</NestedCategoryItem>

// Codeless pattern (causes infinite loops):
<CategoryList>
  <CategoryListView>
    <Category>
      <CategoryName />
      <CategoryList>  // Uses useCollectionItem() to auto-detect parent
        ...
      </CategoryList>
    </Category>
  </CategoryListView>
</CategoryList>`}
          </pre>
        </Paper>
      </div>
    </div>
  )
}
