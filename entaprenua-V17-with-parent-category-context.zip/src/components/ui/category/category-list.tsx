import { splitProps, type JSX, For, createMemo } from "solid-js"
import { Collection, CollectionView, type CollectionLayoutMode, type CollectionColumnCount, type CollectionGapSize } from "../collection"
import { useParentCategoryId } from "./category-context"
import { useQueryState } from "../query"
import { categoriesApi } from "~/lib/api/categories"
import { useCurrentStoreId } from "~/lib/stores/store-context"
import type { Category, PagedResponse } from "~/lib/types"

type CategoryListProps = {
  storeId?: string
  page?: number
  pageSize?: number
  queryKey?: unknown[]
  enabled?: boolean
  errorFallback?: JSX.Element
  loadingFallback?: JSX.Element
  layout?: CollectionLayoutMode
  columns?: CollectionColumnCount
  gap?: CollectionGapSize
  children?: JSX.Element
}

const CategoryList = (props: CategoryListProps) => {
  const [local, others] = splitProps(props, [
    "storeId",
    "page",
    "pageSize",
    "queryKey",
    "enabled",
    "errorFallback",
    "loadingFallback",
    "layout",
    "columns",
    "gap",
    "children",
  ])

  const contextStoreId = useCurrentStoreId()

  const resolvedStoreId = createMemo(() => local.storeId ?? contextStoreId())

  const queryFn = async (): Promise<Category[] | null> => {
    const storeId = resolvedStoreId()
    if (!storeId) return null

    const response = await categoriesApi.getRoot(storeId)
    return response.content
  }

  const key = ["categories", "root", resolvedStoreId()]

  return (
    <Collection
      queryFn={queryFn}
      queryKey={local.queryKey ?? key}
      enabled={local.enabled ?? true}
      layout={local.layout}
      columns={local.columns}
      gap={local.gap}
      loadingFallback={local.loadingFallback ?? <DefaultCategoryListLoading />}
      errorFallback={local.errorFallback}
    >
      {local.children}
    </Collection>
  )
}

type SubcategoryListProps = {
  storeId?: string
  page?: number
  pageSize?: number
  queryKey?: unknown[]
  enabled?: boolean
  errorFallback?: JSX.Element
  loadingFallback?: JSX.Element
  layout?: CollectionLayoutMode
  columns?: CollectionColumnCount
  gap?: CollectionGapSize
  children?: JSX.Element
}

const SubcategoryList = (props: SubcategoryListProps) => {
  const [local, others] = splitProps(props, [
    "storeId",
    "page",
    "pageSize",
    "queryKey",
    "enabled",
    "errorFallback",
    "loadingFallback",
    "layout",
    "columns",
    "gap",
    "children",
  ])

  const contextStoreId = useCurrentStoreId()
  const parentCategoryId = useParentCategoryId()

  const resolvedStoreId = createMemo(() => local.storeId ?? contextStoreId())

  const queryFn = async (): Promise<Category[] | null> => {
    const storeId = resolvedStoreId()
    const parentId = parentCategoryId
    if (!storeId || !parentId) return []

    const page = local.page ?? 0
    const size = local.pageSize ?? 20

    const response = await categoriesApi.getByParent(storeId, parentId, page, size)
    return response.content
  }

  const key = parentCategoryId
    ? ["categories", "children", resolvedStoreId(), parentCategoryId]
    : ["categories", "children", "no-parent"]

  return (
    <Collection
      queryFn={queryFn}
      queryKey={local.queryKey ?? key}
      enabled={local.enabled ?? (parentCategoryId !== undefined)}
      layout={local.layout}
      columns={local.columns}
      gap={local.gap}
      loadingFallback={local.loadingFallback ?? <DefaultCategoryListLoading />}
      errorFallback={local.errorFallback}
    >
      {local.children}
    </Collection>
  )
}

const DefaultCategoryListLoading = () => (
  <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
    <For each={[1, 2, 3, 4, 5, 6, 7, 8]}>
      {() => (
        <div class="animate-pulse space-y-3 p-4 border rounded-lg">
          <div class="h-24 bg-muted rounded-md" />
          <div class="h-4 bg-muted rounded w-3/4" />
          <div class="h-3 bg-muted rounded w-1/2" />
        </div>
      )}
    </For>
  </div>
)

type CategoryListViewProps = {
  class?: string
  children?: JSX.Element
}

const CategoryListView = (props: CategoryListViewProps) => {
  return (
    <CollectionView class={props.class}>
      {props.children}
    </CollectionView>
  )
}

const CategoryListEmptyView = (props: { class?: string; children?: JSX.Element }) => {
  return (
    <div class={props.class}>
      {props.children ?? <DefaultCategoryListEmpty />}
    </div>
  )
}

const DefaultCategoryListEmpty = () => (
  <div class="flex flex-col items-center justify-center min-h-[30vh] gap-2">
    <span class="text-muted-foreground text-lg">No categories found</span>
  </div>
)

export { CategoryList, SubcategoryList, CategoryListView, CategoryListEmptyView }
export type { CategoryListProps, CategoryListViewProps, SubcategoryListProps }
