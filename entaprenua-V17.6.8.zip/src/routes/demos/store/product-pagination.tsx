import { createResource } from "solid-js"
import { 
  ProductPaginationProvider,
  ProductPagination,
  ProductPaginationInfo,
  useProductPagination,
  Pagination,
  ProductList,
  ProductListView,
  ProductImage,
  ProductName,
} from "~/components/ui/product"
import { productsApi } from "~/lib/api/products"
import { Text } from "~/components/ui/text"
import { Paper } from "~/components/ui/paper"
import { Flex } from "~/components/ui/flex"

const TEST_STORE_ID = "019c0000-0000-0000-0000-000000000010"

function PaginationDemo() {
  const pagination = useProductPagination()

  const [products] = createResource(
    pagination.page,
    async (page) => {
      const response = await productsApi.getAll(TEST_STORE_ID, page - 1, 12)
      pagination.setPageData(response)
      return response.content
    }
  )

  return (
    <Paper class="p-6 border rounded-xl">
      <Text variant="h3" class="font-semibold mb-4">Product Pagination</Text>
      <Text variant="body2" class="text-muted-foreground mb-4">
        Page {pagination.page()} of {pagination.totalPages()} ({pagination.totalElements()} total products)
      </Text>

      <ProductList data={products()}>
        <ProductListView class="grid grid-cols-3 gap-4 mb-6">
          <Paper class="border rounded-lg p-3">
            <ProductImage class="w-full h-24 object-cover rounded mb-2" />
            <ProductName class="text-sm font-medium" />
          </Paper>
        </ProductListView>
      </ProductList>

      <Flex class="items-center justify-between">
        <ProductPaginationInfo class="text-sm text-muted-foreground" />
        
        <ProductPagination>
          <Pagination.Previous>Previous</Pagination.Previous>
          <Pagination.Items />
          <Pagination.Next>Next</Pagination.Next>
        </ProductPagination>
      </Flex>
    </Paper>
  )
}

export default function ProductPaginationDemo() {
  return (
    <div class="min-h-screen bg-background p-8">
      <div class="max-w-2xl mx-auto">
        <Text variant="h1" class="font-bold text-3xl mb-8">Product Pagination Demo</Text>
        
        <ProductPaginationProvider>
          <PaginationDemo />
        </ProductPaginationProvider>
      </div>
    </div>
  )
}
