import { Show, splitProps, type JSX, createMemo } from "solid-js"
import { A } from "@solidjs/router"
import { CategoryProvider, useCategory, type CategoryProps } from "./category-context"
import { useCollectionItem } from "../collection"
import { cn } from "~/lib/utils"

type CategoryRootProps = {
  storeId?: string
  categorySlug?: string
  data?: CategoryProps | null
  class?: string
  children?: JSX.Element
}

const Category = (props: CategoryRootProps) => {
  const [local, others] = splitProps(props, ["storeId", "categorySlug", "data", "class", "children"])

  const collectionItem = useCollectionItem()

  const resolvedData = createMemo(() => {
    if (local.data !== undefined) return local.data
    if (collectionItem) return collectionItem.item as CategoryProps
    return null
  })

  return (
    <Show
      when={resolvedData()}
      fallback={<div class={local.class}>{local.children}</div>}
    >
      <CategoryProvider data={resolvedData()!}>
        <CategoryWrapper class={local.class}>
          {local.children}
        </CategoryWrapper>
      </CategoryProvider>
    </Show>
  )
}

type CategoryWrapperProps = {
  href?: string
  class?: string
  children?: JSX.Element
}

const CategoryWrapper = (props: CategoryWrapperProps) => {
  const category = useCategory()

  const resolvedHref = createMemo(() => {
    if (props.href) return props.href
    const slug = category.slug()
    if (!slug) return undefined
    return `/${slug}`
  })

  return (
    <Show
      when={resolvedHref()}
      fallback={<div class={props.class}>{props.children}</div>}
    >
      <A href={resolvedHref()!} class={props.class}>
        {props.children}
      </A>
    </Show>
  )
}

export { Category, Category as CategoryRoot, CategoryWrapper }
export type { CategoryRootProps }
