import {
  CategoryList,
  CategoryListView,
  Category,
  CategoryImage,
  CategoryName,
  CategoryLevel,
  CategoryDepth,
  CategorySlug,
} from "~/components/ui/category"
import { Flex } from "~/components/ui/flex"
import { Text } from "~/components/ui/text"
import { Paper } from "~/components/ui/paper"
import { Link } from "~/components/ui/link"
import { Show } from "solid-js"

const DEMO_STORE_ID = "019c0000-0000-0000-0000-000000000010"

function GridDemo() {
  return (
    <Paper class="p-6 border rounded-xl">
      <Text variant="h3" class="font-semibold mb-4">Category Grid</Text>
      <CategoryList storeId={DEMO_STORE_ID} layout="vertical-grid" columns={4} gap={6}>
        <CategoryListView>
          <Category class="block">
            <Paper class="border rounded-xl overflow-hidden hover:shadow-xl transition-all duration-300">
              <CategoryImage class="w-full h-32 object-cover" />
              <Flex class="flex-col p-4 gap-2">
                <CategoryName class="font-semibold text-base" />
                <Flex class="items-center gap-2">
                  <Text variant="caption" class="text-muted-foreground">Level</Text>
                  <CategoryLevel class="bg-muted px-2 py-0.5 rounded text-xs" />
                </Flex>
              </Flex>
            </Paper>
          </Category>
        </CategoryListView>
      </CategoryList>
    </Paper>
  )
}

function NestedTreeDemo() {
  return (
    <Paper class="p-6 border rounded-xl">
      <Text variant="h3" class="font-semibold mb-4">Nested Category Tree</Text>
      <Text variant="body2" class="text-muted-foreground mb-4">
        Codeless recursive rendering - each level fetches its children automatically
      </Text>
      <CategoryList storeId={DEMO_STORE_ID}>
        <CategoryListView>
          <Category class="block border-b last:border-b-0 py-3">
            <Flex class="items-center gap-3">
              <CategoryDepth class="bg-muted w-6 h-6 rounded flex items-center justify-center text-xs font-medium" />
              <CategoryName class="font-medium" />
              <Text variant="caption" class="text-muted-foreground ml-auto">
                <CategorySlug class="text-xs" />
              </Text>
            </Flex>

            <CategoryList>
              <CategoryListView>
                <Category class="block ml-8 mt-2 border-l-2 border-muted pl-4">
                  <Flex class="items-center gap-3">
                    <CategoryDepth class="bg-muted w-5 h-5 rounded flex items-center justify-center text-xs font-medium" />
                    <CategoryName />
                    <Text variant="caption" class="text-muted-foreground ml-auto">
                      <CategorySlug class="text-xs" />
                    </Text>
                  </Flex>

                  <CategoryList>
                    <CategoryListView>
                      <Category class="block ml-8 mt-2 border-l-2 border-muted pl-4">
                        <Flex class="items-center gap-3">
                          <CategoryDepth class="bg-muted w-4 h-4 rounded flex items-center justify-center text-xs font-medium" />
                          <CategoryName />
                        </Flex>
                      </Category>
                    </CategoryListView>
                  </CategoryList>
                </Category>
              </CategoryListView>
            </CategoryList>
          </Category>
        </CategoryListView>
      </CategoryList>
    </Paper>
  )
}

function SimpleListDemo() {
  return (
    <Paper class="p-6 border rounded-xl">
      <Text variant="h3" class="font-semibold mb-4">Simple List</Text>
      <CategoryList storeId={DEMO_STORE_ID}>
        <CategoryListView class="flex flex-col gap-2">
          <Category class="block">
            <Flex class="items-center gap-4 p-3 border rounded-lg hover:bg-muted transition-colors">
              <CategoryImage class="w-12 h-12 rounded object-cover" />
              <CategoryName class="flex-1 font-medium" />
              <CategoryLevel class="text-xs text-muted-foreground" />
            </Flex>
          </Category>
        </CategoryListView>
      </CategoryList>
    </Paper>
  )
}

function HorizontalScrollDemo() {
  return (
    <Paper class="p-6 border rounded-xl">
      <Text variant="h3" class="font-semibold mb-4">Horizontal Scroll</Text>
      <CategoryList storeId={DEMO_STORE_ID} layout="row" gap={4}>
        <CategoryListView class="flex gap-4 overflow-x-auto pb-2">
          <Category class="block shrink-0 w-40">
            <Paper class="border rounded-lg overflow-hidden hover:shadow-md transition-shadow">
              <CategoryImage class="w-full h-24 object-cover" />
              <Text variant="body2" class="p-2 text-center font-medium truncate">
                <CategoryName />
              </Text>
            </Paper>
          </Category>
        </CategoryListView>
      </CategoryList>
    </Paper>
  )
}

export default function CategoryDemo() {
  return (
    <div class="min-h-screen bg-background">
      <header class="sticky top-0 z-50 bg-white border-b shadow-sm">
        <Flex class="max-w-7xl mx-auto px-6 py-4 items-center justify-between">
          <Link href="demos/store" class="text-2xl font-bold text-primary">
            TechStore
          </Link>
          <Flex class="items-center gap-4">
            <Link href="demos/store" class="text-sm font-medium">
              Products
            </Link>
            <Link href="demos/store/category" class="text-sm font-medium text-primary">
              Categories
            </Link>
          </Flex>
        </Flex>
      </header>

      <div class="bg-primary text-primary-foreground py-16">
        <div class="max-w-7xl mx-auto px-6">
          <Text variant="h1" class="font-bold text-white text-4xl mb-4">
            Shop by Category
          </Text>
          <Text variant="body1" class="text-white/80 text-lg max-w-2xl">
            Browse our products organized by category. Built with atomic, codeless components.
          </Text>
        </div>
      </div>

      <div class="max-w-7xl mx-auto px-6 py-12 space-y-8">
        <Text variant="h2" class="font-bold">Category Components Demo</Text>
        <Text variant="body1" class="text-muted-foreground max-w-3xl">
          This demo showcases the new atomic category components with codeless nested rendering.
          Each CategoryList automatically fetches children based on context.
        </Text>

        <GridDemo />
        <SimpleListDemo />
        <HorizontalScrollDemo />
        <NestedTreeDemo />
      </div>

      <div class="max-w-7xl mx-auto px-6 py-12 border-t">
        <Text variant="h3" class="font-semibold mb-4">How It Works</Text>
        <Paper class="p-6 border rounded-xl">
          <pre class="text-sm text-muted-foreground overflow-x-auto">
{`<CategoryList storeId="...">
  <CategoryListView>
    <Category>
      <CategoryName />
      <CategoryImage />
      
      {/* Nested CategoryList auto-fetches children */}
      <CategoryList>
        <CategoryListView>
          <Category>
            <CategoryName />
          </Category>
        </CategoryListView>
      </CategoryList>
    </Category>
  </CategoryListView>
</CategoryList>`}
          </pre>
        </Paper>
      </div>
    </div>
  )
}
