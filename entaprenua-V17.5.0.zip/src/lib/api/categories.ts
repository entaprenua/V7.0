import { api, getCsrfToken } from './client';
import type { Category, PagedResponse } from '../types';

const CATEGORIES_BASE = (storeId: string) => `/stores/${storeId}/categories`;

export interface CategoryFilters {
  search?: string
  level?: number
  parentId?: string
}

const buildFilterParams = (filters?: CategoryFilters): URLSearchParams => {
  const params = new URLSearchParams();
  if (filters?.search) params.append("search", filters.search);
  if (filters?.level) params.append("level", String(filters.level));
  if (filters?.parentId) params.append("parentId", filters.parentId);
  return params;
};

export const categoriesApi = {
  getAll: async (
    storeId: string, 
    page = 0, 
    size = 20,
    filters?: CategoryFilters
  ): Promise<PagedResponse<Category>> => {
    const csrfToken = getCsrfToken();
    const filterParams = buildFilterParams(filters);
    filterParams.set("page", String(page));
    filterParams.set("size", String(size));
    return api.get<PagedResponse<Category>>(`${CATEGORIES_BASE(storeId)}?${filterParams}`, csrfToken || undefined);
  },

  getById: async (storeId: string, id: string): Promise<Category> => {
    const csrfToken = getCsrfToken();
    return api.get<Category>(`${CATEGORIES_BASE(storeId)}/${id}`, csrfToken || undefined);
  },

  getBySlug: async (storeId: string, slug: string): Promise<Category> => {
    const csrfToken = getCsrfToken();
    return api.get<Category>(`${CATEGORIES_BASE(storeId)}/by-slug/${encodeURIComponent(slug)}`, csrfToken || undefined);
  },

  getByParent: async (
    storeId: string, 
    parentId: string, 
    page = 0, 
    size = 20
  ): Promise<PagedResponse<Category>> => {
    const csrfToken = getCsrfToken();
    return api.get<PagedResponse<Category>>(
      `${CATEGORIES_BASE(storeId)}/${parentId}/subcategories?page=${page}&size=${size}`, 
      csrfToken || undefined
    );
  },

  getRoot: async (storeId: string): Promise<PagedResponse<Category>> => {
    const csrfToken = getCsrfToken();
    return api.get<PagedResponse<Category>>(`${CATEGORIES_BASE(storeId)}?root=true`, csrfToken || undefined);
  },

  create: async (storeId: string, data: Partial<Category>): Promise<Category> => {
    const csrfToken = getCsrfToken();
    return api.post<Category>(CATEGORIES_BASE(storeId), data, csrfToken || undefined);
  },

  update: async (storeId: string, id: string, data: Partial<Category>): Promise<Category> => {
    const csrfToken = getCsrfToken();
    return api.put<Category>(`${CATEGORIES_BASE(storeId)}/${id}`, data, csrfToken || undefined);
  },

  delete: async (storeId: string, id: string): Promise<void> => {
    const csrfToken = getCsrfToken();
    return api.delete<void>(`${CATEGORIES_BASE(storeId)}/${id}`, csrfToken || undefined);
  },
};
